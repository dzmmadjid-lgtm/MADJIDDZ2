package com.example.streamhub.ui.components

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.streamhub.data.SampleCatalog
import com.example.streamhub.model.Episode
import com.example.streamhub.model.MediaItem
import com.example.streamhub.model.MediaType
import com.example.streamhub.theme.StreamTheme

@Composable
fun VideoPlayerSheet(
    media: MediaItem,
    isPlaying: Boolean,
    playbackProgress: Float,
    playbackSeconds: Int,
    totalDurationSeconds: Int,
    selectedQuality: String,
    selectedAudio: String,
    selectedSubtitle: String,
    isInWatchlist: Boolean,
    downloadProgress: Float?,
    onTogglePlay: () -> Unit,
    onSeek: (Float) -> Unit,
    onSkipForward: () -> Unit,
    onSkipBackward: () -> Unit,
    onSelectQuality: (String) -> Unit,
    onSelectAudio: (String) -> Unit,
    onSelectSubtitle: (String) -> Unit,
    onToggleWatchlist: () -> Unit,
    onDownload: () -> Unit,
    onClose: () -> Unit,
    onPlayAnotherMedia: ((MediaItem) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val colors = StreamTheme.colors
    val context = LocalContext.current

    // معرف فيديو يوتيوب النشط حالياً (يتغير عند اختيار حلقة أو فيديو ذي صلة)
    var activeVideoId by remember(media.id) { mutableStateOf(media.youtubeVideoId) }
    var activeTitle by remember(media.id) { mutableStateOf(media.title) }

    // حالات التفاعل مثل يوتيوب الأصلي (إعجاب، عدم إعجاب، اشتراك)
    var isLiked by remember(media.id) { mutableStateOf(false) }
    var isDisliked by remember(media.id) { mutableStateOf(false) }
    var isSubscribed by remember(media.id) { mutableStateOf(false) }
    var likesCount by remember(media.id) { mutableIntStateOf(128400) }
    var isDescriptionExpanded by remember { mutableStateOf(false) }
    var showTrackSettings by remember { mutableStateOf(false) }

    fun openInYouTubeApp(videoId: String) {
        try {
            val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId"))
            context.startActivity(appIntent)
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$videoId"))
            context.startActivity(webIntent)
        }
    }

    fun shareVideo(title: String, videoId: String) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(
                Intent.EXTRA_TEXT,
                "شاهد $title بدقة 4K فائقة عبر StreamHub و YouTube:\nhttps://www.youtube.com/watch?v=$videoId"
            )
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "مشاركة فيديو YouTube")
        context.startActivity(shareIntent)
    }

    Surface(
        color = colors.background,
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding() // حماية شاملة من تداخل أزرار الهاتف
            .testTag("video_player_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // ==========================================
            // 1. شاشة مشغل يوتيوب الحقيقي الرسمي المدمج
            // ==========================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color.Black)
            ) {
                // تضمين مشغل يوتيوب الحقيقي باستخدام Android WebView و YouTube IFrame API
                YouTubePlayerView(
                    videoId = activeVideoId,
                    autoplay = true,
                    modifier = Modifier.fillMaxSize()
                )

                // شريط ترويسة علوي خفيف للتحكم السريع
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.65f))
                            .testTag("btn_close_player")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق المشغل",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // شارة يوتيوب الرسمية الحمراء
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black.copy(alpha = 0.65f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFF0000)) // أحمر يوتيوب
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "YouTube Player",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    IconButton(
                        onClick = { openInYouTubeApp(activeVideoId) },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.65f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = "فتح في تطبيق يوتيوب",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // ==========================================
            // 2. معلومات الفيديو وعنوان العمل
            // ==========================================
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    text = activeTitle,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = colors.textPrimary,
                    lineHeight = 24.sp
                )

                if (media.titleAr.isNotBlank() && media.titleAr != activeTitle) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = media.titleAr,
                        fontSize = 13.sp,
                        color = colors.textSecondary
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // عدد المشاهدات وتاريخ النشر
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = media.viewCount,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textSecondary
                    )
                    Text(text = "•", fontSize = 12.sp, color = colors.textMuted)
                    Text(
                        text = "${media.year}",
                        fontSize = 12.sp,
                        color = colors.textSecondary
                    )
                    Text(text = "•", fontSize = 12.sp, color = colors.textMuted)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(colors.primaryAccent.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = media.videoQuality,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.primaryAccent
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // ==========================================
                // 3. شريط القناة الرسمية على YouTube
                // ==========================================
                Surface(
                    color = colors.cardBackground,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (colors.isOled) colors.secondaryAccent.copy(alpha = 0.25f) else colors.cardBorder,
                            RoundedCornerShape(14.dp)
                        )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            // صورة أو شعار القناة
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0xFFFF0000), colors.primaryAccent)
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = media.youtubeChannel.take(1).uppercase(),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = media.youtubeChannel,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "قناة موثقة",
                                        tint = Color(0xFF38BDF8),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Text(
                                    text = media.subscriberCount,
                                    fontSize = 11.sp,
                                    color = colors.textMuted
                                )
                            }
                        }

                        // زر الاشتراك بقناة يوتيوب
                        Button(
                            onClick = {
                                isSubscribed = !isSubscribed
                                Toast.makeText(
                                    context,
                                    if (isSubscribed) "تم الاشتراك في ${media.youtubeChannel}" else "تم إلغاء الاشتراك",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSubscribed) colors.surfaceVariant else Color(0xFFFF0000),
                                contentColor = if (isSubscribed) colors.textPrimary else Color.White
                            ),
                            modifier = Modifier.height(36.dp)
                        ) {
                            if (isSubscribed) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "مشترك", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            } else {
                                Text(text = "اشتراك", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // ==========================================
                // 4. شريط إجراءات يوتيوب (إعجاب، مشاركة، تنزيل، قائمتي)
                // ==========================================
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // زر الإعجاب وعدم الإعجاب المدمج كشريط يوتيوب
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = colors.surfaceVariant,
                            modifier = Modifier.height(38.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clickable {
                                            if (isLiked) {
                                                isLiked = false
                                            } else {
                                                isLiked = true
                                                isDisliked = false
                                            }
                                        }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ThumbUp,
                                        contentDescription = "إعجاب",
                                        tint = if (isLiked) colors.primaryAccent else colors.textSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${if (isLiked) likesCount + 1 else likesCount}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isLiked) colors.primaryAccent else colors.textPrimary
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .height(18.dp)
                                        .width(1.dp)
                                        .background(colors.cardBorder)
                                )

                                Box(
                                    modifier = Modifier
                                        .clickable {
                                            if (isDisliked) {
                                                isDisliked = false
                                            } else {
                                                isDisliked = true
                                                isLiked = false
                                            }
                                        }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ThumbDown,
                                        contentDescription = "عدم إعجاب",
                                        tint = if (isDisliked) Color(0xFFEF4444) else colors.textSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    // زر المشاركة
                    item {
                        ActionChip(
                            icon = Icons.Default.Share,
                            label = "مشاركة",
                            onClick = { shareVideo(activeTitle, activeVideoId) }
                        )
                    }

                    // زر قائمتي / Watchlist
                    item {
                        ActionChip(
                            icon = if (isInWatchlist) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            label = if (isInWatchlist) "بقائمتي" else "قائمتي",
                            isActive = isInWatchlist,
                            onClick = onToggleWatchlist
                        )
                    }

                    // زر التنزيل
                    item {
                        ActionChip(
                            icon = if (downloadProgress == 1.0f) Icons.Default.Check else Icons.Default.Download,
                            label = when {
                                downloadProgress == 1.0f -> "محمّل"
                                downloadProgress != null -> "${(downloadProgress * 100).toInt()}%"
                                else -> "تنزيل"
                            },
                            isActive = downloadProgress != null,
                            onClick = onDownload
                        )
                    }

                    // فتح في تطبيق YouTube الرسمي
                    item {
                        ActionChip(
                            icon = Icons.Default.OpenInNew,
                            label = "تطبيق YouTube",
                            onClick = { openInYouTubeApp(activeVideoId) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // ==========================================
                // 5. مربع وصف الفيديو والقصة
                // ==========================================
                Surface(
                    color = colors.cardBackground,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isDescriptionExpanded = !isDescriptionExpanded }
                        .animateContentSize()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "تفاصيل العمل والقصة",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = if (isDescriptionExpanded) "إخفاء" else "المزيد",
                                fontSize = 11.sp,
                                color = colors.primaryAccent
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = media.description,
                            fontSize = 12.sp,
                            color = colors.textSecondary,
                            lineHeight = 18.sp,
                            maxLines = if (isDescriptionExpanded) Int.MAX_VALUE else 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        if (isDescriptionExpanded) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "المخرج: ${media.director}",
                                fontSize = 11.sp,
                                color = colors.textMuted
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "طاقم التمثيل: ${media.cast.joinToString(", ")}",
                                fontSize = 11.sp,
                                color = colors.textMuted
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "التصنيفات: ${media.genres.joinToString(" • ")}",
                                fontSize = 11.sp,
                                color = colors.primaryAccent
                            )
                        }
                    }
                }

                // ==========================================
                // 6. إذا كان مسلسلاً: قائمة الحلقات وفيديوهات YouTube
                // ==========================================
                if (media.type == MediaType.SERIES && media.episodes.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "حلقات المسلسل (${media.episodes.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    media.episodes.forEach { ep ->
                        val isCurrentEp = (activeVideoId == (ep.youtubeVideoId ?: media.youtubeVideoId) && activeTitle.contains(ep.title))

                        Surface(
                            color = if (isCurrentEp) colors.primaryAccent.copy(alpha = 0.15f) else colors.cardBackground,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(
                                    width = 1.dp,
                                    color = if (isCurrentEp) colors.primaryAccent else colors.cardBorder,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    ep.youtubeVideoId?.let { activeVideoId = it }
                                    activeTitle = "${media.title} - ${ep.title}"
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isCurrentEp) colors.primaryAccent else colors.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = if (isCurrentEp) Color.White else colors.textPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${ep.episodeNumber}. ${ep.title}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isCurrentEp) colors.primaryAccent else colors.textPrimary
                                    )
                                    Text(
                                        text = ep.description,
                                        fontSize = 11.sp,
                                        color = colors.textSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Text(
                                    text = ep.duration,
                                    fontSize = 11.sp,
                                    color = colors.textMuted
                                )
                            }
                        }
                    }
                }

                // ==========================================
                // 7. فيديوهات ذات صلة على YouTube & StreamHub
                // ==========================================
                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "فيديوهات ذات صلة على YouTube",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Text(
                        text = "تشغيل فوري",
                        fontSize = 11.sp,
                        color = colors.secondaryAccent
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                val relatedList = remember(media.id) {
                    SampleCatalog.allMedia.filter { it.id != media.id }
                }

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    relatedList.take(6).forEach { relatedItem ->
                        Surface(
                            color = colors.cardBackground,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, colors.cardBorder, RoundedCornerShape(12.dp))
                                .clickable {
                                    activeVideoId = relatedItem.youtubeVideoId
                                    activeTitle = relatedItem.title
                                    onPlayAnotherMedia?.invoke(relatedItem)
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // صورة مصغرة لفيديو يوتيوب من الرابط الرسمي
                                Box(
                                    modifier = Modifier
                                        .width(110.dp)
                                        .aspectRatio(16f / 9f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.Black)
                                ) {
                                    AsyncImage(
                                        model = relatedItem.youtubeThumbnailUrl,
                                        contentDescription = relatedItem.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(4.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color.Black.copy(alpha = 0.8f))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = relatedItem.durationOrSeasons,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = relatedItem.title,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textPrimary,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${relatedItem.youtubeChannel} • ${relatedItem.viewCount}",
                                        fontSize = 10.sp,
                                        color = colors.textMuted,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = relatedItem.videoQuality,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = colors.primaryAccent
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun ActionChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isActive: Boolean = false,
    onClick: () -> Unit
) {
    val colors = StreamTheme.colors

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isActive) colors.primaryAccent.copy(alpha = 0.15f) else colors.surfaceVariant,
        modifier = Modifier
            .height(38.dp)
            .clickable(onClick = onClick)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) colors.primaryAccent else colors.textPrimary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = if (isActive) colors.primaryAccent else colors.textPrimary
            )
        }
    }
}
