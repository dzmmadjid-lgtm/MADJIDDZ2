package com.example.ui.tools

import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.theme.AccentViolet
import com.example.utils.NetworkScannerHelper
import com.example.utils.PdfEngine
import com.example.utils.ScannerDevice
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiScannerScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var scannerIp by remember { mutableStateOf("192.168.1.50") }
    var scannerPort by remember { mutableStateOf("80") }
    var isProbing by remember { mutableStateOf(false) }
    var detectedDevice by remember { mutableStateOf<ScannerDevice?>(null) }
    var probeError by remember { mutableStateOf<String?>(null) }

    var selectedResolution by remember { mutableIntStateOf(300) }
    var selectedColorMode by remember { mutableStateOf("Color (RGB)") }

    var isScanning by remember { mutableStateOf(false) }
    val scannedBitmaps = remember { mutableStateListOf<Bitmap>() }
    var exportedPdfFile by remember { mutableStateOf<File?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ماسح الشبكة اللاسلكي", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Scanner Connection Config
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Wifi, contentDescription = null, tint = AccentViolet)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("الاتصال بماسح eSCL / AirScan عبر Wi-Fi", fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "يدعم التطبيق بروتوكول eSCL / AirScan القياسي المعتمد في معظم طابعات وماسحات HP وCanon وEpson وBrother الحديثة.",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = scannerIp,
                            onValueChange = { scannerIp = it },
                            label = { Text("عنوان IP الماسح") },
                            placeholder = { Text("192.168.1.x") },
                            singleLine = true,
                            modifier = Modifier.weight(2f)
                        )

                        OutlinedTextField(
                            value = scannerPort,
                            onValueChange = { scannerPort = it },
                            label = { Text("المنفذ") },
                            placeholder = { Text("80") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Button(
                        onClick = {
                            isProbing = true
                            probeError = null
                            coroutineScope.launch {
                                val port = scannerPort.toIntOrNull() ?: 80
                                val result = NetworkScannerHelper.probeEsclScanner(scannerIp.trim(), port)
                                isProbing = false
                                result.onSuccess { dev ->
                                    detectedDevice = dev
                                    selectedResolution = dev.supportedResolutions.firstOrNull { it == 300 } ?: dev.supportedResolutions.firstOrNull() ?: 300
                                    selectedColorMode = dev.supportedColorModes.firstOrNull() ?: "Color (RGB)"
                                    Toast.makeText(context, "تم الاتصال بالماسح: ${dev.name}", Toast.LENGTH_SHORT).show()
                                }.onFailure { err ->
                                    detectedDevice = null
                                    probeError = err.message
                                }
                            }
                        },
                        enabled = !isProbing && scannerIp.isNotBlank(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentViolet),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("probe_wifi_scanner_button")
                    ) {
                        if (isProbing) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري فحص الماسح...")
                        } else {
                            Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("فحص والتحقق من الماسح")
                        }
                    }

                    if (probeError != null) {
                        Text(
                            text = probeError ?: "",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Scanner Capabilities & Scan Trigger
            if (detectedDevice != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("الماسح المتصل: ${detectedDevice!!.name}", fontWeight = FontWeight.Bold, color = AccentViolet)
                        Text("الموديل: ${detectedDevice!!.model}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Text("دقة المسح (DPI):", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            detectedDevice!!.supportedResolutions.take(4).forEach { res ->
                                FilterChip(
                                    selected = selectedResolution == res,
                                    onClick = { selectedResolution = res },
                                    label = { Text("$res DPI") }
                                )
                            }
                        }

                        Text("نمط الألوان:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            detectedDevice!!.supportedColorModes.forEach { mode ->
                                FilterChip(
                                    selected = selectedColorMode == mode,
                                    onClick = { selectedColorMode = mode },
                                    label = { Text(mode) }
                                )
                            }
                        }

                        // Trigger Scan Job
                        Button(
                            onClick = {
                                isScanning = true
                                coroutineScope.launch {
                                    val result = NetworkScannerHelper.triggerScan(
                                        device = detectedDevice!!,
                                        resolutionDpi = selectedResolution,
                                        colorMode = selectedColorMode
                                    )
                                    isScanning = false
                                    result.onSuccess { bitmap ->
                                        scannedBitmaps.add(bitmap)
                                        Toast.makeText(context, "تم استلام الصفحة بنجاح من الماسح!", Toast.LENGTH_SHORT).show()
                                    }.onFailure { err ->
                                        Toast.makeText(context, "فشل المسح: ${err.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = !isScanning,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentViolet),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("start_wifi_scan_button")
                        ) {
                            if (isScanning) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("جاري سحب المستند من الماسح...")
                            } else {
                                Icon(Icons.Default.Scanner, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("بدء مسح صفحة جديدة", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Scanned Pages Gallery & PDF Export
            if (scannedBitmaps.isNotEmpty()) {
                Text("الصفحات المستلمة (${scannedBitmaps.size})", fontWeight = FontWeight.Bold)

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    itemsIndexed(scannedBitmaps) { idx, bm ->
                        Card(
                            modifier = Modifier
                                .size(100.dp, 130.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                Image(
                                    bitmap = bm.asImageBitmap(),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Text(
                                    text = "${idx + 1}",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .background(Color.Black.copy(alpha = 0.6f))
                                        .padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Compile to PDF
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val tempFiles = mutableListOf<File>()
                            val tempUris = mutableListOf<android.net.Uri>()
                            for ((i, bm) in scannedBitmaps.withIndex()) {
                                val file = File(context.cacheDir, "wifi_scan_${i}_${System.currentTimeMillis()}.jpg")
                                FileOutputStream(file).use { fos ->
                                    bm.compress(Bitmap.CompressFormat.JPEG, 90, fos)
                                }
                                tempFiles.add(file)
                                tempUris.add(android.net.Uri.fromFile(file))
                            }

                            val outFile = File(context.cacheDir, "مسح_شبكة_${System.currentTimeMillis() % 10000}.pdf")
                            val success = PdfEngine.convertImagesToPdf(
                                context = context,
                                imageUris = tempUris,
                                outputFile = outFile,
                                pageSize = "A4",
                                isPortrait = true,
                                marginDp = 10
                            )
                            tempFiles.forEach { it.delete() }
                            if (success) {
                                exportedPdfFile = outFile
                                Toast.makeText(context, "تم إنشاء ملف PDF بنجاح!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصدير جميع الصفحات إلى مستند PDF")
                }

                if (exportedPdfFile != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(exportedPdfFile!!.name, fontWeight = FontWeight.SemiBold)
                            Button(onClick = {
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", exportedPdfFile!!)
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "مشاركة PDF"))
                            }) {
                                Text("مشاركة")
                            }
                        }
                    }
                }
            }
        }
    }
}
