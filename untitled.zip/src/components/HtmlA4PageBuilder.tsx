import React, { useEffect, useRef, useState } from 'react';
import {
  BlockMeasuredReport,
  BorderSide,
  PageLayoutObject,
} from '../models/DocumentModel';
import { toWesternDigits } from '../engines/DocumentRenderer';

interface HtmlA4PageBuilderProps {
  objects: PageLayoutObject[];
  keepHandwriting: boolean;
  selectedObjectId: string | null;
  showBoundingBoxes: boolean;
  highlightPoorBlocks: boolean;
  blockReports?: BlockMeasuredReport[];
  onSelectObject: (id: string) => void;
  onUpdateObject?: (updated: PageLayoutObject) => void;
}

function borderSideToCss(side: BorderSide): string {
  if (!side || side.style === 'none' || side.width <= 0) return 'none';
  const widthMm = Math.max(0.2, side.width * 0.28).toFixed(2);
  return `${widthMm}mm ${side.style} ${side.color || '#0F172A'}`;
}

export const HtmlA4PageBuilder: React.FC<HtmlA4PageBuilderProps> = ({
  objects,
  keepHandwriting,
  selectedObjectId,
  showBoundingBoxes,
  highlightPoorBlocks,
  blockReports = [],
  onSelectObject,
  onUpdateObject,
}) => {
  const wrapperRef = useRef<HTMLDivElement | null>(null);
  const pageRef = useRef<HTMLDivElement | null>(null);
  const [scale, setScale] = useState<number>(1);
  const [dragState, setDragState] = useState<{
    id: string;
    startClientX: number;
    startClientY: number;
    origX: number;
    origY: number;
  } | null>(null);

  // 210mm at 96 DPI is ~793.7px
  const A4_WIDTH_PX = 793.7;
  const A4_HEIGHT_PX = 1122.5;

  useEffect(() => {
    const updateScale = () => {
      if (!wrapperRef.current) return;
      const availW = wrapperRef.current.clientWidth;
      if (availW > 40) {
        setScale(availW / A4_WIDTH_PX);
      }
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  const reportById = new Map<string, BlockMeasuredReport>();
  for (const rep of blockReports) {
    reportById.set(rep.objectId, rep);
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!dragState || !onUpdateObject || !pageRef.current) return;
    const rect = pageRef.current.getBoundingClientRect();
    const dxNorm = ((e.clientX - dragState.startClientX) / rect.width) * 1000;
    const dyNorm = ((e.clientY - dragState.startClientY) / rect.height) * 1000;
    const target = objects.find((o) => o.id === dragState.id);
    if (!target) return;

    onUpdateObject({
      ...target,
      x: Math.round(Math.max(0, Math.min(1000 - target.width, dragState.origX + dxNorm))),
      y: Math.round(Math.max(0, Math.min(1000 - target.height, dragState.origY + dyNorm))),
    });
  };

  const handleMouseUp = () => {
    setDragState(null);
  };

  const sorted = [...objects].sort((a, b) => a.zOrder - b.zOrder);

  return (
    <div
      ref={wrapperRef}
      className="w-full overflow-hidden select-text"
      style={{ height: `${Math.round(A4_HEIGHT_PX * scale)}px` }}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Step 5: Absolutely positioned HTML page, exact 210mm x 297mm */}
      <div
        ref={pageRef}
        className="relative bg-white text-slate-900 origin-top-right"
        style={{
          width: '210mm',
          height: '297mm',
          transform: `scale(${scale})`,
          transformOrigin: 'top right',
          boxSizing: 'border-box',
        }}
      >
        {sorted.map((obj) => {
          // Step 4: Hide handwriting unless keepHandwriting toggle is active
          if (obj.type === 'HANDWRITING' && !keepHandwriting) {
            return null;
          }

          const leftMm = ((obj.x / 1000) * 210).toFixed(3);
          const topMm = ((obj.y / 1000) * 297).toFixed(3);
          const widthMm = ((obj.width / 1000) * 210).toFixed(3);
          const heightMm = ((obj.height / 1000) * 297).toFixed(3);

          const isSelected = selectedObjectId === obj.id;
          const blockReport = reportById.get(obj.id);
          const isPoor = Boolean(highlightPoorBlocks && blockReport?.isPoor);

          const commonStyle: React.CSSProperties = {
            position: 'absolute',
            left: `${leftMm}mm`,
            top: `${topMm}mm`,
            width: `${widthMm}mm`,
            height: `${heightMm}mm`,
            zIndex: obj.zOrder,
            direction: obj.direction,
            textAlign: obj.alignment,
            fontFamily: `"${obj.fontProperties.family}", "Cairo", "Amiri", sans-serif`,
            fontSize: `${obj.fontProperties.sizePt}pt`,
            fontWeight: obj.fontProperties.weight,
            fontStyle: obj.fontProperties.style || 'normal',
            lineHeight: obj.fontProperties.lineHeight || 1.35,
            color: obj.fontProperties.color || '#0F172A',
            backgroundColor:
              obj.backgroundProperties.fill &&
              obj.backgroundProperties.fill !== 'transparent' &&
              obj.backgroundProperties.opacity > 0
                ? obj.backgroundProperties.fill
                : 'transparent',
            borderTop: borderSideToCss(obj.borderProperties.top),
            borderRight: borderSideToCss(obj.borderProperties.right),
            borderBottom: borderSideToCss(obj.borderProperties.bottom),
            borderLeft: borderSideToCss(obj.borderProperties.left),
            boxSizing: 'border-box',
            cursor: 'pointer',
            outline: isSelected
              ? '0.5mm solid #DC2626'
              : isPoor
              ? '0.45mm dashed #D97706'
              : showBoundingBoxes
              ? '0.25mm dashed rgba(37, 99, 235, 0.55)'
              : 'none',
          };

          const onMouseDownElement = (e: React.MouseEvent) => {
            e.stopPropagation();
            onSelectObject(obj.id);
            setDragState({
              id: obj.id,
              startClientX: e.clientX,
              startClientY: e.clientY,
              origX: obj.x,
              origY: obj.y,
            });
          };

          // 1. Real Vector DOTTED_LINE or LINE (NEVER typed dot characters)
          if (obj.type === 'DOTTED_LINE' || obj.type === 'LINE') {
            const isDotted =
              obj.type === 'DOTTED_LINE' || obj.borderProperties.top.style === 'dotted';
            const strokeColor =
              obj.borderProperties.top.color && obj.borderProperties.top.color !== 'transparent'
                ? obj.borderProperties.top.color
                : '#0F172A';
            const strokeWidth = Math.max(1.2, (obj.borderProperties.top.width || 1.4) * 1.1);

            return (
              <div
                key={obj.id}
                style={{
                  ...commonStyle,
                  borderTop: 'none',
                  borderRight: 'none',
                  borderBottom: 'none',
                  borderLeft: 'none',
                }}
                onMouseDown={onMouseDownElement}
              >
                <svg className="w-full h-full overflow-visible" preserveAspectRatio="none">
                  <line
                    x1="0"
                    y1="50%"
                    x2="100%"
                    y2="50%"
                    stroke={strokeColor}
                    strokeWidth={strokeWidth}
                    strokeDasharray={isDotted ? '2, 3.5' : undefined}
                    strokeLinecap={isDotted ? 'round' : 'butt'}
                  />
                </svg>
              </div>
            );
          }

          // 2. Real Structured TABLE using exact measured rowHeights & colWidths
          if (obj.type === 'TABLE' && obj.tableStructure) {
            const table = obj.tableStructure;
            const sumR = table.rowHeights.reduce((a, b) => a + b, 0) || 1;
            const normRowH = table.rowHeights.map((rh) => rh / sumR);
            const sumC = table.colWidths.reduce((a, b) => a + b, 0) || 1;
            const normColW = table.colWidths.map((cw) => cw / sumC);

            return (
              <div key={obj.id} style={commonStyle} onMouseDown={onMouseDownElement}>
                <table
                  dir={table.direction}
                  style={{
                    width: '100%',
                    height: '100%',
                    borderCollapse: 'collapse',
                    tableLayout: 'fixed',
                  }}
                >
                  <colgroup>
                    {normColW.map((cw, ci) => (
                      <col key={ci} style={{ width: `${(cw * 100).toFixed(2)}%` }} />
                    ))}
                  </colgroup>
                  <tbody>
                    {Array.from({ length: table.rows }).map((_, rIdx) => {
                      const rowCells = table.cells.filter(
                        (c) => c.row === rIdx && !c.hiddenByMerge
                      );
                      const rowHeightPct = (normRowH[rIdx] ?? 1 / table.rows) * 100;
                      return (
                        <tr
                          key={rIdx}
                          style={{ height: `${rowHeightPct.toFixed(2)}%` }}
                        >
                          {rowCells.map((cell) => (
                            <td
                              key={cell.id}
                              rowSpan={cell.rowSpan || 1}
                              colSpan={cell.colSpan || 1}
                              dir={cell.direction}
                              style={{
                                textAlign: cell.alignment,
                                verticalAlign: cell.verticalAlignment || 'middle',
                                padding: `${Math.max(1, (cell.padding || 4) * 0.22).toFixed(2)}mm`,
                                fontSize: `${cell.fontSizePt || obj.fontProperties.sizePt}pt`,
                                fontWeight: cell.fontWeight || 'normal',
                                backgroundColor:
                                  cell.backgroundColor && cell.backgroundColor !== 'transparent'
                                    ? cell.backgroundColor
                                    : 'transparent',
                                borderTop: borderSideToCss(cell.borders.top),
                                borderRight: borderSideToCss(cell.borders.right),
                                borderBottom: borderSideToCss(cell.borders.bottom),
                                borderLeft: borderSideToCss(cell.borders.left),
                                lineHeight: 1.25,
                                overflow: 'hidden',
                              }}
                            >
                              {toWesternDigits(cell.content)}
                            </td>
                          ))}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {isPoor && blockReport && (
                  <div className="absolute -top-4 left-0 bg-amber-600 text-white text-[8pt] font-mono px-1 rounded">
                    Δ {blockReport.geometryErrorMm.toFixed(2)}mm · IoU {blockReport.iouScore.toFixed(2)}
                  </div>
                )}
              </div>
            );
          }

          // 3. Vector CHECKBOX at measured size
          if (obj.type === 'CHECKBOX') {
            return (
              <div
                key={obj.id}
                style={{
                  ...commonStyle,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1.8mm',
                }}
                onMouseDown={onMouseDownElement}
              >
                <svg
                  style={{ width: '4.2mm', height: '4.2mm', flexShrink: 0 }}
                  viewBox="0 0 20 20"
                >
                  <rect
                    x="1.5"
                    y="1.5"
                    width="17"
                    height="17"
                    fill="none"
                    stroke="#0F172A"
                    strokeWidth="1.8"
                  />
                  {obj.checked && (
                    <path
                      d="M4.5 10.5 L8.5 14.5 L15.5 5.5"
                      fill="none"
                      stroke="#0F172A"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  )}
                </svg>
                <span>{toWesternDigits(obj.content)}</span>
              </div>
            );
          }

          // 4. Vector DRAWING / Stamp / Seal
          if (obj.type === 'IMAGE' || obj.type === 'DRAWING') {
            const stampColor = obj.stampColor || obj.fontProperties.color || '#1D4ED8';
            return (
              <div
                key={obj.id}
                style={{
                  ...commonStyle,
                  borderTop: 'none',
                  borderRight: 'none',
                  borderBottom: 'none',
                  borderLeft: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                onMouseDown={onMouseDownElement}
              >
                {obj.croppedImageDataUrl ? (
                  <img
                    src={obj.croppedImageDataUrl}
                    alt={obj.content || 'drawing'}
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <svg className="w-full h-full overflow-visible" viewBox="0 0 160 110">
                    {obj.svgPathData ? (
                      <path
                        d={obj.svgPathData}
                        fill="none"
                        stroke={stampColor}
                        strokeWidth="2.2"
                      />
                    ) : (
                      <g transform="rotate(-4 80 55)">
                        <ellipse
                          cx="80"
                          cy="55"
                          rx="74"
                          ry="48"
                          fill="none"
                          stroke={stampColor}
                          strokeWidth="2.4"
                        />
                        <ellipse
                          cx="80"
                          cy="55"
                          rx="68"
                          ry="42"
                          fill="none"
                          stroke={stampColor}
                          strokeWidth="1.1"
                          strokeDasharray="4, 2.5"
                        />
                      </g>
                    )}
                  </svg>
                )}
                {obj.content && (
                  <div
                    className="absolute inset-0 flex items-center justify-center text-center font-bold whitespace-pre-line pointer-events-none"
                    style={{
                      color: stampColor,
                      fontSize: `${obj.fontProperties.sizePt}pt`,
                      transform: 'rotate(-4deg)',
                    }}
                  >
                    {toWesternDigits(obj.content)}
                  </div>
                )}
              </div>
            );
          }

          // 5. HANDWRITING or SIGNATURE_AREA
          if (obj.type === 'HANDWRITING' || obj.type === 'SIGNATURE_AREA') {
            return (
              <div
                key={obj.id}
                style={{
                  ...commonStyle,
                  padding: '1.2mm',
                }}
                onMouseDown={onMouseDownElement}
              >
                {obj.type === 'SIGNATURE_AREA' && obj.content && (
                  <div className="whitespace-pre-line">{toWesternDigits(obj.content)}</div>
                )}
                {keepHandwriting && (
                  <>
                    {obj.croppedImageDataUrl ? (
                      <img
                        src={obj.croppedImageDataUrl}
                        alt="handwriting"
                        className="w-full h-full object-contain pointer-events-none"
                      />
                    ) : (
                      <svg
                        className="w-full h-10 overflow-visible mt-1 pointer-events-none"
                        viewBox="0 0 180 50"
                      >
                        <path
                          d="M 20 35 C 45 10, 75 45, 110 20 C 130 8, 95 40, 150 28"
                          fill="none"
                          stroke={obj.stampColor || '#1D4ED8'}
                          strokeWidth="2.2"
                          strokeLinecap="round"
                        />
                      </svg>
                    )}
                  </>
                )}
              </div>
            );
          }

          // 6. Standard TEXT, PARAGRAPH, or framed BOX (RECTANGLE)
          // Replace any residual runs of >= 5 dots with a real vector SVG dotted line
          const rawLines = toWesternDigits(obj.content || '').split('\n');

          return (
            <div
              key={obj.id}
              style={{
                ...commonStyle,
                padding: obj.type === 'RECTANGLE' ? '1.8mm 2.4mm' : '0.4mm 0.8mm',
                display: obj.type === 'RECTANGLE' && rawLines.length <= 2 ? 'flex' : 'block',
                flexDirection: 'column',
                justifyContent: obj.type === 'RECTANGLE' ? 'center' : 'flex-start',
              }}
              onMouseDown={onMouseDownElement}
            >
              {rawLines.map((line, lIdx) => {
                const hasDots = /[.…]{5,}/.test(line);
                if (!hasDots) {
                  return (
                    <div key={lIdx} className="whitespace-pre-wrap">
                      {line}
                    </div>
                  );
                }
                const parts = line.split(/[.…]{5,}/);
                return (
                  <div key={lIdx} className="flex items-baseline gap-1.5 w-full">
                    {parts.map((part, pIdx) => (
                      <React.Fragment key={pIdx}>
                        {part && <span className="shrink-0">{part}</span>}
                        {pIdx < parts.length - 1 && (
                          <span
                            className="flex-1 min-w-[14mm] inline-block"
                            style={{
                              borderBottom: '0.38mm dotted #334155',
                              height: '0.9em',
                            }}
                          />
                        )}
                      </React.Fragment>
                    ))}
                  </div>
                );
              })}

              {isPoor && blockReport && (
                <div className="absolute -top-4 left-0 bg-amber-600 text-white text-[7.5pt] font-mono px-1 rounded shadow">
                  ضعيف: Δ {blockReport.geometryErrorMm.toFixed(2)}mm · IoU{' '}
                  {blockReport.iouScore.toFixed(2)}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
