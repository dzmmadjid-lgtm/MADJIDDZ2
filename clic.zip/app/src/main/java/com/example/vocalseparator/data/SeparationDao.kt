package com.example.vocalseparator.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SeparationDao {

    @Query("SELECT * FROM separations ORDER BY createdAtTimestamp DESC")
    fun getAllSeparations(): Flow<List<SeparationRecord>>

    @Query("SELECT * FROM separations WHERE id = :id LIMIT 1")
    suspend fun getSeparationById(id: Long): SeparationRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSeparation(record: SeparationRecord): Long

    @Delete
    suspend fun deleteSeparation(record: SeparationRecord)

    @Query("DELETE FROM separations WHERE id = :id")
    suspend fun deleteById(id: Long)
}
