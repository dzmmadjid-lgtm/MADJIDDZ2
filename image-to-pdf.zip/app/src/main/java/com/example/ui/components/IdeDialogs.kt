package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SearchResult
import com.example.data.model.ThemeMode
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, pkg: String, minSdk: Int, targetSdk: Int, template: String) -> Unit
) {
    var projectName by remember { mutableStateOf("MyApplication") }
    var packageName by remember { mutableStateOf("com.example.myapplication") }
    var minSdk by remember { mutableIntStateOf(24) }
    var targetSdk by remember { mutableIntStateOf(36) }
    var template by remember { mutableStateOf("Compose Empty Activity") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Android Project", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = projectName,
                    onValueChange = {
                        projectName = it
                        packageName = "com.example.${it.lowercase().replace(Regex("[^a-z0-9]"), "")}"
                    },
                    label = { Text("Project Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_project_name_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = packageName,
                    onValueChange = { packageName = it },
                    label = { Text("Package Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_project_pkg_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = "$minSdk",
                        onValueChange = { minSdk = it.toIntOrNull() ?: 24 },
                        label = { Text("Min SDK") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = "$targetSdk",
                        onValueChange = { targetSdk = it.toIntOrNull() ?: 36 },
                        label = { Text("Target SDK") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text("Template:", style = MaterialTheme.typography.labelSmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = template == "Compose Empty Activity",
                        onClick = { template = "Compose Empty Activity" }
                    )
                    Text("Jetpack Compose Activity", fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = template == "Standard Android Views",
                        onClick = { template = "Standard Android Views" }
                    )
                    Text("XML Layout + Activity", fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (projectName.isNotBlank() && packageName.isNotBlank()) {
                        onCreate(projectName.trim(), packageName.trim(), minSdk, targetSdk, template)
                    }
                },
                modifier = Modifier.testTag("confirm_create_project_btn")
            ) {
                Text("Create Project")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun NewFileDialog(
    targetDir: File,
    onDismiss: () -> Unit,
    onCreateFile: (String, String) -> Unit,
    onCreateFolder: (String) -> Unit
) {
    var isFolder by remember { mutableStateOf(false) }
    var fileName by remember { mutableStateOf("") }
    var presetType by remember { mutableStateOf("kt") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (isFolder) "New Directory" else "New File in ${targetDir.name}")
        },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = !isFolder,
                        onClick = { isFolder = false }
                    )
                    Text("File", fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(16.dp))
                    RadioButton(
                        selected = isFolder,
                        onClick = { isFolder = true }
                    )
                    Text("Directory", fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = fileName,
                    onValueChange = { fileName = it },
                    label = { Text(if (isFolder) "Directory Name" else "File Name (e.g. MyScreen.kt)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_file_name_input")
                )

                if (!isFolder) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Quick Presets:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SuggestionChip(
                            onClick = {
                                if (!fileName.endsWith(".kt")) fileName = "${fileName.removeSuffix(".kt")}.kt"
                                presetType = "kt"
                            },
                            label = { Text("Kotlin (.kt)", fontSize = 10.sp) }
                        )
                        SuggestionChip(
                            onClick = {
                                if (!fileName.endsWith(".xml")) fileName = "${fileName.removeSuffix(".xml")}.xml"
                                presetType = "xml"
                            },
                            label = { Text("XML (.xml)", fontSize = 10.sp) }
                        )
                        SuggestionChip(
                            onClick = {
                                if (!fileName.endsWith(".gradle.kts")) fileName = "${fileName.removeSuffix(".gradle.kts")}.gradle.kts"
                                presetType = "kts"
                            },
                            label = { Text("Gradle KTS", fontSize = 10.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fileName.isNotBlank()) {
                        if (isFolder) {
                            onCreateFolder(fileName.trim())
                        } else {
                            val initialContent = when {
                                fileName.endsWith(".kt") -> "// Kotlin source\n"
                                fileName.endsWith(".xml") -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n</resources>\n"
                                fileName.endsWith(".json") -> "{\n}\n"
                                else -> ""
                            }
                            onCreateFile(fileName.trim(), initialContent)
                        }
                    }
                },
                modifier = Modifier.testTag("confirm_create_file_btn")
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun RenameDialog(
    currentName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var newName by remember { mutableStateOf(currentName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename") },
        text = {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                label = { Text("New Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newName.isNotBlank() && newName != currentName) {
                        onConfirm(newName.trim())
                    }
                }
            ) {
                Text("Rename")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun SearchInProjectDialog(
    searchResults: List<SearchResult>,
    isSearching: Boolean,
    onSearch: (String) -> Unit,
    onSelectResult: (SearchResult) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Search in Project Files", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth().height(350.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        onSearch(it)
                    },
                    placeholder = { Text("Search text, symbols, classes...") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (isSearching) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                Text(
                    text = "${searchResults.size} results found",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    items(searchResults) { result ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectResult(result) }
                                .padding(vertical = 6.dp)
                        ) {
                            Text(
                                text = "${result.relativePath} : line ${result.lineNumber}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = result.lineContent.trim(),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            HorizontalDivider(modifier = Modifier.padding(top = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun SettingsDialog(
    currentTheme: ThemeMode,
    isCloudBuild: Boolean,
    cloudBuildUrl: String,
    projectRootDir: File? = null,
    onThemeChange: (ThemeMode) -> Unit,
    onCloudBuildToggle: (Boolean) -> Unit,
    onCloudBuildUrlChange: (String) -> Unit,
    onDownloadJdkClick: () -> Unit = {},
    onDismiss: () -> Unit
) {
    var urlInput by remember { mutableStateOf(cloudBuildUrl) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val envReport = remember(projectRootDir) {
        com.example.core.build.BuildEnvironmentDetector.detect(context, projectRootDir)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("IDE Settings & Build Environment", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                item {
                    Text("Appearance Theme:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = currentTheme == ThemeMode.DARK,
                            onClick = { onThemeChange(ThemeMode.DARK) }
                        )
                        Text("Dark Theme (Studio Default)")
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = currentTheme == ThemeMode.OLED,
                            onClick = { onThemeChange(ThemeMode.OLED) }
                        )
                        Text("OLED Pure Black (#000000)")
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = currentTheme == ThemeMode.LIGHT,
                            onClick = { onThemeChange(ThemeMode.LIGHT) }
                        )
                        Text("Light Theme")
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    Text("Device Environment Diagnostics:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                "OS: Android ${envReport.osRelease} (API ${envReport.sdkInt})",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "ABI: ${envReport.supportedAbis.firstOrNull() ?: "generic"}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (envReport.termuxStatus.isReadyForJava) "● JDK: Ready via Termux (${envReport.javaStatus.javaVersion})" else if (envReport.termuxStatus.isInstalled) "● JDK: Termux Installed (OpenJDK Pending)" else "● JDK: Termux Not Installed",
                                    color = if (envReport.termuxStatus.isReadyForJava) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (!envReport.termuxStatus.isReadyForJava) {
                                Text(
                                    "DroidIDE relies on the official Termux app to execute OpenJDK 17 and Gradle via RUN_COMMAND.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            FilledTonalButton(
                                onClick = onDownloadJdkClick,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier
                                    .padding(vertical = 4.dp)
                                    .height(32.dp)
                                    .testTag("settings_download_jdk_btn")
                            ) {
                                Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (envReport.termuxStatus.isReadyForJava) "إدارة بيئة Termux و JDK" else "إعداد بيئة Termux و JDK 17", fontSize = 11.sp)
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (envReport.sdkStatus.isAvailable) "● Android SDK: Found" else "● Android SDK: Not Found",
                                    color = if (envReport.sdkStatus.isAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (envReport.sdkStatus.isAvailable) {
                                Text(
                                    "Path: ${envReport.sdkStatus.sdkPath} (${envReport.sdkStatus.platforms.size} platforms, ${envReport.sdkStatus.buildTools.size} build-tools)",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Text(
                                    "Place Android SDK in files/android-sdk or configure ANDROID_HOME.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (envReport.wrapperStatus.hasGradlew) "● Wrapper: 'gradlew' Found" else "● Wrapper: 'gradlew' Missing",
                                color = if (envReport.wrapperStatus.hasGradlew) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    Text("Build Engine Selection:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = !isCloudBuild,
                            onClick = { onCloudBuildToggle(false) }
                        )
                        Column {
                            Text("Local Process Runner")
                            Text(
                                "Executes ./gradlew via /system/bin/sh in project directory",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = isCloudBuild,
                            onClick = { onCloudBuildToggle(true) }
                        )
                        Column {
                            Text("Remote Cloud Build Runner (Recommended)")
                            Text(
                                "Builds on remote server with full JDK/SDK and returns real APK",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (isCloudBuild) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = {
                                urlInput = it
                                onCloudBuildUrlChange(it)
                            },
                            label = { Text("Cloud Build API Endpoint URL") },
                            placeholder = { Text("https://builder.yourserver.com/api/build") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}

@Composable
fun DeleteProjectTreeDialog(
    projectName: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.DeleteForever,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text("Delete Entire Project Tree?", fontWeight = FontWeight.Bold)
        },
        text = {
            Text(
                "Are you sure you want to completely delete '$projectName' and all its directories and files? This operation cannot be undone."
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                ),
                modifier = Modifier.testTag("confirm_delete_project_btn")
            ) {
                Text("Delete Project")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_delete_project_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun TermuxEnvironmentDialog(
    termuxStatus: com.example.core.termux.TermuxStatus,
    isInstallingJdk: Boolean = false,
    verificationOutput: String? = null,
    onInstallJdkClick: () -> Unit = {},
    onVerifyJavaClick: () -> Unit = {},
    onCheckStatusClick: () -> Unit = {},
    onOpenFdroidClick: () -> Unit = {},
    onOpenTermuxAppClick: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Terminal,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )
        },
        title = {
            Text(
                text = "بيئة تشغيل Termux و OpenJDK 17",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
            ) {
                Text(
                    text = "يعتمد التطبيق على بيئة Termux الرسمية لتنفيذ أوامر Java و Gradle عبر آلية RUN_COMMAND، لضمان استقرار كامل وتوافق مع معمارية Bionic libc في أندرويد.",
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Card 1: Termux App Installation Check
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (termuxStatus.isInstalled) {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                        } else {
                            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f)
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (termuxStatus.isInstalled) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                contentDescription = null,
                                tint = if (termuxStatus.isInstalled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (termuxStatus.isInstalled) "1. تطبيق Termux: مثبت على الجهاز ✓" else "1. تطبيق Termux: غير مثبت ✕",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        if (!termuxStatus.isInstalled) {
                            Text(
                                text = "لتشغيل الجافا يجب تثبيت Termux. اضغط بالأسفل للذهاب مباشرة لصفحة التحميل من F-Droid الرسمية:",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = onOpenFdroidClick,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("open_fdroid_termux_btn")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تثبيت Termux من F-Droid (الرسمي)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        } else {
                            Text(
                                text = "حزمة com.termux موجودة ونشطة على جهازك.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = onOpenTermuxAppClick,
                                modifier = Modifier.fillMaxWidth().height(36.dp)
                            ) {
                                Icon(Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("فتح تطبيق Termux على الهاتف", fontSize = 11.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Card 2: RUN_COMMAND Permission Check
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (termuxStatus.hasRunCommandPermission) {
                            MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (termuxStatus.hasRunCommandPermission) Icons.Default.CheckCircle else Icons.Default.Info,
                                contentDescription = null,
                                tint = if (termuxStatus.hasRunCommandPermission) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (termuxStatus.hasRunCommandPermission) "2. صلاحية RUN_COMMAND: مفعلة ✓" else "2. صلاحية RUN_COMMAND: تنبيه إعدادات",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "للسماح لـ DroidIDE بتنفيذ الأوامر، تأكد من تفعيل الصلاحية ومشاركة التطبيقات في Termux:",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))

                        val setupCmd = "echo \"allow-external-apps=true\" >> ~/.termux/termux.properties"
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = setupCmd,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(setupCmd))
                                        Toast.makeText(context, "تم نسخ الأمر! الصقه في Termux", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Card 3: OpenJDK 17 Installation in Termux
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (termuxStatus.isJdkInstalled) {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (termuxStatus.isJdkInstalled) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (termuxStatus.isJdkInstalled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (termuxStatus.isJdkInstalled) "3. حزمة OpenJDK 17: جاهزة ونشطة ✓" else "3. حزمة OpenJDK 17: غير مثبتة بعد ⚠",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        if (isInstallingJdk) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(6.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "جاري إرسال وتنفيذ: pkg update -y && pkg install openjdk-17 -y ...",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        } else if (!termuxStatus.isJdkInstalled) {
                            Text(
                                "يمكن للتطبيق إرسال أمر التثبيت التلقائي إلى Termux مباشرة:",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = onInstallJdkClick,
                                enabled = termuxStatus.isInstalled,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("install_termux_jdk_btn")
                            ) {
                                Icon(Icons.Default.DownloadForOffline, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تثبيت OpenJDK 17 داخل Termux الآن", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        } else {
                            Text(
                                "بيئة Java 17 مثبّتة وجاهزة لتجميع وتشغيل المشروعات.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Card 4: Verify java -version Command
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("4. التحقق من أمر java -version:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            OutlinedButton(
                                onClick = onVerifyJavaClick,
                                enabled = termuxStatus.isInstalled,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp).testTag("verify_java_btn")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("فحص الآن", fontSize = 11.sp)
                            }
                        }

                        if (!verificationOutput.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = verificationOutput,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        } else if (termuxStatus.javaVersionOutput.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = termuxStatus.javaVersionOutput,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onCheckStatusClick,
                    modifier = Modifier.testTag("refresh_termux_status_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إعادة فحص", fontSize = 12.sp)
                }
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("dismiss_termux_dialog_btn")
                ) {
                    Text("إغلاق", fontSize = 12.sp)
                }
            }
        }
    )
}

@Composable
fun JdkDownloadDialog(
    isDownloading: Boolean,
    progress: Int,
    statusText: String,
    onDownloadOfficial: () -> Unit,
    onImportArchive: (Uri) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val termuxStatus by com.example.core.termux.TermuxManager.status.collectAsState()
    val scope = rememberCoroutineScope()
    var isInstalling by remember { mutableStateOf(false) }
    var verifyText by remember { mutableStateOf<String?>(null) }

    TermuxEnvironmentDialog(
        termuxStatus = termuxStatus,
        isInstallingJdk = isInstalling || isDownloading,
        verificationOutput = verifyText,
        onInstallJdkClick = {
            isInstalling = true
            scope.launch {
                com.example.core.termux.TermuxManager.installJdkInTermux(context)
                isInstalling = false
            }
        },
        onVerifyJavaClick = {
            scope.launch {
                val res = com.example.core.termux.TermuxManager.verifyJavaInstalled(context)
                verifyText = res.second
            }
        },
        onCheckStatusClick = {
            scope.launch {
                com.example.core.termux.TermuxManager.checkStatus(context)
            }
        },
        onOpenFdroidClick = {
            com.example.core.termux.TermuxManager.openFdroidTermuxPage(context)
        },
        onOpenTermuxAppClick = {
            com.example.core.termux.TermuxManager.openTermuxApp(context)
        },
        onDismiss = onDismiss
    )
}

