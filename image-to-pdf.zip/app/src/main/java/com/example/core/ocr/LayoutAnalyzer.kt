package com.example.core.ocr

import com.example.data.model.DetectedLanguage
import com.example.data.model.RectNormalized
import com.example.data.model.RegionType
import com.example.data.model.TextLineItem
import com.example.data.model.TextRegion
import kotlin.math.abs

object LayoutAnalyzer {

    private val LIST_ITEM_PREFIX = Regex("^([•*\\-\\+]|[0-9]{1,2}[\\.\\-\\)]|[أ-ي]\\s*[\\.\\-\\)])\\s+")

    fun classifyAndOrderRegions(
        rawRegions: List<TextRegion>,
        primaryLanguage: DetectedLanguage
    ): List<TextRegion> {
        if (rawRegions.isEmpty()) return emptyList()

        // 1. Classify each region based on position, line count, font size, content
        val classified = rawRegions.map { region ->
            classifyRegion(region, rawRegions)
        }

        // 2. Sort by natural reading order
        return sortReadingOrder(classified, primaryLanguage)
    }

    private fun classifyRegion(region: TextRegion, allRegions: List<TextRegion>): TextRegion {
        if (region.isGraphic) {
            return region.copy(type = RegionType.GRAPHIC_OR_PHOTO)
        }

        val text = region.text.trim()
        val lineCount = region.lines.size.coerceAtLeast(1)
        val box = region.boundingBox

        // Average height per line
        val avgLineHeight = box.height / lineCount

        // 1. List item detection (bullet points or numbered list lines)
        if (LIST_ITEM_PREFIX.containsMatchIn(text) || region.lines.any { LIST_ITEM_PREFIX.containsMatchIn(it.text.trim()) }) {
            return region.copy(type = RegionType.LIST_ITEM)
        }

        // 2. Number / Code / Phone / Date
        val isPureNumeric = region.language == DetectedLanguage.NUMERIC ||
                (text.matches(Regex("^[0-9\\u0660-\\u0669\\s\\-\\+\\.,:/%€$£#A-Za-z]{2,}$")) && text.any { it.isDigit() })
        if (isPureNumeric && text.length < 35) {
            return region.copy(type = RegionType.NUMBER)
        }

        // 3. Title detection: top area or isolated prominent text with high line height, short line count
        val isTopArea = box.top < 0.25f
        val isShort = text.length < 90 && lineCount <= 2
        val isProminentHeight = avgLineHeight > 0.045f

        if ((isTopArea && isShort) || (isProminentHeight && isShort && !text.contains("."))) {
            return region.copy(type = RegionType.TITLE)
        }

        // 4. Table cell detection: check if there are other regions aligned horizontally on roughly the same Y band
        val alignedHorizontally = allRegions.count { other ->
            other.id != region.id && abs(other.boundingBox.top - box.top) < 0.015f
        }
        if (alignedHorizontally >= 2 && text.length < 50) {
            return region.copy(type = RegionType.TABLE_CELL)
        }

        // 5. Paragraph vs Short Text
        if (lineCount >= 2 || text.length > 80) {
            return region.copy(type = RegionType.PARAGRAPH)
        }

        return region.copy(type = RegionType.SHORT_TEXT)
    }

    /**
     * Orders elements by vertical bands (reading order).
     * Inside a band:
     * - Arabic: Right-to-Left (larger left coordinate / right edge comes first)
     * - English / French / LTR: Left-to-Right (smaller left coordinate comes first)
     */
    private fun sortReadingOrder(
        regions: List<TextRegion>,
        primaryLanguage: DetectedLanguage
    ): List<TextRegion> {
        val yThreshold = 0.02f // Vertical band tolerance (approx 2% of page height)

        val sorted = regions.toMutableList()

        // Stable sort with comparator
        sorted.sortWith { a, b ->
            val topDiff = a.boundingBox.top - b.boundingBox.top
            if (abs(topDiff) > yThreshold) {
                // Distinct vertical lines: sort top to bottom
                topDiff.compareTo(0f)
            } else {
                // Same line / band
                val isRtl = a.language == DetectedLanguage.ARABIC ||
                        (a.language == DetectedLanguage.MIXED && primaryLanguage == DetectedLanguage.ARABIC)

                if (isRtl) {
                    // Right to left (descending X)
                    b.boundingBox.left.compareTo(a.boundingBox.left)
                } else {
                    // Left to right (ascending X)
                    a.boundingBox.left.compareTo(b.boundingBox.left)
                }
            }
        }

        return sorted
    }
}
