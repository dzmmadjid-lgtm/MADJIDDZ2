package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.core.ai.AiChatMessage
import com.example.core.ai.AiFixProposal
import com.example.core.git.GitStatus
import com.example.core.terminal.TerminalLine
import com.example.data.model.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BottomToolWindows(
    modifier: Modifier = Modifier,
    activeWindow: BottomToolWindow,
    isExpanded: Boolean,
    isMaximized: Boolean = false,
    onToggleMaximize: () -> Unit = {},
    onTabSelected: (BottomToolWindow) -> Unit,
    onToggleExpanded: () -> Unit,
    // Build Output params
    buildResult: BuildResult?,
    buildLogs: List<BuildLogEntry>,
    buildStatus: BuildStatus,
    onClearLogs: () -> Unit,
    // Problems params
    problems: List<ProblemItem>,
    onJumpToProblem: (File?, Int) -> Unit,
    // Terminal params
    terminalLines: List<TerminalLine>,
    isTerminalRunning: Boolean,
    onExecuteCommand: (String) -> Unit,
    onStopTerminal: () -> Unit,
    onClearTerminal: () -> Unit,
    // JDK params
    isDownloadingJdk: Boolean = false,
    jdkDownloadProgress: Int = 0,
    jdkDownloadStatus: String = "",
    onDownloadJdkClick: () -> Unit = {},
    // Git params
    gitStatus: GitStatus?,
    onCommit: (String) -> Unit,
    onCloneRepo: (String) -> Unit,
    // AI Agent params
    aiMessages: List<AiChatMessage>,
    isAiBusy: Boolean,
    onSendAiPrompt: (String) -> Unit,
    onApplyAiFix: (AiFixProposal) -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface)
    ) {
        // Tab Header Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ToolTabButton(
                    title = "Build Output",
                    icon = Icons.Default.Build,
                    isSelected = activeWindow == BottomToolWindow.BUILD_OUTPUT,
                    badgeCount = if (buildStatus == BuildStatus.RUNNING) -1 else 0,
                    onClick = { onTabSelected(BottomToolWindow.BUILD_OUTPUT) }
                )

                ToolTabButton(
                    title = "Problems",
                    icon = Icons.Default.Warning,
                    isSelected = activeWindow == BottomToolWindow.PROBLEMS,
                    badgeCount = problems.size,
                    onClick = { onTabSelected(BottomToolWindow.PROBLEMS) }
                )

                ToolTabButton(
                    title = "Terminal",
                    icon = Icons.Default.Terminal,
                    isSelected = activeWindow == BottomToolWindow.TERMINAL,
                    badgeCount = 0,
                    onClick = {
                        if (activeWindow == BottomToolWindow.TERMINAL && isExpanded) {
                            onToggleMaximize()
                        } else {
                            onTabSelected(BottomToolWindow.TERMINAL)
                        }
                    }
                )

                ToolTabButton(
                    title = "Git",
                    icon = Icons.Default.Commit,
                    isSelected = activeWindow == BottomToolWindow.GIT,
                    badgeCount = gitStatus?.modifiedFiles?.size ?: 0,
                    onClick = { onTabSelected(BottomToolWindow.GIT) }
                )

                ToolTabButton(
                    title = "AI Assistant",
                    icon = Icons.Default.AutoAwesome,
                    isSelected = activeWindow == BottomToolWindow.AI_ASSISTANT,
                    badgeCount = 0,
                    onClick = { onTabSelected(BottomToolWindow.AI_ASSISTANT) }
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isExpanded) {
                    IconButton(
                        onClick = onToggleMaximize,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (isMaximized) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                            contentDescription = if (isMaximized) "استعادة المحرر" else "شاشة كاملة",
                            tint = if (isMaximized) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onToggleExpanded,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        val targetHeight = when {
            !isExpanded -> 0.dp
            activeWindow == BottomToolWindow.TERMINAL -> 440.dp
            else -> 260.dp
        }

        val animatedHeight by animateDpAsState(
            targetValue = targetHeight,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "BottomToolWindowHeight"
        )

        if (isExpanded || animatedHeight > 0.dp) {
            val boxModifier = if (isMaximized) {
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
            } else {
                Modifier
                    .fillMaxWidth()
                    .height(animatedHeight)
            }

            Box(
                modifier = boxModifier
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (activeWindow) {
                    BottomToolWindow.BUILD_OUTPUT -> {
                        BuildOutputContent(
                            buildResult = buildResult,
                            buildLogs = buildLogs,
                            buildStatus = buildStatus,
                            onClearLogs = onClearLogs,
                            context = context
                        )
                    }

                    BottomToolWindow.PROBLEMS -> {
                        ProblemsContent(
                            problems = problems,
                            onJumpToProblem = onJumpToProblem
                        )
                    }

                    BottomToolWindow.TERMINAL -> {
                        TerminalContent(
                            terminalLines = terminalLines,
                            isTerminalRunning = isTerminalRunning,
                            onExecuteCommand = onExecuteCommand,
                            onStopTerminal = onStopTerminal,
                            onClearTerminal = onClearTerminal,
                            isDownloadingJdk = isDownloadingJdk,
                            jdkDownloadProgress = jdkDownloadProgress,
                            jdkDownloadStatus = jdkDownloadStatus,
                            onDownloadJdkClick = onDownloadJdkClick,
                            isMaximized = isMaximized,
                            onToggleMaximize = onToggleMaximize
                        )
                    }

                    BottomToolWindow.GIT -> {
                        GitContent(
                            gitStatus = gitStatus,
                            onCommit = onCommit,
                            onCloneRepo = onCloneRepo
                        )
                    }

                    BottomToolWindow.AI_ASSISTANT -> {
                        AiAssistantContent(
                            messages = aiMessages,
                            isBusy = isAiBusy,
                            onSendMessage = onSendAiPrompt,
                            onApplyFix = onApplyAiFix
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolTabButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    badgeCount: Int,
    onClick: () -> Unit
) {
    val color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant

    Row(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(15.dp),
            tint = color
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = color,
            fontSize = 11.sp
        )

        if (badgeCount > 0) {
            Spacer(modifier = Modifier.width(4.dp))
            Surface(
                shape = MaterialTheme.shapes.extraSmall,
                color = MaterialTheme.colorScheme.error
            ) {
                Text(
                    text = "$badgeCount",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }
        } else if (badgeCount == -1) {
            // Running indicator
            Spacer(modifier = Modifier.width(4.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(10.dp),
                strokeWidth = 1.5.dp,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

// 1. Build Output Content
@Composable
private fun BuildOutputContent(
    buildResult: BuildResult?,
    buildLogs: List<BuildLogEntry>,
    buildStatus: BuildStatus,
    onClearLogs: () -> Unit,
    context: Context
) {
    val listState = rememberLazyListState()
    val horizontalScrollState = rememberScrollState()
    val clipboardManager = LocalClipboardManager.current
    var isFullScreen by remember { mutableStateOf(false) }

    LaunchedEffect(buildLogs.size) {
        if (buildLogs.isNotEmpty()) {
            listState.animateScrollToItem(buildLogs.size - 1)
        }
    }

    val content = @Composable {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Status header & actions toolbar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    val statusColor = when (buildStatus) {
                        BuildStatus.RUNNING -> MaterialTheme.colorScheme.primary
                        BuildStatus.SUCCESS -> Color(0xFF59A869)
                        BuildStatus.FAILED -> MaterialTheme.colorScheme.error
                        BuildStatus.CANCELLED -> MaterialTheme.colorScheme.outline
                        BuildStatus.IDLE -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(statusColor, shape = androidx.compose.foundation.shape.CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Status: $buildStatus",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = statusColor
                    )

                    if (buildResult != null && buildResult.durationMs > 0) {
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Time: ${buildResult.durationMs / 1000}s",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "(${buildLogs.size} lines)",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Copy All action
                    IconButton(
                        onClick = {
                            val fullLogText = buildLogs.joinToString("\n") { it.message }
                            if (fullLogText.isNotEmpty()) {
                                clipboardManager.setText(AnnotatedString(fullLogText))
                                android.widget.Toast.makeText(context, "All logs copied to clipboard", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.size(28.dp).testTag("copy_logs_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy all logs",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Full Screen toggle action
                    IconButton(
                        onClick = { isFullScreen = !isFullScreen },
                        modifier = Modifier.size(28.dp).testTag("fullscreen_logs_btn")
                    ) {
                        Icon(
                            imageVector = if (isFullScreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                            contentDescription = if (isFullScreen) "Exit full screen" else "Full screen",
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Clear logs action
                    IconButton(
                        onClick = onClearLogs,
                        modifier = Modifier.size(28.dp).testTag("clear_logs_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear logs",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Generated APK Banner (If available)
            if (buildResult?.apkFile != null && buildResult.apkFile.exists()) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF1E3A24)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "APK Generated: ${buildResult.apkFile.name}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF81C784)
                            )
                            Text(
                                text = "Size: ${buildResult.apkSize / 1024} KB  |  ${buildResult.apkFile.parentFile?.name}",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }

                        Row {
                            FilledTonalButton(
                                onClick = {
                                    installApk(context, buildResult.apkFile)
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Open", fontSize = 11.sp)
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            FilledTonalButton(
                                onClick = {
                                    shareApk(context, buildResult.apkFile)
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Share", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // Selectable, full-fidelity, horizontally and vertically scrollable logs view
            SelectionContainer(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(horizontalScrollState)
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        items(buildLogs) { entry ->
                            val textColor = when {
                                entry.isError -> Color(0xFFE05252)
                                entry.message.contains("BUILD SUCCESSFUL", ignoreCase = true) -> Color(0xFF59A869)
                                entry.message.startsWith(">") -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.onBackground
                            }

                            Text(
                                text = entry.message,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 16.sp,
                                color = textColor,
                                softWrap = false
                            )
                        }
                    }
                }
            }
        }
    }

    if (isFullScreen) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { isFullScreen = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                content()
            }
        }
    } else {
        content()
    }
}

// 2. Problems Content
@Composable
private fun ProblemsContent(
    problems: List<ProblemItem>,
    onJumpToProblem: (File?, Int) -> Unit
) {
    if (problems.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF59A869),
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "No problems detected in the project.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            items(problems) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onJumpToProblem(item.file, item.line) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = if (item.isError) Icons.Default.Error else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (item.isError) Color(0xFFE05252) else Color(0xFFE5A800),
                        modifier = Modifier.size(16.dp).padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.relativePath,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "line ${item.line}:${item.column}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.message,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
            }
        }
    }
}

// 3. Terminal Content
@Composable
private fun TerminalContent(
    terminalLines: List<TerminalLine>,
    isTerminalRunning: Boolean,
    onExecuteCommand: (String) -> Unit,
    onStopTerminal: () -> Unit,
    onClearTerminal: () -> Unit,
    isDownloadingJdk: Boolean,
    jdkDownloadProgress: Int,
    jdkDownloadStatus: String,
    onDownloadJdkClick: () -> Unit,
    isMaximized: Boolean = false,
    onToggleMaximize: () -> Unit = {}
) {
    var cmdText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(terminalLines.size, cmdText) {
        val totalCount = terminalLines.size + 1
        try {
            listState.animateScrollToItem(totalCount)
        } catch (_: Exception) {}
    }

    // Auto-focus input field and show keyboard when terminal opens
    LaunchedEffect(Unit) {
        delay(350)
        try {
            focusRequester.requestFocus()
            keyboardController?.show()
        } catch (_: Exception) {}
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Quick Action Bar & Tools Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Manual JDK 17 Download Button
            Button(
                onClick = onDownloadJdkClick,
                enabled = !isDownloadingJdk,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDownloadingJdk) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primary
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                modifier = Modifier
                    .height(30.dp)
                    .testTag("download_jdk_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "Download JDK 17",
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isDownloadingJdk) "جاري التحميل..." else "تحميل JDK 17",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Show Keyboard Button in top bar
            OutlinedButton(
                onClick = {
                    focusRequester.requestFocus()
                    keyboardController?.show()
                },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier
                    .height(30.dp)
                    .testTag("terminal_top_keyboard_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Keyboard,
                    contentDescription = "Show Keyboard",
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("لوحة المفاتيح", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Copy All Terminal Output Button
            OutlinedButton(
                onClick = {
                    val allText = terminalLines.joinToString("\n") { it.text }
                    if (allText.isNotBlank()) {
                        clipboardManager.setText(AnnotatedString(allText))
                        Toast.makeText(context, "تم نسخ مخرجات الطرفية بالكامل", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "لا توجد مخرجات للنسخ حاليًا", Toast.LENGTH_SHORT).show()
                    }
                },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier
                    .height(30.dp)
                    .testTag("copy_terminal_output_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy All",
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("نسخ المخرجات", fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Toggle Maximize / Restore Button
            OutlinedButton(
                onClick = onToggleMaximize,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (isMaximized) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                ),
                modifier = Modifier
                    .height(30.dp)
                    .testTag("terminal_toggle_maximize_btn")
            ) {
                Icon(
                    imageVector = if (isMaximized) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                    contentDescription = if (isMaximized) "عرض المحرر" else "شاشة كاملة",
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isMaximized) "عرض المحرر (تصغير)" else "شاشة كاملة للطرفية",
                    fontSize = 11.sp,
                    fontWeight = if (isMaximized) FontWeight.Bold else FontWeight.Normal
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Clear Terminal Button
            IconButton(
                onClick = onClearTerminal,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    Icons.Default.ClearAll,
                    contentDescription = "Clear Terminal",
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // JDK Download Live Progress Indicator
        if (isDownloadingJdk) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "جاري تثبيت OpenJDK 17...",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "$jdkDownloadProgress%",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { jdkDownloadProgress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                    )
                    if (jdkDownloadStatus.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = jdkDownloadStatus,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // Terminal Output Header
        // Terminal log area header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                .padding(horizontal = 10.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Terminal,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "شاشة الطرفية والمخرجات (Terminal Screen):",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        // Terminal screen with dark console background and live prompt line
        SelectionContainer(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F141C))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                if (terminalLines.isEmpty()) {
                    item {
                        Text(
                            text = "=== Android Studio Terminal (Local Shell Ready) ===",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64B5F6)
                        )
                        Text(
                            text = "بيئة لينكس الطرفية جاهزة • اكتب أمرك في شاشتك بالأسفل",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color(0xFF81C784)
                        )
                        Text(
                            text = "--------------------------------------------------",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                } else {
                    items(terminalLines) { line ->
                        val color = when {
                            line.isCommand -> Color(0xFF64B5F6)
                            line.isError -> Color(0xFFE05252)
                            else -> Color(0xFFE2E8F0)
                        }
                        Text(
                            text = line.text,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            color = color,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    clipboardManager.setText(AnnotatedString(line.text))
                                    Toast.makeText(context, "تم نسخ السطر", Toast.LENGTH_SHORT).show()
                                }
                        )
                    }
                }

                // LIVE PROMPT LINE IN THE TERMINAL SCREEN:
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "user@droid-ide:~$ ",
                            color = Color(0xFF4AF626),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = cmdText,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "█",
                            color = Color(0xFF4AF626),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Quick Command Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val quickCommands = listOf(
                "java -version",
                "./gradlew assembleDebug",
                "./gradlew tasks",
                "ls -la",
                "pwd",
                "env"
            )
            for (qc in quickCommands) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp,
                    modifier = Modifier
                        .padding(end = 6.dp)
                        .clickable {
                            cmdText = qc
                            focusRequester.requestFocus()
                            keyboardController?.show()
                        }
                ) {
                    Text(
                        text = qc,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        // Elevated "My Command Screen" (شاشتي الخاصة لكتابة والتحكم بالأمر ومسح الحروف)
        Surface(
            tonalElevation = 6.dp,
            shadowElevation = 8.dp,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                // Header of My Screen
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "شاشتي لكتابة والتحكم بالأمر:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = if (cmdText.isEmpty()) "بانتظار الإدخال" else "${cmdText.length} حرف",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Live Command Preview Monitor Box (Shows exactly what user typed)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1B222C),
                    border = BorderStroke(
                        1.dp,
                        if (cmdText.isNotEmpty()) MaterialTheme.colorScheme.primary else Color(0xFF333E4F)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            focusRequester.requestFocus()
                            keyboardController?.show()
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$ ",
                            color = Color(0xFF4AF626),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        if (cmdText.isEmpty()) {
                            Text(
                                text = "ما تكتبه سيظهر هنا في شاشتك وفي الطرفية...",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        } else {
                            Text(
                                text = cmdText,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "█",
                                color = Color(0xFF4AF626),
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Editable input field with LTR direction
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    OutlinedTextField(
                        value = cmdText,
                        onValueChange = { cmdText = it },
                        placeholder = { Text("اكتب الأمر هنا: e.g. ls, java -version...", fontSize = 12.sp) },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        keyboardOptions = KeyboardOptions(
                            imeAction = ImeAction.Send,
                            autoCorrectEnabled = false
                        ),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (cmdText.isNotBlank()) {
                                    onExecuteCommand(cmdText)
                                    cmdText = ""
                                }
                            }
                        ),
                        trailingIcon = {
                            if (cmdText.isNotEmpty()) {
                                IconButton(onClick = { cmdText = "" }) {
                                    Icon(
                                        Icons.Default.Clear,
                                        contentDescription = "مسح الكل",
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                            .testTag("terminal_input_field"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Character Editing & Control Toolbar (مسح حرف، مسح الكل، مسافة، والرموز)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // ⌫ مسح حرف واحد (Backspace)
                    Button(
                        onClick = {
                            if (cmdText.isNotEmpty()) {
                                cmdText = cmdText.dropLast(1)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("terminal_backspace_btn")
                    ) {
                        Icon(
                            Icons.Default.Backspace,
                            contentDescription = "مسح حرف",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("مسح حرف (⌫)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // ✕ مسح الكل (Clear All)
                    OutlinedButton(
                        onClick = { cmdText = "" },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("terminal_clear_btn")
                    ) {
                        Icon(
                            Icons.Default.DeleteSweep,
                            contentDescription = "مسح الكل",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("مسح الكل", fontSize = 11.sp)
                    }

                    // ␣ مسافة (Space)
                    FilledTonalButton(
                        onClick = { cmdText += " " },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("terminal_space_btn")
                    ) {
                        Icon(
                            Icons.Default.SpaceBar,
                            contentDescription = "مسافة",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("مسافة", fontSize = 11.sp)
                    }

                    // Quick shell symbol shortcuts
                    val symbols = listOf("-", "/", "~", "|", "&", ".", "*", "$", ";")
                    for (sym in symbols) {
                        SuggestionChip(
                            onClick = { cmdText += sym },
                            label = {
                                Text(
                                    text = sym,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp
                                )
                            },
                            modifier = Modifier.height(30.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Bottom execution row: Keyboard toggle & Execute / Stop button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            focusRequester.requestFocus()
                            keyboardController?.show()
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(44.dp)
                            .weight(0.35f)
                            .testTag("terminal_bottom_keyboard_btn")
                    ) {
                        Icon(Icons.Default.Keyboard, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("لوحة المفاتيح", fontSize = 11.sp)
                    }

                    if (isTerminalRunning) {
                        Button(
                            onClick = onStopTerminal,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(44.dp)
                                .weight(0.65f)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إيقاف الأمر", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = {
                                if (cmdText.isNotBlank()) {
                                    onExecuteCommand(cmdText)
                                    cmdText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(44.dp)
                                .weight(0.65f)
                                .testTag("terminal_send_btn")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Run", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تنفيذ الأمر (Enter ⏎)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// 4. Git Content
@Composable
private fun GitContent(
    gitStatus: GitStatus?,
    onCommit: (String) -> Unit,
    onCloneRepo: (String) -> Unit
) {
    var commitMessage by remember { mutableStateOf("") }
    var showCloneDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CallSplit, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Branch: ${gitStatus?.currentBranch ?: "main"}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            FilledTonalButton(
                onClick = { showCloneDialog = true },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Clone GitHub Repo", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Commit input box
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commitMessage,
                onValueChange = { commitMessage = it },
                placeholder = { Text("Commit message...", fontSize = 11.sp) },
                singleLine = true,
                modifier = Modifier.weight(1f).height(44.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Button(
                onClick = {
                    if (commitMessage.isNotBlank()) {
                        onCommit(commitMessage)
                        commitMessage = ""
                    }
                },
                modifier = Modifier.height(44.dp)
            ) {
                Text("Commit", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Recent Commits:",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        val commits = gitStatus?.recentCommits ?: emptyList()
        if (commits.isEmpty()) {
            Text(
                text = "No commits recorded yet in .git repository.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(top = 4.dp)) {
                items(commits) { c ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = c.id,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = c.message,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }

    if (showCloneDialog) {
        var cloneUrl by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCloneDialog = false },
            title = { Text("Clone GitHub Repository") },
            text = {
                Column {
                    Text("Enter GitHub repository URL to download and import:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = cloneUrl,
                        onValueChange = { cloneUrl = it },
                        placeholder = { Text("https://github.com/owner/repo") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (cloneUrl.isNotBlank()) {
                            onCloneRepo(cloneUrl)
                            showCloneDialog = false
                        }
                    }
                ) {
                    Text("Clone")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCloneDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// 5. AI Assistant Content
@Composable
private fun AiAssistantContent(
    messages: List<AiChatMessage>,
    isBusy: Boolean,
    onSendMessage: (String) -> Unit,
    onApplyFix: (AiFixProposal) -> Unit
) {
    var promptInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Quick Action chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SuggestionChip(
                onClick = { onSendMessage("Analyze recent build problems and suggest fixes") },
                label = { Text("Fix Build Errors", fontSize = 10.sp) },
                icon = { Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(12.dp)) }
            )
            SuggestionChip(
                onClick = { onSendMessage("Explain current file architecture") },
                label = { Text("Explain Code", fontSize = 10.sp) },
                icon = { Icon(Icons.Default.HelpOutline, contentDescription = null, modifier = Modifier.size(12.dp)) }
            )
            SuggestionChip(
                onClick = { onSendMessage("Show project structure") },
                label = { Text("Project Files", fontSize = 10.sp) },
                icon = { Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(12.dp)) }
            )
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

        // Chat list
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.sender == "user"
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                ) {
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                text = msg.text,
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp
                            )

                            // Proposal with Apply Fix button
                            if (msg.proposal != null) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(modifier = Modifier.padding(6.dp)) {
                                        Text(
                                            text = msg.proposal.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = msg.proposal.description,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Button(
                                            onClick = { onApplyFix(msg.proposal) },
                                            modifier = Modifier.fillMaxWidth().height(30.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("Apply Fix to File", fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (isBusy) {
                item {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 1.5.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("AI Agent analyzing...", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // Prompt input
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = promptInput,
                onValueChange = { promptInput = it },
                placeholder = { Text("Ask AI Assistant...", fontSize = 11.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (promptInput.isNotBlank() && !isBusy) {
                        onSendMessage(promptInput)
                        promptInput = ""
                    }
                }),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                modifier = Modifier.weight(1f).height(44.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            IconButton(
                onClick = {
                    if (promptInput.isNotBlank() && !isBusy) {
                        onSendMessage(promptInput)
                        promptInput = ""
                    }
                },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

// Helpers for APK Open / Share
private fun installApk(context: Context, apkFile: File) {
    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider",
            apkFile
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

private fun shareApk(context: Context, apkFile: File) {
    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider",
            apkFile
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, uri)
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(Intent.createChooser(intent, "Share APK"))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
