package com.example.streamhub.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.Typography

// ألوان مخصصة للتصميم السنيمائي المتميز
data class StreamHubColors(
    val isOled: Boolean,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val cardBackground: Color,
    val cardBorder: Color,
    val primaryAccent: Color,
    val secondaryAccent: Color,
    val goldRating: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val navBarBackground: Color,
    val navBarActiveIndicator: Color,
    val drawerBackground: Color,
    val drawerHeaderBackground: Color,
    val dividerColor: Color,
    val badgeLive: Color
)

val OledStreamColors = StreamHubColors(
    isOled = true,
    background = Color(0xFF000000),
    surface = Color(0xFF07080B),
    surfaceVariant = Color(0xFF0F1117),
    cardBackground = Color(0xFF0D0F14),
    cardBorder = Color(0xFF1E232F),
    primaryAccent = Color(0xFFFF1E56), // نيون كريمسون سينمائي مشع
    secondaryAccent = Color(0xFF00F0FF), // سايبر سايان
    goldRating = Color(0xFFFFB800),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFFCBD5E1),
    textMuted = Color(0xFF64748B),
    navBarBackground = Color(0xFF050608).copy(alpha = 0.95f),
    navBarActiveIndicator = Color(0xFFFF1E56),
    drawerBackground = Color(0xFF050608),
    drawerHeaderBackground = Color(0xFF0C0E14),
    dividerColor = Color(0xFF161A24),
    badgeLive = Color(0xFFFF0055)
)

val LightStreamColors = StreamHubColors(
    isOled = false,
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFF1F5F9),
    cardBackground = Color(0xFFFFFFFF),
    cardBorder = Color(0xFFE2E8F0),
    primaryAccent = Color(0xFFE11D48), // روبي أحمر فخم
    secondaryAccent = Color(0xFF0284C7), // أزرق سماوي عميق
    goldRating = Color(0xFFD97706),
    textPrimary = Color(0xFF0F172A),
    textSecondary = Color(0xFF475569),
    textMuted = Color(0xFF94A3B8),
    navBarBackground = Color(0xFFFFFFFF).copy(alpha = 0.96f),
    navBarActiveIndicator = Color(0xFFE11D48),
    drawerBackground = Color(0xFFFFFFFF),
    drawerHeaderBackground = Color(0xFFF1F5F9),
    dividerColor = Color(0xFFE2E8F0),
    badgeLive = Color(0xFFE11D48)
)

val LocalStreamColors = staticCompositionLocalOf { OledStreamColors }

object StreamTheme {
    val colors: StreamHubColors
        @Composable
        @ReadOnlyComposable
        get() = LocalStreamColors.current
}

@Composable
fun StreamHubAppTheme(
    themeMode: AppThemeMode = AppThemeMode.OLED,
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    val customColors = when (themeMode) {
        AppThemeMode.OLED -> OledStreamColors
        AppThemeMode.DARK -> OledStreamColors.copy(background = Color(0xFF0B0D13), surface = Color(0xFF12151E))
        AppThemeMode.LIGHT -> LightStreamColors
    }

    val isLight = themeMode == AppThemeMode.LIGHT

    val materialColorScheme = if (isLight) {
        lightColorScheme(
            primary = customColors.primaryAccent,
            onPrimary = Color.White,
            background = customColors.background,
            onBackground = customColors.textPrimary,
            surface = customColors.surface,
            onSurface = customColors.textPrimary,
            surfaceVariant = customColors.surfaceVariant,
            onSurfaceVariant = customColors.textSecondary,
            outline = customColors.cardBorder
        )
    } else {
        darkColorScheme(
            primary = customColors.primaryAccent,
            onPrimary = Color.White,
            background = customColors.background,
            onBackground = customColors.textPrimary,
            surface = customColors.surface,
            onSurface = customColors.textPrimary,
            surfaceVariant = customColors.surfaceVariant,
            onSurfaceVariant = customColors.textSecondary,
            outline = customColors.cardBorder
        )
    }

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, view)
                val isLightBar = themeMode == AppThemeMode.LIGHT
                insetsController.isAppearanceLightStatusBars = isLightBar
                insetsController.isAppearanceLightNavigationBars = isLightBar
            }
        }
    }

    CompositionLocalProvider(LocalStreamColors provides customColors) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            typography = Typography,
            content = content
        )
    }
}
