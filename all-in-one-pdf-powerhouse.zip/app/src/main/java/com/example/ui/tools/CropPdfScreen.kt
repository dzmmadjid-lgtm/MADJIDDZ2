package com.example.ui.tools

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.theme.AccentOrange
import com.example.utils.PdfEngine
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CropPdfScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var documentName by remember { mutableStateOf("مستند PDF") }
    var totalPages by remember { mutableIntStateOf(0) }
    var currentPageIndex by remember { mutableIntStateOf(0) }
    var currentBitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Margin percentages (0f to 0.35f)
    var cropTop by remember { mutableFloatStateOf(0.05f) }
    var cropBottom by remember { mutableFloatStateOf(0.05f) }
    var cropLeft by remember { mutableFloatStateOf(0.05f) }
    var cropRight by remember { mutableFloatStateOf(0.05f) }
    var applyToAll by remember { mutableStateOf(true) }

    var isProcessing by remember { mutableStateOf(false) }
    var croppedResultFile by remember { mutableStateOf<File?>(null) }

    val pdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            pdfUri = uri
            coroutineScope.launch {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && idx != -1) {
                        documentName = cursor.getString(idx)
                    }
                }
                totalPages = PdfEngine.getPageCount(context, uri)
                currentPageIndex = 0
                currentBitmap = PdfEngine.renderPageToBitmap(context, uri, 0, 700)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("قص وتعديل الهوامش", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Document Selector Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (pdfUri != null) documentName else "اختر ملف PDF لتعديل هوامشه",
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        if (totalPages > 0) {
                            Text("صفحة ${currentPageIndex + 1} من $totalPages", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Button(
                        onClick = { pdfPicker.launch(arrayOf("application/pdf")) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentOrange),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("select_pdf_for_crop_button")
                    ) {
                        Text("اختيار ملف")
                    }
                }
            }

            if (pdfUri != null && currentBitmap != null) {
                // Visual Preview with Crop Box overlay
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Image(
                            bitmap = currentBitmap!!.asImageBitmap(),
                            contentDescription = "معاينة الصفحة",
                            modifier = Modifier.fillMaxSize()
                        )

                        // Visual crop rectangle overlay
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(
                                    top = (320 * cropTop).dp,
                                    bottom = (320 * cropBottom).dp,
                                    start = (200 * cropLeft).dp,
                                    end = (200 * cropRight).dp
                                )
                                .border(2.dp, AccentOrange, RoundedCornerShape(4.dp))
                                .background(AccentOrange.copy(alpha = 0.08f))
                        )
                    }
                }

                // Margin Adjusters
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("ضبط هوامش القص الرقمي", fontWeight = FontWeight.Bold)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الهامش العلوي: ${(cropTop * 100).toInt()}%", fontSize = 12.sp)
                        }
                        Slider(
                            value = cropTop,
                            onValueChange = { cropTop = it },
                            valueRange = 0f..0.3f
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الهامش السفلي: ${(cropBottom * 100).toInt()}%", fontSize = 12.sp)
                        }
                        Slider(
                            value = cropBottom,
                            onValueChange = { cropBottom = it },
                            valueRange = 0f..0.3f
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الهامش الجانبي: ${(cropLeft * 100).toInt()}%", fontSize = 12.sp)
                        }
                        Slider(
                            value = cropLeft,
                            onValueChange = {
                                cropLeft = it
                                cropRight = it
                            },
                            valueRange = 0f..0.3f
                        )

                        // Apply scope toggle
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = applyToAll,
                                onCheckedChange = { applyToAll = it }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تطبيق القص على جميع صفحات المستند", fontSize = 13.sp)
                        }
                    }
                }

                // Crop Action Button
                Button(
                    onClick = {
                        isProcessing = true
                        coroutineScope.launch {
                            val outFile = File(context.cacheDir, "مستند_مقصوص_${System.currentTimeMillis() % 10000}.pdf")
                            val success = PdfEngine.cropPdf(
                                context = context,
                                inputUri = pdfUri!!,
                                marginPercentLeft = cropLeft,
                                marginPercentTop = cropTop,
                                marginPercentRight = cropRight,
                                marginPercentBottom = cropBottom,
                                applyToAll = applyToAll,
                                targetPage = currentPageIndex,
                                outputFile = outFile
                            )
                            isProcessing = false
                            if (success && outFile.exists() && outFile.length() > 0) {
                                croppedResultFile = outFile
                                Toast.makeText(context, "تم قص المستند وحفظه في ملف جديد بنجاح!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "فشل تطبيق القص.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    enabled = !isProcessing,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentOrange),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("execute_crop_pdf_button")
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جاري حفظ التعديل...")
                    } else {
                        Icon(Icons.Default.Crop, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("حفظ المستند المقصوص كملف جديد", fontWeight = FontWeight.Bold)
                    }
                }

                // Result card
                if (croppedResultFile != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("تم إنشاء الملف المقصوص بنجاح:", fontWeight = FontWeight.Bold)
                            Text(croppedResultFile!!.name, style = MaterialTheme.typography.bodySmall)

                            Button(
                                onClick = {
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        croppedResultFile!!
                                    )
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة المستند المقصوص"))
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("مشاركة المستند المقصوص")
                            }
                        }
                    }
                }
            }
        }
    }
}
