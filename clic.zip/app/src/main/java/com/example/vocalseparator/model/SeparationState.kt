package com.example.vocalseparator.model

import com.example.vocalseparator.audio.SourceSeparationEngine
import com.example.vocalseparator.data.SeparationRecord

sealed interface SeparationUiState {
    object Idle : SeparationUiState

    data class Processing(
        val progress: SourceSeparationEngine.SeparationProgress
    ) : SeparationUiState

    data class Success(
        val record: SeparationRecord
    ) : SeparationUiState

    data class Error(
        val message: String
    ) : SeparationUiState
}
