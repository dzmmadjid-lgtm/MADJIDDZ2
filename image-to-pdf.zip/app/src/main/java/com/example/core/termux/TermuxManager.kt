package com.example.core.termux

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import kotlin.coroutines.resume

object TermuxManager {

    private const val TAG = "TermuxManager"

    private val _status = MutableStateFlow(TermuxStatus())
    val status: StateFlow<TermuxStatus> = _status.asStateFlow()

    fun isTermuxInstalled(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    TermuxConstants.TERMUX_PACKAGE_NAME,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(TermuxConstants.TERMUX_PACKAGE_NAME, 0)
            }
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        } catch (e: Exception) {
            Log.w(TAG, "Error checking Termux installation: ${e.message}")
            false
        }
    }

    fun hasRunCommandPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            TermuxConstants.PERMISSION_RUN_COMMAND
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun openFdroidTermuxPage(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(TermuxConstants.FDROID_TERMUX_URL)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open F-Droid page: ${e.message}")
        }
    }

    fun openTermuxApp(context: Context) {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(TermuxConstants.TERMUX_PACKAGE_NAME)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch Termux app: ${e.message}")
        }
    }

    suspend fun checkStatus(context: Context): TermuxStatus = withContext(Dispatchers.IO) {
        val installed = isTermuxInstalled(context)
        val hasPermission = if (installed) hasRunCommandPermission(context) else false

        if (!installed) {
            val s = TermuxStatus(
                isInstalled = false,
                hasRunCommandPermission = false,
                isJdkInstalled = false,
                lastCheckMessage = "تطبيق Termux غير مثبت على جهازك. يلزم تثبيته لتشغيل بيئة جافا."
            )
            _status.value = s
            return@withContext s
        }

        if (!hasPermission) {
            val s = TermuxStatus(
                isInstalled = true,
                hasRunCommandPermission = false,
                isJdkInstalled = false,
                lastCheckMessage = "صلاحية RUN_COMMAND غير ممنوحة لتطبيق DroidApp أو يجب تفعيل allow-external-apps داخل Termux."
            )
            _status.value = s
            return@withContext s
        }

        // Test java -version
        _status.value = _status.value.copy(isChecking = true)
        val javaResult = verifyJavaInstalled(context)

        val finalStatus = TermuxStatus(
            isInstalled = true,
            hasRunCommandPermission = true,
            isJdkInstalled = javaResult.first,
            javaVersionOutput = javaResult.second,
            lastCheckMessage = if (javaResult.first) {
                "بيئة OpenJDK 17 جاهزة ونشطة داخل Termux بنجاح!"
            } else {
                "Termux مثبت ولكن OpenJDK 17 غير مثبت بداخله بعد."
            },
            isChecking = false
        )
        _status.value = finalStatus
        finalStatus
    }

    suspend fun executeCommand(
        context: Context,
        command: String,
        workDir: String? = null,
        inBackground: Boolean = true,
        timeoutMs: Long = 120_000L
    ): TermuxExecutionResult = withContext(Dispatchers.IO) {
        val executionId = UUID.randomUUID().toString()

        val result = withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine { continuation ->
                TermuxResultReceiver.registerListener(executionId) { res ->
                    if (continuation.isActive) {
                        continuation.resume(res)
                    }
                }

                continuation.invokeOnCancellation {
                    TermuxResultReceiver.removeListener(executionId)
                }

                try {
                    val intent = Intent().apply {
                        setClassName(TermuxConstants.TERMUX_PACKAGE_NAME, TermuxConstants.TERMUX_RUN_COMMAND_SERVICE)
                        action = TermuxConstants.ACTION_RUN_COMMAND
                        putExtra(TermuxConstants.EXTRA_COMMAND_PATH, TermuxConstants.TERMUX_BASH_BIN)
                        putExtra(TermuxConstants.EXTRA_ARGUMENTS, arrayOf("-c", command))
                        if (!workDir.isNullOrBlank()) {
                            putExtra(TermuxConstants.EXTRA_WORKDIR, workDir)
                        } else {
                            putExtra(TermuxConstants.EXTRA_WORKDIR, TermuxConstants.TERMUX_HOME)
                        }
                        putExtra(TermuxConstants.EXTRA_BACKGROUND, inBackground)
                        putExtra(TermuxConstants.EXTRA_SESSION_ACTION, "0")

                        val resultIntent = Intent(context, TermuxResultReceiver::class.java).apply {
                            action = TermuxConstants.ACTION_RESULT_BROADCAST
                            putExtra(TermuxConstants.EXTRA_EXECUTION_ID, executionId)
                        }
                        val pendingIntent = PendingIntent.getBroadcast(
                            context,
                            executionId.hashCode(),
                            resultIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                        )
                        putExtra(TermuxConstants.EXTRA_PENDING_INTENT, pendingIntent)
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(intent)
                    } else {
                        context.startService(intent)
                    }
                } catch (e: Exception) {
                    TermuxResultReceiver.removeListener(executionId)
                    if (continuation.isActive) {
                        continuation.resume(
                            TermuxExecutionResult(
                                executionId = executionId,
                                stdout = "",
                                stderr = e.localizedMessage ?: "Failed to start Termux service",
                                exitCode = -1,
                                errCode = -1,
                                errMsg = e.localizedMessage
                            )
                        )
                    }
                }
            }
        }

        result ?: TermuxExecutionResult(
            executionId = executionId,
            stdout = "",
            stderr = "Command execution timed out after ${timeoutMs / 1000}s",
            exitCode = -1,
            errCode = -1,
            errMsg = "Timeout waiting for Termux result"
        )
    }

    suspend fun installJdkInTermux(
        context: Context,
        onProgress: (String) -> Unit = {}
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        onProgress("جاري إرسال أمر تثبيت OpenJDK 17 إلى Termux...")
        val installCmd = "pkg update -y && pkg install openjdk-17 -y"

        // Execute in background or foreground depending on user preference
        val result = executeCommand(
            context = context,
            command = installCmd,
            inBackground = true,
            timeoutMs = 300_000L // 5 minutes for package downloads
        )

        if (result.isSuccess) {
            // Verify java -version
            val verify = verifyJavaInstalled(context)
            if (verify.first) {
                checkStatus(context)
                Pair(true, "تم تثبيت OpenJDK 17 بنجاح داخل Termux!\n${verify.second}")
            } else {
                Pair(false, "انتهى أمر التثبيت ولكن لم يتم التعرف على جافا:\n${result.stdout}\n${result.stderr}")
            }
        } else {
            val err = result.errMsg ?: result.stderr.ifBlank { result.stdout }
            Pair(false, "فشل تثبيت الحزمة عبر Termux (exit code: ${result.exitCode}):\n$err")
        }
    }

    suspend fun verifyJavaInstalled(context: Context): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val result = executeCommand(
            context = context,
            command = "java -version",
            inBackground = true,
            timeoutMs = 15_000L
        )

        // java -version usually writes to stderr or stdout
        val combined = "${result.stdout}\n${result.stderr}".trim()
        val isSuccess = result.exitCode == 0 || (
                combined.contains("openjdk", ignoreCase = true) ||
                combined.contains("version", ignoreCase = true) ||
                combined.contains("Runtime", ignoreCase = true)
        )

        Pair(isSuccess, combined.ifBlank { result.errMsg ?: "No output received from java -version" })
    }
}
