package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.streamhub.ui.StreamHubApp
import com.example.streamhub.viewmodel.StreamHubViewModel

/**
 * النشاط الرئيسي لتطبيق StreamHub الترفيهي فائق الإبهار بدعم OLED والوضع النهاري
 */
class MainActivity : ComponentActivity() {

    private val viewModel: StreamHubViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            StreamHubApp(viewModel = viewModel)
        }
    }
}




