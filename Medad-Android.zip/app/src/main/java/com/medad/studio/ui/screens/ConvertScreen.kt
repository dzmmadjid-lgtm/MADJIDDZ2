package com.medad.studio.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.IosShare
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.medad.studio.pdf.PdfEngine
import com.medad.studio.print.WifiPrint
import com.medad.studio.ui.components.GhostButton
import com.medad.studio.ui.components.GoldButton
import com.medad.studio.ui.components.GoldChip
import com.medad.studio.ui.components.MedadCard
import com.medad.studio.ui.theme.LocalPalette
import kotlinx.coroutines.launch
import java.io.File

enum class ConvertMode { ImagesToPdf, PdfToImages }

@Composable
fun ConvertScreen(
    mode: ConvertMode,
    onBack: () -> Unit,
) {
    val p = LocalPalette.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("جاهز") }
    var progress by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var resultUri by remember { mutableStateOf<Uri?>(null) }
    var resultUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var resultLabel by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        images = uris
        status = if (uris.isEmpty()) "لم تُختر صور" else "تم اختيار ${uris.size} صورة"
    }
    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        pdfUri = uri
        status = if (uri == null) "لم يُختر ملف" else "تم اختيار المستند"
    }

    fun share(uri: Uri, mime: String) {
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = mime
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, "مشاركة"))
    }

    fun shareMany(uris: List<Uri>) {
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/jpeg"
            putParcelableArrayListExtra(android.content.Intent.EXTRA_STREAM, ArrayList(uris))
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, "مشاركة"))
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(p.canvas)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, "رجوع", tint = p.ink)
            }
            Column {
                Text(
                    if (mode == ConvertMode.ImagesToPdf) "صور إلى PDF" else "PDF إلى صور",
                    color = p.ink,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 18.sp,
                )
                Text(status, color = p.muted, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(12.dp))
        GoldChip(if (mode == ConvertMode.ImagesToPdf) "CONVERT · IMG→PDF" else "CONVERT · PDF→IMG")
        Spacer(Modifier.height(16.dp))

        MedadCard {
            Text(
                if (mode == ConvertMode.ImagesToPdf) {
                    "اختر صوراً بالترتيب المطلوب. ستُوسَّط كل صورة داخل صفحة A4 بيضاء بجودة طباعة."
                } else {
                    "اختر مستند PDF. ستُستخرج كل صفحة كصورة JPEG عالية الوضوح داخل مجلد مؤقت قابل للمشاركة."
                },
                color = p.muted,
                fontSize = 14.sp,
                lineHeight = 22.sp,
            )
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (mode == ConvertMode.ImagesToPdf) {
                    GoldButton("اختيار صور", Icons.Outlined.AddPhotoAlternate) {
                        imagePicker.launch(arrayOf("image/*"))
                    }
                } else {
                    GoldButton("اختيار PDF", Icons.Outlined.FolderOpen) {
                        pdfPicker.launch(arrayOf("application/pdf"))
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        if (progress != null) {
            LinearProgressIndicator(
                progress = { progress!!.first / progress!!.second.toFloat().coerceAtLeast(1f) },
                modifier = Modifier.fillMaxWidth(),
                color = p.gold,
                trackColor = p.line,
            )
            Spacer(Modifier.height(8.dp))
            Text("${progress!!.first} / ${progress!!.second}", color = p.muted, fontSize = 12.sp)
        }

        Spacer(Modifier.height(8.dp))
        GoldButton(
            text = if (busy) "جارٍ التحويل…" else "تحويل",
            enabled = !busy && if (mode == ConvertMode.ImagesToPdf) images.isNotEmpty() else pdfUri != null,
            modifier = Modifier.fillMaxWidth(),
        ) {
            busy = true
            status = "تحويل…"
            scope.launch {
                try {
                    if (mode == ConvertMode.ImagesToPdf) {
                        val out = File(context.cacheDir, "medad_${System.currentTimeMillis()}.pdf")
                        PdfEngine.imagesToPdf(context, images, out) { a, b -> progress = a to b }
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", out)
                        resultUri = uri
                        resultUris = listOf(uri)
                        resultLabel = out.name
                        status = "اكتمل: ${out.name}"
                    } else {
                        val dir = File(context.cacheDir, "pages_${System.currentTimeMillis()}")
                        val files = PdfEngine.pdfToJpegFiles(context, pdfUri!!, dir) { a, b -> progress = a to b }
                        val uris = files.map { FileProvider.getUriForFile(context, "${context.packageName}.files", it) }
                        resultUri = uris.firstOrNull()
                        resultUris = uris
                        resultLabel = "${files.size} صورة"
                        status = "اكتمل استخراج ${files.size} صفحة"
                    }
                } catch (e: Exception) {
                    status = e.message ?: "فشل التحويل"
                } finally {
                    busy = false
                }
            }
        }

        if (resultUri != null) {
            Spacer(Modifier.height(16.dp))
            MedadCard {
                Text("النتيجة", color = p.gold, fontSize = 12.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(6.dp))
                Text(resultLabel ?: "", color = p.ink, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GhostButton("مشاركة", Icons.Outlined.IosShare) {
                        if (mode == ConvertMode.PdfToImages && resultUris.size > 1) {
                            shareMany(resultUris)
                        } else {
                            share(resultUri!!, if (mode == ConvertMode.ImagesToPdf) "application/pdf" else "image/jpeg")
                        }
                    }
                    if (mode == ConvertMode.ImagesToPdf) {
                        GhostButton("طباعة", Icons.Outlined.Print) {
                            WifiPrint.systemPrint(context, "مداد", resultUri!!)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
