package com.example.ui.tools

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.theme.AccentSky
import com.example.utils.DocumentFilterType
import com.example.utils.ImageProcessing
import com.example.utils.PdfEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class ScannedPage(
    val originalBitmap: Bitmap,
    var filteredBitmap: Bitmap,
    var activeFilter: DocumentFilterType = DocumentFilterType.MAGIC_COLOR
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentScannerScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val scannedPages = remember { mutableStateListOf<ScannedPage>() }
    var selectedPageIndex by remember { mutableIntStateOf(0) }
    var isProcessing by remember { mutableStateOf(false) }
    var exportedPdfFile by remember { mutableStateOf<File?>(null) }

    // Camera capture launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            coroutineScope.launch {
                val filtered = ImageProcessing.applyFilter(bitmap, DocumentFilterType.MAGIC_COLOR)
                scannedPages.add(ScannedPage(bitmap, filtered, DocumentFilterType.MAGIC_COLOR))
                selectedPageIndex = scannedPages.size - 1
            }
        }
    }

    // Gallery import launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                for (uri in uris) {
                    val stream = context.contentResolver.openInputStream(uri)
                    val bm = BitmapFactory.decodeStream(stream)
                    stream?.close()
                    if (bm != null) {
                        val filtered = ImageProcessing.applyFilter(bm, DocumentFilterType.MAGIC_COLOR)
                        scannedPages.add(ScannedPage(bm, filtered, DocumentFilterType.MAGIC_COLOR))
                    }
                }
                selectedPageIndex = (scannedPages.size - 1).coerceAtLeast(0)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ماسح المستندات بالكاميرا", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Action Buttons: Camera & Gallery
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { cameraLauncher.launch(null) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("capture_camera_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentSky)
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("التقاط بالكاميرا")
                }

                OutlinedButton(
                    onClick = { galleryLauncher.launch("image/*") },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("استيراد من الصور")
                }
            }

            if (scannedPages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Outlined.DocumentScanner, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("التقط مستنداً بالكاميرا أو اختر صوراً لمعالجتها وتنقيتها.", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            } else {
                // Main Preview of Selected Page
                val activePage = scannedPages.getOrNull(selectedPageIndex)
                if (activePage != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Image(
                                bitmap = activePage.filteredBitmap.asImageBitmap(),
                                contentDescription = "معاينة المستند الممسوح",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Fit
                            )

                            // Page Counter Badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(8.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black.copy(alpha = 0.7f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "صفحة ${selectedPageIndex + 1} من ${scannedPages.size}",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Filter Options Bar
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("فلاتر تحسين المستند", fontWeight = FontWeight.Bold)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(
                                    DocumentFilterType.MAGIC_COLOR to "سحري (نقاء)",
                                    DocumentFilterType.BLACK_AND_WHITE to "أبيض وأسود",
                                    DocumentFilterType.GRAYSCALE to "تدرج رمادي",
                                    DocumentFilterType.ORIGINAL to "الأصل"
                                ).forEach { (fType, label) ->
                                    FilterChip(
                                        selected = activePage.activeFilter == fType,
                                        onClick = {
                                            coroutineScope.launch {
                                                val filtered = ImageProcessing.applyFilter(activePage.originalBitmap, fType)
                                                scannedPages[selectedPageIndex] = activePage.copy(
                                                    filteredBitmap = filtered,
                                                    activeFilter = fType
                                                )
                                            }
                                        },
                                        label = { Text(label, fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }

                            // Rotate action
                            OutlinedButton(
                                onClick = {
                                    val rotatedOrig = ImageProcessing.rotateBitmap(activePage.originalBitmap, 90f)
                                    val rotatedFilt = ImageProcessing.rotateBitmap(activePage.filteredBitmap, 90f)
                                    scannedPages[selectedPageIndex] = activePage.copy(
                                        originalBitmap = rotatedOrig,
                                        filteredBitmap = rotatedFilt
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تدوير الصفحة 90 درجة")
                            }
                        }
                    }

                    // Thumbnails list
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        itemsIndexed(scannedPages) { idx, page ->
                            Card(
                                modifier = Modifier
                                    .size(70.dp, 90.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        width = if (selectedPageIndex == idx) 2.dp else 1.dp,
                                        color = if (selectedPageIndex == idx) AccentSky else Color.LightGray,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedPageIndex = idx }
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    Image(
                                        bitmap = page.filteredBitmap.asImageBitmap(),
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Text(
                                        text = "${idx + 1}",
                                        fontSize = 10.sp,
                                        color = Color.White,
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .background(Color.Black.copy(alpha = 0.6f))
                                            .padding(horizontal = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Export Scanned Document to PDF Button
                    Button(
                        onClick = {
                            isProcessing = true
                            coroutineScope.launch {
                                val tempUris = mutableListOf<Uri>()
                                val tempFiles = mutableListOf<File>()

                                for ((i, page) in scannedPages.withIndex()) {
                                    val tempImg = File(context.cacheDir, "scan_p_${i}_${System.currentTimeMillis()}.jpg")
                                    FileOutputStream(tempImg).use { fos ->
                                        page.filteredBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
                                    }
                                    tempFiles.add(tempImg)
                                    tempUris.add(Uri.fromFile(tempImg))
                                }

                                val outFile = File(context.cacheDir, "مسح_ضوئي_${System.currentTimeMillis() % 10000}.pdf")
                                val success = PdfEngine.convertImagesToPdf(
                                    context = context,
                                    imageUris = tempUris,
                                    outputFile = outFile,
                                    pageSize = "A4",
                                    isPortrait = true,
                                    marginDp = 8
                                )

                                tempFiles.forEach { it.delete() }
                                isProcessing = false

                                if (success && outFile.exists() && outFile.length() > 0) {
                                    exportedPdfFile = outFile
                                    Toast.makeText(context, "تم حفظ المسح الضوئي كملف PDF!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "فشل إنشاء ملف PDF.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        enabled = !isProcessing && scannedPages.isNotEmpty(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentSky),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("export_scanner_pdf_button")
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري تجميع وحفظ المستند...")
                        } else {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تصدير المستند الممسوح إلى PDF (${scannedPages.size} صفحات)", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Result Share Card
                    if (exportedPdfFile != null) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("تم تصدير المستند بنجاح:", fontWeight = FontWeight.Bold)
                                Text(exportedPdfFile!!.name, style = MaterialTheme.typography.bodySmall)

                                Button(
                                    onClick = {
                                        val uri = FileProvider.getUriForFile(
                                            context,
                                            "${context.packageName}.fileprovider",
                                            exportedPdfFile!!
                                        )
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/pdf"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة PDF الممسوح"))
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("مشاركة المستند")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
