package com.example.vocalseparator.ui.components

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.vocalseparator.audio.StudioMultiTrackPlayer
import com.example.vocalseparator.data.SeparationRecord
import com.example.vocalseparator.ui.theme.CyanAccent
import com.example.vocalseparator.ui.theme.InstrumentalGold
import com.example.vocalseparator.ui.theme.StudioBorder
import com.example.vocalseparator.ui.theme.StudioCardBg
import com.example.vocalseparator.ui.theme.StudioDarkBg
import com.example.vocalseparator.ui.theme.StudioSurfaceVariant
import com.example.vocalseparator.ui.theme.TextMuted
import com.example.vocalseparator.ui.theme.TextPrimary
import com.example.vocalseparator.ui.theme.TextSecondary
import com.example.vocalseparator.ui.theme.VocalPink
import java.io.File
import java.util.Locale

/**
 * Multi-Track Studio Workstation Deck.
 * Gives full mixing control over isolated Vocals and Instrumental stems.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudioPlayerCard(
    record: SeparationRecord,
    playbackState: StudioMultiTrackPlayer.PlayerPlaybackState,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSeekRelative: (Long) -> Unit,
    onSetVocalsVolume: (Float) -> Unit,
    onSetInstrumentalVolume: (Float) -> Unit,
    onToggleVocalsMute: () -> Unit,
    onToggleInstrumentalMute: () -> Unit,
    onSetSoloMode: (StudioMultiTrackPlayer.TrackSoloMode) -> Unit,
    onExportVocals: () -> Unit,
    onExportInstrumental: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .border(1.dp, CyanAccent.copy(alpha = 0.4f), RoundedCornerShape(22.dp)),
        color = StudioCardBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Track Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = record.title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "مفصول بواسطة الذكاء الاصطناعي • ${record.sampleRate / 1000} kHz",
                        style = MaterialTheme.typography.bodySmall.copy(color = CyanAccent)
                    )
                }

                // Share Button
                IconButton(
                    onClick = {
                        try {
                            val vocalsFile = File(record.vocalsFilePath)
                            val authority = "${context.packageName}.fileprovider"
                            val shareUri = androidx.core.content.FileProvider.getUriForFile(context, authority, vocalsFile)
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "audio/wav"
                                putExtra(Intent.EXTRA_STREAM, shareUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "مشاركة الملف المفصول"))
                        } catch (_: Exception) {}
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(StudioSurfaceVariant)
                        .testTag("share_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "مشاركة",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Audio Waveform Spectrum Visualizer
            AudioVisualizer(
                isPlaying = playbackState.isPlaying,
                accentColor = CyanAccent,
                secondaryColor = VocalPink
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Scrub Bar
            val duration = playbackState.durationMs.coerceAtLeast(1L)
            val currentPos = playbackState.currentPositionMs.coerceIn(0L, duration)
            val progressFrac = currentPos.toFloat() / duration

            Slider(
                value = progressFrac,
                onValueChange = { frac ->
                    onSeekTo((frac * duration).toLong())
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("scrub_bar_slider"),
                colors = SliderDefaults.colors(
                    thumbColor = CyanAccent,
                    activeTrackColor = CyanAccent,
                    inactiveTrackColor = StudioSurfaceVariant
                )
            )

            // Time stamps
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatMs(currentPos),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                )
                Text(
                    text = formatMs(duration),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextMuted,
                        fontWeight = FontWeight.Medium
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Playback Transport Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onSeekRelative(-10000L) },
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(StudioSurfaceVariant)
                        .testTag("rewind_10s_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.FastRewind,
                        contentDescription = "ترجيع 10 ثواني",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(20.dp))

                Button(
                    onClick = onTogglePlayPause,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = StudioDarkBg
                    ),
                    modifier = Modifier
                        .size(64.dp)
                        .testTag("studio_play_pause_btn")
                ) {
                    Icon(
                        imageVector = if (playbackState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (playbackState.isPlaying) "إيقاف مؤقت" else "تشغيل",
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.width(20.dp))

                IconButton(
                    onClick = { onSeekRelative(10000L) },
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(StudioSurfaceVariant)
                        .testTag("forward_10s_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.FastForward,
                        contentDescription = "تقديم 10 ثواني",
                        tint = TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Quick Preset Selection Chips
            Text(
                text = "أوضاع الاستماع السريعة:",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = playbackState.soloMode == StudioMultiTrackPlayer.TrackSoloMode.SOLO_VOCALS,
                    onClick = { onSetSoloMode(StudioMultiTrackPlayer.TrackSoloMode.SOLO_VOCALS) },
                    label = { Text("🎤 الصوت فقط (Acapella)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VocalPink,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("chip_solo_vocals")
                )

                FilterChip(
                    selected = playbackState.soloMode == StudioMultiTrackPlayer.TrackSoloMode.SOLO_INSTRUMENTAL,
                    onClick = { onSetSoloMode(StudioMultiTrackPlayer.TrackSoloMode.SOLO_INSTRUMENTAL) },
                    label = { Text("🎵 كاريوكي (Karaoke)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = InstrumentalGold,
                        selectedLabelColor = StudioDarkBg
                    ),
                    modifier = Modifier.testTag("chip_solo_instrumental")
                )

                FilterChip(
                    selected = playbackState.soloMode == StudioMultiTrackPlayer.TrackSoloMode.CUSTOM_MIX,
                    onClick = { onSetSoloMode(StudioMultiTrackPlayer.TrackSoloMode.CUSTOM_MIX) },
                    label = { Text("🎛️ ميكس مخصص (Mixer)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyanAccent,
                        selectedLabelColor = StudioDarkBg
                    ),
                    modifier = Modifier.testTag("chip_custom_mix")
                )

                FilterChip(
                    selected = playbackState.soloMode == StudioMultiTrackPlayer.TrackSoloMode.SOLO_ORIGINAL,
                    onClick = { onSetSoloMode(StudioMultiTrackPlayer.TrackSoloMode.SOLO_ORIGINAL) },
                    label = { Text("📻 المقطع الأصلي") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = StudioSurfaceVariant,
                        selectedLabelColor = TextPrimary
                    ),
                    modifier = Modifier.testTag("chip_original_track")
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Channel Faders
            TrackFader(
                title = "الصوت البشري (Vocals)",
                subtitle = "الصوت المستخلص بدقة الذكاء الاصطناعي",
                icon = Icons.Default.Mic,
                accentColor = VocalPink,
                volume = playbackState.vocalsVolume,
                isMuted = playbackState.vocalsMuted,
                isSolo = playbackState.soloMode == StudioMultiTrackPlayer.TrackSoloMode.SOLO_VOCALS,
                onVolumeChange = onSetVocalsVolume,
                onMuteToggle = onToggleVocalsMute,
                onSoloToggle = {
                    if (playbackState.soloMode == StudioMultiTrackPlayer.TrackSoloMode.SOLO_VOCALS) {
                        onSetSoloMode(StudioMultiTrackPlayer.TrackSoloMode.CUSTOM_MIX)
                    } else {
                        onSetSoloMode(StudioMultiTrackPlayer.TrackSoloMode.SOLO_VOCALS)
                    }
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            TrackFader(
                title = "الموسيقى (Instrumental)",
                subtitle = "الآلات الموسيقية والإيقاعات المتبقية",
                icon = Icons.Default.MusicNote,
                accentColor = InstrumentalGold,
                volume = playbackState.instrumentalVolume,
                isMuted = playbackState.instrumentalMuted,
                isSolo = playbackState.soloMode == StudioMultiTrackPlayer.TrackSoloMode.SOLO_INSTRUMENTAL,
                onVolumeChange = onSetInstrumentalVolume,
                onMuteToggle = onToggleInstrumentalMute,
                onSoloToggle = {
                    if (playbackState.soloMode == StudioMultiTrackPlayer.TrackSoloMode.SOLO_INSTRUMENTAL) {
                        onSetSoloMode(StudioMultiTrackPlayer.TrackSoloMode.CUSTOM_MIX)
                    } else {
                        onSetSoloMode(StudioMultiTrackPlayer.TrackSoloMode.SOLO_INSTRUMENTAL)
                    }
                }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Export Actions Row
            Text(
                text = "حفظ وتصدير إلى الهاتف (WAV):",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onExportVocals,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = VocalPink
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("export_vocals_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "تصدير Vocals",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ Vocals")
                }

                OutlinedButton(
                    onClick = onExportInstrumental,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = InstrumentalGold
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("export_inst_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "تصدير Instrumental",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ Instrumental")
                }
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return String.format(Locale.getDefault(), "%02d:%02d", m, s)
}
