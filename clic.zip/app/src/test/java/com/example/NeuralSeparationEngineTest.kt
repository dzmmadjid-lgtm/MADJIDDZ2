package com.example

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import com.example.audio.AudioDsp
import com.example.audio.FastFourierTransform
import com.example.audio.WavAudioUtil
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt

class NeuralSeparationEngineTest {

    @Test
    fun testFftAndIfftInversion() {
        val n = 4096
        val fft = FastFourierTransform(n)
        val origReal = FloatArray(n) { i -> sin(2.0 * Math.PI * 440.0 * i / 44100.0).toFloat() }
        val origImag = FloatArray(n)

        val real = origReal.copyOf()
        val imag = origImag.copyOf()

        fft.fft(real, imag)
        fft.ifft(real, imag)

        for (i in 0 until n) {
            assertEquals("FFT inversion mismatch at $i", origReal[i], real[i], 1e-4f)
        }
    }

    @Test
    fun testRealOnnxModelInference() {
        val vocalsModelFile = File("src/main/assets/models/vocals.onnx")
        assertTrue(
            "vocals.onnx must exist at ${vocalsModelFile.absolutePath}",
            vocalsModelFile.exists() && vocalsModelFile.length() > 30_000_000L
        )

        val accompModelFile = File("src/main/assets/models/accompaniment.onnx")
        assertTrue(
            "accompaniment.onnx must exist at ${accompModelFile.absolutePath}",
            accompModelFile.exists() && accompModelFile.length() > 30_000_000L
        )

        // 1. Initialize ONNX Runtime
        val env = OrtEnvironment.getEnvironment()
        val sessionOptions = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(1)
        }

        println("Loading real Vocals ONNX session: ${vocalsModelFile.absolutePath} (${vocalsModelFile.length()} bytes)")
        val vocalsSession = env.createSession(vocalsModelFile.absolutePath, sessionOptions)
        assertNotNull(vocalsSession)

        // Verify model metadata and input/output names
        val inputNames = vocalsSession.inputNames
        val outputNames = vocalsSession.outputNames
        println("ONNX Model Input Names: $inputNames")
        println("ONNX Model Output Names: $outputNames")
        assertTrue(inputNames.contains("x"))
        assertTrue(outputNames.contains("y"))

        // 2. Prepare 4D input tensor for 1 split (512 frames, 1024 bins, 2 channels)
        val numSplits = 1
        val frames = 512
        val bins = 1024
        val totalElements = 2 * numSplits * frames * bins

        val directBuffer = ByteBuffer.allocateDirect(totalElements * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        // Generate synthetic spectrogram with audio energy
        for (ch in 0..1) {
            for (f in 0 until frames) {
                for (b in 0 until bins) {
                    val mag = if (b in 30..300) 0.5f else 0.01f
                    directBuffer.put(mag)
                }
            }
        }
        directBuffer.flip()

        val tensorShape = longArrayOf(2L, numSplits.toLong(), frames.toLong(), bins.toLong())
        val inputTensor = OnnxTensor.createTensor(env, directBuffer, tensorShape)

        // 3. Run genuine Deep Neural Network inference
        println("Running deep neural inference with ONNX Runtime...")
        val startTime = System.currentTimeMillis()
        val results = vocalsSession.run(mapOf("x" to inputTensor))
        val elapsed = System.currentTimeMillis() - startTime
        println("Neural Inference completed in ${elapsed}ms")

        assertNotNull(results)
        val outputTensor = results[0] as OnnxTensor
        val outShape = outputTensor.info.shape
        println("Output Tensor Shape: ${outShape.joinToString(", ")}")

        assertEquals(4, outShape.size)
        assertEquals(2L, outShape[0])
        assertEquals(numSplits.toLong(), outShape[1])
        assertEquals(frames.toLong(), outShape[2])
        assertEquals(bins.toLong(), outShape[3])

        // Verify output buffer contains valid neural activations
        val outputBuffer = outputTensor.floatBuffer
        var nonZeroCount = 0
        var maxVal = 0f
        while (outputBuffer.hasRemaining()) {
            val v = outputBuffer.get()
            if (abs(v) > 1e-6f) nonZeroCount++
            if (v > maxVal) maxVal = v
        }
        println("Neural output stats: nonZeroCount=$nonZeroCount / $totalElements, maxVal=$maxVal")
        assertTrue("Model should produce active neural predictions", nonZeroCount > 1000)
        assertTrue("Model activations should be positive magnitudes", maxVal > 0f)

        inputTensor.close()
        results.close()
        vocalsSession.close()
        env.close()
        println("Real ONNX Deep Neural Separation verified successfully!")
    }
}
