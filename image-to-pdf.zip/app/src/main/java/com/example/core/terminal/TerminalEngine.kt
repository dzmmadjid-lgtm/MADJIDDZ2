package com.example.core.terminal

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

data class TerminalLine(
    val text: String,
    val isCommand: Boolean = false,
    val isError: Boolean = false
)

class TerminalEngine(
    private val scope: CoroutineScope,
    private val context: Context? = null
) {

    private val _output = MutableStateFlow<List<TerminalLine>>(emptyList())
    val output: StateFlow<List<TerminalLine>> = _output.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private var activeProcess: Process? = null
    private var executionJob: Job? = null

    fun appendLine(text: String, isCommand: Boolean = false, isError: Boolean = false) {
        _output.value = _output.value + TerminalLine(text, isCommand, isError)
    }

    fun appendOutput(text: String, isError: Boolean = false) {
        appendLine(text, isCommand = false, isError = isError)
    }

    fun appendCommand(command: String) {
        appendLine("$ $command", isCommand = true, isError = false)
    }

    fun clear() {
        _output.value = emptyList()
    }

    fun getAllText(): String {
        return _output.value.joinToString("\n") { it.text }
    }

    fun executeCommand(command: String, workingDir: File) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return

        appendLine("$ $trimmed", isCommand = true)

        if (trimmed == "clear" || trimmed == "cls") {
            clear()
            return
        }

        executionJob?.cancel()
        executionJob = scope.launch(Dispatchers.IO) {
            _isRunning.value = true
            try {
                val pb = ProcessBuilder("/system/bin/sh", "-c", trimmed)
                pb.directory(workingDir)
                pb.redirectErrorStream(false)

                val env = pb.environment()

                // Inject internal/sandbox JDK if provisioned
                if (context != null) {
                    val jdkDir = File(context.filesDir, "jdk")
                    if (jdkDir.exists()) {
                        val directBin = File(jdkDir, "bin")
                        val binDir = if (directBin.exists()) directBin else {
                            jdkDir.listFiles()?.firstOrNull { File(it, "bin").exists() }?.let { File(it, "bin") }
                        }
                        if (binDir != null && binDir.exists()) {
                            val javaHome = binDir.parentFile?.absolutePath ?: jdkDir.absolutePath
                            env["JAVA_HOME"] = javaHome
                            val currentPath = env["PATH"] ?: System.getenv("PATH") ?: "/system/bin"
                            env["PATH"] = "${binDir.absolutePath}:$currentPath"
                        }
                    }

                    val sdkDir = File(context.filesDir, "android-sdk")
                    if (sdkDir.exists()) {
                        env["ANDROID_HOME"] = sdkDir.absolutePath
                        env["ANDROID_SDK_ROOT"] = sdkDir.absolutePath
                    }
                }

                val androidHome = env["ANDROID_HOME"] ?: System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT")
                if (androidHome != null) {
                    env["ANDROID_HOME"] = androidHome
                    env["ANDROID_SDK_ROOT"] = androidHome
                }

                val process = pb.start()
                activeProcess = process

                // Coroutine to read stdout
                val outJob = launch {
                    val reader = BufferedReader(InputStreamReader(process.inputStream))
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        appendLine(line ?: "")
                    }
                }

                // Coroutine to read stderr
                val errJob = launch {
                    val errReader = BufferedReader(InputStreamReader(process.errorStream))
                    var errLine: String?
                    while (errReader.readLine().also { errLine = it } != null) {
                        appendLine(errLine ?: "", isError = true)
                    }
                }

                outJob.join()
                errJob.join()

                val exitCode = process.waitFor()
                appendLine("[Process completed with exit code $exitCode]")
            } catch (e: Exception) {
                appendLine("Terminal execution error: ${e.localizedMessage}", isError = true)
            } finally {
                activeProcess = null
                _isRunning.value = false
            }
        }
    }

    fun stop() {
        activeProcess?.destroy()
        executionJob?.cancel()
        activeProcess = null
        _isRunning.value = false
        appendLine("[Process stopped by user]", isError = true)
    }
}
