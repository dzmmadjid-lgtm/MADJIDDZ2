package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.image.ImageUtils
import com.example.data.model.DetectedLanguage
import com.example.data.model.OcrPageResult
import com.example.data.model.RegionType
import com.example.data.model.ScanPage
import com.example.data.model.SelectionUnit
import com.example.data.model.TextRegion
import com.example.ui.components.DocumentRegionsCanvas
import com.example.ui.theme.PdfRedDark
import com.example.ui.theme.PdfRedPrimary
import com.example.ui.theme.RegionGraphicColor
import com.example.ui.theme.RegionListColor
import com.example.ui.theme.RegionNumberColor
import com.example.ui.theme.RegionParagraphColor
import com.example.ui.theme.RegionTableCellColor
import com.example.ui.theme.RegionTitleColor
import kotlinx.coroutines.launch

@Composable
fun OcrResultScreen(
    pages: List<ScanPage>,
    currentPageIndex: Int,
    cachedBitmaps: Map<String, Bitmap>,
    activeViewTab: Int,
    selectedRegionId: String?,
    selectionUnit: SelectionUnit,
    customSelectedText: String?,
    searchQuery: String,
    searchMatchCount: Int,
    onSelectPage: (Int) -> Unit,
    onSetActiveViewTab: (Int) -> Unit,
    onSelectRegion: (String?) -> Unit,
    onSetSelectionUnit: (SelectionUnit) -> Unit,
    onUpdateSearchQuery: (String) -> Unit,
    onCopyText: ((String) -> Unit) -> Unit,
    onShareText: () -> Unit,
    onOpenExportDialog: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var showSearchBar by remember { mutableStateOf(false) }

    val currentPage = pages.getOrNull(currentPageIndex)
    val rawBitmap = currentPage?.let { cachedBitmaps[it.id] }
    val displayBitmap = remember(rawBitmap, currentPage?.enhancementMode) {
        if (rawBitmap != null && currentPage != null) {
            ImageUtils.applyEnhancement(rawBitmap, currentPage.enhancementMode)
        } else {
            rawBitmap
        }
    }
    val ocrResult = currentPage?.ocrResult

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("ocr_result_back_button")) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "نتائج فحص النصوص OCR",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (ocrResult != null) {
                                Text(
                                    text = "${ocrResult.stats.wordCount} كلمة • ${ocrResult.stats.regionCount} منطقة • اللغة: ${ocrResult.primaryLanguage.labelAr}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Search Toggle
                        IconButton(
                            onClick = { showSearchBar = !showSearchBar },
                            modifier = Modifier.testTag("toggle_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "بحث",
                                tint = if (showSearchBar) PdfRedPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Export PDF Action
                        Button(
                            onClick = onOpenExportDialog,
                            colors = ButtonDefaults.buttonColors(containerColor = PdfRedPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("open_export_pdf_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Search Bar
                    AnimatedVisibility(visible = showSearchBar) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = onUpdateSearchQuery,
                                placeholder = { Text("بحث عن كلمة أو عبارة داخل النص...") },
                                singleLine = true,
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { onUpdateSearchQuery("") }) {
                                            Icon(imageVector = Icons.Default.Close, contentDescription = "مسح")
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("search_text_input")
                            )
                            if (searchQuery.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "$searchMatchCount مطابقة",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = PdfRedPrimary
                                )
                            }
                        }
                    }

                    // Tab Row: Document vs Extracted Text
                    TabRow(
                        selectedTabIndex = activeViewTab,
                        indicator = { tabPositions ->
                            Box(
                                Modifier
                                    .tabIndicatorOffset(tabPositions[activeViewTab])
                                    .height(3.dp)
                                    .background(PdfRedPrimary)
                            )
                        }
                    ) {
                        Tab(
                            selected = activeViewTab == 0,
                            onClick = { onSetActiveViewTab(0) },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("عرض الوثيقة والمناطق", fontWeight = FontWeight.Bold)
                                }
                            },
                            modifier = Modifier.testTag("tab_document_view")
                        )

                        Tab(
                            selected = activeViewTab == 1,
                            onClick = { onSetActiveViewTab(1) },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.TextFields, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("النص المستخرج والترتيب", fontWeight = FontWeight.Bold)
                                }
                            },
                            modifier = Modifier.testTag("tab_text_view")
                        )
                    }
                }
            }
        },
        bottomBar = {
            // Interactive Text Selection & Actions Bar
            BottomSelectionBar(
                selectionUnit = selectionUnit,
                onSetSelectionUnit = onSetSelectionUnit,
                onCopy = {
                    onCopyText { message ->
                        scope.launch { snackbarHostState.showSnackbar(message) }
                    }
                },
                onShare = onShareText
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Multi-Page Switcher (if pages > 1)
            if (pages.size > 1) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(pages) { idx, _ ->
                        val isSelected = idx == currentPageIndex
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectPage(idx) },
                            label = { Text("صفحة ${idx + 1}") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PdfRedPrimary,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("ocr_page_tab_$idx")
                        )
                    }
                }
            }

            // Main Content Area
            if (ocrResult == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا تتوفر نتائج OCR لهذه الصفحة", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                when (activeViewTab) {
                    0 -> {
                        // Interactive Document & Regions View
                        DocumentAndRegionsView(
                            bitmap = displayBitmap,
                            ocrResult = ocrResult,
                            selectedRegionId = selectedRegionId,
                            onRegionSelected = onSelectRegion
                        )
                    }
                    1 -> {
                        // Extracted Text View in Natural Reading Order
                        ExtractedTextView(
                            ocrResult = ocrResult,
                            searchQuery = searchQuery,
                            selectedRegionId = selectedRegionId,
                            onSelectRegion = onSelectRegion
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DocumentAndRegionsView(
    bitmap: Bitmap?,
    ocrResult: OcrPageResult,
    selectedRegionId: String?,
    onRegionSelected: (String?) -> Unit
) {
    val selectedRegion = ocrResult.regions.find { it.id == selectedRegionId }

    Column(modifier = Modifier.fillMaxSize()) {
        // Interactive Canvas with Bounding Boxes
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (bitmap != null) {
                DocumentRegionsCanvas(
                    bitmap = bitmap,
                    regions = ocrResult.regions,
                    selectedRegionId = selectedRegionId,
                    onRegionSelected = onRegionSelected
                )
            }
        }

        // Selected Region Detail Sheet Card
        if (selectedRegion != null) {
            Card(
                shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RegionBadge(type = selectedRegion.type)
                            Spacer(modifier = Modifier.width(8.dp))
                            LanguageBadge(language = selectedRegion.language)
                        }

                        IconButton(onClick = { onRegionSelected(null) }, modifier = Modifier.size(24.dp)) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "إلغاء التحديد")
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = selectedRegion.text,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun ExtractedTextView(
    ocrResult: OcrPageResult,
    searchQuery: String,
    selectedRegionId: String?,
    onSelectRegion: (String?) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(ocrResult.regions) { region ->
            val isSelected = region.id == selectedRegionId

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) PdfRedPrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(
                    width = if (isSelected) 1.5.dp else 1.dp,
                    color = if (isSelected) PdfRedPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectRegion(if (isSelected) null else region.id) }
                    .testTag("ocr_text_region_${region.id}")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RegionBadge(type = region.type)
                            Spacer(modifier = Modifier.width(8.dp))
                            LanguageBadge(language = region.language)
                        }

                        Text(
                            text = "${(region.confidence * 100).toInt()}% دقة",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Text with query highlighting
                    val annotatedText = buildAnnotatedString {
                        val text = region.text
                        if (searchQuery.isNotBlank() && text.contains(searchQuery, ignoreCase = true)) {
                            var startIndex = 0
                            val lowerText = text.lowercase()
                            val lowerQuery = searchQuery.lowercase()

                            while (startIndex < text.length) {
                                val index = lowerText.indexOf(lowerQuery, startIndex)
                                if (index == -1) {
                                    append(text.substring(startIndex))
                                    break
                                }
                                append(text.substring(startIndex, index))
                                withStyle(
                                    SpanStyle(
                                        background = Color(0xFFFFD54F), // Yellow highlight
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold
                                    )
                                ) {
                                    append(text.substring(index, index + searchQuery.length))
                                }
                                startIndex = index + searchQuery.length
                            }
                        } else {
                            append(text)
                        }
                    }

                    val isTitle = region.type == RegionType.TITLE
                    Text(
                        text = annotatedText,
                        style = if (isTitle) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
                        fontWeight = if (isTitle) FontWeight.Bold else FontWeight.Normal,
                        lineHeight = if (isTitle) 24.sp else 20.sp,
                        color = if (region.isGraphic) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomSelectionBar(
    selectionUnit: SelectionUnit,
    onSetSelectionUnit: (SelectionUnit) -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Selection Units Row ("تحديد النص: كلمة، جملة، فقرة، كل النص")
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تحديد النص:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (unit in SelectionUnit.entries) {
                        val isSelected = selectionUnit == unit
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) PdfRedPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { onSetSelectionUnit(unit) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("select_unit_${unit.name}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = unit.labelAr,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons: Copy, Share
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onCopy,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("copy_text_button")
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("نسخ النص", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onShare,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("share_text_button")
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun RegionBadge(type: RegionType) {
    val (color, text) = when (type) {
        RegionType.TITLE -> Pair(RegionTitleColor, "عنوان")
        RegionType.PARAGRAPH -> Pair(RegionParagraphColor, "فقرة")
        RegionType.LIST_ITEM -> Pair(RegionListColor, "قائمة")
        RegionType.NUMBER -> Pair(RegionNumberColor, "أرقام")
        RegionType.TABLE_CELL -> Pair(RegionTableCellColor, "جدول")
        RegionType.GRAPHIC_OR_PHOTO -> Pair(RegionGraphicColor, "رسم/صورة")
        RegionType.SHORT_TEXT -> Pair(Color(0xFF00897B), "نص قصير")
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp
        )
    }
}

@Composable
private fun LanguageBadge(language: DetectedLanguage) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = language.labelAr,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 10.sp
        )
    }
}
