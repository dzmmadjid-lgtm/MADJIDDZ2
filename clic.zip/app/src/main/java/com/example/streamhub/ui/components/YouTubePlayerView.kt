package com.example.streamhub.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * مشغل يوتيوب حقيقي مدمج باستخدام YouTube IFrame API و Android WebView
 * يوفر تجربة تشغيل أصلية تحاكي تشغيل الفيديو داخل يوتيوب تماماً:
 * - تحكم أصلي بالجودة، الترجمة، والسرعة
 * - دعم وضع ملء الشاشة والشريط الأحمر المميز ليوتيوب
 * - التشغيل التلقائي والتفاعل الكامل باللمس
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubePlayerView(
    videoId: String,
    modifier: Modifier = Modifier,
    autoplay: Boolean = true,
    onFullScreenChange: ((Boolean) -> Unit)? = null
) {
    val context = LocalContext.current
    var isPlayerLoading by remember(videoId) { mutableStateOf(true) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    // إدارة دورة حياة WebView لمنع استمرار الصوت بعد إغلاق المشغل
    DisposableEffect(videoId) {
        onDispose {
            webViewRef?.let { wv ->
                wv.onPause()
                wv.pauseTimers()
                wv.loadUrl("about:blank")
                wv.destroy()
            }
            webViewRef = null
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                createYouTubeWebView(
                    context = ctx,
                    videoId = videoId,
                    autoplay = autoplay,
                    onLoadingChanged = { loading -> isPlayerLoading = loading },
                    onFullScreenChange = onFullScreenChange
                ).also { webViewRef = it }
            },
            update = { wv ->
                // تحديث رابط الفيديو في حال تغير المعرف
                val currentTag = wv.tag as? String
                if (currentTag != videoId) {
                    wv.tag = videoId
                    isPlayerLoading = true
                    wv.loadDataWithBaseURL(
                        "https://www.youtube.com",
                        buildYouTubeHtml(videoId, autoplay),
                        "text/html",
                        "utf-8",
                        null
                    )
                }
            }
        )

        if (isPlayerLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = Color(0xFFFF0000), // أحمر يوتيوب الرسمي
                    strokeWidth = 3.dp
                )
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
private fun createYouTubeWebView(
    context: Context,
    videoId: String,
    autoplay: Boolean,
    onLoadingChanged: (Boolean) -> Unit,
    onFullScreenChange: ((Boolean) -> Unit)?
): WebView {
    return WebView(context).apply {
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        setBackgroundColor(android.graphics.Color.BLACK)
        tag = videoId

        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                safeBrowsingEnabled = false
            }
            // ضبط User-Agent قياسي حديث لضمان توافق مشغل يوتيوب
            userAgentString = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
        }

        webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                onLoadingChanged(true)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                onLoadingChanged(false)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                // منع التوجيه خارج المشغل لإبقاء التجربة سينمائية ونقية
                val url = request?.url?.toString().orEmpty()
                return !(url.contains("youtube.com") || url.contains("youtu.be") || url.contains("youtube-nocookie.com"))
            }
        }

        webChromeClient = object : WebChromeClient() {
            private var customView: View? = null
            private var customViewCallback: CustomViewCallback? = null

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                customView = view
                customViewCallback = callback
                onFullScreenChange?.invoke(true)
            }

            override fun onHideCustomView() {
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                onFullScreenChange?.invoke(false)
            }
        }

        loadDataWithBaseURL(
            "https://www.youtube.com",
            buildYouTubeHtml(videoId, autoplay),
            "text/html",
            "utf-8",
            null
        )
    }
}

/**
 * إنشاء صفحة HTML مدمجة مع مشغل YouTube IFrame الرسمي بضوابط تحكم كاملة
 */
private fun buildYouTubeHtml(videoId: String, autoplay: Boolean): String {
    val autoPlayParam = if (autoplay) 1 else 0
    return """
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <style>
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                    background-color: #000000;
                }
                html, body {
                    width: 100%;
                    height: 100%;
                    overflow: hidden;
                    background: #000000;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .video-container {
                    position: relative;
                    width: 100vw;
                    height: 100vh;
                    background: #000000;
                }
                iframe {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    border: 0;
                    outline: none;
                }
            </style>
        </head>
        <body>
            <div class="video-container">
                <iframe
                    id="player"
                    src="https://www.youtube-nocookie.com/embed/$videoId?autoplay=$autoPlayParam&playsinline=1&enablejsapi=1&fs=1&rel=0&modestbranding=1&controls=1&color=red&iv_load_policy=3&hl=ar"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                    allowfullscreen>
                </iframe>
            </div>
        </body>
        </html>
    """.trimIndent()
}
