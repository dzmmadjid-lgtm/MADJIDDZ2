import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '25mb' }));

const getAiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

const RECONSTRUCTION_SYSTEM_INSTRUCTION = `You are a strict Document Layout Reconstruction & OCR Engine.
Your task is to analyze a photograph or scan of a document page and return its exact coordinate layout model (normalized 0 to 1000 for x, y, width, height) so the page can be digitally reconstructed to look visually identical to the source paper.

ABSOLUTE CONTENT & ANTI-HALLUCINATION RULES:
1. NEVER invent content, rewrite content, summarize, improve grammar, or translate.
2. NEVER replace unclear words with guessed words. If a word or character is unclear, mark confidence < 0.65 and include it in uncertainTokens.
3. Return ONLY elements visibly present in the source image.
4. Preserve exact Arabic RTL text, Arabic/Western numerals, punctuation, and mixed Arabic/Latin ordering.
5. For TABLES: Do NOT flatten tables into plain text. Reconstruct them as a TABLE object with exact rows, cols, rowHeights, colWidths, cell text, rowSpan, colSpan, alignment, and visible borders.
6. Preserve independent font sizes (title, heading, subtitle, normal, small, table, label, footnote) and exact element positions.`;

app.post('/api/reconstruct-document', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/png' } = req.body;
    if (!imageBase64) {
      res.status(400).json({ error: 'Missing imageBase64 payload' });
      return;
    }

    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on the server. Using on-device offline reconstruction engine.',
        offlineFallback: true,
      });
      return;
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType,
              data: cleanBase64,
            },
          },
          {
            text: `Analyze this document page image and reconstruct its complete visual layout in normalized page coordinates (0..1000).
Detect all TEXT blocks, PARAGRAPH blocks, structured TABLE objects (with rows, cols, cells, rowSpan, colSpan, borders), LINE dividers, RECTANGLE boxes, CHECKBOX items, SIGNATURE_AREA regions, and IMAGE/STAMP regions.
Remember: Never invent or alter text. Preserve Arabic RTL direction and exact visual structure.`,
          },
        ],
      },
      config: {
        systemInstruction: RECONSTRUCTION_SYSTEM_INSTRUCTION,
        temperature: 0.1,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            detectedLanguage: { type: Type.STRING },
            pageDirection: { type: Type.STRING },
            estimatedMargins: {
              type: Type.OBJECT,
              properties: {
                top: { type: Type.NUMBER },
                right: { type: Type.NUMBER },
                bottom: { type: Type.NUMBER },
                left: { type: Type.NUMBER },
              },
            },
            objects: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  type: {
                    type: Type.STRING,
                    description: 'TEXT, PARAGRAPH, TABLE, LINE, RECTANGLE, CHECKBOX, SIGNATURE_AREA, or IMAGE',
                  },
                  x: { type: Type.NUMBER, description: '0 to 1000' },
                  y: { type: Type.NUMBER, description: '0 to 1000' },
                  width: { type: Type.NUMBER, description: '0 to 1000' },
                  height: { type: Type.NUMBER, description: '0 to 1000' },
                  content: { type: Type.STRING },
                  confidence: { type: Type.NUMBER, description: '0.0 to 1.0' },
                  uncertainTokens: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  alignment: { type: Type.STRING, description: 'right, center, left, or justify' },
                  direction: { type: Type.STRING, description: 'rtl or ltr' },
                  fontRole: {
                    type: Type.STRING,
                    description: 'title, heading, subtitle, normal, small, table, label, or footnote',
                  },
                  estimatedFontSizePt: { type: Type.NUMBER },
                  fontWeight: { type: Type.STRING, description: 'normal or bold' },
                  hasBorderTop: { type: Type.BOOLEAN },
                  hasBorderRight: { type: Type.BOOLEAN },
                  hasBorderBottom: { type: Type.BOOLEAN },
                  hasBorderLeft: { type: Type.BOOLEAN },
                  borderThickness: { type: Type.NUMBER },
                  backgroundColor: { type: Type.STRING },
                  checked: { type: Type.BOOLEAN },
                  tableData: {
                    type: Type.OBJECT,
                    properties: {
                      rows: { type: Type.INTEGER },
                      cols: { type: Type.INTEGER },
                      rowHeights: {
                        type: Type.ARRAY,
                        items: { type: Type.NUMBER },
                      },
                      colWidths: {
                        type: Type.ARRAY,
                        items: { type: Type.NUMBER },
                      },
                      cells: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            row: { type: Type.INTEGER },
                            col: { type: Type.INTEGER },
                            rowSpan: { type: Type.INTEGER },
                            colSpan: { type: Type.INTEGER },
                            content: { type: Type.STRING },
                            confidence: { type: Type.NUMBER },
                            alignment: { type: Type.STRING },
                            direction: { type: Type.STRING },
                            hasTopBorder: { type: Type.BOOLEAN },
                            hasRightBorder: { type: Type.BOOLEAN },
                            hasBottomBorder: { type: Type.BOOLEAN },
                            hasLeftBorder: { type: Type.BOOLEAN },
                            isHeader: { type: Type.BOOLEAN },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    });

    const rawText = response.text || '{}';
    const parsed = JSON.parse(rawText);
    res.json({ success: true, data: parsed });
  } catch (error: any) {
    console.error('Document reconstruction API error:', error?.message || error);
    res.status(500).json({
      error: error?.message || 'Failed to analyze document via Vision API',
      offlineFallback: true,
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CrimsonPDF Reconstruct Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
