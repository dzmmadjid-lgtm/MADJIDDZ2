package com.example.ui.tools

import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.theme.AccentRed
import com.example.utils.PdfEngine
import com.example.utils.PrintHelper
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DirectPrintScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var documentName by remember { mutableStateOf("مستند PDF") }
    var totalPages by remember { mutableIntStateOf(0) }

    var printerIp by remember { mutableStateOf("192.168.1.100") }
    var printerPort by remember { mutableStateOf("9100") }
    var isTestingConnection by remember { mutableStateOf(false) }
    var connectionTestedOk by remember { mutableStateOf<Boolean?>(null) }

    var isSending by remember { mutableStateOf(false) }
    var sendProgress by remember { mutableFloatStateOf(0f) }
    var resultMessage by remember { mutableStateOf<String?>(null) }

    val pdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            pdfUri = uri
            coroutineScope.launch {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && idx != -1) {
                        documentName = cursor.getString(idx)
                    }
                }
                totalPages = PdfEngine.getPageCount(context, uri)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الطباعة المباشرة (الزر الأحمر)", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Explanation card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2).copy(alpha = 0.7f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(Icons.Outlined.SendToMobile, contentDescription = null, tint = AccentRed)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الإرسال المباشر للطابعة عبر الشبكة (Socket 9100)", fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                        Text(
                            text = "يرسل هذا المسار بيانات PDF مباشرة وبشكل خام عبر مقبس شبكي إلى طابعات الشبكة (Raw JetDirect Port 9100) دون المرور ببرامج وسيطة، وهو مخصص للطابعات التي تدعم استقبال ملفات PDF المباشرة.",
                            fontSize = 12.sp,
                            color = Color(0xFF991B1B)
                        )
                    }
                }
            }

            // Document Selector
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (pdfUri != null) documentName else "اختر ملف PDF للإرسال المباشر",
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        if (totalPages > 0) {
                            Text("عدد الصفحات: $totalPages", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Button(
                        onClick = { pdfPicker.launch(arrayOf("application/pdf")) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("اختيار ملف")
                    }
                }
            }

            // Network Printer Configuration Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("إعدادات طابعة الشبكة", fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = printerIp,
                            onValueChange = {
                                printerIp = it
                                connectionTestedOk = null
                            },
                            label = { Text("عنوان IP للطابعة") },
                            placeholder = { Text("مثال: 192.168.1.150") },
                            singleLine = true,
                            enabled = !isSending,
                            modifier = Modifier.weight(2f)
                        )

                        OutlinedTextField(
                            value = printerPort,
                            onValueChange = {
                                printerPort = it
                                connectionTestedOk = null
                            },
                            label = { Text("المنفذ") },
                            singleLine = true,
                            enabled = !isSending,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Test Connection button
                    OutlinedButton(
                        onClick = {
                            isTestingConnection = true
                            connectionTestedOk = null
                            coroutineScope.launch {
                                val port = printerPort.toIntOrNull() ?: 9100
                                val ok = PrintHelper.testConnection(printerIp.trim(), port)
                                isTestingConnection = false
                                connectionTestedOk = ok
                            }
                        },
                        enabled = !isTestingConnection && printerIp.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isTestingConnection) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("جاري فحص الاتصال...")
                        } else {
                            Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اختبار اتصال المقبس (Ping Port)")
                        }
                    }

                    if (connectionTestedOk != null) {
                        Text(
                            text = if (connectionTestedOk == true) "الاتصال بالمقبس نشط ومفتوح!" else "تعذر الوصول للمنفذ أو أن الطابعة غير متصلة بالشبكة.",
                            color = if (connectionTestedOk == true) Color(0xFF16A34A) else MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Prominent Red Direct Print Button
            Button(
                onClick = {
                    if (pdfUri == null) {
                        Toast.makeText(context, "اختر ملف PDF أولاً", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val port = printerPort.toIntOrNull() ?: 9100
                    isSending = true
                    resultMessage = null
                    coroutineScope.launch {
                        val result = PrintHelper.printDirect(
                            context = context,
                            uri = pdfUri!!,
                            printerIp = printerIp.trim(),
                            port = port,
                            onProgress = { sendProgress = it }
                        )
                        isSending = false
                        result.onSuccess { msg ->
                            resultMessage = msg
                        }.onFailure { err ->
                            resultMessage = err.message
                        }
                    }
                },
                enabled = pdfUri != null && !isSending && printerIp.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("direct_red_print_action_button")
            ) {
                if (isSending) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("جاري إرسال البيانات...")
                } else {
                    Icon(Icons.Default.SendToMobile, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("بدء الإرسال المباشر (الزر الأحمر)", fontWeight = FontWeight.Black, fontSize = 16.sp)
                }
            }

            if (isSending) {
                LinearProgressIndicator(
                    progress = { sendProgress },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "تم نقل ${(sendProgress * 100).toInt()}% من حزم البيانات",
                    fontSize = 12.sp,
                    color = AccentRed
                )
            }

            if (resultMessage != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (resultMessage!!.contains("نجاح")) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                    )
                ) {
                    Text(
                        text = resultMessage ?: "",
                        modifier = Modifier.padding(14.dp),
                        color = if (resultMessage!!.contains("نجاح")) Color(0xFF166534) else Color(0xFF991B1B),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
