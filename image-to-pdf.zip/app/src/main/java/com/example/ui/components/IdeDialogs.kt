package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SearchResult
import com.example.data.model.ThemeMode
import java.io.File

@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, pkg: String, minSdk: Int, targetSdk: Int, template: String) -> Unit
) {
    var projectName by remember { mutableStateOf("MyApplication") }
    var packageName by remember { mutableStateOf("com.example.myapplication") }
    var minSdk by remember { mutableIntStateOf(24) }
    var targetSdk by remember { mutableIntStateOf(36) }
    var template by remember { mutableStateOf("Compose Empty Activity") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Android Project", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = projectName,
                    onValueChange = {
                        projectName = it
                        packageName = "com.example.${it.lowercase().replace(Regex("[^a-z0-9]"), "")}"
                    },
                    label = { Text("Project Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_project_name_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = packageName,
                    onValueChange = { packageName = it },
                    label = { Text("Package Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_project_pkg_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = "$minSdk",
                        onValueChange = { minSdk = it.toIntOrNull() ?: 24 },
                        label = { Text("Min SDK") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = "$targetSdk",
                        onValueChange = { targetSdk = it.toIntOrNull() ?: 36 },
                        label = { Text("Target SDK") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text("Template:", style = MaterialTheme.typography.labelSmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = template == "Compose Empty Activity",
                        onClick = { template = "Compose Empty Activity" }
                    )
                    Text("Jetpack Compose Activity", fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = template == "Standard Android Views",
                        onClick = { template = "Standard Android Views" }
                    )
                    Text("XML Layout + Activity", fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (projectName.isNotBlank() && packageName.isNotBlank()) {
                        onCreate(projectName.trim(), packageName.trim(), minSdk, targetSdk, template)
                    }
                },
                modifier = Modifier.testTag("confirm_create_project_btn")
            ) {
                Text("Create Project")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun NewFileDialog(
    targetDir: File,
    onDismiss: () -> Unit,
    onCreateFile: (String, String) -> Unit,
    onCreateFolder: (String) -> Unit
) {
    var isFolder by remember { mutableStateOf(false) }
    var fileName by remember { mutableStateOf("") }
    var presetType by remember { mutableStateOf("kt") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (isFolder) "New Directory" else "New File in ${targetDir.name}")
        },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = !isFolder,
                        onClick = { isFolder = false }
                    )
                    Text("File", fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(16.dp))
                    RadioButton(
                        selected = isFolder,
                        onClick = { isFolder = true }
                    )
                    Text("Directory", fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = fileName,
                    onValueChange = { fileName = it },
                    label = { Text(if (isFolder) "Directory Name" else "File Name (e.g. MyScreen.kt)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_file_name_input")
                )

                if (!isFolder) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Quick Presets:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SuggestionChip(
                            onClick = {
                                if (!fileName.endsWith(".kt")) fileName = "${fileName.removeSuffix(".kt")}.kt"
                                presetType = "kt"
                            },
                            label = { Text("Kotlin (.kt)", fontSize = 10.sp) }
                        )
                        SuggestionChip(
                            onClick = {
                                if (!fileName.endsWith(".xml")) fileName = "${fileName.removeSuffix(".xml")}.xml"
                                presetType = "xml"
                            },
                            label = { Text("XML (.xml)", fontSize = 10.sp) }
                        )
                        SuggestionChip(
                            onClick = {
                                if (!fileName.endsWith(".gradle.kts")) fileName = "${fileName.removeSuffix(".gradle.kts")}.gradle.kts"
                                presetType = "kts"
                            },
                            label = { Text("Gradle KTS", fontSize = 10.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fileName.isNotBlank()) {
                        if (isFolder) {
                            onCreateFolder(fileName.trim())
                        } else {
                            val initialContent = when {
                                fileName.endsWith(".kt") -> "// Kotlin source\n"
                                fileName.endsWith(".xml") -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n</resources>\n"
                                fileName.endsWith(".json") -> "{\n}\n"
                                else -> ""
                            }
                            onCreateFile(fileName.trim(), initialContent)
                        }
                    }
                },
                modifier = Modifier.testTag("confirm_create_file_btn")
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun RenameDialog(
    currentName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var newName by remember { mutableStateOf(currentName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename") },
        text = {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                label = { Text("New Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newName.isNotBlank() && newName != currentName) {
                        onConfirm(newName.trim())
                    }
                }
            ) {
                Text("Rename")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun SearchInProjectDialog(
    searchResults: List<SearchResult>,
    isSearching: Boolean,
    onSearch: (String) -> Unit,
    onSelectResult: (SearchResult) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Search in Project Files", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth().height(350.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        onSearch(it)
                    },
                    placeholder = { Text("Search text, symbols, classes...") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (isSearching) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                Text(
                    text = "${searchResults.size} results found",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    items(searchResults) { result ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectResult(result) }
                                .padding(vertical = 6.dp)
                        ) {
                            Text(
                                text = "${result.relativePath} : line ${result.lineNumber}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = result.lineContent.trim(),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            HorizontalDivider(modifier = Modifier.padding(top = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun SettingsDialog(
    currentTheme: ThemeMode,
    isCloudBuild: Boolean,
    cloudBuildUrl: String,
    projectRootDir: File? = null,
    onThemeChange: (ThemeMode) -> Unit,
    onCloudBuildToggle: (Boolean) -> Unit,
    onCloudBuildUrlChange: (String) -> Unit,
    onDownloadJdkClick: () -> Unit = {},
    onDismiss: () -> Unit
) {
    var urlInput by remember { mutableStateOf(cloudBuildUrl) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val envReport = remember(projectRootDir) {
        com.example.core.build.BuildEnvironmentDetector.detect(context, projectRootDir)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("IDE Settings & Build Environment", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                item {
                    Text("Appearance Theme:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = currentTheme == ThemeMode.DARK,
                            onClick = { onThemeChange(ThemeMode.DARK) }
                        )
                        Text("Dark Theme (Studio Default)")
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = currentTheme == ThemeMode.OLED,
                            onClick = { onThemeChange(ThemeMode.OLED) }
                        )
                        Text("OLED Pure Black (#000000)")
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = currentTheme == ThemeMode.LIGHT,
                            onClick = { onThemeChange(ThemeMode.LIGHT) }
                        )
                        Text("Light Theme")
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    Text("Device Environment Diagnostics:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                "OS: Android ${envReport.osRelease} (API ${envReport.sdkInt})",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "ABI: ${envReport.supportedAbis.firstOrNull() ?: "generic"}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (envReport.javaStatus.isAvailable) "● JDK: Installed (${envReport.javaStatus.javaVersion})" else "● JDK: Not Found in OS",
                                    color = if (envReport.javaStatus.isAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (!envReport.javaStatus.isAvailable) {
                                Text(
                                    "Standard Android OS (ART) does not provide OpenJDK. Local gradle execution requires OpenJDK 17.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            FilledTonalButton(
                                onClick = onDownloadJdkClick,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier
                                    .padding(vertical = 4.dp)
                                    .height(32.dp)
                                    .testTag("settings_download_jdk_btn")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (envReport.javaStatus.isAvailable) "إعادة تحميل / تحديث JDK 17" else "تحميل وتثبيت JDK 17 يدويًا", fontSize = 11.sp)
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (envReport.sdkStatus.isAvailable) "● Android SDK: Found" else "● Android SDK: Not Found",
                                    color = if (envReport.sdkStatus.isAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (envReport.sdkStatus.isAvailable) {
                                Text(
                                    "Path: ${envReport.sdkStatus.sdkPath} (${envReport.sdkStatus.platforms.size} platforms, ${envReport.sdkStatus.buildTools.size} build-tools)",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Text(
                                    "Place Android SDK in files/android-sdk or configure ANDROID_HOME.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (envReport.wrapperStatus.hasGradlew) "● Wrapper: 'gradlew' Found" else "● Wrapper: 'gradlew' Missing",
                                color = if (envReport.wrapperStatus.hasGradlew) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    Text("Build Engine Selection:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = !isCloudBuild,
                            onClick = { onCloudBuildToggle(false) }
                        )
                        Column {
                            Text("Local Process Runner")
                            Text(
                                "Executes ./gradlew via /system/bin/sh in project directory",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = isCloudBuild,
                            onClick = { onCloudBuildToggle(true) }
                        )
                        Column {
                            Text("Remote Cloud Build Runner (Recommended)")
                            Text(
                                "Builds on remote server with full JDK/SDK and returns real APK",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (isCloudBuild) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = {
                                urlInput = it
                                onCloudBuildUrlChange(it)
                            },
                            label = { Text("Cloud Build API Endpoint URL") },
                            placeholder = { Text("https://builder.yourserver.com/api/build") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}

@Composable
fun DeleteProjectTreeDialog(
    projectName: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.DeleteForever,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text("Delete Entire Project Tree?", fontWeight = FontWeight.Bold)
        },
        text = {
            Text(
                "Are you sure you want to completely delete '$projectName' and all its directories and files? This operation cannot be undone."
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                ),
                modifier = Modifier.testTag("confirm_delete_project_btn")
            ) {
                Text("Delete Project")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_delete_project_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun JdkDownloadDialog(
    isDownloading: Boolean,
    progress: Int,
    statusText: String,
    onDownloadOfficial: () -> Unit,
    onImportArchive: (Uri) -> Unit,
    onDismiss: () -> Unit
) {
    val archivePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            onImportArchive(uri)
        }
    }

    val recommended = remember { com.example.core.build.JdkProvisioner.getRecommendedDownloadUrl() }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Download,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text("تحميل وتثبيت JDK 17 يدويًا", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "لبناء تطبيقات أندرويد محليًا، يتطلب Gradle توفر OpenJDK 17 متوافق مع معمارية المعالج في هاتفك.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("الحزمة المتوافقة تلقائيًا مع جهازك:", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(recommended.first, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            "المصدر: Eclipse Adoptium Temurin OpenJDK 17",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (isDownloading) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("جاري التثبيت في مساحة التطبيق...", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("$progress%", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth().height(6.dp))
                    if (statusText.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(statusText, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onDownloadOfficial,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("download_official_jdk_btn")
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تحميل وتثبيت تلقائي الآن (Adoptium)")
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            archivePicker.launch(arrayOf("application/gzip", "application/x-tar", "application/zip", "*/*"))
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("import_local_jdk_btn")
                    ) {
                        Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("استيراد أرشيف من الهاتف (.tar.gz / .zip)")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("dismiss_jdk_dialog_btn")
            ) {
                Text(if (isDownloading) "متابعة في الخلفية" else "إغلاق")
            }
        }
    )
}

