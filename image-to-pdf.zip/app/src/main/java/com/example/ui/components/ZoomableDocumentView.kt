package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TextRegion

@Composable
fun ZoomableDocumentView(
    bitmap: Bitmap,
    modifier: Modifier = Modifier,
    regions: List<TextRegion> = emptyList(),
    selectedRegionId: String? = null,
    onRegionSelected: ((String?) -> Unit)? = null
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f))
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 5.0f)
                    if (scale > 1f) {
                        val maxOffsetX = (size.width * (scale - 1f)) / 2f
                        val maxOffsetY = (size.height * (scale - 1f)) / 2f
                        offset = Offset(
                            x = (offset.x + pan.x).coerceIn(-maxOffsetX, maxOffsetX),
                            y = (offset.y + pan.y).coerceIn(-maxOffsetY, maxOffsetY)
                        )
                    } else {
                        offset = Offset.Zero
                    }
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        if (scale > 1.2f) {
                            scale = 1f
                            offset = Offset.Zero
                        } else {
                            scale = 2.4f
                        }
                    },
                    onTap = { tapOffset ->
                        if (onRegionSelected != null && regions.isNotEmpty()) {
                            val normX = tapOffset.x / size.width
                            val normY = tapOffset.y / size.height
                            val tapped = regions.find { r ->
                                val b = r.boundingBox
                                normX in b.left..b.right && normY in b.top..b.bottom
                            }
                            onRegionSelected(tapped?.id)
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        val containerWidth = maxWidth.value
        val containerHeight = maxHeight.value

        val imageAspect = bitmap.width.toFloat() / bitmap.height.toFloat()
        val containerAspect = containerWidth / containerHeight

        // Maximize page area: occupy almost 100% of the viewport (zero waste, 3dp safety padding)
        val safetyPadding = 3f

        val displayWidth: Float
        val displayHeight: Float

        if (imageAspect > containerAspect) {
            displayWidth = containerWidth - (safetyPadding * 2)
            displayHeight = displayWidth / imageAspect
        } else {
            displayHeight = containerHeight - (safetyPadding * 2)
            displayWidth = displayHeight * imageAspect
        }

        Box(
            modifier = Modifier
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offset.x
                    translationY = offset.y
                }
                .size(displayWidth.dp, displayHeight.dp)
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(2.dp))
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White)
        ) {
            // Pristine Reconstructed Document / Clean Sheet
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Document Page",
                modifier = Modifier.fillMaxSize()
            )

            // Pure Document View: NO OCR debug bounding boxes!
            // Only draw a subtle soft yellow text selection if the user explicitly clicked a region
            if (selectedRegionId != null) {
                val selectedRegion = regions.find { it.id == selectedRegionId }
                if (selectedRegion != null) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasW = size.width
                        val canvasH = size.height
                        val b = selectedRegion.boundingBox

                        // Soft PDF text highlight (Yellow marker style)
                        drawRect(
                            color = Color(0x66FFEB3B),
                            topLeft = Offset(b.left * canvasW, b.top * canvasH),
                            size = Size(b.width * canvasW, b.height * canvasH)
                        )
                    }
                }
            }
        }

        // Zoom Reset Floating Indicator
        if (scale > 1.05f) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                tonalElevation = 4.dp,
                shadowElevation = 4.dp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
            ) {
                androidx.compose.foundation.layout.Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${(scale * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 11.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                    IconButton(
                        onClick = {
                            scale = 1f
                            offset = Offset.Zero
                        },
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("reset_zoom_button")
                    ) {
                        Icon(imageVector = Icons.Default.RestartAlt, contentDescription = "إعادة ضبط التكبير", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
