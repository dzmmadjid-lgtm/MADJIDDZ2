package com.crimsonpdf.reconstructor.model

import android.graphics.Bitmap

enum class AppThemeMode { DAY, NIGHT, OLED }

enum class ProcessingMode {
    MODE_A_CLEAN_RECONSTRUCTION,
    MODE_B_IMAGE_CLEANING
}

enum class WorkflowTab {
    IMPORT,
    PREPROCESS,
    PREVIEW_COMPARE,
    MANUAL_EDIT,
    EXPORT
}

enum class LayoutObjectType {
    TEXT,
    PARAGRAPH,
    TABLE,
    TABLE_CELL,
    IMAGE,
    LINE,
    RECTANGLE,
    CHECKBOX,
    SIGNATURE_AREA,
    PAGE_BREAK
}

enum class TextAlignment { RIGHT, CENTER, LEFT, JUSTIFY }
enum class TextDirection { RTL, LTR }
enum class FontRole { TITLE, HEADING, SUBTITLE, NORMAL, SMALL, TABLE, LABEL, FOOTNOTE }

data class BorderSide(
    val widthPx: Float = 0f,
    val isDashed: Boolean = false,
    val isDouble: Boolean = false,
    val colorArgb: Int = 0xFF0F172A.toInt()
)

data class BorderProperties(
    val top: BorderSide = BorderSide(),
    val right: BorderSide = BorderSide(),
    val bottom: BorderSide = BorderSide(),
    val left: BorderSide = BorderSide()
) {
    companion object {
        fun uniform(
            widthPx: Float,
            isDashed: Boolean = false,
            isDouble: Boolean = false,
            colorArgb: Int = 0xFF0F172A.toInt()
        ): BorderProperties {
            val side = BorderSide(widthPx, isDashed, isDouble, colorArgb)
            return BorderProperties(side, side, side, side)
        }
    }
}

data class TableCellModel(
    val id: String,
    val row: Int,
    val col: Int,
    val rowSpan: Int = 1,
    val colSpan: Int = 1,
    val content: String,
    val confidence: Float = 0.98f,
    val alignment: TextAlignment = TextAlignment.RIGHT,
    val direction: TextDirection = TextDirection.RTL,
    val fontSizePt: Float = 11f,
    val isBold: Boolean = false,
    val borders: BorderProperties = BorderProperties.uniform(1.2f),
    val backgroundColorArgb: Int = 0x00000000,
    val hiddenByMerge: Boolean = false
)

data class TableStructureModel(
    val rows: Int,
    val cols: Int,
    val rowHeights: List<Float>,
    val colWidths: List<Float>,
    val direction: TextDirection = TextDirection.RTL,
    val cells: List<TableCellModel>
)

data class PageLayoutObject(
    val id: String,
    val type: LayoutObjectType,
    val x: Float,      // 0..1000 normalized page coordinate
    val y: Float,      // 0..1000 normalized page coordinate
    val width: Float,  // 0..1000 normalized page width
    val height: Float, // 0..1000 normalized page height
    val content: String,
    val confidence: Float = 0.98f,
    val uncertainTokens: List<String> = emptyList(),
    val userCorrected: Boolean = false,
    val alignment: TextAlignment = TextAlignment.RIGHT,
    val direction: TextDirection = TextDirection.RTL,
    val fontSizePt: Float = 12f,
    val isBold: Boolean = false,
    val fontRole: FontRole = FontRole.NORMAL,
    val textColorArgb: Int = 0xFF0F172A.toInt(),
    val borders: BorderProperties = BorderProperties(),
    val backgroundColorArgb: Int = 0x00000000,
    val zOrder: Int = 1,
    val checked: Boolean = false,
    val stampColorArgb: Int = 0xFFDC2626.toInt(),
    val tableStructure: TableStructureModel? = null
)

data class PreprocessingConfig(
    val deskewAngleDeg: Float = 0f,
    val rotationDeg: Int = 0,
    val removeShadows: Boolean = true,
    val shadowStrength: Float = 75f,
    val normalizeBackground: Boolean = true,
    val contrastBoost: Float = 45f,
    val denoiseLevel: Float = 35f
)

data class ValidationMetricItem(
    val titleAr: String,
    val detailAr: String,
    val scorePercent: Int,
    val isWarning: Boolean = false
)

data class ValidationReport(
    val iterationsExecuted: Int = 2,
    val overallSimilarityPercent: Int = 96,
    val lowConfidenceCount: Int = 0,
    val metrics: List<ValidationMetricItem> = emptyList(),
    val adjustmentsLog: List<String> = emptyList(),
    val diffHeatmapBitmap: Bitmap? = null
)

data class ReconstructedPage(
    val pageNumber: Int,
    val sourceBitmap: Bitmap,
    val preprocessedBitmap: Bitmap,
    val cleanedModeBBitmap: Bitmap,
    val reconstructedBitmap: Bitmap,
    val objects: List<PageLayoutObject>,
    val preprocessing: PreprocessingConfig,
    val validationReport: ValidationReport
)

data class SampleTestSpec(
    val id: String,
    val index: Int,
    val titleAr: String,
    val categoryAr: String,
    val descriptionAr: String,
    val simulatedIssueAr: String,
    val pageCount: Int = 1
)
