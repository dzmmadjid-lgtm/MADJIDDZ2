import {
  BorderProperties,
  createDefaultBorder,
  LayoutObjectType,
  PageLayoutObject,
  TableCellModel,
  TextAlignment,
  TextDirection,
} from '../models/DocumentModel';
import { toWesternDigits } from './DocumentRenderer';
import { loadImageElement } from './ImagePreprocessor';

export interface VisionAnalysisResult {
  objects: PageLayoutObject[];
  margins: { top: number; right: number; bottom: number; left: number };
  usedServerVision: boolean;
  noticeAr?: string;
}

function normalizeObjectNumerals(obj: PageLayoutObject): PageLayoutObject {
  return {
    ...obj,
    content: toWesternDigits(obj.content || ''),
    uncertainTokens: (obj.uncertainTokens || []).map(toWesternDigits),
    tableStructure: obj.tableStructure
      ? {
          ...obj.tableStructure,
          cells: obj.tableStructure.cells.map((c) => ({
            ...c,
            content: toWesternDigits(c.content || ''),
            uncertainTokens: (c.uncertainTokens || []).map(toWesternDigits),
          })),
        }
      : undefined,
  };
}

function mapRawVisionObjectToLayoutObject(raw: any, index: number): PageLayoutObject {
  const type = (raw.type || 'PARAGRAPH') as LayoutObjectType;
  const direction: TextDirection = raw.direction === 'ltr' ? 'ltr' : 'rtl';
  const alignment: TextAlignment =
    raw.alignment === 'center' || raw.alignment === 'left' || raw.alignment === 'justify'
      ? raw.alignment
      : direction === 'rtl'
      ? 'right'
      : 'left';

  const borderThickness = typeof raw.borderThickness === 'number' ? raw.borderThickness : 1;
  const borderProps: BorderProperties = {
    top: {
      width: raw.hasBorderTop ? borderThickness : 0,
      style: raw.hasBorderTop ? 'solid' : 'none',
      color: '#0F172A',
    },
    right: {
      width: raw.hasBorderRight ? borderThickness : 0,
      style: raw.hasBorderRight ? 'solid' : 'none',
      color: '#0F172A',
    },
    bottom: {
      width: raw.hasBorderBottom ? borderThickness : 0,
      style: raw.hasBorderBottom ? 'solid' : 'none',
      color: '#0F172A',
    },
    left: {
      width: raw.hasBorderLeft ? borderThickness : 0,
      style: raw.hasBorderLeft ? 'solid' : 'none',
      color: '#0F172A',
    },
  };

  let tableStructure = undefined;
  if (type === 'TABLE' && raw.tableData) {
    const rows = Math.max(1, Number(raw.tableData.rows) || 2);
    const cols = Math.max(1, Number(raw.tableData.cols) || 2);
    const rowHeights: number[] =
      Array.isArray(raw.tableData.rowHeights) && raw.tableData.rowHeights.length === rows
        ? raw.tableData.rowHeights
        : Array.from({ length: rows }, () => 1 / rows);
    const colWidths: number[] =
      Array.isArray(raw.tableData.colWidths) && raw.tableData.colWidths.length === cols
        ? raw.tableData.colWidths
        : Array.from({ length: cols }, () => 1 / cols);

    const cells: TableCellModel[] = Array.isArray(raw.tableData.cells)
      ? raw.tableData.cells.map((c: any, ci: number) => ({
          id: `cell_${index}_${ci}`,
          row: Number(c.row) || 0,
          col: Number(c.col) || 0,
          rowSpan: Math.max(1, Number(c.rowSpan) || 1),
          colSpan: Math.max(1, Number(c.colSpan) || 1),
          content: toWesternDigits(typeof c.content === 'string' ? c.content : ''),
          confidence: typeof c.confidence === 'number' ? c.confidence : 0.92,
          alignment:
            c.alignment === 'center' || c.alignment === 'left' ? c.alignment : 'right',
          verticalAlignment: 'middle',
          direction: c.direction === 'ltr' ? 'ltr' : 'rtl',
          padding: 6,
          fontSizePt: Math.max(8, (Number(raw.estimatedFontSizePt) || 11) - 0.5),
          fontWeight: c.isHeader ? 'bold' : 'normal',
          borders: {
            top: {
              width: c.hasTopBorder !== false ? 1 : 0,
              style: c.hasTopBorder !== false ? 'solid' : 'none',
              color: '#1E293B',
            },
            right: {
              width: c.hasRightBorder !== false ? 1 : 0,
              style: c.hasRightBorder !== false ? 'solid' : 'none',
              color: '#1E293B',
            },
            bottom: {
              width: c.hasBottomBorder !== false ? 1 : 0,
              style: c.hasBottomBorder !== false ? 'solid' : 'none',
              color: '#1E293B',
            },
            left: {
              width: c.hasLeftBorder !== false ? 1 : 0,
              style: c.hasLeftBorder !== false ? 'solid' : 'none',
              color: '#1E293B',
            },
          },
          backgroundColor: c.isHeader ? '#F1F5F9' : 'transparent',
        }))
      : [];

    tableStructure = {
      rows,
      cols,
      rowHeights,
      colWidths,
      direction,
      cells,
    };
  }

  return normalizeObjectNumerals({
    id: raw.id || `obj_${index + 1}`,
    type,
    x: Math.max(0, Math.min(980, Number(raw.x) || 60)),
    y: Math.max(0, Math.min(980, Number(raw.y) || 60 + index * 70)),
    width: Math.max(20, Math.min(1000, Number(raw.width) || 880)),
    height: Math.max(8, Math.min(1000, Number(raw.height) || 50)),
    content: toWesternDigits(typeof raw.content === 'string' ? raw.content : ''),
    confidence: typeof raw.confidence === 'number' ? raw.confidence : 0.94,
    uncertainTokens: Array.isArray(raw.uncertainTokens)
      ? raw.uncertainTokens.map(toWesternDigits)
      : [],
    alignment,
    direction,
    fontProperties: {
      family: 'Cairo',
      sizePt: Math.max(8, Math.min(28, Number(raw.estimatedFontSizePt) || 12)),
      weight: raw.fontWeight === 'bold' ? 'bold' : 'normal',
      role: raw.fontRole || 'normal',
      color: '#0F172A',
      lineHeight: 1.4,
    },
    borderProperties: borderProps,
    backgroundProperties: {
      fill: raw.backgroundColor || 'transparent',
      opacity: raw.backgroundColor && raw.backgroundColor !== 'transparent' ? 1 : 0,
    },
    zOrder: index + 1,
    checked: Boolean(raw.checked),
    tableStructure,
  });
}

/**
 * Deterministic pixel-projection & connected-line analyzer for custom uploaded images
 * when the server-side Vision API is unavailable.
 */
async function fallbackSpatialLayoutDetector(
  imageDataUrl: string
): Promise<PageLayoutObject[]> {
  const img = await loadImageElement(imageDataUrl);
  const w = 500;
  const h = 707;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) return [];

  ctx.drawImage(img, 0, 0, w, h);
  const { data } = ctx.getImageData(0, 0, w, h);

  const rowInk = new Float32Array(h);
  for (let y = 0; y < h; y++) {
    let darkCount = 0;
    for (let x = 25; x < w - 25; x++) {
      const idx = (y * w + x) * 4;
      const luma = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
      if (luma < 175) darkCount++;
    }
    rowInk[y] = darkCount / (w - 50);
  }

  const bands: Array<{ yStart: number; yEnd: number; maxDensity: number }> = [];
  let inBand = false;
  let bStart = 0;
  let maxD = 0;

  for (let y = 20; y < h - 20; y++) {
    if (rowInk[y] > 0.025) {
      if (!inBand) {
        inBand = true;
        bStart = y;
        maxD = rowInk[y];
      } else if (rowInk[y] > maxD) {
        maxD = rowInk[y];
      }
    } else if (inBand) {
      if (y - bStart >= 6) {
        bands.push({ yStart: bStart, yEnd: y, maxDensity: maxD });
      }
      inBand = false;
    }
  }

  return bands.slice(0, 10).map((b, idx) => {
    const normY = Math.round((b.yStart / h) * 1000);
    const normH = Math.max(28, Math.round(((b.yEnd - b.yStart) / h) * 1000));
    const isLine = normH <= 12 && b.maxDensity > 0.55;

    return {
      id: `detected_region_${idx + 1}`,
      type: isLine ? 'LINE' : 'RECTANGLE',
      x: 70,
      y: normY,
      width: 860,
      height: normH,
      content: isLine
        ? ''
        : `[منطقة نصية مكتشفة #${idx + 1} — انقر هنا لتفريغ النص من الصورة المصدرية دون تخمين]`,
      confidence: 0.68,
      uncertainTokens: ['منطقة تتطلب تأكيد المستخدم'],
      alignment: 'right',
      direction: 'rtl',
      fontProperties: {
        family: 'Cairo',
        sizePt: 11,
        weight: idx === 0 ? 'bold' : 'normal',
        role: idx === 0 ? 'heading' : 'normal',
        color: '#0F172A',
        lineHeight: 1.35,
      },
      borderProperties: createDefaultBorder(1, 'dashed', '#D97706'),
      backgroundProperties: { fill: 'transparent', opacity: 0 },
      zOrder: idx + 1,
    };
  });
}

export async function analyzeDocumentWithVisionEngine(
  preprocessedImageDataUrl: string,
  presetObjects?: PageLayoutObject[]
): Promise<VisionAnalysisResult> {
  if (presetObjects && presetObjects.length > 0) {
    return {
      objects: presetObjects.map((o) =>
        normalizeObjectNumerals(JSON.parse(JSON.stringify(o)))
      ),
      margins: { top: 55, right: 60, bottom: 55, left: 60 },
      usedServerVision: false,
    };
  }

  try {
    const base64Data = preprocessedImageDataUrl.replace(/^data:image\/\w+;base64,/, '');
    const res = await fetch('/api/reconstruct-document', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        imageBase64: base64Data,
        mimeType: 'image/png',
      }),
    });

    if (res.ok) {
      const payload = await res.json();
      if (payload?.success && Array.isArray(payload.data?.objects) && payload.data.objects.length > 0) {
        const mapped = payload.data.objects.map((raw: any, i: number) =>
          mapRawVisionObjectToLayoutObject(raw, i)
        );
        return {
          objects: mapped,
          margins: payload.data.estimatedMargins || { top: 55, right: 60, bottom: 55, left: 60 },
          usedServerVision: true,
        };
      }
    }
  } catch {
    // Fall back to spatial band detector without hallucinating content
  }

  const fallbackObjects = await fallbackSpatialLayoutDetector(preprocessedImageDataUrl);
  return {
    objects: fallbackObjects.map(normalizeObjectNumerals),
    margins: { top: 60, right: 70, bottom: 60, left: 70 },
    usedServerVision: false,
    noticeAr:
      'تم تحديد مناطق وإحداثيات الفقرات هندسياً من الصورة المرفوعة (مع التزام القاعدة الصارمة بعدم تخمين أو اختراع نصوص غير مؤكدة). يمكنك تحرير أي حقل مباشرة من المفتش اليدوي.',
  };
}
