import React, { useState } from 'react';
import {
  ANDROID_PACKAGE_NAME,
  ANDROID_SOURCE_FILES,
  downloadAndroidProjectZip,
} from '../engines/AndroidProjectGenerator';
import { ThemeMode } from '../models/DocumentModel';
import { Check, Copy, Download, FileCode, X } from 'lucide-react';

interface AndroidArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
}

export const AndroidArchitectureModal: React.FC<AndroidArchitectureModalProps> = ({
  isOpen,
  onClose,
  theme,
}) => {
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  if (!isOpen) return null;

  const activeFile = ANDROID_SOURCE_FILES[selectedFileIndex] || ANDROID_SOURCE_FILES[0];

  const modalClass =
    theme === 'oled'
      ? 'bg-[#050505] border-[#222222] text-white'
      : theme === 'night'
      ? 'bg-slate-900 border-slate-700 text-slate-100'
      : 'bg-white border-slate-200 text-slate-900';

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
      <div
        className={`w-full max-w-5xl rounded-xl border shadow-2xl overflow-hidden flex flex-col max-h-[88vh] ${modalClass}`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-current/10">
          <div>
            <h2 className="text-base font-bold">
              مشروع الأندرويد الكامل القابل للترجمة — حزمة: {ANDROID_PACKAGE_NAME}
            </h2>
            <p className="text-xs opacity-70 mt-0.5">
              معمارية أندرويد متعددة الطبقات (Kotlin + Compose + PdfDocument) مع أيقونة PDF الحمراء وسمات Day / Night / OLED
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadZip}
              disabled={isDownloading}
              className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap"
            >
              <Download className="w-4 h-4" />
              <span>{isDownloading ? 'جاري تجهيز الأرشيف...' : 'تنزيل مشروع Android (ZIP)'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-current/10 transition-colors"
              aria-label="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="grid grid-cols-1 md:grid-cols-12 flex-1 min-h-0">
          {/* Sidebar file list */}
          <div className="md:col-span-4 border-l border-current/10 overflow-y-auto p-3 space-y-1.5">
            {ANDROID_SOURCE_FILES.map((file, idx) => {
              const isSelected = idx === selectedFileIndex;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedFileIndex(idx)}
                  className={`w-full text-right p-2.5 rounded-lg border text-xs transition-colors flex flex-col gap-0.5 ${
                    isSelected
                      ? 'border-red-600 bg-red-600/10 font-semibold'
                      : 'border-transparent hover:bg-current/5'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[11px] truncate dir-ltr text-left">
                      {file.path.split('/').pop()}
                    </span>
                    <FileCode className="w-3.5 h-3.5 text-red-500 shrink-0" />
                  </div>
                  <span className="text-[11px] opacity-80">{file.titleAr}</span>
                </button>
              );
            })}
          </div>

          {/* Code Viewer */}
          <div className="md:col-span-8 flex flex-col min-h-0">
            <div className="flex items-center justify-between px-4 py-2.5 border-b border-current/10 bg-current/[0.03]">
              <span className="font-mono text-xs opacity-80" dir="ltr">
                {activeFile.path}
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="px-3 py-1 rounded border border-current/20 text-xs flex items-center gap-1.5 hover:bg-current/10"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'تم النسخ' : 'نسخ الكود'}</span>
              </button>
            </div>
            <pre
              dir="ltr"
              className="flex-1 overflow-auto p-4 text-xs font-mono leading-relaxed bg-black/90 text-slate-100"
            >
              <code>{activeFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
