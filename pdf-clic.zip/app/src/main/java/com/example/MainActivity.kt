package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.theme.AppThemeMode
import com.example.theme.ClickSchoolTheme
import com.example.theme.ThemePreferences
import com.example.ui.home.HomeScreen
import com.example.ui.reader.PdfReaderScreen
import com.example.ui.tools.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val themePreferences = ThemePreferences(applicationContext)

        setContent {
            val themeMode by themePreferences.themeMode.collectAsState(initial = AppThemeMode.SYSTEM)

            val isDark = when (themeMode) {
                AppThemeMode.SYSTEM -> isSystemInDarkTheme()
                AppThemeMode.LIGHT -> false
                AppThemeMode.DARK -> true
                AppThemeMode.OLED -> true
            }

            DisposableEffect(isDark) {
                enableEdgeToEdge(
                    statusBarStyle = if (isDark) {
                        SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(
                            android.graphics.Color.TRANSPARENT,
                            android.graphics.Color.TRANSPARENT
                        )
                    },
                    navigationBarStyle = if (isDark) {
                        SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(
                            android.graphics.Color.TRANSPARENT,
                            android.graphics.Color.TRANSPARENT
                        )
                    }
                )
                onDispose {}
            }

            ClickSchoolTheme(
                themeMode = themeMode,
                forceRtl = true
            ) {
                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = "home",
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable("home") {
                        HomeScreen(
                            onNavigateToReader = { uri ->
                                if (uri != null) {
                                    val encoded = Uri.encode(uri.toString())
                                    navController.navigate("reader?uri=$encoded")
                                } else {
                                    navController.navigate("reader")
                                }
                            },
                            onNavigateToImagesToPdf = { navController.navigate("images_to_pdf") },
                            onNavigateToPdfToImages = { navController.navigate("pdf_to_images") },
                            onNavigateToMerge = { navController.navigate("merge") },
                            onNavigateToSplit = { navController.navigate("split") },
                            onNavigateToPageManager = { navController.navigate("page_manager") },
                            onNavigateToCrop = { navController.navigate("crop") },
                            onNavigateToTextToPdf = { navController.navigate("text_to_pdf") },
                            onNavigateToScanner = { navController.navigate("scanner") },
                            onNavigateToWifiScanner = { navController.navigate("wifi_scanner") },
                            onNavigateToOrdinaryPrint = { navController.navigate("ordinary_print") },
                            onNavigateToDirectPrint = { navController.navigate("direct_print") },
                            onNavigateToViewer = { navController.navigate("viewer") },
                            onNavigateToSettings = { navController.navigate("settings") }
                        )
                    }

                    composable(
                        route = "reader?uri={uri}",
                        arguments = listOf(
                            navArgument("uri") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            }
                        )
                    ) { backStackEntry ->
                        val uriStr = backStackEntry.arguments?.getString("uri")
                        val uri = if (uriStr != null) Uri.parse(Uri.decode(uriStr)) else null
                        PdfReaderScreen(
                            initialUri = uri,
                            onNavigateBack = { navController.popBackStack() },
                            onNavigateToPageManager = { docUri ->
                                val encoded = Uri.encode(docUri.toString())
                                navController.navigate("page_manager?uri=$encoded")
                            }
                        )
                    }

                    composable("images_to_pdf") {
                        ImageToPdfScreen(onNavigateBack = { navController.popBackStack() })
                    }

                    composable("pdf_to_images") {
                        PdfToImageScreen(onNavigateBack = { navController.popBackStack() })
                    }

                    composable("merge") {
                        MergePdfScreen(onNavigateBack = { navController.popBackStack() })
                    }

                    composable("split") {
                        SplitPdfScreen(onNavigateBack = { navController.popBackStack() })
                    }

                    composable(
                        route = "page_manager?uri={uri}",
                        arguments = listOf(
                            navArgument("uri") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            }
                        )
                    ) { backStackEntry ->
                        val uriStr = backStackEntry.arguments?.getString("uri")
                        val uri = if (uriStr != null) Uri.parse(Uri.decode(uriStr)) else null
                        PageManagerScreen(
                            initialUri = uri,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable("crop") {
                        CropPdfScreen(onNavigateBack = { navController.popBackStack() })
                    }

                    composable("text_to_pdf") {
                        TextToPdfScreen(onNavigateBack = { navController.popBackStack() })
                    }

                    composable("scanner") {
                        DocumentScannerScreen(onNavigateBack = { navController.popBackStack() })
                    }

                    composable("wifi_scanner") {
                        WifiScannerScreen(onNavigateBack = { navController.popBackStack() })
                    }

                    composable("ordinary_print") {
                        OrdinaryPrintScreen(onNavigateBack = { navController.popBackStack() })
                    }

                    composable("direct_print") {
                        DirectPrintScreen(onNavigateBack = { navController.popBackStack() })
                    }

                    composable("viewer") {
                        DocumentViewerScreen(
                            onNavigateBack = { navController.popBackStack() },
                            onNavigateToPdfReader = { docUri ->
                                val encoded = Uri.encode(docUri.toString())
                                navController.navigate("reader?uri=$encoded")
                            }
                        )
                    }

                    composable("settings") {
                        SettingsScreen(
                            themePreferences = themePreferences,
                            currentThemeMode = themeMode,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
