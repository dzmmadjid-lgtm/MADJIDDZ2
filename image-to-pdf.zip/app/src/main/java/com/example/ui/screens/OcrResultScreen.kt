package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.image.ImageUtils
import com.example.data.model.DetectedLanguage
import com.example.data.model.OcrPageResult
import com.example.data.model.RegionType
import com.example.data.model.ScanPage
import com.example.data.model.SelectionUnit
import com.example.data.model.TextRegion
import com.example.ui.components.ZoomableDocumentView
import com.example.ui.theme.PdfRedPrimary
import com.example.ui.theme.RegionGraphicColor
import com.example.ui.theme.RegionListColor
import com.example.ui.theme.RegionNumberColor
import com.example.ui.theme.RegionParagraphColor
import com.example.ui.theme.RegionTableCellColor
import com.example.ui.theme.RegionTitleColor
import kotlinx.coroutines.launch

@Composable
fun OcrResultScreen(
    pages: List<ScanPage>,
    currentPageIndex: Int,
    cachedBitmaps: Map<String, Bitmap>,
    reconstructedBitmaps: Map<String, Bitmap>,
    isReconstructedViewActive: Boolean,
    activeViewTab: Int,
    selectedRegionId: String?,
    selectionUnit: SelectionUnit,
    customSelectedText: String?,
    searchQuery: String,
    searchMatchCount: Int,
    onSelectPage: (Int) -> Unit,
    onSetActiveViewTab: (Int) -> Unit,
    onToggleReconstructedView: (Boolean) -> Unit,
    onSelectRegion: (String?) -> Unit,
    onSetSelectionUnit: (SelectionUnit) -> Unit,
    onUpdateSearchQuery: (String) -> Unit,
    onCopyText: ((String) -> Unit) -> Unit,
    onShareText: () -> Unit,
    onShareCleanImage: () -> Unit,
    onOpenExportDialog: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var showSearchBar by remember { mutableStateOf(false) }
    var showRegionsOverlay by remember { mutableStateOf(false) }

    val currentPage = pages.getOrNull(currentPageIndex)
    val rawBitmap = currentPage?.let { cachedBitmaps[it.id] }
    val reconstructedBitmap = currentPage?.let { reconstructedBitmaps[it.id] }

    val enhancedOriginal = remember(rawBitmap, currentPage?.enhancementMode) {
        if (rawBitmap != null && currentPage != null) {
            ImageUtils.applyEnhancement(rawBitmap, currentPage.enhancementMode)
        } else {
            rawBitmap
        }
    }

    // Active bitmap to display: reconstructed clean sheet or enhanced original
    val displayBitmap = if (isReconstructedViewActive && reconstructedBitmap != null) {
        reconstructedBitmap
    } else {
        enhancedOriginal
    }

    val ocrResult = currentPage?.ocrResult

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("ocr_result_back_button")) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isReconstructedViewActive) "النسخة النظيفة المعاد إنشاؤها" else "معاينة الورقة الأصلية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (ocrResult != null) {
                                Text(
                                    text = "صفحة ${currentPageIndex + 1}/${pages.size} • ${ocrResult.stats.wordCount} كلمة • ${ocrResult.primaryLanguage.labelAr}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Search Toggle
                        IconButton(
                            onClick = { showSearchBar = !showSearchBar },
                            modifier = Modifier.testTag("toggle_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "بحث",
                                tint = if (showSearchBar) PdfRedPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Share clean image
                        IconButton(
                            onClick = onShareCleanImage,
                            modifier = Modifier.testTag("share_clean_image_button")
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = "مشاركة الصورة النظيفة", tint = PdfRedPrimary)
                        }

                        // Export PDF Action
                        Button(
                            onClick = onOpenExportDialog,
                            colors = ButtonDefaults.buttonColors(containerColor = PdfRedPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("open_export_pdf_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تصدير PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Search Bar
                    AnimatedVisibility(visible = showSearchBar) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = onUpdateSearchQuery,
                                placeholder = { Text("بحث عن كلمة أو رقم داخل النص...") },
                                singleLine = true,
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { onUpdateSearchQuery("") }) {
                                            Icon(imageVector = Icons.Default.Close, contentDescription = "مسح")
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("search_text_input")
                            )
                            if (searchQuery.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "$searchMatchCount مطابقة",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = PdfRedPrimary
                                )
                            }
                        }
                    }

                    // View Modes Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Switch between Reconstructed and Original
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = isReconstructedViewActive,
                                onClick = { onToggleReconstructedView(true) },
                                label = { Text("⚡ نسخة نظيفة معاد إنشاؤها", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PdfRedPrimary,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("tab_clean_reconstructed")
                            )

                            FilterChip(
                                selected = !isReconstructedViewActive,
                                onClick = { onToggleReconstructedView(false) },
                                label = { Text("صورة المسح", fontSize = 11.sp) },
                                modifier = Modifier.testTag("tab_original_scan")
                            )
                        }

                        // Toggle Overlay Regions
                        FilterChip(
                            selected = showRegionsOverlay,
                            onClick = { showRegionsOverlay = !showRegionsOverlay },
                            label = { Text("المناطق", fontSize = 11.sp) },
                            modifier = Modifier.testTag("toggle_regions_overlay")
                        )
                    }
                }
            }
        },
        bottomBar = {
            // Interactive Text Selection & Actions Bar
            BottomSelectionBar(
                selectionUnit = selectionUnit,
                onSetSelectionUnit = onSetSelectionUnit,
                onCopy = {
                    onCopyText { message ->
                        scope.launch { snackbarHostState.showSnackbar(message) }
                    }
                },
                onShare = onShareText
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Main Maximized Document Canvas (fills whole screen with no large black box)
            if (displayBitmap != null) {
                ZoomableDocumentView(
                    bitmap = displayBitmap,
                    regions = ocrResult?.regions ?: emptyList(),
                    selectedRegionId = selectedRegionId,
                    onRegionSelected = onSelectRegion,
                    showRegionsOverlay = showRegionsOverlay,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("جاري عرض المستند...", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // Multi-Page Switcher (if pages > 1)
            if (pages.size > 1) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                    tonalElevation = 4.dp,
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 8.dp)
                ) {
                    LazyRow(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        itemsIndexed(pages) { idx, _ ->
                            val isSelected = idx == currentPageIndex
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectPage(idx) },
                                label = { Text("صفحة ${idx + 1}", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PdfRedPrimary,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("ocr_page_tab_$idx")
                            )
                        }
                    }
                }
            }

            // Selected Region Detail Sheet Card (Floating at bottom if a region is tapped)
            val selectedRegion = ocrResult?.regions?.find { it.id == selectedRegionId }
            if (selectedRegion != null) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(12.dp)
                        .fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RegionBadge(type = selectedRegion.type)
                                Spacer(modifier = Modifier.width(6.dp))
                                LanguageBadge(language = selectedRegion.language)
                            }

                            IconButton(onClick = { onSelectRegion(null) }, modifier = Modifier.size(24.dp)) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "إلغاء التحديد")
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = selectedRegion.text,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomSelectionBar(
    selectionUnit: SelectionUnit,
    onSetSelectionUnit: (SelectionUnit) -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            // Selection Units Row ("تحديد النص: كلمة، جملة، فقرة، كل النص")
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تحديد:",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(6.dp))

                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (unit in SelectionUnit.entries) {
                        val isSelected = selectionUnit == unit
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) PdfRedPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { onSetSelectionUnit(unit) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("select_unit_${unit.name}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = unit.labelAr,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Copy and Share icon actions
                IconButton(onClick = onCopy, modifier = Modifier.size(34.dp).testTag("copy_text_button")) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "نسخ", tint = PdfRedPrimary, modifier = Modifier.size(18.dp))
                }

                IconButton(onClick = onShare, modifier = Modifier.size(34.dp).testTag("share_text_button")) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = "مشاركة", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
private fun RegionBadge(type: RegionType) {
    val (color, text) = when (type) {
        RegionType.TITLE -> Pair(RegionTitleColor, "عنوان")
        RegionType.PARAGRAPH -> Pair(RegionParagraphColor, "فقرة")
        RegionType.LIST_ITEM -> Pair(RegionListColor, "قائمة")
        RegionType.NUMBER -> Pair(RegionNumberColor, "أرقام")
        RegionType.TABLE_CELL -> Pair(RegionTableCellColor, "جدول")
        RegionType.GRAPHIC_OR_PHOTO -> Pair(RegionGraphicColor, "رسم/صورة")
        RegionType.SHORT_TEXT -> Pair(Color(0xFF00897B), "نص قصير")
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp
        )
    }
}

@Composable
private fun LanguageBadge(language: DetectedLanguage) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = language.labelAr,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 9.sp
        )
    }
}
