import { jsPDF } from 'jspdf';
import {
  BorderSide,
  PageLayoutObject,
  ProcessingMode,
  ReconstructedPage,
} from '../models/DocumentModel';
import { renderPageToCanvasAsync, toWesternDigits } from './DocumentRenderer';
import { loadImageElement } from './ImagePreprocessor';

export type ExportFormat = 'PDF' | 'PNG' | 'JPG';
export type ExportDpi = 150 | 300 | 400;

export interface ExportOptions {
  format: ExportFormat;
  dpi: ExportDpi;
  jpgQuality: number; // 0.80 to 1.00
  processingMode: ProcessingMode;
  keepHandwriting?: boolean;
  filenamePrefix: string;
}

let cachedArabicFontBase64: string | null = null;

/**
 * Fetches and caches the Amiri Arabic/Latin TrueType font (TTF) as base64
 * so it can be embedded directly inside the jsPDF vector document.
 */
async function loadEmbeddedArabicFontBase64(): Promise<string | null> {
  if (cachedArabicFontBase64) return cachedArabicFontBase64;
  try {
    const ttfUrl =
      'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/amiri/Amiri-Regular.ttf';
    const res = await fetch(ttfUrl);
    if (!res.ok) return null;
    const buf = await res.arrayBuffer();
    const bytes = new Uint8Array(buf);
    let binary = '';
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    cachedArabicFontBase64 = btoa(binary);
    return cachedArabicFontBase64;
  } catch {
    return null;
  }
}

function hexToRgb(hex: string): [number, number, number] {
  const clean = (hex || '#0F172A').replace('#', '').trim();
  if (clean.length === 3) {
    return [
      parseInt(clean[0] + clean[0], 16) || 15,
      parseInt(clean[1] + clean[1], 16) || 23,
      parseInt(clean[2] + clean[2], 16) || 42,
    ];
  }
  const num = parseInt(clean.slice(0, 6), 16);
  if (Number.isNaN(num)) return [15, 23, 42];
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

function drawVectorBorderSideMm(
  pdf: jsPDF,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  side: BorderSide
) {
  if (!side || side.style === 'none' || side.width <= 0) return;
  const [r, g, b] = hexToRgb(side.color || '#0F172A');
  pdf.setDrawColor(r, g, b);
  pdf.setLineWidth(Math.max(0.18, side.width * 0.25));

  if (side.style === 'dotted') {
    pdf.setLineDashPattern([0.5, 0.9], 0);
  } else if (side.style === 'dashed') {
    pdf.setLineDashPattern([1.6, 1.1], 0);
  } else {
    pdf.setLineDashPattern([], 0);
  }

  pdf.line(x1, y1, x2, y2);
  pdf.setLineDashPattern([], 0);
}

function drawVectorBoxBordersMm(
  pdf: jsPDF,
  x: number,
  y: number,
  w: number,
  h: number,
  borders: PageLayoutObject['borderProperties']
) {
  drawVectorBorderSideMm(pdf, x, y, x + w, y, borders.top);
  drawVectorBorderSideMm(pdf, x + w, y, x + w, y + h, borders.right);
  drawVectorBorderSideMm(pdf, x, y + h, x + w, y + h, borders.bottom);
  drawVectorBorderSideMm(pdf, x, y, x, y + h, borders.left);
}

function drawSelectableVectorTextMm(
  pdf: jsPDF,
  rawText: string,
  xMm: number,
  yMm: number,
  wMm: number,
  hMm: number,
  opts: {
    fontSizePt: number;
    color: string;
    align: 'right' | 'center' | 'left' | 'justify';
    dir: 'rtl' | 'ltr';
    lineHeight: number;
    verticalAlign?: 'top' | 'middle' | 'bottom';
    paddingMm?: number;
  }
) {
  const cleanText = toWesternDigits(rawText || '');
  if (!cleanText.trim()) return;

  const pad = opts.paddingMm ?? 1.2;
  const innerX = xMm + pad;
  const innerY = yMm + pad;
  const innerW = Math.max(4, wMm - pad * 2);
  const innerH = Math.max(3, hMm - pad * 2);

  const [r, g, b] = hexToRgb(opts.color || '#0F172A');
  pdf.setTextColor(r, g, b);

  // Fit font size to measured bbox height/width
  let fontSizePt = Math.max(7, opts.fontSizePt);
  pdf.setFontSize(fontSizePt);

  const rawLines = cleanText.replace(/[.…]{5,}/g, '').split('\n');
  const wrappedLines: string[] = [];
  for (const rl of rawLines) {
    const split = pdf.splitTextToSize(rl.trim(), innerW);
    if (Array.isArray(split)) {
      wrappedLines.push(...split);
    } else if (typeof split === 'string') {
      wrappedLines.push(split);
    }
  }

  const ptToMm = 0.352778;
  while (
    fontSizePt > 6.5 &&
    wrappedLines.length * fontSizePt * ptToMm * (opts.lineHeight || 1.3) > innerH + 1.2
  ) {
    fontSizePt -= 0.5;
  }
  pdf.setFontSize(fontSizePt);

  const lineStepMm = fontSizePt * ptToMm * (opts.lineHeight || 1.3);
  const totalTextHMm = wrappedLines.length * lineStepMm;

  let startYMm = innerY + fontSizePt * ptToMm * 0.82;
  if (opts.verticalAlign === 'middle') {
    startYMm =
      innerY +
      Math.max(fontSizePt * ptToMm * 0.78, (innerH - totalTextHMm) / 2 + fontSizePt * ptToMm * 0.78);
  }

  const effectiveAlign =
    opts.align === 'justify' ? (opts.dir === 'rtl' ? 'right' : 'left') : opts.align;

  let anchorX = innerX;
  if (effectiveAlign === 'right') {
    anchorX = innerX + innerW;
  } else if (effectiveAlign === 'center') {
    anchorX = innerX + innerW / 2;
  }

  for (let i = 0; i < wrappedLines.length; i++) {
    const lineYMm = startYMm + i * lineStepMm;
    if (lineYMm > yMm + hMm + 1.5) break;
    const lineStr = wrappedLines[i];
    if (lineStr && lineStr.trim()) {
      pdf.text(lineStr, anchorX, lineYMm, {
        align: effectiveAlign,
      });
    }
  }
}

/**
 * Step 7: Renders one vector A4 page (210mm x 297mm, 0 margins) into jsPDF
 * with selectable text, embedded font, vector lines/dotted lines, and measured table grids.
 */
async function renderVectorPageToJsPdf(
  pdf: jsPDF,
  page: ReconstructedPage,
  keepHandwriting: boolean
) {
  const sorted = [...page.objects].sort((a, b) => a.zOrder - b.zOrder);

  for (const obj of sorted) {
    if (obj.type === 'HANDWRITING' && !keepHandwriting) continue;

    // Derived directly from normalized 0..1000 coordinates -> 210mm x 297mm (0 margins)
    const xMm = (obj.x / 1000) * 210;
    const yMm = (obj.y / 1000) * 297;
    const wMm = (obj.width / 1000) * 210;
    const hMm = (obj.height / 1000) * 297;

    // 1. Background fill
    if (
      obj.backgroundProperties.fill &&
      obj.backgroundProperties.fill !== 'transparent' &&
      obj.backgroundProperties.opacity > 0
    ) {
      const [r, g, b] = hexToRgb(obj.backgroundProperties.fill);
      pdf.setFillColor(r, g, b);
      pdf.rect(xMm, yMm, wMm, hMm, 'F');
    }

    // 2. Vector DOTTED_LINE or LINE
    if (obj.type === 'DOTTED_LINE') {
      drawVectorBorderSideMm(pdf, xMm, yMm + hMm / 2, xMm + wMm, yMm + hMm / 2, {
        width: obj.borderProperties.top.width || 1.4,
        style: 'dotted',
        color: obj.borderProperties.top.color || '#334155',
      });
      continue;
    }

    if (obj.type === 'LINE') {
      const isHoriz = wMm >= hMm;
      const side: BorderSide =
        obj.borderProperties.top.width > 0
          ? obj.borderProperties.top
          : { width: 1.4, style: 'solid', color: obj.fontProperties.color || '#0F172A' };
      if (isHoriz) {
        drawVectorBorderSideMm(pdf, xMm, yMm + hMm / 2, xMm + wMm, yMm + hMm / 2, side);
      } else {
        drawVectorBorderSideMm(pdf, xMm + wMm / 2, yMm, xMm + wMm / 2, yMm + hMm, side);
      }
      continue;
    }

    // 3. Vector Structured TABLE with exact measured rowHeights & colWidths
    if (obj.type === 'TABLE' && obj.tableStructure) {
      const table = obj.tableStructure;
      const sumR = table.rowHeights.reduce((a, b) => a + b, 0) || 1;
      const normRowH = table.rowHeights.map((rh) => rh / sumR);
      const sumC = table.colWidths.reduce((a, b) => a + b, 0) || 1;
      const normColW = table.colWidths.map((cw) => cw / sumC);

      const rowYMm: number[] = [yMm];
      for (let r = 0; r < table.rows; r++) {
        rowYMm.push(rowYMm[r] + normRowH[r] * hMm);
      }

      const colXMm: number[] = [];
      const colWMm: number[] = [];
      if (table.direction === 'rtl') {
        let cursorRight = xMm + wMm;
        for (let c = 0; c < table.cols; c++) {
          const cw = normColW[c] * wMm;
          colWMm.push(cw);
          colXMm.push(cursorRight - cw);
          cursorRight -= cw;
        }
      } else {
        let cursorLeft = xMm;
        for (let c = 0; c < table.cols; c++) {
          const cw = normColW[c] * wMm;
          colWMm.push(cw);
          colXMm.push(cursorLeft);
          cursorLeft += cw;
        }
      }

      for (const cell of table.cells) {
        if (cell.hiddenByMerge) continue;
        const rStart = Math.max(0, Math.min(table.rows - 1, cell.row));
        const rEnd = Math.max(rStart + 1, Math.min(table.rows, rStart + (cell.rowSpan || 1)));
        const cStart = Math.max(0, Math.min(table.cols - 1, cell.col));
        const cEnd = Math.max(cStart + 1, Math.min(table.cols, cStart + (cell.colSpan || 1)));

        const cellY = rowYMm[rStart];
        const cellH = rowYMm[rEnd] - rowYMm[rStart];

        let cellX = colXMm[cStart];
        let cellW = 0;
        if (table.direction === 'rtl') {
          cellX = colXMm[cEnd - 1];
          for (let c = cStart; c < cEnd; c++) cellW += colWMm[c];
        } else {
          cellX = colXMm[cStart];
          for (let c = cStart; c < cEnd; c++) cellW += colWMm[c];
        }

        if (cell.backgroundColor && cell.backgroundColor !== 'transparent') {
          const [r, g, b] = hexToRgb(cell.backgroundColor);
          pdf.setFillColor(r, g, b);
          pdf.rect(cellX, cellY, cellW, cellH, 'F');
        }

        drawVectorBoxBordersMm(pdf, cellX, cellY, cellW, cellH, cell.borders);

        drawSelectableVectorTextMm(pdf, cell.content, cellX, cellY, cellW, cellH, {
          fontSizePt: cell.fontSizePt || obj.fontProperties.sizePt,
          color: obj.fontProperties.color || '#0F172A',
          align: cell.alignment,
          dir: cell.direction,
          lineHeight: 1.25,
          verticalAlign: cell.verticalAlignment || 'middle',
          paddingMm: 1.2,
        });
      }

      drawVectorBoxBordersMm(pdf, xMm, yMm, wMm, hMm, obj.borderProperties);
      continue;
    }

    // 4. Vector CHECKBOX
    if (obj.type === 'CHECKBOX') {
      const boxSizeMm = Math.min(wMm, hMm, 4.2);
      const boxX = obj.direction === 'rtl' ? xMm + wMm - boxSizeMm - 0.8 : xMm + 0.8;
      const boxY = yMm + (hMm - boxSizeMm) / 2;

      pdf.setDrawColor(15, 23, 42);
      pdf.setLineWidth(0.35);
      pdf.rect(boxX, boxY, boxSizeMm, boxSizeMm, 'S');

      if (obj.checked) {
        pdf.setLineWidth(0.45);
        pdf.line(
          boxX + boxSizeMm * 0.2,
          boxY + boxSizeMm * 0.52,
          boxX + boxSizeMm * 0.44,
          boxY + boxSizeMm * 0.78
        );
        pdf.line(
          boxX + boxSizeMm * 0.44,
          boxY + boxSizeMm * 0.78,
          boxX + boxSizeMm * 0.82,
          boxY + boxSizeMm * 0.22
        );
      }

      const labelX = obj.direction === 'rtl' ? xMm : boxX + boxSizeMm + 1.5;
      const labelW = Math.max(4, wMm - boxSizeMm - 2.5);
      drawSelectableVectorTextMm(pdf, obj.content, labelX, yMm, labelW, hMm, {
        fontSizePt: obj.fontProperties.sizePt,
        color: obj.fontProperties.color || '#0F172A',
        align: obj.alignment,
        dir: obj.direction,
        lineHeight: 1.25,
        verticalAlign: 'middle',
        paddingMm: 0.5,
      });
      continue;
    }

    // 5. Vector Stamp / Drawing / Handwriting crop
    if (obj.type === 'IMAGE' || obj.type === 'DRAWING' || obj.type === 'HANDWRITING') {
      if (obj.croppedImageDataUrl) {
        pdf.addImage(obj.croppedImageDataUrl, 'PNG', xMm, yMm, wMm, hMm, undefined, 'FAST');
      } else {
        const [r, g, b] = hexToRgb(obj.stampColor || obj.fontProperties.color || '#1D4ED8');
        pdf.setDrawColor(r, g, b);
        pdf.setLineWidth(0.45);
        pdf.ellipse(xMm + wMm / 2, yMm + hMm / 2, wMm * 0.46, hMm * 0.44, 'S');
        if (obj.content) {
          drawSelectableVectorTextMm(pdf, obj.content, xMm, yMm, wMm, hMm, {
            fontSizePt: obj.fontProperties.sizePt,
            color: obj.stampColor || obj.fontProperties.color || '#1D4ED8',
            align: 'center',
            dir: obj.direction,
            lineHeight: 1.25,
            verticalAlign: 'middle',
          });
        }
      }
      continue;
    }

    // 6. Standard TEXT, PARAGRAPH, RECTANGLE, SIGNATURE_AREA
    drawVectorBoxBordersMm(pdf, xMm, yMm, wMm, hMm, obj.borderProperties);
    drawSelectableVectorTextMm(pdf, obj.content, xMm, yMm, wMm, hMm, {
      fontSizePt: obj.fontProperties.sizePt,
      color: obj.fontProperties.color || '#0F172A',
      align: obj.alignment,
      dir: obj.direction,
      lineHeight: obj.fontProperties.lineHeight || 1.38,
      verticalAlign: obj.type === 'RECTANGLE' ? 'middle' : 'top',
      paddingMm: obj.type === 'RECTANGLE' ? 1.8 : 0.8,
    });
  }
}

function getPixelDimensionsForDpi(dpi: ExportDpi, aspectRatio = 210 / 297) {
  const widthInches = 8.27; // A4 width
  const widthPx = Math.round(widthInches * dpi);
  const heightPx = Math.round(widthPx / aspectRatio);
  return { widthPx, heightPx };
}

async function renderPageForRasterExport(
  page: ReconstructedPage,
  options: ExportOptions
): Promise<HTMLCanvasElement> {
  const { widthPx, heightPx } = getPixelDimensionsForDpi(
    options.dpi,
    page.aspectRatio || 210 / 297
  );
  const canvas = document.createElement('canvas');
  canvas.width = widthPx;
  canvas.height = heightPx;

  if (options.processingMode === 'MODE_B_IMAGE_CLEANING') {
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, widthPx, heightPx);
      const cleanedImg = await loadImageElement(
        options.keepHandwriting
          ? page.cleanedModeBImageDataUrl
          : page.preprocessedImageDataUrl || page.sourceImageDataUrl
      );
      ctx.drawImage(cleanedImg, 0, 0, widthPx, heightPx);
    }
    return canvas;
  }

  await renderPageToCanvasAsync(canvas, page.objects, {
    widthPx,
    heightPx,
    keepHandwriting: Boolean(options.keepHandwriting ?? page.preprocessing.keepHandwriting),
    highlightLowConfidence: false,
    showBoundingBoxes: false,
  });

  return canvas;
}

function triggerBlobDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

export async function exportReconstructedDocument(
  pages: ReconstructedPage[],
  options: ExportOptions
): Promise<{ filename: string; sizeKb: number; dimensionsLabel: string }> {
  if (!pages || pages.length === 0) {
    throw new Error('لا توجد صفحات جاهزة للتصدير.');
  }

  const firstDims = getPixelDimensionsForDpi(options.dpi, pages[0].aspectRatio || 210 / 297);
  const modeSuffix =
    options.processingMode === 'MODE_A_CLEAN_RECONSTRUCTION' ? 'vector_a4' : 'cleaned';
  const cleanPrefix = (options.filenamePrefix || 'crimson_doc').replace(
    /[^a-zA-Z0-9_\u0600-\u06FF-]/g,
    '_'
  );

  if (options.format === 'PDF') {
    // Step 7: Vector PDF, A4 (210mm x 297mm), margins 0, one page per source page, text selectable, fonts embedded
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: [210, 297],
      compress: true,
    });

    const fontB64 = await loadEmbeddedArabicFontBase64();
    if (fontB64) {
      pdf.addFileToVFS('Amiri-Regular.ttf', fontB64);
      pdf.addFont('Amiri-Regular.ttf', 'Amiri', 'normal');
      pdf.setFont('Amiri', 'normal');
    }

    for (let i = 0; i < pages.length; i++) {
      if (i > 0) {
        pdf.addPage([210, 297], 'portrait');
        if (fontB64) pdf.setFont('Amiri', 'normal');
      }

      const keepHw = Boolean(options.keepHandwriting ?? pages[i].preprocessing.keepHandwriting);

      if (options.processingMode === 'MODE_B_IMAGE_CLEANING') {
        const canvas = await renderPageForRasterExport(pages[i], options);
        const imgDataUrl = canvas.toDataURL('image/jpeg', 0.98);
        pdf.addImage(imgDataUrl, 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
      } else {
        await renderVectorPageToJsPdf(pdf, pages[i], keepHw);
      }
    }

    const pdfBlob = pdf.output('blob');
    const filename = `${cleanPrefix}_${modeSuffix}_210x297mm.pdf`;
    triggerBlobDownload(pdfBlob, filename);

    return {
      filename,
      sizeKb: Math.max(1, Math.round(pdfBlob.size / 1024)),
      dimensionsLabel: `Vector A4 · 210 × 297 mm · Margins 0 · Selectable Text`,
    };
  }

  // PNG or JPG export
  let totalSize = 0;
  let lastFilename = '';
  const mimeType = options.format === 'PNG' ? 'image/png' : 'image/jpeg';
  const ext = options.format === 'PNG' ? 'png' : 'jpg';

  for (let i = 0; i < pages.length; i++) {
    const canvas = await renderPageForRasterExport(pages[i], options);
    const blob: Blob = await new Promise((resolve, reject) => {
      canvas.toBlob(
        (b) => (b ? resolve(b) : reject(new Error('فشل توليد ملف الصورة'))),
        mimeType,
        options.jpgQuality
      );
    });
    const pageTag = pages.length > 1 ? `_p${i + 1}` : '';
    const filename = `${cleanPrefix}_${modeSuffix}${pageTag}_${options.dpi}dpi.${ext}`;
    triggerBlobDownload(blob, filename);
    totalSize += blob.size;
    lastFilename = filename;
  }

  return {
    filename: lastFilename,
    sizeKb: Math.round(totalSize / 1024),
    dimensionsLabel: `${firstDims.widthPx} × ${firstDims.heightPx} px (${options.dpi} DPI)`,
  };
}
