package com.example.ui.reader

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.theme.AccentRed
import com.example.theme.AccentYellow
import com.example.ui.components.ZoomableBox
import com.example.utils.PdfEngine
import com.example.utils.PrintHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(
    initialUri: Uri?,
    onNavigateBack: () -> Unit,
    onNavigateToPageManager: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentUri by remember { mutableStateOf(initialUri) }
    var documentName by remember { mutableStateOf("مستند PDF") }
    var totalPages by remember { mutableIntStateOf(0) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Page bitmaps cache
    val pageBitmaps = remember { mutableStateMapOf<Int, Bitmap>() }
    val listState = rememberLazyListState()

    // View settings
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var rotationDegrees by remember { mutableIntStateOf(0) }
    var showThumbnails by remember { mutableStateOf(false) }
    var showJumpDialog by remember { mutableStateOf(false) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }
    var showDirectPrintDialog by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }

    // File Picker
    val openDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            currentUri = uri
        }
    }

    // Load PDF metadata and pages count
    LaunchedEffect(currentUri) {
        val uri = currentUri ?: return@LaunchedEffect
        isLoading = true
        errorMessage = null
        pageBitmaps.clear()

        try {
            // Get Display Name
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex != -1) {
                    documentName = cursor.getString(nameIndex)
                }
            }

            // Get Page Count
            val count = PdfEngine.getPageCount(context, uri)
            totalPages = count
            if (count == 0) {
                errorMessage = "تعذر قراءة صفحات المستند أو أن الملف مشفر/تالف."
            }
        } catch (e: Exception) {
            errorMessage = "خطأ في قراءة المستند: ${e.localizedMessage}"
        } finally {
            isLoading = false
        }
    }

    // Derived current page index (1-indexed)
    val currentPageIndex by remember {
        derivedStateOf {
            if (totalPages == 0) 0 else (listState.firstVisibleItemIndex + 1).coerceAtMost(totalPages)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = documentName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (totalPages > 0) {
                            Text(
                                text = "صفحة $currentPageIndex من $totalPages",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("reader_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع"
                        )
                    }
                },
                actions = {
                    if (currentUri != null && totalPages > 0) {
                        // Yellow Print Button (Ordinary Printing)
                        IconButton(
                            onClick = {
                                (context as? Activity)?.let { activity ->
                                    PrintHelper.printOrdinary(activity, currentUri!!, documentName)
                                }
                            },
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFEF9C3))
                                .border(1.dp, Color(0xFFFACC15), RoundedCornerShape(8.dp))
                                .testTag("reader_yellow_print_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Print,
                                contentDescription = "طباعة عادية",
                                tint = Color(0xFF854D0E),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Red Direct Print Button (Direct Network Socket Printing)
                        IconButton(
                            onClick = { showDirectPrintDialog = true },
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFEE2E2))
                                .border(1.dp, Color(0xFFF87171), RoundedCornerShape(8.dp))
                                .testTag("reader_red_direct_print_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.SendToMobile,
                                contentDescription = "طباعة مباشرة",
                                tint = AccentRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Search Button
                        IconButton(onClick = { showSearchDialog = true }) {
                            Icon(imageVector = Icons.Outlined.Search, contentDescription = "بحث")
                        }

                        // More Menu Button
                        Box {
                            IconButton(onClick = { showMoreMenu = true }) {
                                Icon(imageVector = Icons.Default.MoreVert, contentDescription = "المزيد")
                            }

                            DropdownMenu(
                                expanded = showMoreMenu,
                                onDismissRequest = { showMoreMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("إدارة الصفحات") },
                                    leadingIcon = { Icon(Icons.Outlined.GridView, null) },
                                    onClick = {
                                        showMoreMenu = false
                                        currentUri?.let { onNavigateToPageManager(it) }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("الانتقال إلى صفحة...") },
                                    leadingIcon = { Icon(Icons.Outlined.Numbers, null) },
                                    onClick = {
                                        showMoreMenu = false
                                        showJumpDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("تدوير العرض (90°)") },
                                    leadingIcon = { Icon(Icons.Outlined.RotateRight, null) },
                                    onClick = {
                                        showMoreMenu = false
                                        rotationDegrees = (rotationDegrees + 90) % 360
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("مشاركة المستند") },
                                    leadingIcon = { Icon(Icons.Outlined.Share, null) },
                                    onClick = {
                                        showMoreMenu = false
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/pdf"
                                            putExtra(Intent.EXTRA_STREAM, currentUri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة PDF"))
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("معلومات المستند") },
                                    leadingIcon = { Icon(Icons.Outlined.Info, null) },
                                    onClick = {
                                        showMoreMenu = false
                                        showInfoDialog = true
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                // Empty state: No file loaded
                currentUri == null -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(88.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.PictureAsPdf,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(44.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = "قارئ المستندات الاحترافي",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "اختر أي ملف PDF من جهازك للقراءة والتقريب والطباعة المباشرة وإدارة الصفحات بأمان محلي 100%.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 16.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = { openDocLauncher.launch(arrayOf("application/pdf")) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth(0.7f)
                                .height(50.dp)
                                .testTag("import_pdf_button")
                        ) {
                            Icon(Icons.Default.FileOpen, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("استيراد ملف PDF", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Loading
                isLoading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator()
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("جاري قراءة صفحات المستند...", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // Error
                errorMessage != null -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = errorMessage ?: "",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { openDocLauncher.launch(arrayOf("application/pdf")) }) {
                            Text("اختر ملفاً آخر")
                        }
                    }
                }

                // Continuous PDF Page Stream
                else -> {
                    ZoomableBox(
                        modifier = Modifier.fillMaxSize(),
                        currentScale = zoomScale,
                        onScaleChange = { zoomScale = it }
                    ) {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            items(totalPages) { pageIndex ->
                                val bitmap = pageBitmaps[pageIndex]

                                LaunchedEffect(pageIndex, currentUri) {
                                    if (bitmap == null && currentUri != null) {
                                        val rendered = PdfEngine.renderPageToBitmap(context, currentUri!!, pageIndex)
                                        if (rendered != null) {
                                            pageBitmaps[pageIndex] = rendered
                                        }
                                    }
                                }

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .shadow(4.dp, RoundedCornerShape(8.dp)),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    if (bitmap != null) {
                                        Image(
                                            bitmap = bitmap.asImageBitmap(),
                                            contentDescription = "صفحة ${pageIndex + 1}",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .wrapContentHeight()
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(350.dp)
                                                .background(Color(0xFFF1F5F9)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Floating Controls (Zoom & Quick Page indicator)
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 20.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(30.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                            tonalElevation = 6.dp,
                            shadowElevation = 6.dp,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Zoom out
                                IconButton(
                                    onClick = { zoomScale = (zoomScale - 0.25f).coerceAtLeast(0.75f) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "تصغير", modifier = Modifier.size(18.dp))
                                }

                                // Fit width / Reset
                                TextButton(
                                    onClick = { zoomScale = if (zoomScale == 1f) 1.5f else 1f },
                                    contentPadding = PaddingValues(horizontal = 6.dp)
                                ) {
                                    Text(
                                        text = "${(zoomScale * 100).toInt()}%",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }

                                // Zoom in
                                IconButton(
                                    onClick = { zoomScale = (zoomScale + 0.25f).coerceAtMost(3.5f) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "تكبير", modifier = Modifier.size(18.dp))
                                }

                                VerticalDivider(modifier = Modifier.height(18.dp))

                                // Page pill
                                Text(
                                    text = "$currentPageIndex / $totalPages",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier
                                        .clickable { showJumpDialog = true }
                                        .padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Jump to page Dialog
    if (showJumpDialog) {
        var targetPageText by remember { mutableStateOf(currentPageIndex.toString()) }
        AlertDialog(
            onDismissRequest = { showJumpDialog = false },
            title = { Text("الانتقال إلى صفحة") },
            text = {
                Column {
                    Text("أدخل رقم الصفحة بين 1 و $totalPages:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = targetPageText,
                        onValueChange = { targetPageText = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val target = targetPageText.toIntOrNull()
                        if (target != null && target in 1..totalPages) {
                            coroutineScope.launch {
                                listState.scrollToItem(target - 1)
                            }
                            showJumpDialog = false
                        } else {
                            Toast.makeText(context, "رقم صفحة غير صحيح", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("انتقال")
                }
            },
            dismissButton = {
                TextButton(onClick = { showJumpDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Direct Print Dialog (Red Button Workflow)
    if (showDirectPrintDialog && currentUri != null) {
        var printerIp by remember { mutableStateOf("192.168.1.100") }
        var printerPort by remember { mutableStateOf("9100") }
        var isSending by remember { mutableStateOf(false) }
        var sendProgress by remember { mutableFloatStateOf(0f) }
        var statusMsg by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { if (!isSending) showDirectPrintDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.SendToMobile, contentDescription = null, tint = AccentRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("الطباعة المباشرة عبر الشبكة", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "إرسال ملف PDF مباشرة عبر مقبس الشبكة (RAW Socket Port 9100) إلى طابعة الشبكة المعرفة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = printerIp,
                        onValueChange = { printerIp = it },
                        label = { Text("عنوان IP للطابعة") },
                        placeholder = { Text("مثال: 192.168.1.50") },
                        singleLine = true,
                        enabled = !isSending,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = printerPort,
                        onValueChange = { printerPort = it },
                        label = { Text("المنفذ (الافتراضي 9100)") },
                        singleLine = true,
                        enabled = !isSending,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (isSending) {
                        LinearProgressIndicator(
                            progress = { sendProgress },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "جاري إرسال البيانات: ${(sendProgress * 100).toInt()}%",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    if (statusMsg != null) {
                        Text(
                            text = statusMsg ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (statusMsg!!.contains("نجاح")) Color(0xFF16A34A) else MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val portInt = printerPort.toIntOrNull() ?: 9100
                        isSending = true
                        statusMsg = null
                        coroutineScope.launch {
                            val result = PrintHelper.printDirect(
                                context = context,
                                uri = currentUri!!,
                                printerIp = printerIp.trim(),
                                port = portInt,
                                onProgress = { sendProgress = it }
                            )
                            isSending = false
                            result.onSuccess { msg ->
                                statusMsg = msg
                            }.onFailure { err ->
                                statusMsg = err.message
                            }
                        }
                    },
                    enabled = !isSending && printerIp.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentRed)
                ) {
                    Text("إرسال للطابعة")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDirectPrintDialog = false },
                    enabled = !isSending
                ) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Text Search Dialog
    if (showSearchDialog && currentUri != null) {
        var searchQuery by remember { mutableStateOf("") }
        var searchResult by remember { mutableStateOf<String?>(null) }
        var isSearching by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showSearchDialog = false },
            title = { Text("البحث في نصوص المستند") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("الكلمة المراد البحث عنها") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (isSearching) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }

                    if (searchResult != null) {
                        Text(
                            text = searchResult ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (searchQuery.isNotBlank()) {
                            isSearching = true
                            coroutineScope.launch {
                                val fullText = PdfEngine.extractSearchableText(context, currentUri!!)
                                isSearching = false
                                val occurrences = Regex(Regex.escape(searchQuery), RegexOption.IGNORE_CASE).findAll(fullText).count()
                                searchResult = if (occurrences > 0) {
                                    "تم العثور على \"$searchQuery\" ($occurrences مرة) في المستند."
                                } else {
                                    "لم يتم العثور على الكلمة، أو أن المستند عبارة عن صور ممسوحة ضوئياً بدون طبقة نصية."
                                }
                            }
                        }
                    }
                ) {
                    Text("بحث")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSearchDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Document Info Dialog
    if (showInfoDialog && currentUri != null) {
        AlertDialog(
            onDismissRequest = { showInfoDialog = false },
            title = { Text("معلومات المستند") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("اسم الملف: $documentName", fontWeight = FontWeight.SemiBold)
                    Text("عدد الصفحات: $totalPages")
                    Text("المسار: ${currentUri?.path ?: ""}", fontSize = 11.sp, color = Color.Gray)
                    Text("الأمان: تمت معالجة المستند محلياً بالكامل دون أي رفع خارجي.")
                }
            },
            confirmButton = {
                TextButton(onClick = { showInfoDialog = false }) {
                    Text("حسناً")
                }
            }
        )
    }
}
