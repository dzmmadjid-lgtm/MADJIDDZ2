package com.example.core.reconstruct

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.core.image.ImageUtils
import com.example.data.model.DetectedLanguage
import com.example.data.model.OcrPageResult
import com.example.data.model.RegionType
import com.example.data.model.TextRegion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object DocumentReconstructor {

    data class ReconstructionOptions(
        val removeShadows: Boolean = true,
        val deskewAndStraighten: Boolean = true,
        val reconstructTables: Boolean = true,
        val preserveGraphics: Boolean = true,
        val paperTone: PaperTone = PaperTone.CLEAN_WHITE
    )

    enum class PaperTone(val labelAr: String, val colorInt: Int) {
        CLEAN_WHITE("أبيض ناصع", Color.WHITE),
        NATURAL_PAPER("ورق طبيعي", Color.rgb(253, 252, 248)),
        BLUEPRINT("رسم تقني", Color.rgb(245, 248, 255))
    }

    /**
     * Recreates a pristine, straight digital document from a camera photo or scan.
     * Removes shadows, paper creases, fingerprints, and uneven illumination,
     * while reconstructing vector elements: text with proper RTL/LTR alignment,
     * table grid lines, and crisp logos/stamps.
     */
    suspend fun reconstruct(
        sourceBitmap: Bitmap,
        ocrResult: OcrPageResult?,
        options: ReconstructionOptions = ReconstructionOptions()
    ): Bitmap = withContext(Dispatchers.Default) {
        // 1. Deskew & straighten
        val straightened = if (options.deskewAndStraighten) {
            autoDeskew(sourceBitmap, ocrResult)
        } else {
            sourceBitmap
        }

        // 2. Intelligent shadow & stain removal (Paper Whitening)
        val whitenedBase = if (options.removeShadows) {
            removeShadowsAndStains(straightened)
        } else {
            straightened
        }

        // 3. Digital Reconstruction: generate high-res clean document canvas
        val outWidth = max(straightened.width, 1600)
        val outHeight = max(straightened.height, 2200)

        val reconstructed = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(reconstructed)

        // Fill paper tone
        canvas.drawColor(options.paperTone.colorInt)

        if (ocrResult == null || ocrResult.regions.isEmpty()) {
            // Draw whitened base if no OCR regions available yet
            val dstRect = RectF(0f, 0f, outWidth.toFloat(), outHeight.toFloat())
            val srcRect = Rect(0, 0, whitenedBase.width, whitenedBase.height)
            canvas.drawBitmap(whitenedBase, srcRect, dstRect, Paint(Paint.FILTER_BITMAP_FLAG))
            return@withContext reconstructed
        }

        // Draw reconstructed elements with high typographic precision
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(20, 20, 25)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 30, 35)
            typeface = Typeface.DEFAULT
        }

        val tableLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(120, 125, 135)
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
        }

        val tableHeaderBgPaint = Paint().apply {
            color = Color.rgb(243, 245, 249)
            style = Paint.Style.FILL
        }

        // Group regions for tables detection
        val tableRegions = ocrResult.regions.filter { it.type == RegionType.TABLE_CELL }
        if (options.reconstructTables && tableRegions.isNotEmpty()) {
            reconstructTableGrid(canvas, tableRegions, outWidth, outHeight, tableLinePaint, tableHeaderBgPaint)
        }

        // Render each region cleanly
        for (region in ocrResult.regions) {
            val box = region.boundingBox
            val rx = box.left * outWidth
            val ry = box.top * outHeight
            val rw = (box.width * outWidth).coerceAtLeast(30f)
            val rh = (box.height * outHeight).coerceAtLeast(15f)

            if (region.isGraphic && options.preserveGraphics) {
                // Cut the graphic/stamp from whitened image and draw cleanly
                val srcLeft = (box.left * whitenedBase.width).toInt().coerceIn(0, whitenedBase.width - 1)
                val srcTop = (box.top * whitenedBase.height).toInt().coerceIn(0, whitenedBase.height - 1)
                val srcRight = (box.right * whitenedBase.width).toInt().coerceIn(srcLeft + 1, whitenedBase.width)
                val srcBottom = (box.bottom * whitenedBase.height).toInt().coerceIn(srcTop + 1, whitenedBase.height)

                val cropW = srcRight - srcLeft
                val cropH = srcBottom - srcTop
                if (cropW > 4 && cropH > 4) {
                    val graphicBitmap = Bitmap.createBitmap(whitenedBase, srcLeft, srcTop, cropW, cropH)
                    val dst = RectF(rx, ry, rx + rw, ry + rh)
                    canvas.drawBitmap(graphicBitmap, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
                }
                continue
            }

            val text = region.text.trim()
            if (text.isEmpty()) continue

            val isArabic = region.language == DetectedLanguage.ARABIC ||
                    (region.language == DetectedLanguage.MIXED && ocrResult.primaryLanguage == DetectedLanguage.ARABIC)

            val alignment = if (isArabic) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL

            val fontSize = when (region.type) {
                RegionType.TITLE -> (rh * 0.75f).coerceIn(24f, 62f)
                RegionType.NUMBER -> (rh * 0.65f).coerceIn(18f, 42f)
                RegionType.LIST_ITEM -> (rh * 0.60f).coerceIn(16f, 38f)
                else -> (rh / region.lines.size.coerceAtLeast(1) * 0.75f).coerceIn(15f, 36f)
            }

            val paint = if (region.type == RegionType.TITLE) {
                titlePaint.apply { textSize = fontSize }
            } else {
                bodyPaint.apply { textSize = fontSize }
            }

            // Draw under-rule or divider for titles if prominent
            if (region.type == RegionType.TITLE && box.top < 0.22f) {
                val underlinePaint = Paint().apply {
                    color = Color.rgb(183, 28, 28)
                    strokeWidth = 3f
                }
                canvas.drawLine(rx, ry + rh + 10f, rx + rw, ry + rh + 10f, underlinePaint)
            }

            try {
                val staticLayout = StaticLayout.Builder.obtain(text, 0, text.length, paint, rw.toInt().coerceAtLeast(60))
                    .setAlignment(alignment)
                    .setLineSpacing(3f, 1.15f)
                    .setIncludePad(false)
                    .build()

                canvas.save()
                canvas.translate(rx, ry)
                staticLayout.draw(canvas)
                canvas.restore()
            } catch (e: Exception) {
                canvas.drawText(text, rx, ry + rh, paint)
            }
        }

        reconstructed
    }

    /**
     * Automatic shadow, glare, and stain removal:
     * Performs adaptive illumination normalization so that paper becomes uniformly white
     * and text strokes remain sharp and dark.
     */
    fun removeShadowsAndStains(source: Bitmap): Bitmap {
        val width = source.width
        val height = source.height
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        // Block-based local background estimation
        val blockSize = 32
        val blocksX = (width + blockSize - 1) / blockSize
        val blocksY = (height + blockSize - 1) / blockSize
        val maxLum = IntArray(blocksX * blocksY)

        // Find max luminance in each local block (representing paper background)
        for (by in 0 until blocksY) {
            for (bx in 0 until blocksX) {
                var maxL = 0
                val startY = by * blockSize
                val endY = min(height, startY + blockSize)
                val startX = bx * blockSize
                val endX = min(width, startX + blockSize)

                for (y in startY until endY) {
                    val rowOffset = y * width
                    for (x in startX until endX) {
                        val p = pixels[rowOffset + x]
                        val r = (p shr 16) and 0xFF
                        val g = (p shr 8) and 0xFF
                        val b = p and 0xFF
                        val lum = (r * 299 + g * 587 + b * 114) / 1000
                        if (lum > maxL) maxL = lum
                    }
                }
                maxLum[by * blocksX + bx] = max(maxL, 110)
            }
        }

        // Normalize each pixel by its local paper background luminance
        val outPixels = IntArray(width * height)
        for (y in 0 until height) {
            val by = (y / blockSize).coerceIn(0, blocksY - 1)
            val rowOffset = y * width
            for (x in 0 until width) {
                val bx = (x / blockSize).coerceIn(0, blocksX - 1)
                val bgLum = maxLum[by * blocksX + bx].toFloat()

                val p = pixels[rowOffset + x]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val lum = (r * 299 + g * 587 + b * 114) / 1000

                // Normalized luminance ratio
                val ratio = lum.toFloat() / bgLum
                if (ratio > 0.88f) {
                    // Turn illuminated background into pure paper white
                    outPixels[rowOffset + x] = Color.WHITE
                } else {
                    // Darken ink text and preserve color
                    val darkFactor = (ratio / 0.88f).coerceIn(0f, 1f)
                    val nr = (r * darkFactor).toInt().coerceIn(0, 255)
                    val ng = (g * darkFactor).toInt().coerceIn(0, 255)
                    val nb = (b * darkFactor).toInt().coerceIn(0, 255)
                    outPixels[rowOffset + x] = Color.rgb(nr, ng, nb)
                }
            }
        }

        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        result.setPixels(outPixels, 0, width, 0, 0, width, height)
        return result
    }

    /**
     * Automatic Deskew: detects slight camera rotation angle and straightens the page.
     */
    private fun autoDeskew(bitmap: Bitmap, ocrResult: OcrPageResult?): Bitmap {
        if (ocrResult == null || ocrResult.regions.size < 3) return bitmap

        // Estimate skew angle from text lines
        var totalAngle = 0f
        var count = 0

        for (region in ocrResult.regions) {
            for (line in region.lines) {
                val box = line.boundingBox
                if (box.width > 0.25f) {
                    // In a straight document, text lines are horizontal
                    val dx = box.width
                    val dy = box.bottom - box.top
                    val angle = (dy / dx) * (180f / Math.PI.toFloat())
                    if (abs(angle) < 15f) {
                        totalAngle += angle
                        count++
                    }
                }
            }
        }

        val avgAngle = if (count > 0) totalAngle / count else 0f
        return if (abs(avgAngle) > 0.75f) {
            ImageUtils.rotateBitmap(bitmap, -avgAngle)
        } else {
            bitmap
        }
    }

    private fun reconstructTableGrid(
        canvas: Canvas,
        tableRegions: List<TextRegion>,
        outWidth: Int,
        outHeight: Int,
        linePaint: Paint,
        headerBgPaint: Paint
    ) {
        val minLeft = tableRegions.minOf { it.boundingBox.left } * outWidth
        val maxRight = tableRegions.maxOf { it.boundingBox.right } * outWidth
        val minTop = tableRegions.minOf { it.boundingBox.top } * outHeight
        val maxBottom = tableRegions.maxOf { it.boundingBox.bottom } * outHeight

        // Draw outer border
        canvas.drawRect(minLeft - 6f, minTop - 6f, maxRight + 6f, maxBottom + 6f, linePaint)

        // Draw header row highlight
        val headerBottom = minTop + (maxBottom - minTop) / 4f
        canvas.drawRect(minLeft - 6f, minTop - 6f, maxRight + 6f, headerBottom, headerBgPaint)
        canvas.drawLine(minLeft - 6f, headerBottom, maxRight + 6f, headerBottom, linePaint)

        // Draw inner horizontal rows
        for (r in tableRegions) {
            val y = r.boundingBox.bottom * outHeight
            if (y < maxBottom - 10f) {
                canvas.drawLine(minLeft - 6f, y, maxRight + 6f, y, linePaint)
            }
        }
    }
}
