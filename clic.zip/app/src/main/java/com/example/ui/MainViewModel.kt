package com.example.ui

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.StereoAudio
import com.example.audio.WavAudioUtil
import com.example.data.SeparationDatabase
import com.example.data.SeparationEntity
import com.example.data.SeparationRepository
import com.example.neural.AiModelManager
import com.example.neural.ModelDiagnosticInfo
import com.example.neural.NeuralSourceSeparator
import com.example.player.MultiTrackPlayer
import com.example.player.MultiTrackPlayerState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class ProcessingUiState(
    val isProcessing: Boolean = false,
    val stage: String = "",
    val progress: Float = 0f,
    val errorMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val tag = "MainViewModel"

    private val modelManager = AiModelManager(application.applicationContext)
    private val separator = NeuralSourceSeparator(modelManager)
    private val repository = SeparationRepository(
        SeparationDatabase.getDatabase(application.applicationContext).separationDao()
    )

    val player = MultiTrackPlayer(viewModelScope)

    val modelInfo: StateFlow<ModelDiagnosticInfo> = modelManager.modelInfo
    val playerState: StateFlow<MultiTrackPlayerState> = player.state

    private val _processingState = MutableStateFlow(ProcessingUiState())
    val processingState: StateFlow<ProcessingUiState> = _processingState.asStateFlow()

    private val _currentSeparation = MutableStateFlow<SeparationEntity?>(null)
    val currentSeparation: StateFlow<SeparationEntity?> = _currentSeparation.asStateFlow()

    val history: StateFlow<List<SeparationEntity>> = repository.allSeparations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Initialize the neural model on launch
        viewModelScope.launch {
            modelManager.initializeModels()
        }
    }

    /**
     * Performs instant separation on built-in high-quality demo audio.
     */
    fun processDemoAudio() {
        if (_processingState.value.isProcessing) return

        viewModelScope.launch {
            try {
                _processingState.value = ProcessingUiState(
                    isProcessing = true,
                    stage = "توليد أغنية تجريبية (صوت بشري + جيتار وباس)...",
                    progress = 0.05f
                )

                val demoAudio = withContext(Dispatchers.Default) {
                    WavAudioUtil.createDemoSong(durationSeconds = 10.0f)
                }

                performSeparation(demoAudio, "أغنية تجريبية (Demo Anthem)")
            } catch (t: Throwable) {
                Log.e(tag, "Separation error: ${t.message}", t)
                val msg = when (t) {
                    is OutOfMemoryError -> "ذاكرة الجهاز غير كافية لهذا الملف الصوتي. يرجى تجربة مقطع صوتي أقصر."
                    else -> t.localizedMessage ?: t.message ?: "حدث خطأ أثناء معالجة الصوت"
                }
                _processingState.value = ProcessingUiState(
                    isProcessing = false,
                    errorMessage = msg
                )
            }
        }
    }

    /**
     * Processes an audio file selected by the user via Android document/audio picker.
     */
    fun processAudioUri(uri: Uri, displayName: String) {
        if (_processingState.value.isProcessing) return

        viewModelScope.launch {
            try {
                _processingState.value = ProcessingUiState(
                    isProcessing = true,
                    stage = "قراءة وفك تشفير الملف الصوتي...",
                    progress = 0.05f
                )

                val audio = withContext(Dispatchers.IO) {
                    val context = getApplication<Application>().applicationContext
                    com.example.audio.UniversalAudioDecoder.decodeUriToStereoAudio(context, uri)
                }

                performSeparation(audio, displayName)
            } catch (t: Throwable) {
                Log.e(tag, "Separation error: ${t.message}", t)
                val msg = when (t) {
                    is OutOfMemoryError -> "ذاكرة الجهاز غير كافية لهذا الملف الصوتي. يرجى تجربة مقطع صوتي أقصر (أقل من 6 دقائق)."
                    else -> "فشل في قراءة أو فك تشفير الملف الصوتي: ${t.localizedMessage ?: t.message}"
                }
                _processingState.value = ProcessingUiState(
                    isProcessing = false,
                    errorMessage = msg
                )
            }
        }
    }

    private suspend fun performSeparation(audio: StereoAudio, title: String) {
        val context = getApplication<Application>().applicationContext

        val result = separator.separate(audio) { stage, progress ->
            _processingState.value = _processingState.value.copy(
                stage = stage,
                progress = progress
            )
        }

        // Save output stems to app persistent storage
        val stemsDir = File(context.filesDir, "stems").apply { mkdirs() }
        val timestamp = System.currentTimeMillis()
        val vocalsFile = File(stemsDir, "vocals_$timestamp.wav")
        val instFile = File(stemsDir, "instrumental_$timestamp.wav")

        withContext(Dispatchers.IO) {
            WavAudioUtil.writeWavFile(result.vocals, vocalsFile)
            WavAudioUtil.writeWavFile(result.instrumental, instFile)
        }

        val entity = SeparationEntity(
            title = title,
            durationSeconds = result.durationSeconds,
            inferenceTimeMs = result.inferenceTimeMs,
            modelName = result.modelName,
            vocalsPath = vocalsFile.absolutePath,
            instrumentalPath = instFile.absolutePath
        )

        val id = repository.saveSeparation(entity)
        val savedEntity = entity.copy(id = id)

        _currentSeparation.value = savedEntity
        _processingState.value = ProcessingUiState(isProcessing = false)

        // Load tracks into multi-track synchronized player
        player.loadTracks(vocalsFile, instFile)
        player.play()
    }

    fun playSeparationItem(item: SeparationEntity) {
        _currentSeparation.value = item
        val vFile = File(item.vocalsPath)
        val iFile = File(item.instrumentalPath)
        if (vFile.exists() && iFile.exists()) {
            player.loadTracks(vFile, iFile)
            player.play()
        }
    }

    fun deleteItem(item: SeparationEntity) {
        viewModelScope.launch {
            try {
                File(item.vocalsPath).delete()
                File(item.instrumentalPath).delete()
            } catch (e: Exception) {
                Log.w(tag, "Could not delete stem files: ${e.message}")
            }
            repository.delete(item)
            if (_currentSeparation.value?.id == item.id) {
                player.release()
                _currentSeparation.value = null
            }
        }
    }

    fun clearError() {
        _processingState.value = _processingState.value.copy(errorMessage = null)
    }

    fun reloadModel() {
        viewModelScope.launch {
            modelManager.initializeModels(forceReload = true)
        }
    }

    override fun onCleared() {
        super.onCleared()
        player.release()
        modelManager.release()
    }
}
