package com.example.vocalseparator.ui.theme

import androidx.compose.ui.graphics.Color

val StudioDarkBg = Color(0xFF090D16)
val StudioCardBg = Color(0xFF131929)
val StudioSurfaceVariant = Color(0xFF1B243B)
val StudioBorder = Color(0xFF26324F)

val CyanAccent = Color(0xFF00E5FF)
val CyanAccentDark = Color(0xFF00A3B5)

val VocalPink = Color(0xFFFF2A85)
val VocalPinkLight = Color(0xFFFF60A6)

val InstrumentalGold = Color(0xFFFFB800)
val InstrumentalGoldDark = Color(0xFFC78F00)

val StudioSuccess = Color(0xFF10B981)
val StudioWarning = Color(0xFFF59E0B)
val StudioError = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
