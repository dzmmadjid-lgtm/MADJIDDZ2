package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.streamhub.ui.screens.YouTubeHomeScreen

/**
 * النشاط الرئيسي لتطبيق youtub M المتطور لتشغيل يوتيوب بلمسات سحرية فائقة
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            YouTubeHomeScreen()
        }
    }
}




