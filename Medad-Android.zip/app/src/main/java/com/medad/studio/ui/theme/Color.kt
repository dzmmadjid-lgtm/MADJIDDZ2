package com.medad.studio.ui.theme

import androidx.compose.ui.graphics.Color

val InkBlack = Color(0xFF000000)
val InkSoft = Color(0xFF0B0B0C)
val InkPanel = Color(0xFF121214)
val InkLine = Color(0xFF2A2A2E)

val Gold = Color(0xFFC9A227)
val GoldSoft = Color(0xFFE4C56A)
val GoldDim = Color(0xFF8A7018)
val Cream = Color(0xFFF4E4B3)

val DayBg = Color(0xFFF6F0E8)
val DayPanel = Color(0xFFFFFBF6)
val DayInk = Color(0xFF1A1612)
val DayMuted = Color(0xFF6B5E4E)
val DayLine = Color(0xFFE6D9C6)
val DayGold = Color(0xFF9A7410)

val NightMuted = Color(0xFF9A948A)
val NightText = Color(0xFFF3EEE6)
val Danger = Color(0xFFCF6679)
val Success = Color(0xFF7DCEA0)
