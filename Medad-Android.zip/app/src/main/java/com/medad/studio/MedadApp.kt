package com.medad.studio

import android.app.Application

class MedadApp : Application()
