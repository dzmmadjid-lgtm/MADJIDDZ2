package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.ScannerViewModel
import com.example.ui.components.ScannerWorkspaceView
import com.example.ui.theme.CanonScanTheme

class MainActivity : ComponentActivity() {
    private val viewModel: ScannerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CanonScanTheme {
                Surface(
                    modifier = Modifier.fillMaxSize().statusBarsPadding(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val discoveredScanners by viewModel.discoveredScanners.collectAsState()
                    val selectedScanner by viewModel.selectedScanner.collectAsState()
                    val isScanning by viewModel.isScanning.collectAsState()
                    val scanStatusLogs by viewModel.scanStatusLogs.collectAsState()
                    val scanError by viewModel.scanError.collectAsState()
                    val scannedBitmap by viewModel.scannedBitmap.collectAsState()
                    val editedBitmap by viewModel.editedBitmap.collectAsState()
                    val savedPages by viewModel.savedScanPages.collectAsState()
                    val lastSavedImage by viewModel.lastSavedImageFile.collectAsState()
                    val lastPdf by viewModel.lastGeneratedPdfFile.collectAsState()

                    LaunchedEffect(Unit) { viewModel.refreshUsbScanners() }

                    ScannerWorkspaceView(
                        discoveredScanners = discoveredScanners,
                        selectedScanner = selectedScanner,
                        isScanning = isScanning,
                        scanStatusLogs = scanStatusLogs,
                        scanError = scanError,
                        scannedBitmap = scannedBitmap,
                        editedBitmap = editedBitmap,
                        savedPages = savedPages,
                        lastSavedImageFile = lastSavedImage,
                        lastGeneratedPdfFile = lastPdf,
                        onRefreshUsbScanners = { viewModel.refreshUsbScanners() },
                        onProbeWifiScanner = { ip -> viewModel.probeNetworkScanner(ip) },
                        onSelectScanner = { dev -> viewModel.selectScannerDevice(dev) },
                        onRequestUsbPermission = { dev -> viewModel.requestScannerUsbPermission(dev) },
                        onStartScan = { opts -> viewModel.executeHardwareScan(opts) },
                        onApplyImageTransform = { rot, fh, fv, l, t, r, b, c ->
                            viewModel.applyScanImageTransform(rot, fh, fv, l, t, r, b, c)
                        },
                        onResetImageTransform = { viewModel.resetEditedScanBitmap() },
                        onSaveEditedImage = { viewModel.saveEditedScanImage() },
                        onAddPageToPdfQueue = { viewModel.addCurrentScanPageToPdfQueue() },
                        onClearPdfQueue = { viewModel.clearSavedPdfPages() },
                        onGeneratePdfDocument = { name -> viewModel.buildPdfFromScannedPages(name) }
                    )
                }
            }
        }
    }
}
