package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object PdfEngine {

    // Copy Content URI to a temporary cache file so both PdfRenderer and PDFBox can access it safely
    suspend fun uriToTempFile(context: Context, uri: Uri, prefix: String = "temp_doc_"): File = withContext(Dispatchers.IO) {
        val tempFile = File.createTempFile(prefix, ".pdf", context.cacheDir)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tempFile).use { output ->
                input.copyTo(output)
            }
        } ?: throw IllegalArgumentException("Cannot open stream for URI: $uri")
        tempFile
    }

    // Get total page count using native PdfRenderer
    suspend fun getPageCount(context: Context, uri: Uri): Int = withContext(Dispatchers.IO) {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: return@withContext 0
        pfd.use {
            val renderer = PdfRenderer(it)
            val count = renderer.pageCount
            renderer.close()
            count
        }
    }

    // Render a single PDF page to a Bitmap
    suspend fun renderPageToBitmap(
        context: Context,
        uri: Uri,
        pageIndex: Int,
        maxDimension: Int = 1200
    ): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return@withContext null
            pfd.use { descriptor ->
                val renderer = PdfRenderer(descriptor)
                if (pageIndex < 0 || pageIndex >= renderer.pageCount) {
                    renderer.close()
                    return@withContext null
                }
                val page = renderer.openPage(pageIndex)
                val width = page.width
                val height = page.height
                val scale = if (width > height) {
                    maxDimension.toFloat() / width
                } else {
                    maxDimension.toFloat() / height
                }.coerceAtMost(2.5f)

                val targetW = (width * scale).toInt().coerceAtLeast(1)
                val targetH = (height * scale).toInt().coerceAtLeast(1)

                val bitmap = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                canvas.drawColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                renderer.close()
                bitmap
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // Merge multiple PDF files into one output file using PDFBox
    suspend fun mergePdfs(
        context: Context,
        inputUris: List<Uri>,
        outputFile: File
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val merger = PDFMergerUtility()
            merger.destinationFileName = outputFile.absolutePath
            val tempFiles = mutableListOf<File>()

            for (uri in inputUris) {
                val temp = uriToTempFile(context, uri, "merge_src_")
                tempFiles.add(temp)
                merger.addSource(temp)
            }

            merger.mergeDocuments(null)
            tempFiles.forEach { it.delete() }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // Split PDF: Extract a range of pages [fromPage..toPage] (1-indexed)
    suspend fun extractPageRange(
        context: Context,
        inputUri: Uri,
        fromPage: Int,
        toPage: Int,
        outputFile: File
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val tempFile = uriToTempFile(context, inputUri)
            PDDocument.load(tempFile).use { srcDoc ->
                PDDocument().use { outDoc ->
                    val total = srcDoc.numberOfPages
                    val start = (fromPage - 1).coerceIn(0, total - 1)
                    val end = (toPage - 1).coerceIn(start, total - 1)

                    for (i in start..end) {
                        outDoc.addPage(srcDoc.getPage(i))
                    }
                    outDoc.save(outputFile)
                }
            }
            tempFile.delete()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // Delete specific pages (0-indexed list of page indices to delete)
    // Mandatory Example: 6 pages, delete page 2 -> result has exactly pages 1, 3, 4, 5, 6 preserved.
    suspend fun deletePages(
        context: Context,
        inputUri: Uri,
        pageIndicesToDelete: Set<Int>,
        outputFile: File
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val tempFile = uriToTempFile(context, inputUri)
            PDDocument.load(tempFile).use { srcDoc ->
                PDDocument().use { outDoc ->
                    val total = srcDoc.numberOfPages
                    for (i in 0 until total) {
                        if (!pageIndicesToDelete.contains(i)) {
                            outDoc.addPage(srcDoc.getPage(i))
                        }
                    }
                    outDoc.save(outputFile)
                }
            }
            tempFile.delete()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // Reorder pages based on index mapping (e.g. [2, 0, 1])
    suspend fun reorderPages(
        context: Context,
        inputUri: Uri,
        newOrderIndices: List<Int>,
        outputFile: File
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val tempFile = uriToTempFile(context, inputUri)
            PDDocument.load(tempFile).use { srcDoc ->
                PDDocument().use { outDoc ->
                    for (index in newOrderIndices) {
                        if (index in 0 until srcDoc.numberOfPages) {
                            outDoc.addPage(srcDoc.getPage(index))
                        }
                    }
                    outDoc.save(outputFile)
                }
            }
            tempFile.delete()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // Rotate pages by degrees (90, 180, 270)
    suspend fun rotatePages(
        context: Context,
        inputUri: Uri,
        targetPages: Set<Int>,
        degrees: Int,
        outputFile: File
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val tempFile = uriToTempFile(context, inputUri)
            PDDocument.load(tempFile).use { doc ->
                for (pageIdx in targetPages) {
                    if (pageIdx in 0 until doc.numberOfPages) {
                        val page = doc.getPage(pageIdx)
                        val currentRotation = page.rotation
                        page.rotation = (currentRotation + degrees) % 360
                    }
                }
                doc.save(outputFile)
            }
            tempFile.delete()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // Crop PDF margins
    suspend fun cropPdf(
        context: Context,
        inputUri: Uri,
        marginPercentLeft: Float,
        marginPercentTop: Float,
        marginPercentRight: Float,
        marginPercentBottom: Float,
        applyToAll: Boolean,
        targetPage: Int,
        outputFile: File
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val tempFile = uriToTempFile(context, inputUri)
            PDDocument.load(tempFile).use { doc ->
                val count = doc.numberOfPages
                val pagesToCrop = if (applyToAll) (0 until count).toList() else listOf(targetPage)

                for (idx in pagesToCrop) {
                    if (idx in 0 until count) {
                        val page = doc.getPage(idx)
                        val mediaBox = page.mediaBox
                        val w = mediaBox.width
                        val h = mediaBox.height

                        val newX = mediaBox.lowerLeftX + (w * marginPercentLeft)
                        val newY = mediaBox.lowerLeftY + (h * marginPercentBottom)
                        val newW = w * (1f - marginPercentLeft - marginPercentRight)
                        val newH = h * (1f - marginPercentTop - marginPercentBottom)

                        if (newW > 50 && newH > 50) {
                            val cropBox = PDRectangle(newX, newY, newW, newH)
                            page.cropBox = cropBox
                        }
                    }
                }
                doc.save(outputFile)
            }
            tempFile.delete()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // Search and extract text from PDF using PDFBox
    suspend fun extractSearchableText(
        context: Context,
        inputUri: Uri
    ): String = withContext(Dispatchers.IO) {
        try {
            val tempFile = uriToTempFile(context, inputUri)
            val text = PDDocument.load(tempFile).use { doc ->
                val stripper = PDFTextStripper()
                stripper.getText(doc)
            }
            tempFile.delete()
            text ?: ""
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    // Convert Images to PDF with layout options (A4, Letter, Fit), orientation, margins
    suspend fun convertImagesToPdf(
        context: Context,
        imageUris: List<Uri>,
        outputFile: File,
        pageSize: String = "A4", // "A4", "LETTER", "FIT_IMAGE"
        isPortrait: Boolean = true,
        marginDp: Int = 16,
        quality: Int = 85
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val pdfDoc = PdfDocument()

            // Standard dimensions at 72 dpi: A4 is 595 x 842 pt, Letter is 612 x 792 pt
            val (baseWidth, baseHeight) = when (pageSize) {
                "LETTER" -> if (isPortrait) 612 to 792 else 792 to 612
                "A4" -> if (isPortrait) 595 to 842 else 842 to 595
                else -> if (isPortrait) 595 to 842 else 842 to 595
            }

            for ((index, uri) in imageUris.withIndex()) {
                val input: InputStream? = context.contentResolver.openInputStream(uri)
                val originalBitmap = BitmapFactory.decodeStream(input)
                input?.close()

                if (originalBitmap != null) {
                    val pageWidth = if (pageSize == "FIT_IMAGE") originalBitmap.width else baseWidth
                    val pageHeight = if (pageSize == "FIT_IMAGE") originalBitmap.height else baseHeight

                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                    val page = pdfDoc.startPage(pageInfo)
                    val canvas = page.canvas

                    canvas.drawColor(Color.WHITE)

                    val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

                    if (pageSize == "FIT_IMAGE") {
                        canvas.drawBitmap(originalBitmap, 0f, 0f, paint)
                    } else {
                        val availableW = (pageWidth - (marginDp * 2)).toFloat().coerceAtLeast(10f)
                        val availableH = (pageHeight - (marginDp * 2)).toFloat().coerceAtLeast(10f)

                        val imgW = originalBitmap.width.toFloat()
                        val imgH = originalBitmap.height.toFloat()
                        val scale = (availableW / imgW).coerceAtMost(availableH / imgH)

                        val destW = imgW * scale
                        val destH = imgH * scale
                        val destX = marginDp + (availableW - destW) / 2f
                        val destY = marginDp + (availableH - destH) / 2f

                        val scaledBitmap = Bitmap.createScaledBitmap(
                            originalBitmap,
                            destW.toInt().coerceAtLeast(1),
                            destH.toInt().coerceAtLeast(1),
                            true
                        )
                        canvas.drawBitmap(scaledBitmap, destX, destY, paint)
                        if (scaledBitmap != originalBitmap) {
                            scaledBitmap.recycle()
                        }
                    }

                    pdfDoc.finishPage(page)
                    originalBitmap.recycle()
                }
            }

            FileOutputStream(outputFile).use { fos ->
                pdfDoc.writeTo(fos)
            }
            pdfDoc.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // Convert Text to PDF with Arabic shaping and layout
    suspend fun convertTextToPdf(
        title: String,
        content: String,
        outputFile: File,
        pageSize: String = "A4",
        isPortrait: Boolean = true,
        fontSizeSp: Float = 16f,
        alignRight: Boolean = true
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val pdfDoc = PdfDocument()
            val (pageWidth, pageHeight) = when (pageSize) {
                "LETTER" -> if (isPortrait) 612 to 792 else 792 to 612
                else -> if (isPortrait) 595 to 842 else 842 to 595
            }

            val margin = 40
            val contentWidth = pageWidth - (margin * 2)
            val contentHeight = pageHeight - (margin * 2)

            val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.BLACK
                textSize = fontSizeSp * 1.33f
            }

            val alignment = if (alignRight) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL

            val staticLayout = StaticLayout.Builder
                .obtain(content, 0, content.length, textPaint, contentWidth)
                .setAlignment(alignment)
                .setLineSpacing(4f, 1.15f)
                .setIncludePad(true)
                .build()

            val totalLines = staticLayout.lineCount
            var currentLine = 0
            var pageIndex = 1

            while (currentLine < totalLines) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex).create()
                val page = pdfDoc.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawColor(Color.WHITE)

                val lineTopAtStart = staticLayout.getLineTop(currentLine)
                var lastLineOnThisPage = currentLine

                while (lastLineOnThisPage < totalLines &&
                    (staticLayout.getLineBottom(lastLineOnThisPage) - lineTopAtStart) <= contentHeight
                ) {
                    lastLineOnThisPage++
                }

                canvas.save()
                canvas.translate(margin.toFloat(), (margin - lineTopAtStart).toFloat())
                canvas.clipRect(0f, lineTopAtStart.toFloat(), contentWidth.toFloat(), (lineTopAtStart + contentHeight).toFloat())
                staticLayout.draw(canvas)
                canvas.restore()

                // Draw page number in footer
                val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.GRAY
                    textSize = 10f
                    textAlign = Paint.Align.CENTER
                }
                canvas.drawText("$pageIndex", (pageWidth / 2).toFloat(), (pageHeight - 20).toFloat(), footerPaint)

                pdfDoc.finishPage(page)
                currentLine = lastLineOnThisPage.coerceAtLeast(currentLine + 1)
                pageIndex++
            }

            FileOutputStream(outputFile).use { fos ->
                pdfDoc.writeTo(fos)
            }
            pdfDoc.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // Export PDF pages to image files (JPG or PNG)
    suspend fun exportPagesToImages(
        context: Context,
        inputUri: Uri,
        pageIndices: List<Int>,
        outputDir: File,
        format: String = "JPG", // "JPG" or "PNG"
        quality: Int = 90
    ): List<File> = withContext(Dispatchers.IO) {
        val resultFiles = mutableListOf<File>()
        try {
            val pfd = context.contentResolver.openFileDescriptor(inputUri, "r") ?: return@withContext emptyList()
            pfd.use { descriptor ->
                val renderer = PdfRenderer(descriptor)
                val isJpg = format.equals("JPG", ignoreCase = true)
                val ext = if (isJpg) "jpg" else "png"
                val compressFormat = if (isJpg) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG

                for (idx in pageIndices) {
                    if (idx in 0 until renderer.pageCount) {
                        val page = renderer.openPage(idx)
                        val w = page.width * 2
                        val h = page.height * 2
                        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        val canvas = Canvas(bitmap)
                        canvas.drawColor(Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        page.close()

                        val outFile = File(outputDir, "Page_${idx + 1}_${System.currentTimeMillis()}.$ext")
                        FileOutputStream(outFile).use { fos ->
                            bitmap.compress(compressFormat, quality, fos)
                        }
                        bitmap.recycle()
                        resultFiles.add(outFile)
                    }
                }
                renderer.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        resultFiles
    }
}
