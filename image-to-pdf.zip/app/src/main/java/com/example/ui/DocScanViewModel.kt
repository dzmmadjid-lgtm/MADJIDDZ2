package com.example.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.demo.DemoDocumentFactory
import com.example.core.image.ImageUtils
import com.example.core.ocr.MultiLanguageOcrEngine
import com.example.core.pdf.PdfDocumentGenerator
import com.example.data.model.DetectedLanguage
import com.example.data.model.EnhancementMode
import com.example.data.model.OcrPageResult
import com.example.data.model.PdfExportMode
import com.example.data.model.RegionType
import com.example.data.model.ScanPage
import com.example.data.model.SelectionUnit
import com.example.data.model.TextRegion
import com.example.core.reconstruct.DocumentReconstructor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

enum class AppScreen {
    HOME,
    SCAN_EDIT,
    OCR_RESULT,
    PDF_VIEWER
}

enum class PipelineStage(val titleAr: String, val progress: Float) {
    IDLE("جاهز", 0f),
    DOCUMENT_DETECTION("اكتشاف حدود الوثيقة...", 0.15f),
    TEXT_REGION_DETECTION("تحديد مناطق النصوص وفصل الصور...", 0.35f),
    PERSPECTIVE_CORRECTION("تصحيح المنظور والزوايا...", 0.50f),
    IMAGE_ENHANCEMENT("تطبيق فلتر تحسين الصورة...", 0.65f),
    OCR_PROCESSING("التعرف الضوئي على النصوص (OCR)...", 0.78f),
    LANGUAGE_DETECTION("تحليل اللغات (العربية، الفرنسية، الإنجليزية)...", 0.85f),
    LAYOUT_ANALYSIS("تحليل الهيكل والترتيب الطبيعي للقراءة...", 0.90f),
    DOCUMENT_RECONSTRUCTION("إعادة إنشاء الوثيقة وإزالة الظلال والبقع...", 0.96f),
    COMPLETED("تمت إعادة الإنشاء بنجاح!", 1.0f)
}

data class ExportedDocInfo(
    val file: File,
    val title: String,
    val mode: PdfExportMode,
    val pageCount: Int,
    val createdAt: Long = System.currentTimeMillis()
)

data class DocScanUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val pages: List<ScanPage> = emptyList(),
    val currentPageIndex: Int = 0,
    val cachedBitmaps: Map<String, Bitmap> = emptyMap(),
    val reconstructedBitmaps: Map<String, Bitmap> = emptyMap(),
    val isReconstructedViewActive: Boolean = true,
    val pipelineStage: PipelineStage = PipelineStage.IDLE,
    val isProcessing: Boolean = false,
    val statusMessage: String? = null,
    // Text Selection & Search in OCR result
    val activeViewTab: Int = 0, // 0: Document View, 1: Extracted Text
    val selectedRegionId: String? = null,
    val selectionUnit: SelectionUnit = SelectionUnit.PARAGRAPH,
    val customSelectedText: String? = null,
    val searchQuery: String = "",
    val searchMatchCount: Int = 0,
    // PDF Export
    val isExportingPdf: Boolean = false,
    val latestExportedPdf: ExportedDocInfo? = null,
    val showExportDialog: Boolean = false,
    val recentExports: List<ExportedDocInfo> = emptyList()
)

class DocScanViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(DocScanUiState())
    val uiState: StateFlow<DocScanUiState> = _uiState.asStateFlow()

    private val context get() = getApplication<Application>()

    /**
     * Import multiple images from gallery / photo picker
     */
    fun importImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, statusMessage = "جاري استيراد الصور...") }

            val newPages = mutableListOf<ScanPage>()
            val newBitmaps = _uiState.value.cachedBitmaps.toMutableMap()

            for (uri in uris) {
                val pageId = UUID.randomUUID().toString()
                val bitmap = ImageUtils.loadBitmapFromUri(context, uri)
                if (bitmap != null) {
                    newBitmaps[pageId] = bitmap
                    newPages.add(
                        ScanPage(
                            id = pageId,
                            uriString = uri.toString(),
                            originalWidth = bitmap.width,
                            originalHeight = bitmap.height,
                            enhancementMode = EnhancementMode.B_AND_W
                        )
                    )
                }
            }

            if (newPages.isNotEmpty()) {
                val updatedPages = _uiState.value.pages + newPages
                _uiState.update {
                    it.copy(
                        pages = updatedPages,
                        cachedBitmaps = newBitmaps,
                        currentPageIndex = (_uiState.value.pages.size).coerceAtMost(updatedPages.lastIndex),
                        currentScreen = AppScreen.SCAN_EDIT,
                        isProcessing = false,
                        statusMessage = "تم استيراد ${newPages.size} صورة بنجاح"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        statusMessage = "تعذر تحميل بعض الصور المحددة"
                    )
                }
            }
        }
    }

    /**
     * Load built-in realistic demo document
     */
    fun loadDemoDocument(demoId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, statusMessage = "جاري تجهيز النموذج التجريبي...") }

            val file = DemoDocumentFactory.createDemoDocumentBitmap(context, demoId)
            val uri = Uri.fromFile(file)
            val bitmap = ImageUtils.loadBitmapFromUri(context, uri)

            if (bitmap != null) {
                val pageId = UUID.randomUUID().toString()
                val page = ScanPage(
                    id = pageId,
                    uriString = uri.toString(),
                    originalWidth = bitmap.width,
                    originalHeight = bitmap.height,
                    enhancementMode = EnhancementMode.B_AND_W
                )

                val newBitmaps = _uiState.value.cachedBitmaps.toMutableMap().apply {
                    put(pageId, bitmap)
                }

                _uiState.update {
                    it.copy(
                        pages = listOf(page),
                        cachedBitmaps = newBitmaps,
                        currentPageIndex = 0,
                        currentScreen = AppScreen.SCAN_EDIT,
                        isProcessing = false,
                        statusMessage = "تم فتح المستند التجريبي"
                    )
                }
            }
        }
    }

    fun selectPage(index: Int) {
        if (index in _uiState.value.pages.indices) {
            _uiState.update { it.copy(currentPageIndex = index) }
        }
    }

    fun removePage(index: Int) {
        val currentList = _uiState.value.pages.toMutableList()
        if (index in currentList.indices) {
            val removed = currentList.removeAt(index)
            val newBitmaps = _uiState.value.cachedBitmaps.toMutableMap().apply {
                remove(removed.id)
            }
            val newIndex = (index.coerceAtMost(currentList.lastIndex)).coerceAtLeast(0)

            _uiState.update {
                it.copy(
                    pages = currentList,
                    cachedBitmaps = newBitmaps,
                    currentPageIndex = newIndex,
                    currentScreen = if (currentList.isEmpty()) AppScreen.HOME else it.currentScreen
                )
            }
        }
    }

    fun rotateCurrentPage() {
        val pageIndex = _uiState.value.currentPageIndex
        val page = _uiState.value.pages.getOrNull(pageIndex) ?: return
        val currentBitmap = _uiState.value.cachedBitmaps[page.id] ?: return

        val rotatedBitmap = ImageUtils.rotateBitmap(currentBitmap, 90f)
        val newBitmaps = _uiState.value.cachedBitmaps.toMutableMap().apply {
            put(page.id, rotatedBitmap)
        }

        val updatedPage = page.copy(
            rotationDegrees = (page.rotationDegrees + 90) % 360,
            originalWidth = rotatedBitmap.width,
            originalHeight = rotatedBitmap.height,
            ocrResult = null // invalidate previous OCR on rotation
        )

        val updatedPages = _uiState.value.pages.toMutableList().apply {
            set(pageIndex, updatedPage)
        }

        _uiState.update {
            it.copy(pages = updatedPages, cachedBitmaps = newBitmaps)
        }
    }

    fun setEnhancementMode(mode: EnhancementMode) {
        val pageIndex = _uiState.value.currentPageIndex
        val page = _uiState.value.pages.getOrNull(pageIndex) ?: return

        val updatedPage = page.copy(enhancementMode = mode)
        val updatedPages = _uiState.value.pages.toMutableList().apply {
            set(pageIndex, updatedPage)
        }
        _uiState.update { it.copy(pages = updatedPages) }
    }

    /**
     * Executes the full pipeline:
     * Image -> Document Detection -> Text Region Detection -> Perspective Correction ->
     * Image Enhancement -> OCR -> Language Detection -> Layout Analysis -> Reading Order -> Done
     */
    fun runOcrPipeline() {
        val pages = _uiState.value.pages
        if (pages.isEmpty()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true) }

            val updatedPages = pages.toMutableList()

            for ((idx, page) in pages.withIndex()) {
                val rawBitmap = _uiState.value.cachedBitmaps[page.id] ?: continue

                // Stage 1: Document Detection
                _uiState.update {
                    it.copy(
                        pipelineStage = PipelineStage.DOCUMENT_DETECTION,
                        statusMessage = "الصفحة ${idx + 1}/${pages.size}: فحص حواف ومستند الصفحة..."
                    )
                }
                delay(200)

                // Stage 2: Text Region Detection & Graphics separation
                _uiState.update {
                    it.copy(
                        pipelineStage = PipelineStage.TEXT_REGION_DETECTION,
                        statusMessage = "الصفحة ${idx + 1}/${pages.size}: تحديد مناطق النصوص وفصل الصور..."
                    )
                }
                delay(200)

                // Stage 3: Perspective Correction
                _uiState.update {
                    it.copy(
                        pipelineStage = PipelineStage.PERSPECTIVE_CORRECTION,
                        statusMessage = "الصفحة ${idx + 1}/${pages.size}: تسوية زوايا الصفحة..."
                    )
                }
                delay(150)

                // Stage 4: Image Enhancement
                _uiState.update {
                    it.copy(
                        pipelineStage = PipelineStage.IMAGE_ENHANCEMENT,
                        statusMessage = "الصفحة ${idx + 1}/${pages.size}: تطبيق فلتر ${page.enhancementMode.labelAr}..."
                    )
                }
                val enhancedBitmap = ImageUtils.applyEnhancement(rawBitmap, page.enhancementMode)
                delay(200)

                // Stage 5: OCR Recognition
                _uiState.update {
                    it.copy(
                        pipelineStage = PipelineStage.OCR_PROCESSING,
                        statusMessage = "الصفحة ${idx + 1}/${pages.size}: استخراج النصوص والأرقام..."
                    )
                }
                val ocrResult = MultiLanguageOcrEngine.recognizeDocument(enhancedBitmap, idx)

                // Stage 6: Language Detection
                _uiState.update {
                    it.copy(
                        pipelineStage = PipelineStage.LANGUAGE_DETECTION,
                        statusMessage = "الصفحة ${idx + 1}/${pages.size}: تحديد لغات النص..."
                    )
                }
                delay(150)

                // Stage 7: Layout Analysis & Reading Order
                _uiState.update {
                    it.copy(
                        pipelineStage = PipelineStage.LAYOUT_ANALYSIS,
                        statusMessage = "الصفحة ${idx + 1}/${pages.size}: ترتيب القراءة الطبيعي..."
                    )
                }
                delay(150)

                // Stage 8: Document Digital Reconstruction
                _uiState.update {
                    it.copy(
                        pipelineStage = PipelineStage.DOCUMENT_RECONSTRUCTION,
                        statusMessage = "الصفحة ${idx + 1}/${pages.size}: إزالة الظلال والبقع وإعادة إنشاء الوثيقة..."
                    )
                }
                val reconstructedBitmap = DocumentReconstructor.reconstruct(rawBitmap, ocrResult)

                val newReconstructed = _uiState.value.reconstructedBitmaps.toMutableMap().apply {
                    put(page.id, reconstructedBitmap)
                }
                _uiState.update { it.copy(reconstructedBitmaps = newReconstructed) }

                updatedPages[idx] = page.copy(ocrResult = ocrResult)
            }

            _uiState.update {
                it.copy(
                    pipelineStage = PipelineStage.COMPLETED,
                    pages = updatedPages,
                    isProcessing = false,
                    currentScreen = AppScreen.OCR_RESULT,
                    isReconstructedViewActive = true,
                    statusMessage = "تمت إعادة إنشاء الوثيقة واستخراج النصوص بنجاح!"
                )
            }
        }
    }

    fun setActiveViewTab(tab: Int) {
        _uiState.update { it.copy(activeViewTab = tab) }
    }

    fun selectRegion(regionId: String?) {
        val page = _uiState.value.pages.getOrNull(_uiState.value.currentPageIndex)
        val region = page?.ocrResult?.regions?.find { it.id == regionId }

        _uiState.update {
            it.copy(
                selectedRegionId = regionId,
                customSelectedText = region?.text
            )
        }
    }

    fun setSelectionUnit(unit: SelectionUnit) {
        val page = _uiState.value.pages.getOrNull(_uiState.value.currentPageIndex)
        val ocr = page?.ocrResult ?: return
        val currentRegion = ocr.regions.find { it.id == _uiState.value.selectedRegionId } ?: ocr.regions.firstOrNull()

        val textToSelect = when (unit) {
            SelectionUnit.ALL -> ocr.fullText
            SelectionUnit.PARAGRAPH -> currentRegion?.text ?: ocr.fullText
            SelectionUnit.SENTENCE -> {
                val full = currentRegion?.text ?: ocr.fullText
                full.split(Regex("[.!?\n]+")).firstOrNull { it.isNotBlank() } ?: full
            }
            SelectionUnit.WORD -> {
                val full = currentRegion?.text ?: ocr.fullText
                full.split(Regex("\\s+")).firstOrNull { it.isNotBlank() } ?: full
            }
        }

        _uiState.update {
            it.copy(
                selectionUnit = unit,
                customSelectedText = textToSelect
            )
        }
    }

    fun updateSearchQuery(query: String) {
        val page = _uiState.value.pages.getOrNull(_uiState.value.currentPageIndex)
        val fullText = page?.ocrResult?.fullText ?: ""

        val count = if (query.trim().isEmpty()) {
            0
        } else {
            Regex(Regex.escape(query), RegexOption.IGNORE_CASE).findAll(fullText).count()
        }

        _uiState.update {
            it.copy(searchQuery = query, searchMatchCount = count)
        }
    }

    fun copySelectedText(onSuccess: (String) -> Unit) {
        val text = _uiState.value.customSelectedText
            ?: _uiState.value.pages.getOrNull(_uiState.value.currentPageIndex)?.ocrResult?.fullText
            ?: ""

        if (text.isNotBlank()) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("DocScan OCR Text", text)
            clipboard.setPrimaryClip(clip)
            onSuccess("تم نسخ النص إلى الحافظة")
        }
    }

    fun shareText() {
        val text = _uiState.value.customSelectedText
            ?: _uiState.value.pages.getOrNull(_uiState.value.currentPageIndex)?.ocrResult?.fullText
            ?: ""

        if (text.isNotBlank()) {
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, text)
                type = "text/plain"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val shareIntent = Intent.createChooser(sendIntent, "مشاركة النص المستخرج").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(shareIntent)
        }
    }

    fun toggleReconstructedView(active: Boolean) {
        _uiState.update { it.copy(isReconstructedViewActive = active) }
    }

    fun reconstructCurrentPage() {
        val page = _uiState.value.pages.getOrNull(_uiState.value.currentPageIndex) ?: return
        val raw = _uiState.value.cachedBitmaps[page.id] ?: return
        val ocr = page.ocrResult

        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, statusMessage = "جاري إعادة بناء الوثيقة وإزالة الظلال...") }
            val reconstructed = DocumentReconstructor.reconstruct(raw, ocr)
            val updated = _uiState.value.reconstructedBitmaps.toMutableMap().apply {
                put(page.id, reconstructed)
            }
            _uiState.update {
                it.copy(
                    reconstructedBitmaps = updated,
                    isReconstructedViewActive = true,
                    isProcessing = false,
                    statusMessage = "تمت إعادة إنشاء النسخة النظيفة بنجاح"
                )
            }
        }
    }

    fun shareCurrentDocumentImage(onSuccess: (String) -> Unit = {}) {
        val page = _uiState.value.pages.getOrNull(_uiState.value.currentPageIndex) ?: return
        val bitmap = if (_uiState.value.isReconstructedViewActive) {
            _uiState.value.reconstructedBitmaps[page.id] ?: _uiState.value.cachedBitmaps[page.id]
        } else {
            _uiState.value.cachedBitmaps[page.id]
        } ?: return

        viewModelScope.launch {
            val file = ImageUtils.saveBitmapToCache(context, bitmap, "clean_doc")
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val chooser = Intent.createChooser(intent, "مشاركة صورة الوثيقة النظيفة").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(chooser)
            onSuccess("تم تجهيز صورة الوثيقة للمشاركة")
        }
    }

    fun setShowExportDialog(show: Boolean) {
        _uiState.update { it.copy(showExportDialog = show) }
    }

    fun exportPdf(mode: PdfExportMode, title: String = "DocScan_Document") {
        viewModelScope.launch {
            _uiState.update { it.copy(isExportingPdf = true, statusMessage = "جاري إنشاء ملف PDF...") }

            val pagesWithBitmaps = mutableListOf<Pair<ScanPage, Bitmap>>()
            for (p in _uiState.value.pages) {
                val raw = _uiState.value.cachedBitmaps[p.id] ?: continue
                val bitmapToUse = if (mode == PdfExportMode.RECONSTRUCTED_VECTOR) {
                    _uiState.value.reconstructedBitmaps[p.id] ?: ImageUtils.applyEnhancement(raw, p.enhancementMode)
                } else {
                    ImageUtils.applyEnhancement(raw, p.enhancementMode)
                }
                pagesWithBitmaps.add(Pair(p, bitmapToUse))
            }

            if (pagesWithBitmaps.isNotEmpty()) {
                val pdfFile = PdfDocumentGenerator.generatePdf(context, pagesWithBitmaps, mode, title)
                val exportInfo = ExportedDocInfo(
                    file = pdfFile,
                    title = title,
                    mode = mode,
                    pageCount = pagesWithBitmaps.size
                )

                _uiState.update {
                    it.copy(
                        isExportingPdf = false,
                        showExportDialog = false,
                        latestExportedPdf = exportInfo,
                        recentExports = listOf(exportInfo) + it.recentExports,
                        statusMessage = "تم إنشاء ملف PDF بنجاح!"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isExportingPdf = false,
                        statusMessage = "لا توجد صفحات صالحة للتصدير"
                    )
                }
            }
        }
    }

    fun openExportedPdf(file: File) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            shareExportedPdf(file)
        }
    }

    fun shareExportedPdf(file: File) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val shareIntent = Intent.createChooser(intent, "مشاركة ملف PDF").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(shareIntent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun navigateTo(screen: AppScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }
}
