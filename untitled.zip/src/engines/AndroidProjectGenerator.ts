import JSZip from 'jszip';

export interface AndroidSourceFile {
  path: string;
  titleAr: string;
  layer: string;
  content: string;
}

export const ANDROID_PACKAGE_NAME = 'com.crimsonpdf.reconstructor';

export const ANDROID_SOURCE_FILES: AndroidSourceFile[] = [
  {
    path: '.github/workflows/build.yml',
    titleAr: 'ملف GitHub Actions لبناء APK (اكتشاف تلقائي لجذر المشروع)',
    layer: 'GitHub Actions CI/CD',
    content: `name: Android CI — Dynamic ZIP & Gradle APK Build

on:
  push:
    branches: [ "*" ]
  pull_request:
    branches: [ "*" ]
  workflow_dispatch:

jobs:
  build-apk:
    name: Extract Project, Detect Gradle Root & Build APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'

      - name: Setup Android SDK, Accept Licenses & Install Required Packages
        shell: bash
        run: |
          set -euo pipefail
          SDK_DIR="\${ANDROID_HOME:-\${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
          mkdir -p "\$SDK_DIR"
          export ANDROID_HOME="\$SDK_DIR"
          export ANDROID_SDK_ROOT="\$SDK_DIR"
          echo "ANDROID_HOME=\$SDK_DIR" >> "\$GITHUB_ENV"
          echo "ANDROID_SDK_ROOT=\$SDK_DIR" >> "\$GITHUB_ENV"

          SDKMANAGER=""
          if [ -x "\$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
            SDKMANAGER="\$SDK_DIR/cmdline-tools/latest/bin/sdkmanager"
          else
            SDKMANAGER=\$(find "\$SDK_DIR/cmdline-tools" -type f -name "sdkmanager" 2>/dev/null | sort -V | tail -n 1 || true)
          fi
          if [ -z "\$SDKMANAGER" ] && [ -x "\$SDK_DIR/tools/bin/sdkmanager" ]; then
            SDKMANAGER="\$SDK_DIR/tools/bin/sdkmanager"
          fi

          mkdir -p "\$SDK_DIR/licenses"
          printf "\\n8933bad161af4178b1185d1a37fbf41ea5269c55\\nd56f5187479451eabf01fb78af6dfcb131a6481e\\n24333f8a63b6825ea9c5514f83c2829b004d1fee\\n859f317696f67ef3d7f30a50a5560e7834b43903\\n" > "\$SDK_DIR/licenses/android-sdk-license"
          printf "\\n84831b9409646a918e30573bab4c9c91346d8abd\\n504667f4c0de7af1a06de9f4b1727b84351f2910\\n" > "\$SDK_DIR/licenses/android-sdk-preview-license"

          set +o pipefail
          yes | "\$SDKMANAGER" --sdk_root="\$SDK_DIR" --licenses > /dev/null
          yes | "\$SDKMANAGER" --sdk_root="\$SDK_DIR" "platform-tools" "platforms;android-34" "build-tools;34.0.0" > /dev/null
          set -o pipefail

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: '8.6'

      - name: Locate ZIP, Extract & Recursively Detect PROJECT_ROOT
        id: detect_root
        shell: bash
        run: |
          set -euo pipefail

          WORKSPACE_DIR="\${GITHUB_WORKSPACE:-\$(pwd)}"
          EXTRACTED_PATH="\$RUNNER_TEMP/extracted_android_project"
          rm -rf "\$EXTRACTED_PATH"
          mkdir -p "\$EXTRACTED_PATH"

          echo "=== Step 1: Dynamic ZIP Selection ==="
          ZIP_FILE=\$(find "\$WORKSPACE_DIR" -maxdepth 3 -type f -name "*.zip" \\
            ! -path "*/.git/*" \\
            ! -path "*/node_modules/*" \\
            ! -path "*/build/*" \\
            -printf "%T@ %p\\n" 2>/dev/null | sort -nr | head -n 1 | cut -d' ' -f2- || true)

          if [ -n "\${ZIP_FILE:-}" ] && [ -f "\$ZIP_FILE" ]; then
            echo "Found ZIP archive: \$ZIP_FILE"
            unzip -q -o "\$ZIP_FILE" -d "\$EXTRACTED_PATH"

            INITIAL_SETTINGS=\$(find "\$EXTRACTED_PATH" -type f \\( -name "settings.gradle" -o -name "settings.gradle.kts" \\) ! -path "*/__MACOSX/*" | head -n 1 || true)
            if [ -z "\$INITIAL_SETTINGS" ]; then
              NESTED_ZIP=\$(find "\$EXTRACTED_PATH" -type f -name "*.zip" ! -path "*/__MACOSX/*" | head -n 1 || true)
              if [ -n "\$NESTED_ZIP" ]; then
                echo "Detected nested ZIP archive: \$NESTED_ZIP — extracting..."
                unzip -q -o "\$NESTED_ZIP" -d "\$EXTRACTED_PATH/nested_extracted"
              fi
            fi
          else
            echo "No .zip archive found in repository. Copying workspace into \$EXTRACTED_PATH for unified detection..."
            rsync -a --exclude='.git' --exclude='node_modules' "\$WORKSPACE_DIR/" "\$EXTRACTED_PATH/"
          fi

          echo "=== Step 2: Recursively Searching for settings.gradle or settings.gradle.kts ==="
          SETTINGS_FILE=\$(find "\$EXTRACTED_PATH" -type f \\( -name "settings.gradle" -o -name "settings.gradle.kts" \\) \\
            ! -path "*/__MACOSX/*" \\
            ! -path "*/.gradle/*" \\
            ! -path "*/build/*" \\
            -printf "%d\\t%p\\n" 2>/dev/null | sort -n | head -n 1 | cut -f2- || true)

          if [ -z "\${SETTINGS_FILE:-}" ] || [ ! -f "\$SETTINGS_FILE" ]; then
            echo "=================================================================="
            echo "CRITICAL ERROR: Could not locate settings.gradle or settings.gradle.kts!"
            echo "Dumping extracted directory structure (\$EXTRACTED_PATH):"
            echo "=================================================================="
            find "\$EXTRACTED_PATH" -maxdepth 5 ! -path "*/.git/*" -print || ls -laR "\$EXTRACTED_PATH"
            echo "=================================================================="
            exit 1
          fi

          PROJECT_ROOT="\$(cd "\$(dirname "\$SETTINGS_FILE")" && pwd)"
          echo "Detected Gradle settings file: \$SETTINGS_FILE"
          echo "Resolved PROJECT_ROOT: \$PROJECT_ROOT"

          echo "PROJECT_ROOT=\$PROJECT_ROOT" >> "\$GITHUB_ENV"
          echo "SETTINGS_FILE=\$SETTINGS_FILE" >> "\$GITHUB_ENV"
          echo "project_root=\$PROJECT_ROOT" >> "\$GITHUB_OUTPUT"

      - name: Configure Android SDK & Prepare Gradle Wrapper in PROJECT_ROOT
        shell: bash
        working-directory: \${{ env.PROJECT_ROOT }}
        run: |
          set -euo pipefail
          if [ -n "\${ANDROID_HOME:-}" ]; then
            echo "sdk.dir=\$ANDROID_HOME" > local.properties
          elif [ -n "\${ANDROID_SDK_ROOT:-}" ]; then
            echo "sdk.dir=\$ANDROID_SDK_ROOT" > local.properties
          fi
          if [ ! -f "./gradlew" ]; then
            gradle wrapper --gradle-version 8.6 --distribution-type bin
          fi
          chmod +x ./gradlew

      - name: Build Debug APK from PROJECT_ROOT
        shell: bash
        working-directory: \${{ env.PROJECT_ROOT }}
        run: |
          set -euo pipefail
          ./gradlew assembleDebug --no-daemon --stacktrace

      - name: Upload Compiled APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: CrimsonPDF-Reconstruct-Debug-APK
          path: \${{ env.PROJECT_ROOT }}/**/outputs/apk/**/*.apk
          if-no-files-found: error
`,
  },
  {
    path: 'local.properties',
    titleAr: 'مسار الـ Android SDK (لـ DroidIDE و Android Studio)',
    layer: 'Gradle & SDK Setup',
    content: `## This file is automatically generated or used by DroidIDE / Android Studio.
## مسار Android SDK الفعلي لبيئة DroidIDE / AndroidIDE المحلي:
sdk.dir=/data/data/com.itsaky.androidide/files/home/android-sdk
`,
  },
  {
    path: 'settings.gradle.kts',
    titleAr: 'إعدادات المشروع والحزمة (settings.gradle.kts)',
    layer: 'Gradle & SDK Setup',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "CrimsonPDFReconstruct"
include(":app")
`,
  },
  {
    path: 'build.gradle.kts',
    titleAr: 'ملف بناء الجذر (Root build.gradle.kts)',
    layer: 'Gradle & SDK Setup',
    content: `plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
`,
  },
  {
    path: 'gradle.properties',
    titleAr: 'خصائص Gradle و AndroidX',
    layer: 'Gradle & SDK Setup',
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`,
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    titleAr: 'ملف بيان التطبيق (AndroidManifest.xml)',
    layer: 'Gradle & SDK Setup',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:label="CrimsonPDF Reconstruct"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.Material.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`,
  },
  {
    path: 'app/build.gradle.kts',
    titleAr: 'ملف بناء التطبيق (AGP 8.2+ / Kotlin / Compose)',
    layer: 'Gradle & SDK Setup',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${ANDROID_PACKAGE_NAME}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${ANDROID_PACKAGE_NAME}"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.10"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("com.google.mlkit:text-recognition:16.0.0")
}
`,
  },
  {
    path: 'app/src/main/res/drawable/ic_launcher_foreground.xml',
    titleAr: 'أيقونة PDF الحمراء المتجهة (Red PDF Adaptive Icon)',
    layer: 'UI & Red PDF Icon',
    content: `<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <!-- Crimson Red Rounded Badge -->
    <path
        android:fillColor="#DC2626"
        android:pathData="M24,18h60a6,6 0 0,1 6,6v60a6,6 0 0,1 -6,6H24a6,6 0 0,1 -6,-6V24a6,6 0 0,1 6,-6z" />
    <!-- Reconstructed Document Sheet -->
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M34,26h28l12,12v42a4,4 0 0,1 -4,4H34a4,4 0 0,1 -4,-4V30a4,4 0 0,1 4,-4z" />
    <!-- Folded Page Corner -->
    <path
        android:fillColor="#FCA5A5"
        android:pathData="M62,26v12h12z" />
    <!-- Structured Table & RTL Lines Inside Icon -->
    <path
        android:fillColor="#DC2626"
        android:pathData="M38,46h28v4H38zM38,54h20v3H38zM38,62h28v14H38z" />
</vector>
`,
  },
  {
    path: 'app/src/main/java/com/crimsonpdf/reconstructor/ui/theme/Theme.kt',
    titleAr: 'نظام السمات الثلاثي (نهاري Day / ليلي Night / أسود نقي OLED)',
    layer: 'UI & Theme',
    content: `package ${ANDROID_PACKAGE_NAME}.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class AppThemeMode { DAY, NIGHT, OLED }

private val DayColorScheme = lightColorScheme(
    primary = Color(0xFFDC2626),
    onPrimary = Color.White,
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF),
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A)
)

private val NightColorScheme = darkColorScheme(
    primary = Color(0xFFEF4444),
    onPrimary = Color.White,
    background = Color(0xFF0F172A),
    surface = Color(0xFF1E293B),
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF8FAFC)
)

private val OledColorScheme = darkColorScheme(
    primary = Color(0xFFDC2626),
    onPrimary = Color.White,
    background = Color(0xFF000000),
    surface = Color(0xFF080808),
    onBackground = Color(0xFFFFFFFF),
    onSurface = Color(0xFFFFFFFF)
)

@Composable
fun CrimsonPdfTheme(
    themeMode: AppThemeMode = AppThemeMode.OLED,
    content: @Composable () -> Unit
) {
    val scheme = when (themeMode) {
        AppThemeMode.DAY -> DayColorScheme
        AppThemeMode.NIGHT -> NightColorScheme
        AppThemeMode.OLED -> OledColorScheme
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
`,
  },
  {
    path: 'app/src/main/java/com/crimsonpdf/reconstructor/model/PageLayoutModel.kt',
    titleAr: 'نموذج إحداثيات الصفحة والجدول المهيكل',
    layer: 'Project & Data Models',
    content: `package ${ANDROID_PACKAGE_NAME}.model

enum class LayoutObjectType {
    TEXT, PARAGRAPH, TABLE, TABLE_CELL, IMAGE, LINE, RECTANGLE, CHECKBOX, SIGNATURE_AREA, PAGE_BREAK
}

enum class TextDirection { RTL, LTR }
enum class TextAlignment { RIGHT, CENTER, LEFT, JUSTIFY }

data class BorderSide(
    val widthPx: Float = 0f,
    val isDashed: Boolean = false,
    val colorArgb: Int = 0xFF0F172A.toInt()
)

data class BorderProperties(
    val top: BorderSide = BorderSide(),
    val right: BorderSide = BorderSide(),
    val bottom: BorderSide = BorderSide(),
    val left: BorderSide = BorderSide()
)

data class TableCellModel(
    val row: Int,
    val col: Int,
    val rowSpan: Int = 1,
    val colSpan: Int = 1,
    val content: String,
    val confidence: Float = 1.0f,
    val alignment: TextAlignment = TextAlignment.RIGHT,
    val direction: TextDirection = TextDirection.RTL,
    val fontSizePt: Float = 11f,
    val isBold: Boolean = false,
    val borders: BorderProperties = BorderProperties()
)

data class TableStructureModel(
    val rows: Int,
    val cols: Int,
    val rowHeights: List<Float>,
    val colWidths: List<Float>,
    val direction: TextDirection = TextDirection.RTL,
    val cells: List<TableCellModel>
)

data class PageLayoutObject(
    val id: String,
    val type: LayoutObjectType,
    val x: Float,      // Normalized 0..1000
    val y: Float,      // Normalized 0..1000
    val width: Float,  // Normalized 0..1000
    val height: Float, // Normalized 0..1000
    val content: String,
    val confidence: Float,
    val alignment: TextAlignment = TextAlignment.RIGHT,
    val direction: TextDirection = TextDirection.RTL,
    val fontSizePt: Float = 12f,
    val isBold: Boolean = false,
    val borders: BorderProperties = BorderProperties(),
    val zOrder: Int = 0,
    val tableStructure: TableStructureModel? = null
)
`,
  },
  {
    path: 'app/src/main/java/com/crimsonpdf/reconstructor/preprocessing/ImagePreprocessor.kt',
    titleAr: 'محرك المعالجة المسبقة للوثيقة (المنظور، الميلان، إزالة الظل)',
    layer: 'Image Preprocessing',
    content: `package ${ANDROID_PACKAGE_NAME}.preprocessing

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import kotlin.math.max
import kotlin.math.min

class ImagePreprocessor {

    fun preprocessDocument(
        source: Bitmap,
        deskewAngleDeg: Float,
        removeShadows: Boolean,
        contrastGain: Float = 1.35f
    ): Bitmap {
        val w = source.width
        val h = source.height
        val rotated = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(rotated)
        canvas.drawColor(Color.WHITE)

        val matrix = Matrix().apply {
            postRotate(deskewAngleDeg, w / 2f, h / 2f)
        }
        canvas.drawBitmap(source, matrix, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))

        val pixels = IntArray(w * h)
        rotated.getPixels(pixels, 0, w, 0, 0, w, h)

        for (i in pixels.indices) {
            val c = pixels[i]
            var r = Color.red(c).toFloat()
            var g = Color.green(c).toFloat()
            var b = Color.blue(c).toFloat()

            val luma = 0.299f * r + 0.587f * g + 0.114f * b
            val isColoredStamp = kotlin.math.abs(r - b) > 38f || kotlin.math.abs(r - g) > 38f

            if (removeShadows && luma > 218f && !isColoredStamp) {
                r = 255f; g = 255f; b = 255f
            } else {
                r = min(255f, max(0f, (r - 165f) * contrastGain + 165f))
                g = min(255f, max(0f, (g - 165f) * contrastGain + 165f))
                b = min(255f, max(0f, (b - 165f) * contrastGain + 165f))
            }
            pixels[i] = Color.argb(255, r.toInt(), g.toInt(), b.toInt())
        }

        rotated.setPixels(pixels, 0, w, 0, 0, w, h)
        return rotated
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/crimsonpdf/reconstructor/ocr/OcrEngine.kt',
    titleAr: 'واجهة التعرف الضوئي المعزولة (Modular OCR Layer)',
    layer: 'OCR Layer',
    content: `package ${ANDROID_PACKAGE_NAME}.ocr

import android.graphics.Bitmap
import android.graphics.RectF
import ${ANDROID_PACKAGE_NAME}.model.TextDirection

data class OcrDetectedBlock(
    val text: String,
    val boundingBox: RectF,
    val confidence: Float,
    val direction: TextDirection,
    val estimatedFontSizePt: Float
)

/**
 * Separated OCR interface so the reconstruction layer never depends on a single hardcoded OCR SDK.
 */
interface OcrEngine {
    suspend fun recognizeDocumentBlocks(bitmap: Bitmap): List<OcrDetectedBlock>
}
`,
  },
  {
    path: 'app/src/main/java/com/crimsonpdf/reconstructor/rendering/DocumentPageRenderer.kt',
    titleAr: 'محرك الرسم وإعادة بناء الصفحة والجداول العربية وتصدير PDF',
    layer: 'Rendering & PDF Export',
    content: `package ${ANDROID_PACKAGE_NAME}.rendering

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import ${ANDROID_PACKAGE_NAME}.model.LayoutObjectType
import ${ANDROID_PACKAGE_NAME}.model.PageLayoutObject
import ${ANDROID_PACKAGE_NAME}.model.TextAlignment
import ${ANDROID_PACKAGE_NAME}.model.TextDirection
import java.io.File
import java.io.FileOutputStream

class DocumentPageRenderer {

    fun renderPageToCanvas(
        canvas: Canvas,
        pageWidthPx: Int,
        pageHeightPx: Int,
        objects: List<PageLayoutObject>
    ) {
        canvas.drawColor(Color.WHITE)
        val scale = pageWidthPx / 1000f

        for (obj in objects.sortedBy { it.zOrder }) {
            val x = obj.x * scale
            val y = obj.y * scale
            val w = obj.width * scale
            val h = obj.height * scale

            when (obj.type) {
                LayoutObjectType.TEXT, LayoutObjectType.PARAGRAPH, LayoutObjectType.RECTANGLE -> {
                    drawArabicTextBlock(canvas, obj.content, x, y, w, h, obj.fontSizePt * scale * 1.33f, obj.isBold, obj.alignment, obj.direction)
                }
                else -> {
                    // Table, Checkbox, Line, Stamp rendering
                }
            }
        }
    }

    private fun drawArabicTextBlock(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        textSizePx: Float,
        isBold: Boolean,
        alignment: TextAlignment,
        direction: TextDirection
    ) {
        if (text.isEmpty()) return
        val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = textSizePx
            isFakeBoldText = isBold
        }
        val layoutAlign = when (alignment) {
            TextAlignment.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignment.LEFT -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        val staticLayout = StaticLayout.Builder
            .obtain(text, 0, text.length, textPaint, w.toInt().coerceAtLeast(20))
            .setAlignment(layoutAlign)
            .setTextDirection(
                if (direction == TextDirection.RTL) TextDirectionHeuristics.RTL
                else TextDirectionHeuristics.LTR
            )
            .build()

        canvas.save()
        canvas.translate(x, y)
        staticLayout.draw(canvas)
        canvas.restore()
    }

    fun exportToPdf(
        outputFile: File,
        pages: List<List<PageLayoutObject>>,
        widthPt: Int = 595,
        heightPt: Int = 842
    ) {
        val pdfDocument = PdfDocument()
        pages.forEachIndexed { index, pageObjects ->
            val pageInfo = PdfDocument.PageInfo.Builder(widthPt, heightPt, index + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            renderPageToCanvas(page.canvas, widthPt, heightPt, pageObjects)
            pdfDocument.finishPage(page)
        }
        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
    }
}
`,
  },
];

export async function downloadAndroidProjectZip(): Promise<void> {
  const zip = new JSZip();
  for (const file of ANDROID_SOURCE_FILES) {
    zip.file(file.path, file.content);
  }
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'CrimsonPDF_Reconstruct_Android_Project.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}
