package com.example.core.termux

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import java.util.concurrent.ConcurrentHashMap

class TermuxResultReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent == null) return

        val executionId = intent.getStringExtra(TermuxConstants.EXTRA_EXECUTION_ID) ?: ""
        val bundle = intent.getBundleExtra(TermuxConstants.EXTRA_PLUGIN_RESULT_BUNDLE) ?: intent.extras

        val stdout = bundle?.getString(TermuxConstants.EXTRA_PLUGIN_RESULT_BUNDLE_STDOUT) ?: ""
        val stderr = bundle?.getString(TermuxConstants.EXTRA_PLUGIN_RESULT_BUNDLE_STDERR) ?: ""
        val exitCode = bundle?.getInt(TermuxConstants.EXTRA_PLUGIN_RESULT_BUNDLE_EXIT_CODE, -1) ?: -1
        val errCode = bundle?.getInt(TermuxConstants.EXTRA_PLUGIN_RESULT_BUNDLE_ERR, 0) ?: 0
        val errMsg = bundle?.getString(TermuxConstants.EXTRA_PLUGIN_RESULT_BUNDLE_ERRMSG)

        Log.d(TAG, "Termux result received for id=$executionId, exitCode=$exitCode, errCode=$errCode, errMsg=$errMsg")

        val result = TermuxExecutionResult(
            executionId = executionId,
            stdout = stdout,
            stderr = stderr,
            exitCode = exitCode,
            errCode = errCode,
            errMsg = errMsg
        )

        // Notify active listener for this execution
        val listener = activeListeners.remove(executionId)
        if (listener != null) {
            listener.invoke(result)
        }

        // Also notify global observers (like terminal logs)
        globalListeners.forEach { it.invoke(result) }
    }

    companion object {
        private const val TAG = "TermuxResultReceiver"
        private val activeListeners = ConcurrentHashMap<String, (TermuxExecutionResult) -> Unit>()
        private val globalListeners = mutableListOf<(TermuxExecutionResult) -> Unit>()

        fun registerListener(executionId: String, callback: (TermuxExecutionResult) -> Unit) {
            activeListeners[executionId] = callback
        }

        fun removeListener(executionId: String) {
            activeListeners.remove(executionId)
        }

        fun addGlobalListener(callback: (TermuxExecutionResult) -> Unit) {
            globalListeners.add(callback)
        }

        fun removeGlobalListener(callback: (TermuxExecutionResult) -> Unit) {
            globalListeners.remove(callback)
        }
    }
}
