package com.example.streamhub.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.streamhub.data.SampleCatalog
import com.example.streamhub.model.MediaItem
import com.example.streamhub.model.MediaType
import com.example.streamhub.model.NavigationDestination
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StreamHubViewModel : ViewModel() {

    // إدارة الثيم (OLED الفاحم vs النهاري الأنيق)
    private val _themeMode = MutableStateFlow(AppThemeMode.OLED)
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    // الوجهة الحالية
    private val _activeDestination = MutableStateFlow(NavigationDestination.HOME)
    val activeDestination: StateFlow<NavigationDestination> = _activeDestination.asStateFlow()

    // القائمة الجانبية (Drawer)
    private val _isDrawerOpen = MutableStateFlow(false)
    val isDrawerOpen: StateFlow<Boolean> = _isDrawerOpen.asStateFlow()

    // تفاصيل الوسائط المحددة
    private val _selectedMedia = MutableStateFlow<MediaItem?>(null)
    val selectedMedia: StateFlow<MediaItem?> = _selectedMedia.asStateFlow()

    // مشغل الفيديو
    private val _isPlayerActive = MutableStateFlow(false)
    val isPlayerActive: StateFlow<Boolean> = _isPlayerActive.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0.28f)
    val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    private val _playbackSeconds = MutableStateFlow(24 * 60 + 15) // 24:15
    val playbackSeconds: StateFlow<Int> = _playbackSeconds.asStateFlow()

    private val _totalDurationSeconds = MutableStateFlow(124 * 60) // 2h 04m
    val totalDurationSeconds: StateFlow<Int> = _totalDurationSeconds.asStateFlow()

    private val _selectedQuality = MutableStateFlow("4K Ultra HD")
    val selectedQuality: StateFlow<String> = _selectedQuality.asStateFlow()

    private val _selectedAudio = MutableStateFlow("Dolby Atmos (English)")
    val selectedAudio: StateFlow<String> = _selectedAudio.asStateFlow()

    private val _selectedSubtitle = MutableStateFlow("العربية")
    val selectedSubtitle: StateFlow<String> = _selectedSubtitle.asStateFlow()

    // البحث والتصفية
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedGenre = MutableStateFlow("All")
    val selectedGenre: StateFlow<String> = _selectedGenre.asStateFlow()

    private val _filter4KOnly = MutableStateFlow(false)
    val filter4KOnly: StateFlow<Boolean> = _filter4KOnly.asStateFlow()

    // قائمة المشاهدة لاحقاً (Watchlist)
    private val _watchlist = MutableStateFlow(setOf("movie_cyberpunk", "series_andalus", "anime_neon_tokyo"))
    val watchlist: StateFlow<Set<String>> = _watchlist.asStateFlow()

    // التحميل للمشاهدة بدون إنترنت (Downloads)
    // MediaId -> Progress (1.0f means completed)
    private val _downloads = MutableStateFlow(
        mapOf(
            "movie_interstellar_horizon" to 1.0f,
            "movie_cyberpunk" to 0.72f
        )
    )
    val downloads: StateFlow<Map<String, Float>> = _downloads.asStateFlow()

    // حالة تقدم تنزيل متحركة
    private var downloadJob: Job? = null

    // تصفية المحتوى بناءً على البحث والتصنيف
    val filteredMedia: StateFlow<List<MediaItem>> = combine(
        _searchQuery,
        _selectedCategory,
        _selectedGenre,
        _filter4KOnly
    ) { query, category, genre, only4K ->
        SampleCatalog.allMedia.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.title.contains(query, ignoreCase = true) ||
                    item.titleAr.contains(query, ignoreCase = true) ||
                    item.genres.any { it.contains(query, ignoreCase = true) } ||
                    item.cast.any { it.contains(query, ignoreCase = true) }

            val matchesCategory = when (category) {
                "All" -> true
                "Movies" -> item.type == MediaType.MOVIE
                "TV Shows" -> item.type == MediaType.SERIES
                "Anime" -> item.type == MediaType.ANIME
                "Live TV" -> item.type == MediaType.LIVE_TV
                else -> true
            }

            val matchesGenre = if (genre == "All") true else item.genres.contains(genre)
            val matches4K = if (!only4K) true else item.videoQuality.contains("4K", ignoreCase = true)

            matchesQuery && matchesCategory && matchesGenre && matches4K
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SampleCatalog.allMedia)

    // العناصر الرائجة (Trending)
    val trendingMedia: List<MediaItem> = SampleCatalog.allMedia
        .filter { it.trendingRank != null }
        .sortedBy { it.trendingRank }

    // متابعة المشاهدة (Continue Watching)
    val continueWatching: List<MediaItem> = SampleCatalog.allMedia
        .filter { it.watchProgress != null }

    // البث المباشر (Live TV)
    val liveChannels: List<MediaItem> = SampleCatalog.allMedia
        .filter { it.type == MediaType.LIVE_TV }

    init {
        // محاكاة استمرار تشغيل الفيديو التفاعلي
        viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_isPlayerActive.value && _isPlaying.value) {
                    val current = _playbackSeconds.value + 1
                    val total = _totalDurationSeconds.value
                    if (current <= total) {
                        _playbackSeconds.value = current
                        _playbackProgress.value = current.toFloat() / total.toFloat()
                    }
                }
            }
        }
    }

    // تبديل أوضاع السمة الثلاثية: OLED (الأسود المطلق) <-> نهاري فخم
    fun toggleThemeMode() {
        _themeMode.value = when (_themeMode.value) {
            AppThemeMode.OLED -> AppThemeMode.LIGHT
            AppThemeMode.LIGHT -> AppThemeMode.OLED
            AppThemeMode.DARK -> AppThemeMode.OLED
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        _themeMode.value = mode
    }

    fun openDrawer() {
        _isDrawerOpen.value = true
    }

    fun closeDrawer() {
        _isDrawerOpen.value = false
    }

    fun navigateTo(destination: NavigationDestination) {
        _activeDestination.value = destination
        _isDrawerOpen.value = false
    }

    fun openMediaDetail(media: MediaItem) {
        _selectedMedia.value = media
    }

    fun closeMediaDetail() {
        _selectedMedia.value = null
    }

    fun playMedia(media: MediaItem) {
        _selectedMedia.value = media
        _isPlayerActive.value = true
        _isPlaying.value = true
        _playbackSeconds.value = 120
        _playbackProgress.value = 0.05f
    }

    fun closePlayer() {
        _isPlayerActive.value = false
        _isPlaying.value = false
    }

    fun togglePlayPause() {
        _isPlaying.value = !_isPlaying.value
    }

    fun seekTo(progress: Float) {
        _playbackProgress.value = progress
        _playbackSeconds.value = (progress * _totalDurationSeconds.value).toInt()
    }

    fun skipForward10() {
        val next = (_playbackSeconds.value + 10).coerceAtMost(_totalDurationSeconds.value)
        _playbackSeconds.value = next
        _playbackProgress.value = next.toFloat() / _totalDurationSeconds.value
    }

    fun skipBackward10() {
        val prev = (_playbackSeconds.value - 10).coerceAtLeast(0)
        _playbackSeconds.value = prev
        _playbackProgress.value = prev.toFloat() / _totalDurationSeconds.value
    }

    fun setQuality(quality: String) {
        _selectedQuality.value = quality
    }

    fun setAudio(audio: String) {
        _selectedAudio.value = audio
    }

    fun setSubtitle(sub: String) {
        _selectedSubtitle.value = sub
    }

    fun toggleWatchlist(mediaId: String) {
        val current = _watchlist.value.toMutableSet()
        if (current.contains(mediaId)) {
            current.remove(mediaId)
        } else {
            current.add(mediaId)
        }
        _watchlist.value = current
    }

    fun startOrToggleDownload(mediaId: String) {
        val current = _downloads.value.toMutableMap()
        if (current.containsKey(mediaId) && current[mediaId] == 1.0f) {
            // تنزيل مكتمل بالفعل
            return
        }

        // بدء محاكاة التنزيل
        current[mediaId] = 0.1f
        _downloads.value = current

        downloadJob?.cancel()
        downloadJob = viewModelScope.launch {
            var progress = 0.1f
            while (progress < 1.0f) {
                delay(400)
                progress += 0.15f
                val map = _downloads.value.toMutableMap()
                map[mediaId] = progress.coerceAtMost(1.0f)
                _downloads.value = map
            }
        }
    }

    fun deleteDownload(mediaId: String) {
        val current = _downloads.value.toMutableMap()
        current.remove(mediaId)
        _downloads.value = current
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setSelectedGenre(genre: String) {
        _selectedGenre.value = genre
    }

    fun toggleFilter4K() {
        _filter4KOnly.value = !_filter4KOnly.value
    }

    /**
     * التعامل مع زر الرجوع الفعلي للهاتف:
     * يرجع true إذا تم استهلاك الحدث داخل التطبيق (إغلاق المشغل، أو القائمة، أو العودة للشاشة الرئيسية)،
     * ويرجع false للسماح للنظام بالخروج.
     */
    fun handleSystemBackPress(): Boolean {
        if (_isPlayerActive.value) {
            closePlayer()
            return true
        }
        if (_selectedMedia.value != null) {
            closeMediaDetail()
            return true
        }
        if (_isDrawerOpen.value) {
            closeDrawer()
            return true
        }
        if (_activeDestination.value != NavigationDestination.HOME) {
            navigateTo(NavigationDestination.HOME)
            return true
        }
        return false
    }
}
