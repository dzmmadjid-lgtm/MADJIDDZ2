package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RegionType
import com.example.data.model.TextRegion
import com.example.ui.theme.RegionGraphicColor
import com.example.ui.theme.RegionListColor
import com.example.ui.theme.RegionNumberColor
import com.example.ui.theme.RegionParagraphColor
import com.example.ui.theme.RegionTableCellColor
import com.example.ui.theme.RegionTitleColor

@Composable
fun ZoomableDocumentView(
    bitmap: Bitmap,
    modifier: Modifier = Modifier,
    regions: List<TextRegion> = emptyList(),
    selectedRegionId: String? = null,
    onRegionSelected: ((String?) -> Unit)? = null,
    showRegionsOverlay: Boolean = false
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 4.5f)
                    if (scale > 1f) {
                        val maxOffsetX = (size.width * (scale - 1f)) / 2f
                        val maxOffsetY = (size.height * (scale - 1f)) / 2f
                        offset = Offset(
                            x = (offset.x + pan.x).coerceIn(-maxOffsetX, maxOffsetX),
                            y = (offset.y + pan.y).coerceIn(-maxOffsetY, maxOffsetY)
                        )
                    } else {
                        offset = Offset.Zero
                    }
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        if (scale > 1.2f) {
                            scale = 1f
                            offset = Offset.Zero
                        } else {
                            scale = 2.2f
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        val containerWidth = maxWidth.value
        val containerHeight = maxHeight.value

        val imageAspect = bitmap.width.toFloat() / bitmap.height.toFloat()
        val containerAspect = containerWidth / containerHeight

        // Maximize page size: use almost 100% of the available viewport (just 4dp safety margin)
        val horizontalMargin = 4f
        val verticalMargin = 4f

        val displayWidth: Float
        val displayHeight: Float

        if (imageAspect > containerAspect) {
            displayWidth = containerWidth - (horizontalMargin * 2)
            displayHeight = displayWidth / imageAspect
        } else {
            displayHeight = containerHeight - (verticalMargin * 2)
            displayWidth = displayHeight * imageAspect
        }

        Box(
            modifier = Modifier
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offset.x
                    translationY = offset.y
                }
                .size(displayWidth.dp, displayHeight.dp)
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(2.dp))
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White)
        ) {
            // Paper Image
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Document Page",
                modifier = Modifier.fillMaxSize()
            )

            // Optional Interactive Regions Overlay
            if (showRegionsOverlay && regions.isNotEmpty()) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(regions, selectedRegionId) {
                            if (onRegionSelected != null) {
                                detectTapGestures { tapOffset ->
                                    val normX = tapOffset.x / size.width
                                    val normY = tapOffset.y / size.height

                                    val tappedRegion = regions.find { r ->
                                        val b = r.boundingBox
                                        normX in b.left..b.right && normY in b.top..b.bottom
                                    }
                                    onRegionSelected(tappedRegion?.id)
                                }
                            }
                        }
                ) {
                    val canvasW = size.width
                    val canvasH = size.height

                    for (r in regions) {
                        val isSelected = r.id == selectedRegionId
                        val b = r.boundingBox

                        val left = b.left * canvasW
                        val top = b.top * canvasH
                        val width = b.width * canvasW
                        val height = b.height * canvasH

                        val color = when (r.type) {
                            RegionType.TITLE -> RegionTitleColor
                            RegionType.PARAGRAPH -> RegionParagraphColor
                            RegionType.LIST_ITEM -> RegionListColor
                            RegionType.NUMBER -> RegionNumberColor
                            RegionType.TABLE_CELL -> RegionTableCellColor
                            RegionType.GRAPHIC_OR_PHOTO -> RegionGraphicColor
                            RegionType.SHORT_TEXT -> Color(0xFF00897B)
                        }

                        drawRect(
                            color = color.copy(alpha = if (isSelected) 0.35f else 0.16f),
                            topLeft = Offset(left, top),
                            size = Size(width, height)
                        )

                        drawRect(
                            color = if (isSelected) Color.White else color.copy(alpha = 0.85f),
                            topLeft = Offset(left, top),
                            size = Size(width, height),
                            style = Stroke(width = if (isSelected) 3.5f else 1.6f)
                        )
                    }
                }
            }
        }

        // Zoom Reset Floating Badge
        if (scale > 1.05f) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                tonalElevation = 4.dp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
            ) {
                androidx.compose.foundation.layout.Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${(scale * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 11.sp
                    )
                    IconButton(
                        onClick = {
                            scale = 1f
                            offset = Offset.Zero
                        },
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("reset_zoom_button")
                    ) {
                        Icon(imageVector = Icons.Default.RestartAlt, contentDescription = "إعادة ضبط التكبير", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
