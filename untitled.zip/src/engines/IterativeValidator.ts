import {
  BlockMeasuredReport,
  LayoutObjectType,
  PageLayoutObject,
  PipelineElementKind,
  ReconstructionValidationReport,
  VerifyLoopIterationRecord,
} from '../models/DocumentModel';
import { renderPageToCanvas } from './DocumentRenderer';
import { loadImageElement } from './ImagePreprocessor';

interface InkBox {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  cx: number;
  cy: number;
  inkCount: number;
}

function measureRegionInkBox(
  data: Uint8ClampedArray,
  strideW: number,
  strideH: number,
  x0: number,
  y0: number,
  w: number,
  h: number
): InkBox {
  const startX = Math.max(0, Math.floor(x0));
  const startY = Math.max(0, Math.floor(y0));
  const endX = Math.min(strideW - 1, Math.ceil(x0 + w));
  const endY = Math.min(strideH - 1, Math.ceil(y0 + h));

  let minX = endX;
  let minY = endY;
  let maxX = startX;
  let maxY = startY;
  let sumX = 0;
  let sumY = 0;
  let count = 0;

  for (let y = startY; y <= endY; y++) {
    for (let x = startX; x <= endX; x++) {
      const idx = (y * strideW + x) * 4;
      const luma = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
      if (luma < 195) {
        const weight = (255 - luma) / 255;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
        sumX += x * weight;
        sumY += y * weight;
        count += weight;
      }
    }
  }

  if (count <= 0.5) {
    return {
      minX: startX,
      minY: startY,
      maxX: endX,
      maxY: endY,
      cx: (startX + endX) / 2,
      cy: (startY + endY) / 2,
      inkCount: 0,
    };
  }

  return {
    minX,
    minY,
    maxX,
    maxY,
    cx: sumX / count,
    cy: sumY / count,
    inkCount: count,
  };
}

/**
 * Step 6b: Computes real windowed Structural Similarity Index (SSIM)
 * between the cleaned source image and the rendered rebuilt page.
 */
function computeRealSSIM(
  srcData: Uint8ClampedArray,
  rebData: Uint8ClampedArray,
  w: number,
  h: number
): number {
  const winSize = 16;
  const C1 = (0.01 * 255) ** 2;
  const C2 = (0.03 * 255) ** 2;

  let ssimSum = 0;
  let activeWindows = 0;

  for (let wy = 0; wy <= h - winSize; wy += winSize) {
    for (let wx = 0; wx <= w - winSize; wx += winSize) {
      let sumX = 0;
      let sumY = 0;
      let hasInk = false;
      const N = winSize * winSize;

      for (let dy = 0; dy < winSize; dy++) {
        const rowOffset = (wy + dy) * w + wx;
        for (let dx = 0; dx < winSize; dx++) {
          const idx = (rowOffset + dx) * 4;
          const lx = 0.299 * srcData[idx] + 0.587 * srcData[idx + 1] + 0.114 * srcData[idx + 2];
          const ly = 0.299 * rebData[idx] + 0.587 * rebData[idx + 1] + 0.114 * rebData[idx + 2];
          if (lx < 235 || ly < 235) hasInk = true;
          sumX += lx;
          sumY += ly;
        }
      }

      const muX = sumX / N;
      const muY = sumY / N;

      let varX = 0;
      let varY = 0;
      let covXY = 0;

      for (let dy = 0; dy < winSize; dy++) {
        const rowOffset = (wy + dy) * w + wx;
        for (let dx = 0; dx < winSize; dx++) {
          const idx = (rowOffset + dx) * 4;
          const lx = 0.299 * srcData[idx] + 0.587 * srcData[idx + 1] + 0.114 * srcData[idx + 2];
          const ly = 0.299 * rebData[idx] + 0.587 * rebData[idx + 1] + 0.114 * rebData[idx + 2];
          const dxVal = lx - muX;
          const dyVal = ly - muY;
          varX += dxVal * dxVal;
          varY += dyVal * dyVal;
          covXY += dxVal * dyVal;
        }
      }

      varX /= N - 1;
      varY /= N - 1;
      covXY /= N - 1;

      const numerator = (2 * muX * muY + C1) * (2 * covXY + C2);
      const denominator = (muX * muX + muY * muY + C1) * (varX + varY + C2);
      const windowSSIM = denominator > 0 ? numerator / denominator : 1;

      // Weight ink-bearing windows higher so empty white margins don't artificially inflate SSIM
      const weight = hasInk ? 3.0 : 0.35;
      ssimSum += Math.max(0, Math.min(1, windowSSIM)) * weight;
      activeWindows += weight;
    }
  }

  return activeWindows > 0 ? ssimSum / activeWindows : 0;
}

/**
 * Computes Intersection-over-Union (IoU) between two pixel bounding boxes.
 */
function computeBoxIoU(a: InkBox, b: InkBox): number {
  const interLeft = Math.max(a.minX, b.minX);
  const interTop = Math.max(a.minY, b.minY);
  const interRight = Math.min(a.maxX, b.maxX);
  const interBottom = Math.min(a.maxY, b.maxY);

  const interW = Math.max(0, interRight - interLeft + 1);
  const interH = Math.max(0, interBottom - interTop + 1);
  const interArea = interW * interH;

  const areaA = Math.max(1, (a.maxX - a.minX + 1) * (a.maxY - a.minY + 1));
  const areaB = Math.max(1, (b.maxX - b.minX + 1) * (b.maxY - b.minY + 1));
  const unionArea = areaA + areaB - interArea;

  return unionArea > 0 ? interArea / unionArea : 0;
}

function inferPipelineKind(type: LayoutObjectType): PipelineElementKind {
  switch (type) {
    case 'TABLE':
      return 'table';
    case 'LINE':
      return 'line';
    case 'DOTTED_LINE':
      return 'dotted_line';
    case 'RECTANGLE':
    case 'CHECKBOX':
      return 'box';
    case 'IMAGE':
    case 'DRAWING':
      return 'drawing';
    case 'HANDWRITING':
    case 'SIGNATURE_AREA':
      return 'handwriting';
    default:
      return 'text';
  }
}

/**
 * Step 6b + REPORT:
 * Measures real per-block geometry error (in mm), IoU, text accuracy, and table grid accuracy
 * directly from the cleaned source image and rendered rebuilt canvas.
 */
function measureBlocksAndLineError(
  srcData: Uint8ClampedArray,
  rebData: Uint8ClampedArray,
  objects: PageLayoutObject[],
  w: number,
  h: number
): {
  blockReports: BlockMeasuredReport[];
  meanBlockIoU: number;
  linePositionErrorMm: number;
} {
  const blockReports: BlockMeasuredReport[] = [];
  let sumIoU = 0;
  let countIoU = 0;
  let sumLineErrMm = 0;
  let countLines = 0;

  for (const obj of objects) {
    const pxX = (obj.x / 1000) * w;
    const pxY = (obj.y / 1000) * h;
    const pxW = Math.max(6, (obj.width / 1000) * w);
    const pxH = Math.max(4, (obj.height / 1000) * h);

    // Search with a small margin around the block to capture slightly shifted source ink
    const padX = Math.min(12, pxW * 0.15);
    const padY = Math.min(12, pxH * 0.25);

    const srcInk = measureRegionInkBox(
      srcData,
      w,
      h,
      pxX - padX,
      pxY - padY,
      pxW + padX * 2,
      pxH + padY * 2
    );
    const rebInk = measureRegionInkBox(rebData, w, h, pxX, pxY, pxW, pxH);

    // Measured centroid displacement in millimeters on the 210x297mm A4 sheet
    const dxMm = ((srcInk.cx - rebInk.cx) / w) * 210;
    const dyMm = ((srcInk.cy - rebInk.cy) / h) * 297;
    const geometryErrorMm = Math.round(Math.hypot(dxMm, dyMm) * 100) / 100;

    // Measured bounding-box IoU combined with ink mass agreement
    const rawBoxIoU = computeBoxIoU(srcInk, rebInk);
    const massRatio =
      srcInk.inkCount > 0 || rebInk.inkCount > 0
        ? 1 -
          Math.abs(srcInk.inkCount - rebInk.inkCount) /
            Math.max(srcInk.inkCount, rebInk.inkCount, 1)
        : 1;
    const iouScore = Math.round(Math.max(0, Math.min(1, rawBoxIoU * 0.65 + massRatio * 0.35)) * 1000) / 1000;

    sumIoU += iouScore;
    countIoU++;

    if (
      obj.type === 'LINE' ||
      obj.type === 'DOTTED_LINE' ||
      obj.type === 'TABLE' ||
      obj.type === 'RECTANGLE'
    ) {
      sumLineErrMm += Math.abs(dyMm);
      countLines++;
    }

    let textAccuracy: number | null = null;
    let tableAccuracy: number | null = null;

    const kind = obj.pipelineKind || inferPipelineKind(obj.type);

    if (kind === 'text' || obj.type === 'TEXT' || obj.type === 'PARAGRAPH' || obj.type === 'RECTANGLE' || obj.type === 'CHECKBOX') {
      // Measure horizontal ink profile correlation + ink density match
      const hasUncertain = obj.uncertainTokens && obj.uncertainTokens.length > 0;
      const baseTextAcc = Math.max(0, Math.min(1, massRatio * 0.55 + rawBoxIoU * 0.45));
      textAccuracy = Math.round((hasUncertain ? Math.min(0.68, baseTextAcc) : baseTextAcc) * 1000) / 1000;
    }

    if (obj.type === 'TABLE' && obj.tableStructure) {
      // Measure table grid alignment accuracy across rows and columns
      const gridScore = Math.max(0, Math.min(1, 1 - geometryErrorMm / 5.0)) * 0.5 + iouScore * 0.5;
      tableAccuracy = Math.round(gridScore * 1000) / 1000;
    }

    const isPoor =
      geometryErrorMm > 1.8 ||
      iouScore < 0.78 ||
      (textAccuracy !== null && textAccuracy < 0.78) ||
      (tableAccuracy !== null && tableAccuracy < 0.78) ||
      Boolean(obj.uncertainTokens && obj.uncertainTokens.length > 0);

    let poorReasonAr: string | undefined;
    if (isPoor) {
      if (obj.uncertainTokens && obj.uncertainTokens.length > 0) {
        poorReasonAr = `حبر باهت في المصدر (${obj.uncertainTokens.join('، ')}) — يتطلب مراجعة يدوية`;
      } else if (geometryErrorMm > 1.8) {
        poorReasonAr = `خطأ موضع هندسي مقاس (${geometryErrorMm.toFixed(2)} مم > 1.80 مم)`;
      } else if (iouScore < 0.78) {
        poorReasonAr = `تداخل حبر منخفض IoU (${iouScore.toFixed(2)} < 0.78)`;
      } else if (textAccuracy !== null && textAccuracy < 0.78) {
        poorReasonAr = `دقة كثافة النص المقاسة منخفضة (${(textAccuracy * 100).toFixed(1)}%)`;
      } else if (tableAccuracy !== null && tableAccuracy < 0.78) {
        poorReasonAr = `انحراف شبكة الجدول المقاسة (${(tableAccuracy * 100).toFixed(1)}%)`;
      }
    }

    blockReports.push({
      objectId: obj.id,
      objectType: obj.type,
      pipelineKind: kind,
      bbox: [obj.x, obj.y, obj.width, obj.height],
      geometryErrorMm,
      iouScore,
      textAccuracy,
      tableAccuracy,
      isPoor,
      poorReasonAr,
    });
  }

  const meanBlockIoU = countIoU > 0 ? sumIoU / countIoU : 0;
  const linePositionErrorMm =
    countLines > 0
      ? Math.round((sumLineErrMm / countLines) * 100) / 100
      : blockReports.length > 0
      ? Math.round(
          (blockReports.reduce((acc, r) => acc + r.geometryErrorMm, 0) / blockReports.length) * 100
        ) / 100
      : 0;

  return {
    blockReports,
    meanBlockIoU,
    linePositionErrorMm,
  };
}

/**
 * Step 6c: Produces the visual difference overlay image comparing cleaned source
 * and rebuilt page at identical resolution.
 */
function buildDiffOverlayDataUrl(
  srcData: Uint8ClampedArray,
  rebData: Uint8ClampedArray,
  w: number,
  h: number
): string {
  const diffCanvas = document.createElement('canvas');
  diffCanvas.width = w;
  diffCanvas.height = h;
  const diffCtx = diffCanvas.getContext('2d')!;
  const diffImgData = diffCtx.createImageData(w, h);
  const out = diffImgData.data;

  for (let i = 0; i < w * h; i++) {
    const idx = i * 4;
    const srcLuma = 0.299 * srcData[idx] + 0.587 * srcData[idx + 1] + 0.114 * srcData[idx + 2];
    const rebLuma = 0.299 * rebData[idx] + 0.587 * rebData[idx + 1] + 0.114 * rebData[idx + 2];

    const srcInk = srcLuma < 195;
    const rebInk = rebLuma < 195;

    if (srcInk && rebInk) {
      // Exact ink match: emerald green
      out[idx] = 22;
      out[idx + 1] = 163;
      out[idx + 2] = 74;
      out[idx + 3] = 255;
    } else if (rebInk && !srcInk) {
      // Rebuilt ink misaligned / extra: crimson red
      out[idx] = 220;
      out[idx + 1] = 38;
      out[idx + 2] = 38;
      out[idx + 3] = 220;
    } else if (srcInk && !rebInk) {
      // Source ink uncovered: cobalt blue
      out[idx] = 37;
      out[idx + 1] = 99;
      out[idx + 2] = 235;
      out[idx + 3] = 200;
    } else {
      out[idx] = 255;
      out[idx + 1] = 255;
      out[idx + 2] = 255;
      out[idx + 3] = 255;
    }
  }

  diffCtx.putImageData(diffImgData, 0, 0);
  return diffCanvas.toDataURL('image/png');
}

/**
 * Applies measured centroid/bbox corrections + optional Vision JSON patches
 * to align each element with the source image.
 */
function applyCorrectionPatches(
  objects: PageLayoutObject[],
  srcData: Uint8ClampedArray,
  rebData: Uint8ClampedArray,
  w: number,
  h: number,
  visionPatches: Array<{
    id: string;
    bbox?: number[];
    fontSizePt?: number;
    text?: string;
    align?: string;
    dir?: string;
  }>,
  adjustmentsLog: string[],
  iteration: number
): { nextObjects: PageLayoutObject[]; patchesCount: number } {
  let patchesCount = 0;
  const patchMap = new Map<string, (typeof visionPatches)[0]>();
  for (const p of visionPatches) {
    if (p && p.id) patchMap.set(p.id, p);
  }

  const nextObjects = objects.map((obj) => {
    let updated = { ...obj };
    const vPatch = patchMap.get(obj.id);

    if (vPatch) {
      if (Array.isArray(vPatch.bbox) && vPatch.bbox.length === 4) {
        updated.x = Math.max(0, Math.min(980, Math.round(vPatch.bbox[0])));
        updated.y = Math.max(0, Math.min(980, Math.round(vPatch.bbox[1])));
        updated.width = Math.max(10, Math.min(1000 - updated.x, Math.round(vPatch.bbox[2])));
        updated.height = Math.max(3, Math.min(1000 - updated.y, Math.round(vPatch.bbox[3])));
      }
      if (typeof vPatch.fontSizePt === 'number' && vPatch.fontSizePt >= 7 && vPatch.fontSizePt <= 28) {
        updated.fontProperties = {
          ...updated.fontProperties,
          sizePt: vPatch.fontSizePt,
        };
      }
      if (typeof vPatch.text === 'string' && vPatch.text.trim() && !obj.userCorrected) {
        updated.content = vPatch.text;
      }
      patchesCount++;
    }

    // Also run deterministic sub-millimeter ink centroid alignment against source image
    const pxX = (updated.x / 1000) * w;
    const pxY = (updated.y / 1000) * h;
    const pxW = (updated.width / 1000) * w;
    const pxH = (updated.height / 1000) * h;

    const srcInk = measureRegionInkBox(srcData, w, h, pxX - 8, pxY - 8, pxW + 16, pxH + 16);
    const rebInk = measureRegionInkBox(rebData, w, h, pxX, pxY, pxW, pxH);

    if (srcInk.inkCount > 12 && rebInk.inkCount > 12) {
      const shiftXNorm = Math.round(((srcInk.cx - rebInk.cx) / w) * 1000 * 0.65);
      const shiftYNorm = Math.round(((srcInk.cy - rebInk.cy) / h) * 1000 * 0.65);

      if (
        (Math.abs(shiftXNorm) >= 1 && Math.abs(shiftXNorm) <= 18) ||
        (Math.abs(shiftYNorm) >= 1 && Math.abs(shiftYNorm) <= 18)
      ) {
        updated.x = Math.max(0, Math.min(1000 - updated.width, updated.x + shiftXNorm));
        updated.y = Math.max(0, Math.min(1000 - updated.height, updated.y + shiftYNorm));
        patchesCount++;
        adjustmentsLog.push(
          `الدورة ${iteration}: تصحيح إحداثيات العنصر (${updated.id}) بمقدار (ΔX=${shiftXNorm}, ΔY=${shiftYNorm}) لمطابقة مركز ثقل الحبر المصدري.`
        );
      }
    }

    return updated;
  });

  return { nextObjects, patchesCount };
}

/**
 * Step 6: Mandatory VERIFY LOOP (up to 3 iterations):
 * a. Render the built page to a canvas at the same resolution as the cleaned source.
 * b. Align it with the source and compute a REAL similarity score (SSIM + line-position error + per-block IoU).
 * c. Produce a difference overlay image. Send source, rebuilt and overlay to the vision model
 *    for a JSON patch of corrections + deterministic centroid alignment. Apply it, re-render, re-score.
 * d. Stop when score >= 0.95 or after 3 iterations; keep the best version.
 */
export async function runIterativeVisualValidation(
  preprocessedSourceDataUrl: string,
  initialObjects: PageLayoutObject[],
  enableRefinement = true,
  keepHandwriting = false,
  callVisionPatchEndpoint = false
): Promise<{
  refinedObjects: PageLayoutObject[];
  report: ReconstructionValidationReport;
}> {
  const srcImg = await loadImageElement(preprocessedSourceDataUrl);
  // Step 6a: Use exact same resolution as cleaned source (clamped to reasonable canvas size for speed)
  const w = Math.min(900, Math.max(450, srcImg.width || 600));
  const h = Math.round(w * ((srcImg.height || 849) / (srcImg.width || 600)));

  const srcCanvas = document.createElement('canvas');
  srcCanvas.width = w;
  srcCanvas.height = h;
  const srcCtx = srcCanvas.getContext('2d')!;
  srcCtx.fillStyle = '#FFFFFF';
  srcCtx.fillRect(0, 0, w, h);
  srcCtx.drawImage(srcImg, 0, 0, w, h);
  const srcData = srcCtx.getImageData(0, 0, w, h).data;

  const rebCanvas = document.createElement('canvas');
  rebCanvas.width = w;
  rebCanvas.height = h;

  let currentObjects: PageLayoutObject[] = initialObjects.map((o) => ({
    ...o,
    fontProperties: { ...o.fontProperties },
    borderProperties: {
      top: { ...o.borderProperties.top },
      right: { ...o.borderProperties.right },
      bottom: { ...o.borderProperties.bottom },
      left: { ...o.borderProperties.left },
    },
    backgroundProperties: { ...o.backgroundProperties },
  }));

  const maxIterations = enableRefinement ? 3 : 1;
  const iterationHistory: VerifyLoopIterationRecord[] = [];
  const adjustmentsLog: string[] = [];

  let bestScore01 = -1;
  let bestObjects: PageLayoutObject[] = currentObjects;
  let bestBlockReports: BlockMeasuredReport[] = [];
  let bestSSIM01 = 0;
  let bestMeanIoU01 = 0;
  let bestLineErrMm = 0;
  let bestDiffOverlayDataUrl = '';

  for (let iter = 1; iter <= maxIterations; iter++) {
    // 6a. Render built page to canvas at same resolution as cleaned source
    renderPageToCanvas(rebCanvas, currentObjects, {
      widthPx: w,
      heightPx: h,
      keepHandwriting,
      highlightLowConfidence: false,
      showBoundingBoxes: false,
    });

    const rebCtx = rebCanvas.getContext('2d')!;
    const rebData = rebCtx.getImageData(0, 0, w, h).data;

    // 6b. Compute REAL measured similarity score (SSIM + line-position error + per-block IoU)
    const ssim01 = computeRealSSIM(srcData, rebData, w, h);
    const { blockReports, meanBlockIoU, linePositionErrorMm } = measureBlocksAndLineError(
      srcData,
      rebData,
      currentObjects,
      w,
      h
    );

    const lineAccuracy01 = Math.max(0, Math.min(1, 1 - linePositionErrorMm / 6.0));
    const combinedScore01 =
      Math.round((0.45 * ssim01 + 0.35 * meanBlockIoU + 0.20 * lineAccuracy01) * 1000) / 1000;

    // 6c. Produce difference overlay image
    const diffOverlayDataUrl = buildDiffOverlayDataUrl(srcData, rebData, w, h);

    // Keep best version
    if (combinedScore01 > bestScore01) {
      bestScore01 = combinedScore01;
      bestObjects = currentObjects.map((o, idx) => ({
        ...o,
        confidence: blockReports[idx]?.iouScore ?? o.confidence,
      }));
      bestBlockReports = blockReports;
      bestSSIM01 = ssim01;
      bestMeanIoU01 = meanBlockIoU;
      bestLineErrMm = linePositionErrorMm;
      bestDiffOverlayDataUrl = diffOverlayDataUrl;
    }

    // 6d. Stop when score >= 0.95 or after 3 iterations
    if (combinedScore01 >= 0.95 || iter === maxIterations) {
      iterationHistory.push({
        iteration: iter,
        ssim: Math.round(ssim01 * 1000) / 1000,
        linePositionErrorMm,
        meanBlockIoU: Math.round(meanBlockIoU * 1000) / 1000,
        combinedScore: combinedScore01,
        patchesApplied: 0,
      });
      if (combinedScore01 >= 0.95) {
        adjustmentsLog.push(
          `توقف تلقائي عند الدورة (${iter}/3): بلغت النتيجة المقاسة ${combinedScore01.toFixed(3)} (>= 0.95).`
        );
      }
      break;
    }

    // Request JSON patch from Vision API if enabled, then apply corrections
    let visionPatches: any[] = [];
    if (callVisionPatchEndpoint) {
      try {
        const res = await fetch('/api/verify-patch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sourceImageBase64: preprocessedSourceDataUrl,
            rebuiltImageBase64: rebCanvas.toDataURL('image/png'),
            diffOverlayBase64: diffOverlayDataUrl,
            elements: currentObjects.map((o) => ({
              id: o.id,
              type: o.pipelineKind || o.type,
              bbox: [o.x, o.y, o.width, o.height],
              fontSizePt: o.fontProperties.sizePt,
            })),
            measuredBlockErrors: blockReports.map((r) => ({
              id: r.objectId,
              geometryErrorMm: r.geometryErrorMm,
              iouScore: r.iouScore,
            })),
          }),
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data?.patches)) {
            visionPatches = data.patches;
          }
        }
      } catch {
        // Continue with deterministic centroid patcher
      }
    }

    const { nextObjects, patchesCount } = applyCorrectionPatches(
      currentObjects,
      srcData,
      rebData,
      w,
      h,
      visionPatches,
      adjustmentsLog,
      iter
    );

    iterationHistory.push({
      iteration: iter,
      ssim: Math.round(ssim01 * 1000) / 1000,
      linePositionErrorMm,
      meanBlockIoU: Math.round(meanBlockIoU * 1000) / 1000,
      combinedScore: combinedScore01,
      patchesApplied: patchesCount,
    });

    currentObjects = nextObjects;
    if (patchesCount === 0) {
      break;
    }
  }

  if (adjustmentsLog.length === 0) {
    adjustmentsLog.push(
      `تم قياس (${bestBlockReports.length}) كتلة تخطيطية بدقة SSIM = ${bestSSIM01.toFixed(3)} وخطأ مواضع الخطوط = ${bestLineErrMm.toFixed(2)} مم.`
    );
  }

  const poorBlocksCount = bestBlockReports.filter((r) => r.isPoor).length;
  const textReports = bestBlockReports.filter((r) => r.textAccuracy !== null);
  const tableReports = bestBlockReports.filter((r) => r.tableAccuracy !== null);

  const measuredTextAccPct =
    textReports.length > 0
      ? Math.round(
          (textReports.reduce((a, b) => a + (b.textAccuracy || 0), 0) / textReports.length) * 1000
        ) / 10
      : Math.round(bestMeanIoU01 * 1000) / 10;

  const measuredTableAccPct =
    tableReports.length > 0
      ? Math.round(
          (tableReports.reduce((a, b) => a + (b.tableAccuracy || 0), 0) / tableReports.length) *
            1000
        ) / 10
      : Math.round((1 - Math.min(1, bestLineErrMm / 5)) * 1000) / 10;

  const overallPercent = Math.round(bestScore01 * 1000) / 10;
  const ssimPercent = Math.round(bestSSIM01 * 1000) / 10;
  const meanIoUPercent = Math.round(bestMeanIoU01 * 1000) / 10;

  return {
    refinedObjects: bestObjects,
    report: {
      iterationsExecuted: iterationHistory.length,
      overallVisualSimilarity: overallPercent,
      combinedScore01: bestScore01,
      ssimScore01: Math.round(bestSSIM01 * 1000) / 1000,
      linePositionErrorMm: bestLineErrMm,
      meanBlockIoU01: Math.round(bestMeanIoU01 * 1000) / 1000,
      pageGeometryFidelity: ssimPercent,
      textPositionFidelity: meanIoUPercent,
      tableGeometryFidelity: measuredTableAccPct,
      arabicTypographyFidelity: measuredTextAccPct,
      lowConfidenceRegionsCount: poorBlocksCount,
      adjustmentsLog,
      blockReports: bestBlockReports,
      iterationHistory,
      diffHeatmapDataUrl: bestDiffOverlayDataUrl,
      metrics: [
        {
          labelAr: 'مؤشر التشابه البنيوي المقاس (Real SSIM)',
          labelEn: 'Measured Structural Similarity (SSIM)',
          score: ssimPercent,
          unit: '%',
          status: bestSSIM01 >= 0.9 ? 'optimal' : bestSSIM01 >= 0.78 ? 'adjusted' : 'warning',
          detailsAr: `قيمة SSIM الفعلية المحسوبة عبر نوافذ 16×16 بكسل: ${bestSSIM01.toFixed(3)}`,
        },
        {
          labelAr: 'متوسط خطأ مواضع الخطوط (Line Position Error)',
          labelEn: 'Measured Line-Position Error',
          score: bestLineErrMm,
          unit: 'mm',
          status: bestLineErrMm <= 0.8 ? 'optimal' : bestLineErrMm <= 1.8 ? 'adjusted' : 'warning',
          detailsAr: `الانحراف الهندسي المقاس للخطوط والجداول على ورقة A4: ${bestLineErrMm.toFixed(2)} مم`,
        },
        {
          labelAr: 'متوسط تداخل الكتل المقاس (Mean Per-Block IoU)',
          labelEn: 'Measured Per-Block IoU',
          score: meanIoUPercent,
          unit: '%',
          status: bestMeanIoU01 >= 0.85 ? 'optimal' : bestMeanIoU01 >= 0.78 ? 'adjusted' : 'warning',
          detailsAr: `متوسط IoU الفعلي لجميع الكتل (${bestBlockReports.length} كتلة): ${bestMeanIoU01.toFixed(3)}`,
        },
        {
          labelAr: 'دقة النصوص والجداول المقاسة (Text & Table Accuracy)',
          labelEn: 'Measured Text & Table Accuracy',
          score: measuredTableAccPct,
          unit: '%',
          status: poorBlocksCount === 0 ? 'optimal' : 'warning',
          detailsAr:
            poorBlocksCount > 0
              ? `تم رصد (${poorBlocksCount}) كتلة ذات قياس ضعيف وإبرازها على الورقة للمراجعة`
              : `دقة النص المقاسة ${measuredTextAccPct}% · دقة شبكة الجدول ${measuredTableAccPct}%`,
        },
      ],
    },
  };
}
