package com.example.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.ThemeMode
import com.example.ui.components.ScannerWorkspaceView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdeMainScreen(viewModel: IdeViewModel) {
    val context = LocalContext.current
    val themeMode by viewModel.themeMode.collectAsState()

    // Canon MF440 Hardware Scanner States
    val discoveredScanners by viewModel.discoveredScanners.collectAsState()
    val selectedScanner by viewModel.selectedScanner.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val scanStatusLogs by viewModel.scanStatusLogs.collectAsState()
    val scanError by viewModel.scanError.collectAsState()
    val scannedBitmap by viewModel.scannedBitmap.collectAsState()
    val editedBitmap by viewModel.editedBitmap.collectAsState()
    val savedScanPages by viewModel.savedScanPages.collectAsState()
    val lastSavedImageFile by viewModel.lastSavedImageFile.collectAsState()
    val lastGeneratedPdfFile by viewModel.lastGeneratedPdfFile.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = Color(0xFFD50000),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Scanner,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Canon MF440 Scanner",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "USB OTG & Wi-Fi eSCL/MFNP • com.canon.mf440.scanner",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                actions = {
                    // Refresh USB Scanners button
                    IconButton(onClick = { viewModel.refreshUsbScanners() }) {
                        Icon(
                            Icons.Default.Usb,
                            contentDescription = "Scan USB Bus",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Share / Open Last Generated PDF if available
                    if (lastGeneratedPdfFile != null && lastGeneratedPdfFile!!.exists()) {
                        IconButton(
                            onClick = {
                                try {
                                    val pdfFile = lastGeneratedPdfFile!!
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        pdfFile
                                    )
                                    val shareIntent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, "application/pdf")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Open Scanned PDF"))
                                } catch (_: Exception) {}
                            }
                        ) {
                            Icon(
                                Icons.Default.PictureAsPdf,
                                contentDescription = "Open Generated PDF",
                                tint = Color(0xFFFF5252)
                            )
                        }
                    }

                    // Theme Mode Switcher: Light / Dark / OLED Pure Black
                    FilledTonalButton(
                        onClick = { viewModel.toggleTheme() },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .padding(end = 6.dp)
                    ) {
                        val (icon, label) = when (themeMode) {
                            ThemeMode.LIGHT -> Icons.Default.LightMode to "Light"
                            ThemeMode.DARK -> Icons.Default.DarkMode to "Dark"
                            ThemeMode.OLED -> Icons.Default.Contrast to "OLED"
                        }
                        Icon(icon, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            ScannerWorkspaceView(
                discoveredScanners = discoveredScanners,
                selectedScanner = selectedScanner,
                isScanning = isScanning,
                scanStatusLogs = scanStatusLogs,
                scanError = scanError,
                scannedBitmap = scannedBitmap,
                editedBitmap = editedBitmap,
                savedPages = savedScanPages,
                lastSavedImageFile = lastSavedImageFile,
                lastGeneratedPdfFile = lastGeneratedPdfFile,
                onRefreshUsbScanners = { viewModel.refreshUsbScanners() },
                onProbeWifiScanner = { ip -> viewModel.probeNetworkScanner(ip) },
                onSelectScanner = { dev -> viewModel.selectScannerDevice(dev) },
                onRequestUsbPermission = { dev -> viewModel.requestScannerUsbPermission(dev) },
                onStartScan = { opts -> viewModel.executeHardwareScan(opts) },
                onApplyImageTransform = { rot, flipH, flipV, cL, cT, cR, cB, contrast ->
                    viewModel.applyScanImageTransform(rot, flipH, flipV, cL, cT, cR, cB, contrast)
                },
                onResetImageTransform = { viewModel.resetEditedScanBitmap() },
                onSaveEditedImage = { viewModel.saveEditedScanImage() },
                onAddPageToPdfQueue = { viewModel.addCurrentScanPageToPdfQueue() },
                onClearPdfQueue = { viewModel.clearSavedPdfPages() },
                onGeneratePdfDocument = { pdfName -> viewModel.buildPdfFromScannedPages(pdfName) }
            )
        }
    }
}
