package com.crimsonpdf.reconstructor.preprocessing

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import com.crimsonpdf.reconstructor.model.PreprocessingConfig
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object ImagePreprocessor {

    fun processBitmap(
        source: Bitmap,
        config: PreprocessingConfig,
        forModeB: Boolean = false
    ): Bitmap {
        val w = source.width.coerceAtLeast(100)
        val h = source.height.coerceAtLeast(100)

        val outBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)
        canvas.drawColor(Color.WHITE)

        val totalAngle = config.rotationDeg.toFloat() + config.deskewAngleDeg
        val matrix = Matrix().apply {
            postRotate(totalAngle, w / 2f, h / 2f)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(source, matrix, paint)

        val pixels = IntArray(w * h)
        outBitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val blockSize = 28
        val gridCols = ceil(w.toDouble() / blockSize).toInt().coerceAtLeast(1)
        val gridRows = ceil(h.toDouble() / blockSize).toInt().coerceAtLeast(1)
        val bgLumaGrid = FloatArray(gridCols * gridRows) { 230f }

        if (config.removeShadows || config.normalizeBackground) {
            for (gy in 0 until gridRows) {
                for (gx in 0 until gridCols) {
                    var maxLuma = 160f
                    val startY = gy * blockSize
                    val endY = min(h, startY + blockSize)
                    val startX = gx * blockSize
                    val endX = min(w, startX + blockSize)

                    var y = startY
                    while (y < endY) {
                        var x = startX
                        while (x < endX) {
                            val c = pixels[y * w + x]
                            val luma = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
                            if (luma > maxLuma) maxLuma = luma
                            x += 3
                        }
                        y += 3
                    }
                    bgLumaGrid[gy * gridCols + gx] = max(115f, maxLuma)
                }
            }
        }

        val shadowFactor = if (config.removeShadows) (config.shadowStrength / 100f) else 0f
        val contrastGain = 1f + (config.contrastBoost / 100f) * (if (forModeB) 1.25f else 1.05f)
        val whiteClip = if (config.normalizeBackground) (if (forModeB) 216f else 222f) else 248f

        for (y in 0 until h) {
            val gy = min(gridRows - 1, y / blockSize)
            val rowOffset = y * w
            for (x in 0 until w) {
                val gx = min(gridCols - 1, x / blockSize)
                val idx = rowOffset + x
                val c = pixels[idx]

                var r = Color.red(c).toFloat()
                var g = Color.green(c).toFloat()
                var b = Color.blue(c).toFloat()

                if (shadowFactor > 0f) {
                    val localBg = bgLumaGrid[gy * gridCols + gx]
                    val scale = 1f + shadowFactor * (252f / localBg - 1f)
                    r = min(255f, r * scale)
                    g = min(255f, g * scale)
                    b = min(255f, b * scale)
                }

                val luma = 0.299f * r + 0.587f * g + 0.114f * b
                val isColoredInk = abs(r - b) > 36f || abs(r - g) > 36f

                if (luma >= whiteClip && !isColoredInk) {
                    r = 255f
                    g = 255f
                    b = 255f
                } else {
                    r = min(255f, max(0f, (r - 160f) * contrastGain + 160f))
                    g = min(255f, max(0f, (g - 160f) * contrastGain + 160f))
                    b = min(255f, max(0f, (b - 160f) * contrastGain + 160f))
                }

                pixels[idx] = Color.argb(255, r.toInt(), g.toInt(), b.toInt())
            }
        }

        outBitmap.setPixels(pixels, 0, w, 0, 0, w, h)
        return outBitmap
    }

    /**
     * Crops a normalized region (0..1000) from the preprocessed document bitmap and converts
     * paper background pixels to transparent while preserving crisp dark/colored ink.
     */
    fun extractCleanInkPatch(
        preprocessed: Bitmap,
        xNorm: Float,
        yNorm: Float,
        wNorm: Float,
        hNorm: Float
    ): Bitmap {
        val bw = preprocessed.width.coerceAtLeast(1)
        val bh = preprocessed.height.coerceAtLeast(1)

        val left = ((xNorm / 1000f) * bw).roundToInt().coerceIn(0, bw - 2)
        val top = ((yNorm / 1000f) * bh).roundToInt().coerceIn(0, bh - 2)
        val right = (((xNorm + wNorm) / 1000f) * bw).roundToInt().coerceIn(left + 1, bw)
        val bottom = (((yNorm + hNorm) / 1000f) * bh).roundToInt().coerceIn(top + 1, bh)

        val cw = (right - left).coerceAtLeast(1)
        val ch = (bottom - top).coerceAtLeast(1)

        val cropped = Bitmap.createBitmap(preprocessed, left, top, cw, ch)
        val out = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(cw * ch)
        cropped.getPixels(pixels, 0, cw, 0, 0, cw, ch)

        for (i in pixels.indices) {
            val c = pixels[i]
            val r = Color.red(c)
            val g = Color.green(c)
            val b = Color.blue(c)
            val luma = 0.299f * r + 0.587f * g + 0.114f * b
            val isColored = abs(r - b) > 34 || abs(r - g) > 34

            if (luma >= 224f && !isColored) {
                pixels[i] = Color.TRANSPARENT
            } else if (!isColored) {
                // Darken ink slightly for crisp print reproduction
                val dark = (luma * 0.72f).roundToInt().coerceIn(0, 190)
                pixels[i] = Color.argb(255, dark, dark, dark)
            } else {
                pixels[i] = Color.argb(255, r, g, b)
            }
        }
        out.setPixels(pixels, 0, cw, 0, 0, cw, ch)
        return out
    }
}
