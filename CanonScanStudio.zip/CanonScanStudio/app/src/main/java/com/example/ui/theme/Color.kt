package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkSurface = Color(0xFF1E1E1E)
val DarkBackground = Color(0xFF121212)
val DarkSurfaceVariant = Color(0xFF2D2D2D)
