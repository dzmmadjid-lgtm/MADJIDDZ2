#!/usr/bin/env python3
import os
import sys
import glob
import subprocess
import re
import zipfile

def find_apk(custom_path=None):
    if custom_path and os.path.isfile(custom_path):
        return custom_path
    
    candidates = [
        "app/build/outputs/apk/debug/app-debug.apk",
        "build/outputs/apk/debug/app-debug.apk",
        ".build-outputs/app-debug.apk",
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
            
    found = glob.glob("**/app-debug.apk", recursive=True)
    if found:
        return found[0]
        
    found_any = glob.glob("**/*debug*.apk", recursive=True)
    if found_any:
        return found_any[0]
        
    return None

def find_tool(tool_name):
    try:
        path = subprocess.check_output(["which", tool_name], text=True).strip()
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    except Exception:
        pass

    sdk_roots = [
        os.environ.get("ANDROID_HOME", ""),
        os.environ.get("ANDROID_SDK_ROOT", ""),
        "/usr/local/lib/android/sdk",
        "/opt/android/sdk",
        os.path.expanduser("~/Android/Sdk"),
        "/root/Android/Sdk",
    ]

    for root in sdk_roots:
        if not root or not os.path.isdir(root):
            continue
        bt_dir = os.path.join(root, "build-tools")
        if os.path.isdir(bt_dir):
            versions = sorted(os.listdir(bt_dir), reverse=True)
            for v in versions:
                candidate = os.path.join(bt_dir, v, tool_name)
                if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                    return candidate

    return None

def main():
    custom_apk = sys.argv[1] if len(sys.argv) > 1 else None
    apk_path = find_apk(custom_apk)
    
    if not apk_path:
        print("ERROR: Could not find any debug APK file to verify.")
        sys.exit(1)

    size_bytes = os.path.getsize(apk_path)
    size_mb = size_bytes / (1024 * 1024)

    aapt2_bin = find_tool("aapt2")
    apksigner_bin = find_tool("apksigner")

    if not aapt2_bin:
        print("ERROR: aapt2 build tool not found in SDK or PATH.")
        sys.exit(1)

    if not apksigner_bin:
        print("ERROR: apksigner build tool not found in SDK or PATH.")
        sys.exit(1)

    # 1. AAPT2 badging analysis
    badging_proc = subprocess.run([aapt2_bin, "dump", "badging", apk_path], capture_output=True, text=True)
    badging = badging_proc.stdout
    
    m_pkg = re.search(r"package:\s+name='([^']+)'", badging)
    m_vc = re.search(r"versionCode='([^']+)'", badging)
    m_vn = re.search(r"versionName='([^']+)'", badging)
    m_min = re.search(r"minSdkVersion:'([^']+)'", badging)
    m_target = re.search(r"targetSdkVersion:'([^']+)'", badging)
    m_abi = re.search(r"native-code:\s*(.*)", badging)

    pkg = m_pkg.group(1) if m_pkg else "UNKNOWN"
    vc = m_vc.group(1) if m_vc else "0"
    vn = m_vn.group(1) if m_vn else "1.0"
    min_sdk = m_min.group(1) if m_min else "UNKNOWN"
    target_sdk = m_target.group(1) if m_target else "UNKNOWN"
    abis = m_abi.group(1).strip() if m_abi else "none"

    # 2. ZIP integrity test (unzip -t)
    zip_proc = subprocess.run(["unzip", "-t", apk_path], capture_output=True, text=True)
    zip_ok = (zip_proc.returncode == 0)
    zip_test = "PASSED (0 errors, valid archive)" if zip_ok else "FAILED (corrupt zip archive)"

    # 3. APK Signer verification
    signer_proc = subprocess.run([apksigner_bin, "verify", "--verbose", "--print-certs", apk_path], capture_output=True, text=True)
    signer_out = signer_proc.stdout

    m_dn = re.search(r"Signer #1 certificate DN:\s*(.*)", signer_out)
    m_sha = re.search(r"Signer #1 certificate SHA-256 digest:\s*(.*)", signer_out)
    m_v1 = re.search(r"Verified using v1 scheme.*:\s*(.*)", signer_out)
    m_v2 = re.search(r"Verified using v2 scheme.*:\s*(.*)", signer_out)
    m_v3 = re.search(r"Verified using v3 scheme.*:\s*(.*)", signer_out)

    v1_ok = m_v1.group(1).strip() if m_v1 else "false"
    v2_ok = m_v2.group(1).strip() if m_v2 else "false"
    v3_ok = m_v3.group(1).strip() if m_v3 else "false"

    signer_verified = ("Verifies" in signer_out) and (v2_ok == "true" or v3_ok == "true")
    if signer_verified:
        apksigner_res = f"PASSED (v1: {v1_ok}, v2: {v2_ok}, v3: {v3_ok})"
    else:
        apksigner_res = "FAILED (Invalid or missing signature)"

    dn_str = m_dn.group(1).strip() if m_dn else "Unknown DN"
    sha_str = m_sha.group(1).strip() if m_sha else "Unknown SHA256"
    
    is_debug_keystore = ("Android Debug" in dn_str)
    sig_info = f"{dn_str} | SHA256: {sha_str}" + (" [Verified debug.keystore]" if is_debug_keystore else "")

    # 4. ONNX Runtime & arm64-v8a verification
    with zipfile.ZipFile(apk_path, "r") as zf:
        names = zf.namelist()
        has_arm64_dir = any(n.startswith("lib/arm64-v8a/") for n in names)
        has_onnx_so = "lib/arm64-v8a/libonnxruntime.so" in names
        has_onnx_jni = "lib/arm64-v8a/libonnxruntime4j_jni.so" in names
        has_vocals_model = "assets/models/vocals.onnx" in names
        has_accomp_model = "assets/models/accompaniment.onnx" in names

    models_status = ""
    if has_vocals_model and has_accomp_model:
        models_status = " [Neural Models Bundled in assets/]"
    else:
        models_status = " [Warning: Neural models missing from assets/]"

    if has_arm64_dir and has_onnx_so and has_onnx_jni:
        onnx_arm64 = f"CONFIRMED (libonnxruntime.so & libonnxruntime4j_jni.so present){models_status}"
    elif has_arm64_dir:
        onnx_arm64 = "INCOMPLETE (arm64 directory present, but missing ONNX Runtime binaries)"
    else:
        onnx_arm64 = "MISSING (No arm64-v8a native libraries found in APK)"

    # 5. Overall installability verdict for Android 16 (ARM64)
    reasons_failed = []
    if not zip_ok:
        reasons_failed.append("Corrupt zip structure")
    if not signer_verified:
        reasons_failed.append("Invalid signature")
    if not is_debug_keystore:
        reasons_failed.append("Not signed with required debug.keystore")
    if "CONFIRMED" not in onnx_arm64:
        reasons_failed.append("Missing required ONNX arm64-v8a libraries")
    if pkg == "UNKNOWN":
        reasons_failed.append("Missing package name")

    if not reasons_failed:
        installability = "VALID & READY FOR ANDROID 16 ARM64"
    else:
        installability = f"NOT INSTALLABLE ({', '.join(reasons_failed)})"

    # Print output formatted exactly as requested
    print("=" * 60)
    print("               APK VERIFICATION REPORT")
    print("=" * 60)
    print(f"APK: {apk_path}")
    print(f"SIZE: {size_bytes} bytes ({size_mb:.2f} MB)")
    print(f"PACKAGE: {pkg}")
    print(f"VERSION: {vn} (code: {vc})")
    print(f"MIN SDK: {min_sdk}")
    print(f"TARGET SDK: {target_sdk}")
    print(f"ABIs: {abis}")
    print(f"SIGNATURE: {sig_info}")
    print(f"APKSIGNER: {apksigner_res}")
    print(f"AAPT2: VALID (Manifest & Resources parsed successfully)")
    print(f"ZIP TEST: {zip_test}")
    print(f"ONNX ARM64: {onnx_arm64}")
    print(f"INSTALLABILITY: {installability}")
    print("=" * 60)

    if reasons_failed:
        sys.exit(1)

if __name__ == "__main__":
    main()
