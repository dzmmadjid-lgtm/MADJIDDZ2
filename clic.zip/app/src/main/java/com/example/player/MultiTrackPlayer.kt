package com.example.player

import android.media.MediaPlayer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

data class MultiTrackPlayerState(
    val isLoaded: Boolean = false,
    val isPlaying: Boolean = false,
    val currentPositionMs: Int = 0,
    val totalDurationMs: Int = 0,
    val vocalsVolume: Float = 1.0f,
    val instrumentalVolume: Float = 1.0f,
    val isVocalsMuted: Boolean = false,
    val isInstrumentalMuted: Boolean = false,
    val isVocalsSolo: Boolean = false,
    val isInstrumentalSolo: Boolean = false
)

class MultiTrackPlayer(
    private val scope: CoroutineScope
) {
    private val tag = "MultiTrackPlayer"

    private val _state = MutableStateFlow(MultiTrackPlayerState())
    val state: StateFlow<MultiTrackPlayerState> = _state.asStateFlow()

    private var vocalsPlayer: MediaPlayer? = null
    private var instrumentalPlayer: MediaPlayer? = null
    private var progressJob: Job? = null

    fun loadTracks(vocalsFile: File, instrumentalFile: File) {
        release()
        try {
            val vPlayer = MediaPlayer().apply {
                setDataSource(vocalsFile.absolutePath)
                prepare()
            }
            val iPlayer = MediaPlayer().apply {
                setDataSource(instrumentalFile.absolutePath)
                prepare()
            }

            vocalsPlayer = vPlayer
            instrumentalPlayer = iPlayer

            val duration = maxOf(vPlayer.duration, iPlayer.duration)

            _state.value = MultiTrackPlayerState(
                isLoaded = true,
                isPlaying = false,
                currentPositionMs = 0,
                totalDurationMs = duration,
                vocalsVolume = 1.0f,
                instrumentalVolume = 1.0f
            )

            updateVolumes()

            vPlayer.setOnCompletionListener {
                if (instrumentalPlayer?.isPlaying != true) {
                    stopPlaybackState()
                }
            }
            iPlayer.setOnCompletionListener {
                if (vocalsPlayer?.isPlaying != true) {
                    stopPlaybackState()
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Error loading tracks: ${e.message}", e)
            _state.value = MultiTrackPlayerState(isLoaded = false)
        }
    }

    fun play() {
        val vp = vocalsPlayer ?: return
        val ip = instrumentalPlayer ?: return

        // Synchronize positions before playing
        val targetPos = _state.value.currentPositionMs
        vp.seekTo(targetPos)
        ip.seekTo(targetPos)

        vp.start()
        ip.start()

        _state.value = _state.value.copy(isPlaying = true)
        startProgressTracking()
    }

    fun pause() {
        vocalsPlayer?.pause()
        instrumentalPlayer?.pause()
        _state.value = _state.value.copy(isPlaying = false)
        progressJob?.cancel()
    }

    fun togglePlayPause() {
        if (_state.value.isPlaying) pause() else play()
    }

    fun seekTo(positionMs: Int) {
        val clamped = positionMs.coerceIn(0, _state.value.totalDurationMs)
        vocalsPlayer?.seekTo(clamped)
        instrumentalPlayer?.seekTo(clamped)
        _state.value = _state.value.copy(currentPositionMs = clamped)
    }

    fun setVocalsVolume(volume: Float) {
        _state.value = _state.value.copy(vocalsVolume = volume.coerceIn(0f, 1f))
        updateVolumes()
    }

    fun setInstrumentalVolume(volume: Float) {
        _state.value = _state.value.copy(instrumentalVolume = volume.coerceIn(0f, 1f))
        updateVolumes()
    }

    fun toggleVocalsMute() {
        val newMute = !_state.value.isVocalsMuted
        _state.value = _state.value.copy(isVocalsMuted = newMute, isVocalsSolo = false)
        updateVolumes()
    }

    fun toggleInstrumentalMute() {
        val newMute = !_state.value.isInstrumentalMuted
        _state.value = _state.value.copy(isInstrumentalMuted = newMute, isInstrumentalSolo = false)
        updateVolumes()
    }

    fun toggleVocalsSolo() {
        val newSolo = !_state.value.isVocalsSolo
        _state.value = _state.value.copy(
            isVocalsSolo = newSolo,
            isInstrumentalSolo = false,
            isVocalsMuted = false
        )
        updateVolumes()
    }

    fun toggleInstrumentalSolo() {
        val newSolo = !_state.value.isInstrumentalSolo
        _state.value = _state.value.copy(
            isInstrumentalSolo = newSolo,
            isVocalsSolo = false,
            isInstrumentalMuted = false
        )
        updateVolumes()
    }

    private fun updateVolumes() {
        val s = _state.value
        val vp = vocalsPlayer ?: return
        val ip = instrumentalPlayer ?: return

        val effVocalsVol = when {
            s.isInstrumentalSolo -> 0f
            s.isVocalsMuted -> 0f
            else -> s.vocalsVolume
        }

        val effInstVol = when {
            s.isVocalsSolo -> 0f
            s.isInstrumentalMuted -> 0f
            else -> s.instrumentalVolume
        }

        vp.setVolume(effVocalsVol, effVocalsVol)
        ip.setVolume(effInstVol, effInstVol)
    }

    private fun startProgressTracking() {
        progressJob?.cancel()
        progressJob = scope.launch(Dispatchers.Main) {
            while (isActive && _state.value.isPlaying) {
                val current = vocalsPlayer?.currentPosition ?: instrumentalPlayer?.currentPosition ?: 0
                _state.value = _state.value.copy(currentPositionMs = current)
                delay(100)
            }
        }
    }

    private fun stopPlaybackState() {
        _state.value = _state.value.copy(isPlaying = false, currentPositionMs = 0)
        progressJob?.cancel()
    }

    fun release() {
        progressJob?.cancel()
        vocalsPlayer?.release()
        instrumentalPlayer?.release()
        vocalsPlayer = null
        instrumentalPlayer = null
        _state.value = MultiTrackPlayerState()
    }
}
