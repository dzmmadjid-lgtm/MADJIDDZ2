package com.example.neural

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import android.util.Log
import com.example.audio.AudioDsp
import com.example.audio.StereoAudio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Result of the neural source separation operation.
 */
data class SeparationResult(
    val vocals: StereoAudio,
    val instrumental: StereoAudio,
    val durationSeconds: Float,
    val inferenceTimeMs: Long,
    val modelName: String,
    val isNeuralInference: Boolean = true
)

/**
 * Executes the complete Deep Neural Source Separation pipeline on stereo audio:
 * Audio -> Preprocessing (STFT 4096/1024) -> Spleeter ONNX Inference -> Neural Masking -> iSTFT -> Stems.
 */
class NeuralSourceSeparator(
    private val modelManager: AiModelManager
) {
    private val tag = "NeuralSourceSeparator"
    private val audioDsp = AudioDsp(nFft = 4096, hopLength = 1024)

    suspend fun separate(
        audio: StereoAudio,
        onProgress: (step: String, progress: Float) -> Unit = { _, _ -> }
    ): SeparationResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()

        onProgress("التحقق من نموذج الذكاء الاصطناعي العصبي...", 0.05f)
        val initialized = modelManager.initializeModels()
        val vocalsSession = modelManager.vocalsSession
        val accompSession = modelManager.accompanimentSession

        require(initialized && vocalsSession != null && accompSession != null) {
            "لم يتم تحميل نموذج الذكاء الاصطناعي بنجاح: ${modelManager.modelInfo.value.lastError ?: "نموذج ONNX غير متوفر"}"
        }

        // 1. Preprocessing: Short-Time Fourier Transform (STFT)
        onProgress("معالجة وتحليل الترددات (STFT 4096)...", 0.15f)
        val stftL = audioDsp.computeStft(audio.left)
        val stftR = audioDsp.computeStft(audio.right)
        val numFrames = stftL.numFrames
        require(numFrames > 0) { "الملف الصوتي قصير جداً لإجراء عملية الفصل" }

        val numSplits = (numFrames + 511) / 512
        val bins = 1024 // Spleeter operates on first 1024 frequency bins (0..11025 Hz)
        val fftBins = audioDsp.fftBins // 2049

        Log.i(tag, "Audio frames: $numFrames, splits: $numSplits (512 frames each)")

        val vocalsStftL = AudioDsp.StftChannelResult(
            numFrames,
            Array(numFrames) { FloatArray(fftBins) },
            Array(numFrames) { FloatArray(fftBins) }
        )
        val vocalsStftR = AudioDsp.StftChannelResult(
            numFrames,
            Array(numFrames) { FloatArray(fftBins) },
            Array(numFrames) { FloatArray(fftBins) }
        )
        val accompStftL = AudioDsp.StftChannelResult(
            numFrames,
            Array(numFrames) { FloatArray(fftBins) },
            Array(numFrames) { FloatArray(fftBins) }
        )
        val accompStftR = AudioDsp.StftChannelResult(
            numFrames,
            Array(numFrames) { FloatArray(fftBins) },
            Array(numFrames) { FloatArray(fftBins) }
        )

        // Allocate reusable single-split buffer [2, 1, 512, 1024] to minimize memory pressure
        val splitElements = 2 * 1 * 512 * bins
        val splitBuffer = ByteBuffer.allocateDirect(splitElements * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        val env = OrtEnvironment.getEnvironment()
        val splitTensorShape = longArrayOf(2L, 1L, 512L, bins.toLong())

        // 2 & 3. Process each 512-frame chunk through the ONNX deep neural networks
        for (split in 0 until numSplits) {
            val progressFraction = 0.20f + 0.65f * (split.toFloat() / numSplits)
            onProgress("استدلال النموذج العصبي: مقطع ${split + 1} من $numSplits...", progressFraction)

            splitBuffer.clear()
            val startFrame = split * 512

            // Populate Channel 0 (Left)
            for (f in 0 until 512) {
                val frameIdx = startFrame + f
                if (frameIdx < numFrames) {
                    val r = stftL.real[frameIdx]
                    val im = stftL.imag[frameIdx]
                    for (b in 0 until bins) {
                        splitBuffer.put(sqrt(r[b] * r[b] + im[b] * im[b]))
                    }
                } else {
                    for (b in 0 until bins) splitBuffer.put(0f)
                }
            }

            // Populate Channel 1 (Right)
            for (f in 0 until 512) {
                val frameIdx = startFrame + f
                if (frameIdx < numFrames) {
                    val r = stftR.real[frameIdx]
                    val im = stftR.imag[frameIdx]
                    for (b in 0 until bins) {
                        splitBuffer.put(sqrt(r[b] * r[b] + im[b] * im[b]))
                    }
                } else {
                    for (b in 0 until bins) splitBuffer.put(0f)
                }
            }
            splitBuffer.flip()

            val splitInputTensor = OnnxTensor.createTensor(env, splitBuffer, splitTensorShape)

            val vocalsResult = vocalsSession.run(mapOf("x" to splitInputTensor))
            val vocalsTensor = vocalsResult[0] as OnnxTensor
            val vocalsBuf = vocalsTensor.floatBuffer

            val accompResult = accompSession.run(mapOf("x" to splitInputTensor))
            val accompTensor = accompResult[0] as OnnxTensor
            val accompBuf = accompTensor.floatBuffer

            val chStride = 512 * bins

            for (ch in 0..1) {
                val origStft = if (ch == 0) stftL else stftR
                val targetV = if (ch == 0) vocalsStftL else vocalsStftR
                val targetA = if (ch == 0) accompStftL else accompStftR
                val chOffset = ch * chStride

                for (f in 0 until 512) {
                    val frameIdx = startFrame + f
                    if (frameIdx >= numFrames) break

                    val fOffset = chOffset + f * bins
                    val origReal = origStft.real[frameIdx]
                    val origImag = origStft.imag[frameIdx]

                    for (b in 0 until bins) {
                        val v = vocalsBuf.get(fOffset + b)
                        val a = accompBuf.get(fOffset + b)

                        val v2 = v * v + 1e-10f / 2f
                        val a2 = a * a + 1e-10f / 2f
                        val sum = v * v + a * a + 1e-10f

                        val maskV = v2 / sum
                        val maskA = a2 / sum

                        targetV.real[frameIdx][b] = origReal[b] * maskV
                        targetV.imag[frameIdx][b] = origImag[b] * maskV

                        targetA.real[frameIdx][b] = origReal[b] * maskA
                        targetA.imag[frameIdx][b] = origImag[b] * maskA
                    }

                    // High frequencies above 11 kHz: preserve instrumental brilliance, zero vocal noise
                    for (b in bins until fftBins) {
                        targetV.real[frameIdx][b] = 0f
                        targetV.imag[frameIdx][b] = 0f

                        targetA.real[frameIdx][b] = origReal[b]
                        targetA.imag[frameIdx][b] = origImag[b]
                    }
                }
            }

            splitInputTensor.close()
            vocalsResult.close()
            accompResult.close()
        }

        // 4. Inverse STFT (iSTFT) to synthesize time-domain waveforms
        onProgress("إعادة بناء الإشارات الصوتية (Inverse STFT)...", 0.90f)
        val vocalsWaveL = audioDsp.inverseStft(vocalsStftL)
        val vocalsWaveR = audioDsp.inverseStft(vocalsStftR)

        val accompWaveL = audioDsp.inverseStft(accompStftL)
        val accompWaveR = audioDsp.inverseStft(accompStftR)

        // Trim or match original input length
        val originalLength = audio.left.size
        val finalVocalsL = trimToLength(vocalsWaveL, originalLength)
        val finalVocalsR = trimToLength(vocalsWaveR, originalLength)
        val finalAccompL = trimToLength(accompWaveL, originalLength)
        val finalAccompR = trimToLength(accompWaveR, originalLength)

        val vocalsAudio = StereoAudio(finalVocalsL, finalVocalsR, audio.sampleRate)
        val instrumentalAudio = StereoAudio(finalAccompL, finalAccompR, audio.sampleRate)

        val inferenceTimeMs = System.currentTimeMillis() - startTime
        onProgress("اكتمل الفصل العصبي بنجاح!", 1.0f)

        Log.i(tag, "Neural separation finished in ${inferenceTimeMs}ms for ${audio.durationSeconds}s audio.")

        SeparationResult(
            vocals = vocalsAudio,
            instrumental = instrumentalAudio,
            durationSeconds = audio.durationSeconds,
            inferenceTimeMs = inferenceTimeMs,
            modelName = "Spleeter 2-Stems Deep U-Net (ONNX)",
            isNeuralInference = true
        )
    }

    private fun trimToLength(samples: FloatArray, targetLength: Int): FloatArray {
        return if (samples.size == targetLength) {
            samples
        } else if (samples.size > targetLength) {
            samples.copyOf(targetLength)
        } else {
            val padded = FloatArray(targetLength)
            System.arraycopy(samples, 0, padded, 0, samples.size)
            padded
        }
    }
}
