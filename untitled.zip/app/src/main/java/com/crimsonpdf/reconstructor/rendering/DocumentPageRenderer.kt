package com.crimsonpdf.reconstructor.rendering

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import com.crimsonpdf.reconstructor.model.BorderProperties
import com.crimsonpdf.reconstructor.model.BorderSide
import com.crimsonpdf.reconstructor.model.LayoutObjectType
import com.crimsonpdf.reconstructor.model.PageLayoutObject
import com.crimsonpdf.reconstructor.model.TableCellModel
import com.crimsonpdf.reconstructor.model.TextAlignment
import com.crimsonpdf.reconstructor.model.TextDirection
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

object DocumentPageRenderer {

    fun renderToBitmap(
        objects: List<PageLayoutObject>,
        widthPx: Int = 900,
        heightPx: Int = 1273,
        selectedObjectId: String? = null,
        highlightLowConfidence: Boolean = true,
        showBoundingBoxes: Boolean = false,
        simulateScanAngleDeg: Float? = null,
        simulateNoiseLevel: Int = 0,
        simulateShadowStrength: Int = 0
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        renderToCanvas(
            canvas = canvas,
            widthPx = widthPx,
            heightPx = heightPx,
            objects = objects,
            selectedObjectId = selectedObjectId,
            highlightLowConfidence = highlightLowConfidence,
            showBoundingBoxes = showBoundingBoxes,
            simulateScanAngleDeg = simulateScanAngleDeg,
            simulateShadowStrength = simulateShadowStrength
        )

        if (simulateScanAngleDeg != null && simulateNoiseLevel > 0) {
            val pixels = IntArray(widthPx * heightPx)
            bitmap.getPixels(pixels, 0, widthPx, 0, 0, widthPx, heightPx)
            val amp = (simulateNoiseLevel / 100f) * 38f
            var i = 0
            while (i < pixels.size) {
                val c = pixels[i]
                val delta = (((i * 1103515245 + 12345) and 0xFF) / 255f - 0.5f) * amp
                val r = min(255, max(0, (Color.red(c) + delta).toInt()))
                val g = min(255, max(0, (Color.green(c) + delta).toInt()))
                val b = min(255, max(0, (Color.blue(c) + delta).toInt()))
                pixels[i] = Color.argb(255, r, g, b)
                i += 5
            }
            bitmap.setPixels(pixels, 0, widthPx, 0, 0, widthPx, heightPx)
        }

        return bitmap
    }

    fun renderToCanvas(
        canvas: Canvas,
        widthPx: Int,
        heightPx: Int,
        objects: List<PageLayoutObject>,
        selectedObjectId: String? = null,
        highlightLowConfidence: Boolean = false,
        showBoundingBoxes: Boolean = false,
        simulateScanAngleDeg: Float? = null,
        simulateShadowStrength: Int = 0
    ) {
        val scale = widthPx / 1000f
        canvas.save()

        if (simulateScanAngleDeg != null) {
            canvas.drawColor(Color.parseColor("#CBD5E1"))
            canvas.rotate(simulateScanAngleDeg, widthPx / 2f, heightPx / 2f)
            val paperPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, widthPx.toFloat(), heightPx.toFloat(),
                    intArrayOf(
                        Color.parseColor("#FDFBF7"),
                        Color.parseColor("#F7F4EC"),
                        Color.parseColor("#EFECE2")
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            val pad = 14f * scale
            canvas.drawRect(pad, pad, widthPx - pad, heightPx - pad, paperPaint)
        } else {
            canvas.drawColor(Color.WHITE)
        }

        val sorted = objects.sortedBy { it.zOrder }
        for (obj in sorted) {
            val x = obj.x * scale
            val y = obj.y * scale
            val w = obj.width * scale
            val h = obj.height * scale

            if (obj.backgroundColorArgb != 0 && obj.type != LayoutObjectType.TABLE) {
                val bgPaint = Paint().apply {
                    style = Paint.Style.FILL
                    color = obj.backgroundColorArgb
                }
                canvas.drawRect(x, y, x + w, y + h, bgPaint)
            }

            when (obj.type) {
                LayoutObjectType.LINE -> {
                    drawBorderSide(canvas, x, y + h / 2f, x + w, y + h / 2f, obj.borders.top, scale)
                }
                LayoutObjectType.TABLE -> {
                    drawTableObject(canvas, obj, x, y, w, h, scale)
                }
                LayoutObjectType.CHECKBOX -> {
                    drawCheckboxObject(canvas, obj, x, y, w, h, scale)
                }
                LayoutObjectType.IMAGE -> {
                    drawStampOrEmblem(canvas, obj, x, y, w, h, scale)
                }
                LayoutObjectType.SIGNATURE_AREA -> {
                    drawSignatureArea(canvas, obj, x, y, w, h, scale)
                }
                LayoutObjectType.PAGE_BREAK -> {
                    val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE
                        color = Color.parseColor("#94A3B8")
                        strokeWidth = 1.5f * scale
                        pathEffect = DashPathEffect(floatArrayOf(8f * scale, 5f * scale), 0f)
                    }
                    canvas.drawLine(x, y + h / 2f, x + w, y + h / 2f, dashPaint)
                    drawMultilineText(
                        canvas, obj.content, x, y, w, h,
                        fontSizePx = obj.fontSizePt * 1.3f * scale,
                        isBold = obj.isBold,
                        colorArgb = Color.parseColor("#475569"),
                        alignment = TextAlignment.CENTER,
                        direction = obj.direction,
                        verticalCenter = true,
                        paddingPx = 2f * scale
                    )
                }
                else -> {
                    drawBoxBorders(canvas, x, y, w, h, obj.borders, scale)
                    drawMultilineText(
                        canvas, obj.content, x, y, w, h,
                        fontSizePx = obj.fontSizePt * 1.33f * scale,
                        isBold = obj.isBold,
                        colorArgb = obj.textColorArgb,
                        alignment = obj.alignment,
                        direction = obj.direction,
                        verticalCenter = obj.type == LayoutObjectType.RECTANGLE,
                        paddingPx = (if (obj.type == LayoutObjectType.RECTANGLE) 10f else 4f) * scale
                    )
                }
            }

            // Low-confidence highlight
            if (highlightLowConfidence && obj.confidence < 0.78f && !obj.userCorrected) {
                val warnFill = Paint().apply {
                    style = Paint.Style.FILL
                    color = Color.argb(28, 245, 158, 11)
                }
                val warnStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    color = Color.parseColor("#D97706")
                    strokeWidth = 2.2f * scale
                    pathEffect = DashPathEffect(floatArrayOf(6f * scale, 4f * scale), 0f)
                }
                canvas.drawRect(x, y, x + w, y + h, warnFill)
                canvas.drawRect(x, y, x + w, y + h, warnStroke)
            }

            // Selection or Bounding Box Inspector
            val isSelected = selectedObjectId == obj.id
            if (showBoundingBoxes || isSelected) {
                val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    color = if (isSelected) Color.parseColor("#DC2626") else Color.argb(110, 37, 99, 235)
                    strokeWidth = (if (isSelected) 2.8f else 1.2f) * scale
                }
                canvas.drawRect(x, y, x + w, y + h, boxPaint)

                if (isSelected) {
                    val handlePaint = Paint().apply {
                        style = Paint.Style.FILL
                        color = Color.parseColor("#DC2626")
                    }
                    val hs = 7f * scale
                    canvas.drawRect(x - hs, y - hs, x + hs, y + hs, handlePaint)
                    canvas.drawRect(x + w - hs, y - hs, x + w + hs, y + hs, handlePaint)
                    canvas.drawRect(x - hs, y + h - hs, x + hs, y + h + hs, handlePaint)
                    canvas.drawRect(x + w - hs, y + h - hs, x + w + hs, y + h + hs, handlePaint)
                }
            }
        }

        if (simulateScanAngleDeg != null && simulateShadowStrength > 0) {
            val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    widthPx * 0.72f,
                    heightPx * 0.32f,
                    widthPx * 0.9f,
                    intArrayOf(
                        Color.TRANSPARENT,
                        Color.argb(((simulateShadowStrength / 100f) * 88).toInt(), 15, 23, 42)
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, widthPx.toFloat(), heightPx.toFloat(), shadowPaint)
        }

        canvas.restore()
    }

    private fun drawBorderSide(
        canvas: Canvas,
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        side: BorderSide,
        scale: Float
    ) {
        if (side.widthPx <= 0f) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = side.colorArgb
            strokeWidth = max(1f, side.widthPx * scale)
            if (side.isDashed) {
                pathEffect = DashPathEffect(floatArrayOf(6f * scale, 4f * scale), 0f)
            }
        }
        canvas.drawLine(x1, y1, x2, y2, paint)

        if (side.isDouble) {
            val offset = 3f * scale
            val dx = x2 - x1
            val dy = y2 - y1
            val len = hypot(dx, dy).coerceAtLeast(1f)
            val nx = (-dy / len) * offset
            val ny = (dx / len) * offset
            canvas.drawLine(x1 + nx, y1 + ny, x2 + nx, y2 + ny, paint)
        }
    }

    private fun drawBoxBorders(
        canvas: Canvas,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        borders: BorderProperties,
        scale: Float
    ) {
        drawBorderSide(canvas, x, y, x + w, y, borders.top, scale)
        drawBorderSide(canvas, x + w, y, x + w, y + h, borders.right, scale)
        drawBorderSide(canvas, x, y + h, x + w, y + h, borders.bottom, scale)
        drawBorderSide(canvas, x, y, x, y + h, borders.left, scale)
    }

    private fun drawMultilineText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        fontSizePx: Float,
        isBold: Boolean,
        colorArgb: Int,
        alignment: TextAlignment,
        direction: TextDirection,
        verticalCenter: Boolean,
        paddingPx: Float
    ) {
        if (text.isEmpty()) return
        val innerX = x + paddingPx
        val innerY = y + paddingPx
        val innerW = max(16, (w - paddingPx * 2f).toInt())
        val innerH = max(16f, h - paddingPx * 2f)

        val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorArgb
            textSize = max(8f, fontSizePx)
            typeface = if (isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
        }

        val layoutAlign = when {
            alignment == TextAlignment.CENTER -> Layout.Alignment.ALIGN_CENTER
            direction == TextDirection.RTL && alignment == TextAlignment.RIGHT -> Layout.Alignment.ALIGN_NORMAL
            direction == TextDirection.RTL && alignment == TextAlignment.LEFT -> Layout.Alignment.ALIGN_OPPOSITE
            direction == TextDirection.LTR && alignment == TextAlignment.LEFT -> Layout.Alignment.ALIGN_NORMAL
            direction == TextDirection.LTR && alignment == TextAlignment.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }

        val staticLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder
                .obtain(text, 0, text.length, textPaint, innerW)
                .setAlignment(layoutAlign)
                .setLineSpacing(0f, 1.22f)
                .setIncludePad(false)
                .setTextDirection(
                    if (direction == TextDirection.RTL) TextDirectionHeuristics.RTL
                    else TextDirectionHeuristics.LTR
                )
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, textPaint, innerW, layoutAlign, 1.22f, 0f, false)
        }

        val textHeight = staticLayout.height.toFloat()
        val drawY = if (verticalCenter) {
            innerY + max(0f, (innerH - textHeight) / 2f)
        } else {
            innerY
        }

        canvas.save()
        canvas.clipRect(x, y, x + w, y + h + 6f)
        canvas.translate(innerX, drawY)
        staticLayout.draw(canvas)
        canvas.restore()
    }

    private fun drawTableObject(
        canvas: Canvas,
        obj: PageLayoutObject,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        scale: Float
    ) {
        val tbl = obj.tableStructure ?: return
        val rows = tbl.rows.coerceAtLeast(1)
        val cols = tbl.cols.coerceAtLeast(1)

        val rSum = tbl.rowHeights.sum().takeIf { it > 0f } ?: 1f
        val cSum = tbl.colWidths.sum().takeIf { it > 0f } ?: 1f

        val normRowH = tbl.rowHeights.map { (it / rSum) * h }
        val normColW = tbl.colWidths.map { (it / cSum) * w }

        val rowY = FloatArray(rows + 1)
        rowY[0] = y
        for (r in 0 until rows) {
            rowY[r + 1] = rowY[r] + (normRowH.getOrElse(r) { h / rows })
        }

        fun cellRect(cell: TableCellModel): FloatArray {
            val rStart = cell.row.coerceIn(0, rows - 1)
            val rEnd = (rStart + cell.rowSpan.coerceAtLeast(1)).coerceAtMost(rows)
            val cStart = cell.col.coerceIn(0, cols - 1)
            val cEnd = (cStart + cell.colSpan.coerceAtLeast(1)).coerceAtMost(cols)

            val cy = rowY[rStart]
            val ch = rowY[rEnd] - cy

            var cw = 0f
            for (c in cStart until cEnd) {
                cw += normColW.getOrElse(c) { w / cols }
            }

            val cx = if (tbl.direction == TextDirection.RTL) {
                var offsetFromRight = 0f
                for (c in 0 until cEnd) {
                    offsetFromRight += normColW.getOrElse(c) { w / cols }
                }
                x + w - offsetFromRight
            } else {
                var offsetFromLeft = 0f
                for (c in 0 until cStart) {
                    offsetFromLeft += normColW.getOrElse(c) { w / cols }
                }
                x + offsetFromLeft
            }
            return floatArrayOf(cx, cy, cw, ch)
        }

        for (cell in tbl.cells) {
            if (cell.hiddenByMerge) continue
            val rect = cellRect(cell)
            val cx = rect[0]
            val cy = rect[1]
            val cw = rect[2]
            val ch = rect[3]

            if (cell.backgroundColorArgb != 0) {
                val bgPaint = Paint().apply {
                    style = Paint.Style.FILL
                    color = cell.backgroundColorArgb
                }
                canvas.drawRect(cx, cy, cx + cw, cy + ch, bgPaint)
            }

            drawBoxBorders(canvas, cx, cy, cw, ch, cell.borders, scale)
            drawMultilineText(
                canvas = canvas,
                text = cell.content,
                x = cx,
                y = cy,
                w = cw,
                h = ch,
                fontSizePx = cell.fontSizePt * 1.3f * scale,
                isBold = cell.isBold,
                colorArgb = obj.textColorArgb,
                alignment = cell.alignment,
                direction = cell.direction,
                verticalCenter = true,
                paddingPx = 5f * scale
            )
        }

        drawBoxBorders(canvas, x, y, w, h, obj.borders, scale)
    }

    private fun drawCheckboxObject(
        canvas: Canvas,
        obj: PageLayoutObject,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        scale: Float
    ) {
        val boxSize = min(22f * scale, h * 0.72f)
        val boxX = if (obj.direction == TextDirection.RTL) x + w - boxSize - 4f * scale else x + 4f * scale
        val boxY = y + (h - boxSize) / 2f

        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = obj.textColorArgb
            strokeWidth = 1.8f * scale
        }
        canvas.drawRect(boxX, boxY, boxX + boxSize, boxY + boxSize, strokePaint)

        if (obj.checked) {
            val checkPath = Path().apply {
                moveTo(boxX + boxSize * 0.2f, boxY + boxSize * 0.52f)
                lineTo(boxX + boxSize * 0.44f, boxY + boxSize * 0.76f)
                lineTo(boxX + boxSize * 0.82f, boxY + boxSize * 0.24f)
            }
            strokePaint.strokeWidth = 2.4f * scale
            canvas.drawPath(checkPath, strokePaint)
        }

        val textW = w - boxSize - 12f * scale
        val textX = if (obj.direction == TextDirection.RTL) x else x + boxSize + 10f * scale
        drawMultilineText(
            canvas = canvas,
            text = obj.content,
            x = textX,
            y = y,
            w = textW,
            h = h,
            fontSizePx = obj.fontSizePt * 1.3f * scale,
            isBold = obj.isBold,
            colorArgb = obj.textColorArgb,
            alignment = if (obj.direction == TextDirection.RTL) TextAlignment.RIGHT else TextAlignment.LEFT,
            direction = obj.direction,
            verticalCenter = true,
            paddingPx = 2f * scale
        )
    }

    private fun drawStampOrEmblem(
        canvas: Canvas,
        obj: PageLayoutObject,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        scale: Float
    ) {
        val cx = x + w / 2f
        val cy = y + h / 2f
        val radius = min(w, h) * 0.45f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = obj.stampColorArgb
            strokeWidth = 2.2f * scale
        }
        canvas.drawCircle(cx, cy, radius, paint)
        paint.strokeWidth = 1.1f * scale
        canvas.drawCircle(cx, cy, radius * 0.84f, paint)

        drawMultilineText(
            canvas = canvas,
            text = obj.content,
            x = x + w * 0.14f,
            y = y + h * 0.18f,
            w = w * 0.72f,
            h = h * 0.64f,
            fontSizePx = obj.fontSizePt * 1.25f * scale,
            isBold = true,
            colorArgb = obj.stampColorArgb,
            alignment = TextAlignment.CENTER,
            direction = TextDirection.RTL,
            verticalCenter = true,
            paddingPx = 2f * scale
        )
    }

    private fun drawSignatureArea(
        canvas: Canvas,
        obj: PageLayoutObject,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        scale: Float
    ) {
        drawBoxBorders(canvas, x, y, w, h, obj.borders, scale)
        drawMultilineText(
            canvas = canvas,
            text = obj.content,
            x = x,
            y = y,
            w = w,
            h = h * 0.55f,
            fontSizePx = obj.fontSizePt * 1.3f * scale,
            isBold = obj.isBold,
            colorArgb = obj.textColorArgb,
            alignment = obj.alignment,
            direction = obj.direction,
            verticalCenter = false,
            paddingPx = 6f * scale
        )

        val sigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.parseColor("#1E3A8A")
            strokeWidth = 2.0f * scale
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val sx = x + w * 0.22f
        val sy = y + h * 0.74f
        val path = Path().apply {
            moveTo(sx, sy)
            cubicTo(
                sx + w * 0.18f, sy - h * 0.22f,
                sx + w * 0.35f, sy + h * 0.15f,
                sx + w * 0.55f, sy - h * 0.08f
            )
            cubicTo(
                sx + w * 0.42f, sy + h * 0.18f,
                sx + w * 0.15f, sy + h * 0.12f,
                sx + w * 0.58f, sy + h * 0.05f
            )
        }
        canvas.drawPath(path, sigPaint)
    }
}
