package com.example.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Filter
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.image.ImageUtils
import com.example.data.model.EnhancementMode
import com.example.data.model.ScanPage
import com.example.ui.PipelineStage
import com.example.ui.theme.PdfRedDark
import com.example.ui.theme.PdfRedHover
import com.example.ui.theme.PdfRedLight
import com.example.ui.theme.PdfRedPrimary

@Composable
fun ScanEditScreen(
    pages: List<ScanPage>,
    currentPageIndex: Int,
    cachedBitmaps: Map<String, Bitmap>,
    isProcessing: Boolean,
    pipelineStage: PipelineStage,
    statusMessage: String?,
    onSelectPage: (Int) -> Unit,
    onRemovePage: (Int) -> Unit,
    onRotatePage: () -> Unit,
    onSetEnhancement: (EnhancementMode) -> Unit,
    onAddMoreImages: (List<Uri>) -> Unit,
    onStartOcr: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler {
        if (!isProcessing) onBack()
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) onAddMoreImages(uris)
    }

    val currentPage = pages.getOrNull(currentPageIndex)
    val rawBitmap = currentPage?.let { cachedBitmaps[it.id] }

    val previewBitmap = remember(rawBitmap, currentPage?.enhancementMode) {
        if (rawBitmap != null && currentPage != null) {
            ImageUtils.applyEnhancement(rawBitmap, currentPage.enhancementMode)
        } else {
            rawBitmap
        }
    }

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, enabled = !isProcessing, modifier = Modifier.testTag("back_to_home_button")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "معاينة وتحسين المستند",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "صفحة ${currentPageIndex + 1} من ${pages.size}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = onRotatePage,
                        enabled = !isProcessing,
                        modifier = Modifier.testTag("rotate_page_button")
                    ) {
                        Icon(imageVector = Icons.Default.RotateRight, contentDescription = "تدوير 90°", tint = PdfRedPrimary)
                    }

                    if (pages.size > 1) {
                        IconButton(
                            onClick = { onRemovePage(currentPageIndex) },
                            enabled = !isProcessing,
                            modifier = Modifier.testTag("delete_page_button")
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف الصفحة", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Multi-Page Thumbnails Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الصفحات (${pages.size}):",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    itemsIndexed(pages) { index, page ->
                        val isSelected = index == currentPageIndex
                        val pageBitmap = cachedBitmaps[page.id]

                        Box(
                            modifier = Modifier
                                .size(50.dp, 66.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = if (isSelected) PdfRedPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .background(Color(0xFF222228))
                                .clickable(enabled = !isProcessing) { onSelectPage(index) }
                                .testTag("page_thumb_$index"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (pageBitmap != null) {
                                Image(
                                    bitmap = pageBitmap.asImageBitmap(),
                                    contentDescription = "صفحة ${index + 1}",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            // Page number badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(topStart = 6.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "${index + 1}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Add Page Button (+)
                    item {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            enabled = !isProcessing,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .size(50.dp, 66.dp)
                                .testTag("add_more_pages_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "إضافة صورة", tint = PdfRedPrimary)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Document Image View
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1E1E24))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (previewBitmap != null) {
                    Image(
                        bitmap = previewBitmap.asImageBitmap(),
                        contentDescription = "Preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                    )
                } else {
                    Text(
                        text = "جاري تحميل الصورة...",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Enhancement Filters Selector
            Text(
                text = "مرشحات تحسين الوثيقة (Filters):",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(EnhancementMode.entries) { mode ->
                    val isSelected = currentPage?.enhancementMode == mode
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSetEnhancement(mode) },
                        label = { Text(mode.labelAr) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PdfRedPrimary,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("filter_${mode.name}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Pipeline Progress Card (When Processing)
            AnimatedVisibility(visible = isProcessing) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = pipelineStage.titleAr,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = PdfRedPrimary
                            )
                            Text(
                                text = "${(pipelineStage.progress * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = PdfRedPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { pipelineStage.progress },
                            color = PdfRedPrimary,
                            trackColor = PdfRedPrimary.copy(alpha = 0.2f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        )
                        if (statusMessage != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = statusMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Bottom OCR Execution Button
            Button(
                onClick = onStartOcr,
                enabled = !isProcessing && pages.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PdfRedPrimary,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("run_ocr_pipeline_button")
            ) {
                Icon(
                    imageVector = Icons.Default.DocumentScanner,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "بدء اكتشاف النصوص OCR لكافة الصفحات (${pages.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
