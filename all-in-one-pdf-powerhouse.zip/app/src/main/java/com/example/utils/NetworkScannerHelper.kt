package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit

data class ScannerDevice(
    val ip: String,
    val port: Int,
    val name: String,
    val model: String,
    val supportedResolutions: List<Int>,
    val supportedColorModes: List<String>
)

object NetworkScannerHelper {

    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Query eSCL Scanner capabilities at IP and port
    suspend fun probeEsclScanner(ip: String, port: Int = 80): Result<ScannerDevice> = withContext(Dispatchers.IO) {
        try {
            val url = "http://$ip:$port/eSCL/ScannerCapabilities"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("رمز الاستجابة: ${response.code}"))
            }

            val body = response.body?.string() ?: ""
            if (!body.contains("ScannerCapabilities", ignoreCase = true)) {
                return@withContext Result.failure(Exception("الجهاز لا يدعم بروتوكول eSCL / AirScan"))
            }

            // Extract basic fields from XML
            val makeAndModel = extractXmlTag(body, "MakeAndModel") ?: extractXmlTag(body, "pwg:MakeAndModel") ?: "eSCL Scanner"
            val manufacturer = extractXmlTag(body, "Manufacturer") ?: ""
            val name = if (manufacturer.isNotBlank()) "$manufacturer $makeAndModel" else makeAndModel

            // Extract resolutions
            val resMatches = Regex("<(?:pwg:)?DiscreteResolution>.*?<(?:pwg:)?XResolution>(\\d+)</(?:pwg:)?XResolution>.*?</(?:pwg:)?DiscreteResolution>", RegexOption.DOT_MATCHES_ALL)
                .findAll(body)
                .mapNotNull { it.groupValues.getOrNull(1)?.toIntOrNull() }
                .distinct()
                .sorted()
                .toList()

            val resolutions = if (resMatches.isNotEmpty()) resMatches else listOf(150, 300, 600)

            // Extract color modes
            val colorModes = mutableListOf<String>()
            if (body.contains("RGB24", ignoreCase = true)) colorModes.add("Color (RGB)")
            if (body.contains("Grayscale8", ignoreCase = true)) colorModes.add("Grayscale")
            if (body.contains("BlackAndWhite1", ignoreCase = true)) colorModes.add("Black & White")
            if (colorModes.isEmpty()) colorModes.addAll(listOf("Color (RGB)", "Grayscale"))

            Result.success(
                ScannerDevice(
                    ip = ip,
                    port = port,
                    name = name,
                    model = makeAndModel,
                    supportedResolutions = resolutions,
                    supportedColorModes = colorModes
                )
            )
        } catch (e: Exception) {
            Result.failure(Exception("تعذر الاتصال بالماسح على $ip:$port (${e.localizedMessage})"))
        }
    }

    // Trigger an eSCL scan job and retrieve the scanned bitmap
    suspend fun triggerScan(
        device: ScannerDevice,
        resolutionDpi: Int = 300,
        colorMode: String = "Color (RGB)",
        source: String = "Platen" // Platen or Adf
    ): Result<Bitmap> = withContext(Dispatchers.IO) {
        try {
            val colorModeXml = when {
                colorMode.contains("Gray", ignoreCase = true) -> "Grayscale8"
                colorMode.contains("Black", ignoreCase = true) -> "BlackAndWhite1"
                else -> "RGB24"
            }

            val scanSettingsXml = """
                <?xml version="1.0" encoding="UTF-8"?>
                <scan:ScanSettings xmlns:scan="http://schemas.hp.com/imaging/escl/2011/05/03" xmlns:pwg="http://www.pwg.org/schemas/2010/12/sm">
                    <pwg:Version>2.0</pwg:Version>
                    <pwg:ScanRegions>
                        <pwg:ScanRegion>
                            <pwg:Height>3507</pwg:Height>
                            <pwg:Width>2480</pwg:Width>
                            <pwg:XOffset>0</pwg:XOffset>
                            <pwg:YOffset>0</pwg:YOffset>
                        </pwg:ScanRegion>
                    </pwg:ScanRegions>
                    <scan:InputSource>$source</scan:InputSource>
                    <scan:ColorMode>$colorModeXml</scan:ColorMode>
                    <scan:XResolution>$resolutionDpi</scan:XResolution>
                    <scan:YResolution>$resolutionDpi</scan:YResolution>
                    <pwg:DocumentFormat>image/jpeg</pwg:DocumentFormat>
                </scan:ScanSettings>
            """.trimIndent()

            val postJobUrl = "http://${device.ip}:${device.port}/eSCL/ScanJobs"
            val postRequest = Request.Builder()
                .url(postJobUrl)
                .post(scanSettingsXml.toRequestBody("text/xml".toMediaType()))
                .build()

            val postResponse = client.newCall(postRequest).execute()
            if (!postResponse.isSuccessful && postResponse.code != 201) {
                return@withContext Result.failure(Exception("فشل بدء مهمة المسح. رمز الخطأ: ${postResponse.code}"))
            }

            // Location header usually points to the created ScanJob or NextDocument
            val location = postResponse.header("Location")
            val documentUrl = if (location != null) {
                if (location.startsWith("http")) "$location/NextDocument" else "http://${device.ip}:${device.port}$location/NextDocument"
            } else {
                "http://${device.ip}:${device.port}/eSCL/ScanJobs/NextDocument"
            }

            // Wait a moment for scanner carriage to acquire and return document
            var attempts = 0
            var docStream: InputStream? = null
            while (attempts < 15 && docStream == null) {
                kotlinx.coroutines.delay(1500)
                attempts++
                val docRequest = Request.Builder().url(documentUrl).build()
                val docResponse = client.newCall(docRequest).execute()
                if (docResponse.isSuccessful) {
                    docStream = docResponse.body?.byteStream()
                }
            }

            if (docStream == null) {
                return@withContext Result.failure(Exception("انتهت مهلة انتظار الصورة من الماسح الضوئي."))
            }

            val bitmap = BitmapFactory.decodeStream(docStream)
            docStream.close()

            if (bitmap != null) {
                Result.success(bitmap)
            } else {
                Result.failure(Exception("تعذر فك ترميز بيانات الصورة المستلمة من الماسح."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ أثناء عملية المسح: ${e.localizedMessage}"))
        }
    }

    private fun extractXmlTag(xml: String, tag: String): String? {
        val regex = Regex("<(?:[\\w]+:)?$tag>(.*?)</(?:[\\w]+:)?$tag>", RegexOption.DOT_MATCHES_ALL)
        return regex.find(xml)?.groupValues?.getOrNull(1)?.trim()
    }
}
