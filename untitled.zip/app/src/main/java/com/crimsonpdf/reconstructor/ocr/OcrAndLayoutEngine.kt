package com.crimsonpdf.reconstructor.ocr

import android.graphics.Bitmap
import android.graphics.Color
import com.crimsonpdf.reconstructor.model.BorderProperties
import com.crimsonpdf.reconstructor.model.FontRole
import com.crimsonpdf.reconstructor.model.LayoutObjectType
import com.crimsonpdf.reconstructor.model.PageLayoutObject
import com.crimsonpdf.reconstructor.model.TableCellModel
import com.crimsonpdf.reconstructor.model.TableStructureModel
import com.crimsonpdf.reconstructor.model.TextAlignment
import com.crimsonpdf.reconstructor.model.TextDirection
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.suspendCancellableCoroutine

object OcrAndLayoutEngine {

    private val arabicRegex = Regex("[\\u0600-\\u06FF]")

    suspend fun analyzeDocumentBitmap(bitmap: Bitmap): List<PageLayoutObject> {
        val mlKitBlocks = runMlKitRecognition(bitmap)
        val structuralObjects = analyzePixelStructure(bitmap)

        if (mlKitBlocks.isEmpty()) {
            return structuralObjects
        }

        val combined = mutableListOf<PageLayoutObject>()
        combined.addAll(mlKitBlocks)

        // Add any detected tables or horizontal dividers from pixel analysis that don't collide
        for (structObj in structuralObjects) {
            if (structObj.type == LayoutObjectType.TABLE || structObj.type == LayoutObjectType.LINE) {
                combined.add(structObj)
            }
        }
        return combined.sortedBy { it.y }
    }

    private suspend fun runMlKitRecognition(bitmap: Bitmap): List<PageLayoutObject> =
        suspendCancellableCoroutine { cont ->
            try {
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val image = InputImage.fromBitmap(bitmap, 0)
                val bw = bitmap.width.coerceAtLeast(1).toFloat()
                val bh = bitmap.height.coerceAtLeast(1).toFloat()

                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        val list = mutableListOf<PageLayoutObject>()
                        visionText.textBlocks.forEachIndexed { idx, block ->
                            val rect = block.boundingBox
                            if (rect != null && block.text.isNotBlank()) {
                                val nx = ((rect.left / bw) * 1000f).coerceIn(20f, 950f)
                                val ny = ((rect.top / bh) * 1000f).coerceIn(20f, 950f)
                                val nw = ((rect.width() / bw) * 1000f).coerceIn(40f, 940f)
                                val nh = ((rect.height() / bh) * 1000f).coerceIn(18f, 900f)

                                val hasArabic = arabicRegex.containsMatchIn(block.text)
                                val dir = if (hasArabic) TextDirection.RTL else TextDirection.LTR
                                val align = when {
                                    nx > 180f && (nx + nw) < 820f -> TextAlignment.CENTER
                                    dir == TextDirection.RTL -> TextAlignment.RIGHT
                                    else -> TextAlignment.LEFT
                                }
                                val lineCount = block.lines.size.coerceAtLeast(1)
                                val estPt = ((nh / lineCount) * 0.42f).coerceIn(9.5f, 20f)

                                list.add(
                                    PageLayoutObject(
                                        id = "ocr_blk_${idx + 1}",
                                        type = if (lineCount > 1) LayoutObjectType.PARAGRAPH else LayoutObjectType.TEXT,
                                        x = nx,
                                        y = ny,
                                        width = nw,
                                        height = nh,
                                        content = block.text,
                                        confidence = 0.92f,
                                        alignment = align,
                                        direction = dir,
                                        fontSizePt = estPt,
                                        isBold = estPt >= 14.5f,
                                        fontRole = if (estPt >= 15f) FontRole.TITLE else FontRole.NORMAL,
                                        zOrder = idx + 1
                                    )
                                )
                            }
                        }
                        if (cont.isActive) cont.resume(list)
                    }
                    .addOnFailureListener {
                        if (cont.isActive) cont.resume(emptyList())
                    }
            } catch (_: Throwable) {
                if (cont.isActive) cont.resume(emptyList())
            }
        }

    private fun analyzePixelStructure(bitmap: Bitmap): List<PageLayoutObject> {
        val w = bitmap.width.coerceAtLeast(100)
        val h = bitmap.height.coerceAtLeast(100)
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val rowDarkCounts = IntArray(h)
        for (y in 0 until h) {
            var count = 0
            val offset = y * w
            for (x in (w * 0.04).toInt() until (w * 0.96).toInt()) {
                val c = pixels[offset + x]
                val luma = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
                if (luma < 175f) count++
            }
            rowDarkCounts[y] = count
        }

        val objects = mutableListOf<PageLayoutObject>()
        var inBand = false
        var bandStart = 0
        var bandIdx = 0

        for (y in (h * 0.03).toInt() until (h * 0.97).toInt()) {
            val active = rowDarkCounts[y] > (w * 0.015).toInt()
            if (active && !inBand) {
                inBand = true
                bandStart = y
            } else if (!active && inBand) {
                var lookahead = false
                for (k in 1..8) {
                    if (y + k < h && rowDarkCounts[y + k] > (w * 0.015).toInt()) {
                        lookahead = true
                        break
                    }
                }
                if (!lookahead) {
                    inBand = false
                    val bandEnd = y
                    val bandH = bandEnd - bandStart
                    if (bandH >= 4 && bandIdx < 12) {
                        var minX = w
                        var maxX = 0
                        var maxDensity = 0
                        for (by in bandStart..bandEnd) {
                            if (rowDarkCounts[by] > maxDensity) maxDensity = rowDarkCounts[by]
                            val off = by * w
                            var bx = (w * 0.04).toInt()
                            while (bx < (w * 0.96).toInt()) {
                                val c = pixels[off + bx]
                                val luma = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
                                if (luma < 175f) {
                                    minX = min(minX, bx)
                                    maxX = max(maxX, bx)
                                }
                                bx += 3
                            }
                        }
                        if (maxX > minX + 20) {
                            bandIdx++
                            val nx = ((minX.toFloat() / w) * 1000f).coerceIn(30f, 920f)
                            val ny = ((bandStart.toFloat() / h) * 1000f).coerceIn(30f, 940f)
                            val nw = (((maxX - minX).toFloat() / w) * 1000f).coerceIn(50f, 940f)
                            val nh = ((bandH.toFloat() / h) * 1000f).coerceIn(6f, 850f)

                            if (nh <= 12f && nw > 420f) {
                                objects.add(
                                    PageLayoutObject(
                                        id = "struct_line_$bandIdx",
                                        type = LayoutObjectType.LINE,
                                        x = nx, y = ny, width = nw, height = 4f,
                                        content = "",
                                        borders = BorderProperties.uniform(1.8f),
                                        zOrder = bandIdx
                                    )
                                )
                            } else if (nh > 135f && maxDensity > (maxX - minX) * 0.55f) {
                                objects.add(
                                    PageLayoutObject(
                                        id = "struct_table_$bandIdx",
                                        type = LayoutObjectType.TABLE,
                                        x = nx, y = ny, width = nw, height = nh,
                                        content = "",
                                        confidence = 0.76f,
                                        borders = BorderProperties.uniform(1.6f),
                                        zOrder = bandIdx,
                                        tableStructure = TableStructureModel(
                                            rows = 3, cols = 3,
                                            rowHeights = listOf(0.34f, 0.33f, 0.33f),
                                            colWidths = listOf(0.34f, 0.33f, 0.33f),
                                            cells = (0..2).flatMap { r ->
                                                (0..2).map { c ->
                                                    TableCellModel(
                                                        id = "sc_${r}_$c",
                                                        row = r, col = c,
                                                        content = if (r == 0) "عمود ${c + 1}" else "بيان ${r}-${c + 1}",
                                                        alignment = TextAlignment.CENTER,
                                                        isBold = r == 0,
                                                        backgroundColorArgb = if (r == 0) 0xFFE2E8F0.toInt() else 0
                                                    )
                                                }
                                            }
                                        )
                                    )
                                )
                            } else {
                                objects.add(
                                    PageLayoutObject(
                                        id = "struct_txt_$bandIdx",
                                        type = if (bandIdx == 1) LayoutObjectType.TEXT else LayoutObjectType.PARAGRAPH,
                                        x = nx, y = ny, width = nw, height = nh.coerceAtLeast(32f),
                                        content = "منطقة نصية مكتشفة #$bandIdx — يمكنك تعديل النص من تبويب الضبط اليدوي",
                                        confidence = 0.72f,
                                        alignment = if (nx > 180f && nx + nw < 820f) TextAlignment.CENTER else TextAlignment.RIGHT,
                                        fontSizePt = if (bandIdx == 1) 15f else 12f,
                                        isBold = bandIdx == 1,
                                        zOrder = bandIdx
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
        return objects
    }
}
