package com.example.core.fs

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.*
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

data class JdkInstallStatus(
    val isInstalled: Boolean = false,
    val javaVersion: String = "Not Installed",
    val javaHomePath: String = "",
    val javaBinPath: String = "",
    val usesLinker: Boolean = false,
    val errorDetails: String? = null
)

class JdkProvisioner(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    var usesLinker: Boolean = false
        private set

    val systemLinker: File? by lazy {
        val candidates = listOf(
            File("/system/bin/linker64"),
            File("/system/bin/linker"),
            File("/apex/com.android.runtime/bin/linker64"),
            File("/apex/com.android.runtime/bin/linker")
        )
        candidates.firstOrNull { it.exists() }
    }

    val internalJdkDir: File
        get() = File(context.filesDir, "jdk")

    val javaExecutable: File
        get() = File(internalJdkDir, "bin/java")

    /**
     * Constructs the executable command tokens, using the system linker fallback if required.
     */
    fun getJavaInvocation(javaBin: File, vararg args: String): List<String> {
        return if (usesLinker && systemLinker != null) {
            listOf(systemLinker!!.absolutePath, javaBin.absolutePath) + args.toList()
        } else {
            listOf(javaBin.absolutePath) + args.toList()
        }
    }

    /**
     * Check if a valid runnable JDK is installed and verify its version.
     */
    suspend fun checkJdkStatus(): JdkInstallStatus = withContext(Dispatchers.IO) {
        val javaBin = javaExecutable
        if (!javaBin.exists()) {
            return@withContext JdkInstallStatus(
                isInstalled = false,
                errorDetails = "JDK not found at ${internalJdkDir.absolutePath}"
            )
        }

        // Ensure executable flags
        ensureExecutablePermissions(internalJdkDir)

        // Run java -version test
        val (testResult, linkerUsed) = runJavaVersionTest(javaBin)
        if (testResult.first == 0) {
            usesLinker = linkerUsed
            JdkInstallStatus(
                isInstalled = true,
                javaVersion = testResult.second,
                javaHomePath = internalJdkDir.absolutePath,
                javaBinPath = javaBin.absolutePath,
                usesLinker = linkerUsed
            )
        } else {
            JdkInstallStatus(
                isInstalled = false,
                javaVersion = "Execution failed",
                javaHomePath = internalJdkDir.absolutePath,
                javaBinPath = javaBin.absolutePath,
                usesLinker = linkerUsed,
                errorDetails = testResult.second
            )
        }
    }

    /**
     * Install JDK from an Android content Uri (picked by user via SAF).
     */
    suspend fun installJdkFromUri(
        uri: Uri,
        fileName: String,
        onProgress: (String) -> Unit
    ): JdkInstallStatus = withContext(Dispatchers.IO) {
        try {
            onProgress("Opening file: $fileName...")
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: throw IOException("Cannot read file from storage")

            val tempFile = File(context.cacheDir, "jdk_archive_${System.currentTimeMillis()}_$fileName")
            try {
                onProgress("Copying archive to local cache...")
                FileOutputStream(tempFile).use { out ->
                    inputStream.copyTo(out)
                }

                installJdkFromArchiveFile(tempFile, onProgress)
            } finally {
                if (tempFile.exists()) tempFile.delete()
            }
        } catch (e: Exception) {
            JdkInstallStatus(
                isInstalled = false,
                errorDetails = "Failed to install from file: ${e.message}"
            )
        }
    }

    /**
     * Download JDK from a direct URL and install it.
     */
    suspend fun downloadAndInstallJdk(
        url: String,
        onProgress: (String) -> Unit
    ): JdkInstallStatus = withContext(Dispatchers.IO) {
        val tempFile = File(context.cacheDir, "jdk_download_${System.currentTimeMillis()}.archive")
        try {
            onProgress("Connecting to download server...")
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                throw IOException("Download failed with HTTP ${response.code}: ${response.message}")
            }

            val body = response.body ?: throw IOException("Empty response body")
            val totalBytes = body.contentLength()
            var downloadedBytes = 0L

            onProgress("Downloading JDK (${if (totalBytes > 0) "${totalBytes / (1024 * 1024)} MB" else "streaming"})...")
            body.byteStream().use { input ->
                FileOutputStream(tempFile).use { output ->
                    val buffer = ByteArray(32 * 1024)
                    var read: Int
                    var lastUpdate = System.currentTimeMillis()
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                        downloadedBytes += read
                        val now = System.currentTimeMillis()
                        if (now - lastUpdate > 500) {
                            lastUpdate = now
                            if (totalBytes > 0) {
                                val percent = (downloadedBytes * 100 / totalBytes).toInt()
                                onProgress("Downloading: $percent% (${downloadedBytes / (1024 * 1024)} MB / ${totalBytes / (1024 * 1024)} MB)")
                            } else {
                                onProgress("Downloaded: ${downloadedBytes / (1024 * 1024)} MB...")
                            }
                        }
                    }
                    output.flush()
                }
            }

            installJdkFromArchiveFile(tempFile, onProgress)
        } catch (e: Exception) {
            JdkInstallStatus(
                isInstalled = false,
                errorDetails = "Download failed: ${e.message}"
            )
        } finally {
            if (tempFile.exists()) tempFile.delete()
        }
    }

    /**
     * Extracts either .tar.xz or .zip archive to internalJdkDir and configures executable permissions.
     */
    private fun installJdkFromArchiveFile(
        archiveFile: File,
        onProgress: (String) -> Unit
    ): JdkInstallStatus {
        onProgress("Preparing destination directory...")
        val targetDir = internalJdkDir
        if (targetDir.exists()) {
            targetDir.deleteRecursively()
        }
        targetDir.mkdirs()

        val tempExtractDir = File(context.filesDir, "jdk_tmp_${System.currentTimeMillis()}")
        if (tempExtractDir.exists()) tempExtractDir.deleteRecursively()
        tempExtractDir.mkdirs()

        try {
            val isZip = isZipFile(archiveFile)
            if (isZip) {
                onProgress("Extracting ZIP archive...")
                extractZip(archiveFile, tempExtractDir, onProgress)
            } else {
                onProgress("Extracting TAR/XZ archive...")
                extractTarXz(archiveFile, tempExtractDir, onProgress)
            }

            // Locate bin/java
            onProgress("Locating bin/java executable...")
            val foundJavaBin = findFileRecursively(tempExtractDir, "java") { f ->
                f.isFile && f.parentFile?.name == "bin"
            }

            if (foundJavaBin == null) {
                return JdkInstallStatus(
                    isInstalled = false,
                    errorDetails = "Invalid JDK archive: 'bin/java' was not found inside the extracted files."
                )
            }

            // Move the root JDK folder into targetDir
            val jdkRoot = foundJavaBin.parentFile?.parentFile ?: tempExtractDir
            onProgress("Installing JDK files to executable path...")
            copyDirectory(jdkRoot, targetDir)

            onProgress("Setting executable permissions (chmod 755)...")
            ensureExecutablePermissions(targetDir)

            onProgress("Verifying java executable with 'java -version'...")
            val (testResult, linkerUsed) = runJavaVersionTest(File(targetDir, "bin/java"))
            val (exitCode, output) = testResult
            usesLinker = linkerUsed

            return if (exitCode == 0) {
                JdkInstallStatus(
                    isInstalled = true,
                    javaVersion = output,
                    javaHomePath = targetDir.absolutePath,
                    javaBinPath = File(targetDir, "bin/java").absolutePath,
                    usesLinker = linkerUsed
                )
            } else {
                JdkInstallStatus(
                    isInstalled = false,
                    javaVersion = "Verification Failed",
                    javaHomePath = targetDir.absolutePath,
                    javaBinPath = File(targetDir, "bin/java").absolutePath,
                    usesLinker = linkerUsed,
                    errorDetails = "Executable verification failed (exit code $exitCode):\n$output"
                )
            }
        } finally {
            if (tempExtractDir.exists()) tempExtractDir.deleteRecursively()
        }
    }

    private fun isZipFile(file: File): Boolean {
        return try {
            FileInputStream(file).use { fis ->
                val b = ByteArray(4)
                if (fis.read(b) == 4) {
                    b[0] == 0x50.toByte() && b[1] == 0x4B.toByte() && b[2] == 0x03.toByte() && b[3] == 0x04.toByte()
                } else false
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun extractZip(zipFile: File, outputDir: File, onProgress: (String) -> Unit) {
        ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
            var count = 0
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(outputDir, entry.name)
                // Protect against Zip Slip
                if (!outFile.canonicalPath.startsWith(outputDir.canonicalPath)) {
                    throw SecurityException("Zip Slip detected: ${entry.name}")
                }

                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { fos ->
                        zis.copyTo(fos)
                    }
                }
                count++
                if (count % 200 == 0) {
                    onProgress("Extracted $count files...")
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    private fun extractTarXz(archiveFile: File, outputDir: File, onProgress: (String) -> Unit) {
        val fis = FileInputStream(archiveFile)
        val bufferedIn = BufferedInputStream(fis)
        val xzIn = try {
            XZCompressorInputStream(bufferedIn)
        } catch (e: Exception) {
            // If not xz compressed, fallback directly to tar
            bufferedIn
        }

        TarArchiveInputStream(xzIn).use { tis ->
            var count = 0
            var entry = tis.nextTarEntry
            while (entry != null) {
                val outFile = File(outputDir, entry.name)
                if (!outFile.canonicalPath.startsWith(outputDir.canonicalPath)) {
                    throw SecurityException("Tar slip detected: ${entry.name}")
                }

                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { fos ->
                        tis.copyTo(fos)
                    }
                }
                count++
                if (count % 200 == 0) {
                    onProgress("Extracted $count files...")
                }
                entry = tis.nextTarEntry
            }
        }
    }

    private fun findFileRecursively(dir: File, name: String, condition: (File) -> Boolean): File? {
        val files = dir.listFiles() ?: return null
        for (f in files) {
            if (f.name == name && condition(f)) return f
            if (f.isDirectory) {
                val found = findFileRecursively(f, name, condition)
                if (found != null) return found
            }
        }
        return null
    }

    private fun copyDirectory(sourceDir: File, destDir: File) {
        if (!destDir.exists()) destDir.mkdirs()
        val files = sourceDir.listFiles() ?: return
        for (f in files) {
            val target = File(destDir, f.name)
            if (f.isDirectory) {
                copyDirectory(f, target)
            } else {
                f.copyTo(target, overwrite = true)
            }
        }
    }

    /**
     * Applies execute permission to all files in bin directory and any .so libraries.
     */
    fun ensureExecutablePermissions(jdkHome: File) {
        val binDir = File(jdkHome, "bin")
        if (binDir.exists()) {
            binDir.listFiles()?.forEach { binary ->
                try {
                    binary.setReadable(true, false)
                    binary.setExecutable(true, false)
                } catch (e: Exception) {}
            }
        }

        val libDir = File(jdkHome, "lib")
        if (libDir.exists()) {
            libDir.walkTopDown().forEach { file ->
                if (file.name.endsWith(".so") || file.parentFile?.name == "bin") {
                    try {
                        file.setReadable(true, false)
                        file.setExecutable(true, false)
                    } catch (e: Exception) {}
                }
            }
        }

        // Also run chmod 755 through runtime shell if available
        try {
            val chmodBin = Runtime.getRuntime().exec(arrayOf("chmod", "-R", "755", jdkHome.absolutePath))
            chmodBin.waitFor()
        } catch (e: Exception) {}
    }

    /**
     * Executes `java -version` and captures standard output and error, falling back to system linker if needed.
     */
    fun runJavaVersionTest(javaBin: File): Pair<Pair<Int, String>, Boolean> {
        try {
            javaBin.setReadable(true, false)
            javaBin.setExecutable(true, false)
            Runtime.getRuntime().exec(arrayOf("chmod", "755", javaBin.absolutePath)).waitFor()
        } catch (e: Exception) {}

        // 1. Try direct execution
        val directResult = executeProcess(listOf(javaBin.absolutePath, "-version"), javaBin)
        if (directResult.first == 0) {
            return Pair(directResult, false)
        }

        // 2. Try via system shell
        val shResult = executeProcess(listOf("sh", "-c", "\"${javaBin.absolutePath}\" -version"), javaBin)
        if (shResult.first == 0) {
            return Pair(shResult, false)
        }

        // 3. If direct execution fails (e.g. error=13 Permission denied), try via system linker
        val linker = systemLinker
        if (linker != null) {
            val linkerResult = executeProcess(listOf(linker.absolutePath, javaBin.absolutePath, "-version"), javaBin)
            if (linkerResult.first == 0) {
                return Pair(linkerResult, true)
            }
            return Pair(
                Pair(directResult.first, "Direct: ${directResult.second}\nLinker: ${linkerResult.second}"),
                false
            )
        }

        return Pair(directResult, false)
    }

    private fun executeProcess(command: List<String>, javaBin: File): Pair<Int, String> {
        return try {
            val pb = ProcessBuilder(command)
            val env = pb.environment()
            val jdkHome = javaBin.parentFile?.parentFile
            if (jdkHome != null) {
                env["JAVA_HOME"] = jdkHome.absolutePath
                val binPath = File(jdkHome, "bin").absolutePath
                val libPath = File(jdkHome, "lib").absolutePath
                val jliPath = File(jdkHome, "lib/jli").absolutePath
                val serverPath = File(jdkHome, "lib/server").absolutePath
                val existingPath = env["PATH"] ?: ""
                env["PATH"] = "$binPath:$existingPath"
                val existingLd = env["LD_LIBRARY_PATH"] ?: ""
                env["LD_LIBRARY_PATH"] = "$libPath:$jliPath:$serverPath:$existingLd"
            }

            val process = pb.start()
            val out = StringBuilder()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errReader = BufferedReader(InputStreamReader(process.errorStream))

            var l: String?
            while (reader.readLine().also { l = it } != null) {
                out.appendLine(l)
            }
            while (errReader.readLine().also { l = it } != null) {
                out.appendLine(l)
            }

            val exit = process.waitFor()
            val outputStr = out.toString().trim()
            Pair(exit, if (outputStr.isNotEmpty()) outputStr else "exit code $exit")
        } catch (e: Exception) {
            Pair(-1, "Execution error: ${e.message}")
        }
    }
}
