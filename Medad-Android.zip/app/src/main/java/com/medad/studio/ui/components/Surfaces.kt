package com.medad.studio.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.medad.studio.ui.theme.LocalPalette

@Composable
fun Hairline(modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Box(
        modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(p.line.copy(alpha = 0.7f)),
    )
}

@Composable
fun GoldChip(text: String) {
    val p = LocalPalette.current
    Text(
        text = text.uppercase(),
        color = p.gold,
        fontSize = 11.sp,
        letterSpacing = 2.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .border(1.dp, p.gold.copy(alpha = 0.45f), RoundedCornerShape(100))
            .padding(horizontal = 12.dp, vertical = 6.dp),
    )
}

@Composable
fun MedadCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    val p = LocalPalette.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.985f else 1f, label = "cardScale")
    Box(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(22.dp))
            .background(p.panel)
            .border(1.dp, p.line, RoundedCornerShape(22.dp))
            .then(
                if (onClick != null) {
                    Modifier.clickable(interactionSource = interaction, indication = null, onClick = onClick)
                } else {
                    Modifier
                },
            )
            .padding(20.dp),
    ) {
        content()
    }
}

@Composable
fun GoldButton(
    text: String,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, label = "btn")
    Row(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (enabled) {
                    Brush.linearGradient(listOf(p.gold, p.goldSoft))
                } else {
                    Brush.linearGradient(listOf(p.line, p.line))
                },
            )
            .clickable(enabled = enabled, interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = if (p.oled) Color.Black else Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text,
            color = if (enabled) {
                if (p.oled) Color.Black else Color.White
            } else {
                p.muted
            },
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
        )
    }
}

@Composable
fun GhostButton(
    text: String,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, p.line, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = p.ink, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = p.ink, fontWeight = FontWeight.Medium, fontSize = 14.sp)
    }
}

@Composable
fun IconOrb(icon: ImageVector, gold: Boolean = false) {
    val p = LocalPalette.current
    Box(
        Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(if (gold) p.gold.copy(alpha = 0.16f) else p.elevated)
            .border(1.dp, if (gold) p.gold.copy(alpha = 0.35f) else p.line, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = if (gold) p.gold else p.ink, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun FeatureTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    MedadCard(modifier = modifier, onClick = onClick) {
        Column {
            IconOrb(icon, gold = true)
            Spacer(Modifier.height(18.dp))
            Text(title, color = p.ink, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(subtitle, color = p.muted, fontSize = 13.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
fun RowScope.StatCell(label: String, value: String) {
    val p = LocalPalette.current
    Column(Modifier.weight(1f)) {
        Text(label, color = p.muted, fontSize = 11.sp, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = p.ink, fontWeight = FontWeight.Medium, fontSize = 16.sp)
    }
}
