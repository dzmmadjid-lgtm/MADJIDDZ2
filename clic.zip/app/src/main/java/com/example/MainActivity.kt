package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.vocalseparator.ui.screens.StudioScreen
import com.example.vocalseparator.ui.theme.VocalSeparatorTheme
import com.example.vocalseparator.viewmodel.VocalSeparatorViewModel

/**
 * النشاط الرئيسي لتطبيق فصل الصوت والموسيقى بالذكاء الاصطناعي (VocalRemover AI).
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            VocalSeparatorTheme {
                val viewModel: VocalSeparatorViewModel = viewModel()
                StudioScreen(viewModel = viewModel)
            }
        }
    }
}
