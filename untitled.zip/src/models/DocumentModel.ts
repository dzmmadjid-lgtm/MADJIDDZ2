export type ThemeMode = 'day' | 'night' | 'oled';

export type ProcessingMode = 'MODE_A_CLEAN_RECONSTRUCTION' | 'MODE_B_IMAGE_CLEANING';

export type PipelineStage =
  | 'IMPORT'
  | 'PREPROCESS'
  | 'ANALYZE_RECONSTRUCT'
  | 'VALIDATE_EDIT'
  | 'EXPORT';

export type LayoutObjectType =
  | 'TEXT'
  | 'PARAGRAPH'
  | 'TABLE'
  | 'TABLE_CELL'
  | 'IMAGE'
  | 'LINE'
  | 'DOTTED_LINE'
  | 'RECTANGLE'
  | 'CHECKBOX'
  | 'SIGNATURE_AREA'
  | 'DRAWING'
  | 'HANDWRITING'
  | 'PAGE_BREAK';

export type PipelineElementKind =
  | 'text'
  | 'line'
  | 'table'
  | 'box'
  | 'dotted_line'
  | 'drawing'
  | 'handwriting';

export type TextAlignment = 'right' | 'center' | 'left' | 'justify';
export type TextDirection = 'rtl' | 'ltr';
export type VerticalAlignment = 'top' | 'middle' | 'bottom';

export type FontRole =
  | 'title'
  | 'heading'
  | 'subtitle'
  | 'normal'
  | 'small'
  | 'table'
  | 'label'
  | 'footnote';

export type ArabicFontFamily = 'Amiri' | 'Cairo' | 'Tajawal' | 'IBM Plex Sans Arabic';

export interface BorderSide {
  width: number; // 0 = missing border, 1 = thin, 2 = medium, 3 = thick
  style: 'solid' | 'dashed' | 'dotted' | 'double' | 'none';
  color: string;
}

export interface BorderProperties {
  top: BorderSide;
  right: BorderSide;
  bottom: BorderSide;
  left: BorderSide;
}

export interface FontProperties {
  family: ArabicFontFamily;
  sizePt: number;
  weight: 'normal' | 'bold';
  style?: 'normal' | 'italic';
  role: FontRole;
  color: string;
  lineHeight: number;
}

export interface BackgroundProperties {
  fill: string; // 'transparent' or hex color
  opacity: number;
}

export interface TableCellModel {
  id: string;
  row: number;
  col: number;
  rowSpan: number;
  colSpan: number;
  content: string;
  confidence: number;
  uncertainTokens?: string[];
  alignment: TextAlignment;
  verticalAlignment: VerticalAlignment;
  direction: TextDirection;
  padding: number;
  fontSizePt: number;
  fontWeight: 'normal' | 'bold';
  borders: BorderProperties;
  backgroundColor: string;
  hiddenByMerge?: boolean;
}

export interface TableStructureModel {
  rows: number;
  cols: number;
  rowHeights: number[]; // Measured relative proportions summing to 1.0
  colWidths: number[]; // Measured relative proportions summing to 1.0
  direction: TextDirection;
  cells: TableCellModel[];
}

export interface MeasuredBox {
  id: string;
  kind: PipelineElementKind | 'checkbox';
  /** Normalized [x, y, width, height] in 0..1000 relative to cleaned page */
  bbox: [number, number, number, number];
  checked?: boolean;
  svgPathData?: string;
  croppedImageDataUrl?: string;
  tableGrid?: {
    rows: number;
    cols: number;
    rowHeights: number[];
    colWidths: number[];
  };
}

export interface PageLayoutObject {
  id: string;
  type: LayoutObjectType;
  /** Pipeline canonical kind ('text'|'line'|'table'|'box'|'dotted_line'|'drawing'|'handwriting') */
  pipelineKind?: PipelineElementKind;
  /** Normalized coordinates (0 to 1000) relative to cleaned page width and height */
  x: number;
  y: number;
  width: number;
  height: number;
  content: string;
  lang?: 'ar' | 'fr' | 'en' | 'mixed';
  confidence: number; // Measured accuracy score (never self-assigned)
  uncertainTokens: string[];
  userCorrected?: boolean;
  alignment: TextAlignment;
  direction: TextDirection;
  fontProperties: FontProperties;
  borderProperties: BorderProperties;
  backgroundProperties: BackgroundProperties;
  zOrder: number;
  checked?: boolean; // For CHECKBOX
  tableStructure?: TableStructureModel; // For TABLE
  croppedImageDataUrl?: string; // Cleaned transparent crop for HANDWRITING or complex DRAWING
  svgPathData?: string; // Clean vector SVG path for simple DRAWING
  stampColor?: string;
}

export interface Point2D {
  x: number; // 0 to 1 normalized
  y: number; // 0 to 1 normalized
}

export interface PreprocessingConfig {
  perspectiveCorners: [Point2D, Point2D, Point2D, Point2D]; // TL, TR, BR, BL
  deskewAngleDeg: number; // Measured or refined angle (-15 to +15)
  rotationDeg: 0 | 90 | 180 | 270;
  autoOrientationDetect: boolean;
  splitTwoPageScan: boolean;
  removeShadows: boolean;
  shadowStrength: number; // 0 to 100
  removeBleedThrough: boolean;
  normalizeBackground: boolean;
  cropToPageBorder: boolean;
  keepHandwriting: boolean; // Step 4: Default = false (remove by inpainting), toggle = true (keep cleaned transparent crop)
  contrastBoost: number; // 0 to 100
  denoiseLevel: number; // 0 to 100
  sharpenAmount: number; // 0 to 100
}

export interface BlockMeasuredReport {
  objectId: string;
  objectType: LayoutObjectType;
  pipelineKind: PipelineElementKind;
  bbox: [number, number, number, number];
  /** Measured geometry error in millimeters on the 210x297mm A4 page */
  geometryErrorMm: number;
  /** Measured Intersection-over-Union (0.00 to 1.00) between source ink box and rebuilt ink box */
  iouScore: number;
  /** Measured text ink density & character fill accuracy (0.00 to 1.00), null for non-text */
  textAccuracy: number | null;
  /** Measured table grid line intersection alignment accuracy (0.00 to 1.00), null for non-table */
  tableAccuracy: number | null;
  /** True when geometryErrorMm > 1.8mm or iouScore < 0.78 or text/table accuracy < 0.80 */
  isPoor: boolean;
  poorReasonAr?: string;
}

export interface VerifyLoopIterationRecord {
  iteration: number;
  ssim: number; // 0.000 to 1.000
  linePositionErrorMm: number;
  meanBlockIoU: number; // 0.000 to 1.000
  combinedScore: number; // 0.000 to 1.000 (stops when >= 0.95)
  patchesApplied: number;
}

export interface ValidationMetric {
  labelAr: string;
  labelEn: string;
  score: number; // Measured value
  unit?: string;
  status: 'optimal' | 'adjusted' | 'warning';
  detailsAr: string;
}

export interface ReconstructionValidationReport {
  iterationsExecuted: number;
  /** Combined measured similarity (0..100 for display, computed from SSIM + line error + IoU) */
  overallVisualSimilarity: number;
  /** Raw 0..1 combined score used in Step 6d verify loop threshold (>= 0.95) */
  combinedScore01: number;
  ssimScore01: number;
  linePositionErrorMm: number;
  meanBlockIoU01: number;
  pageGeometryFidelity: number;
  textPositionFidelity: number;
  tableGeometryFidelity: number;
  arabicTypographyFidelity: number;
  lowConfidenceRegionsCount: number;
  adjustmentsLog: string[];
  metrics: ValidationMetric[];
  blockReports: BlockMeasuredReport[];
  iterationHistory: VerifyLoopIterationRecord[];
  diffHeatmapDataUrl?: string;
}

export interface ReconstructedPage {
  pageNumber: number;
  widthMm: number; // 210
  heightMm: number; // 297
  aspectRatio: number; // 210 / 297
  sourceImageDataUrl: string;
  /** Cleaned page with handwriting inpainted (default Step 4) */
  preprocessedImageDataUrl: string;
  /** Cleaned page with handwriting preserved */
  cleanedModeBImageDataUrl: string;
  reconstructedPreviewDataUrl?: string;
  direction: TextDirection;
  detectedOrientationDeg?: 0 | 90 | 180 | 270;
  measuredSkewDeg?: number;
  wasSplitFromTwoPageScan?: boolean;
  measuredBoxes?: MeasuredBox[];
  margins: {
    top: number;
    right: number;
    bottom: number;
    left: number;
  };
  objects: PageLayoutObject[];
  preprocessing: PreprocessingConfig;
  validationReport: ReconstructionValidationReport;
}

export interface SampleTestSpec {
  id: string;
  index: number;
  titleAr: string;
  titleEn: string;
  categoryAr: string;
  descriptionAr: string;
  simulatedIssueAr: string;
  pageCount: number;
}

export function createDefaultBorder(
  width = 0,
  style: 'solid' | 'dashed' | 'dotted' | 'double' | 'none' = 'none',
  color = '#1E293B'
): BorderProperties {
  const side: BorderSide = {
    width,
    style: width > 0 ? (style === 'none' ? 'solid' : style) : 'none',
    color,
  };
  return {
    top: { ...side },
    right: { ...side },
    bottom: { ...side },
    left: { ...side },
  };
}

export function createDefaultPreprocessingConfig(): PreprocessingConfig {
  return {
    perspectiveCorners: [
      { x: 0.0, y: 0.0 },
      { x: 1.0, y: 0.0 },
      { x: 1.0, y: 1.0 },
      { x: 0.0, y: 1.0 },
    ],
    deskewAngleDeg: 0,
    rotationDeg: 0,
    autoOrientationDetect: true,
    splitTwoPageScan: true,
    removeShadows: true,
    shadowStrength: 80,
    removeBleedThrough: true,
    normalizeBackground: true,
    cropToPageBorder: true,
    keepHandwriting: false, // Default = remove handwriting by inpainting
    contrastBoost: 45,
    denoiseLevel: 35,
    sharpenAmount: 50,
  };
}
