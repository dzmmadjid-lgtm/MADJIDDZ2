import { MeasuredBox } from '../models/DocumentModel';
import { DetectedHandwritingLayer, loadImageElement } from './ImagePreprocessor';

export interface PageMeasurementResult {
  measuredBoxes: MeasuredBox[];
  measuredMargins: {
    top: number;
    right: number;
    bottom: number;
    left: number;
  };
}

interface PixelSegment {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

/**
 * Step 2: MEASURE
 * Detects horizontal/vertical lines with morphological operations, dotted lines,
 * table grids (with exact measured rowHeights and colWidths), boxes, checkboxes,
 * drawings, and text-block bounding boxes.
 * Stores ALL coordinates as normalized values (0-1000 on each axis) relative to the cleaned page.
 */
export async function measureCleanedPageLayout(
  cleanedImageDataUrl: string,
  handwritingLayers: DetectedHandwritingLayer[] = []
): Promise<PageMeasurementResult> {
  const img = await loadImageElement(cleanedImageDataUrl);
  const w = 600;
  const h = 849; // Exact A4 proportion
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return {
      measuredBoxes: [],
      measuredMargins: { top: 50, right: 50, bottom: 50, left: 50 },
    };
  }

  ctx.drawImage(img, 0, 0, w, h);
  const { data } = ctx.getImageData(0, 0, w, h);

  // 1. Binary foreground ink map (1 = dark ink, 0 = background)
  const ink = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const luma = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
      if (luma < 185) {
        ink[y * w + x] = 1;
      }
    }
  }

  const measuredBoxes: MeasuredBox[] = [];

  // 2. Morphological Horizontal Line Detection (opening with horizontal kernel)
  const horizKernel = Math.max(24, Math.round(w * 0.055));
  const horizMap = new Uint8Array(w * h);
  const horizSegments: PixelSegment[] = [];

  for (let y = 4; y < h - 4; y++) {
    let runStart = -1;
    for (let x = 4; x < w - 4; x++) {
      // Allow 1px vertical tolerance for slight rasterization step
      const hasInk =
        ink[y * w + x] === 1 ||
        ink[(y - 1) * w + x] === 1 ||
        ink[(y + 1) * w + x] === 1;
      if (hasInk) {
        if (runStart < 0) runStart = x;
      } else if (runStart >= 0) {
        const runLen = x - runStart;
        if (runLen >= horizKernel) {
          horizSegments.push({ x0: runStart, y0: y, x1: x - 1, y1: y });
          for (let rx = runStart; rx < x; rx++) horizMap[y * w + rx] = 1;
        }
        runStart = -1;
      }
    }
    if (runStart >= 0 && w - 4 - runStart >= horizKernel) {
      horizSegments.push({ x0: runStart, y0: y, x1: w - 5, y1: y });
      for (let rx = runStart; rx < w - 4; rx++) horizMap[y * w + rx] = 1;
    }
  }

  // Merge vertically adjacent horizontal segments within 3px
  const mergedHoriz = mergeNearbySegments(horizSegments, true, 4);

  // 3. Morphological Vertical Line Detection (opening with vertical kernel)
  const vertKernel = Math.max(22, Math.round(h * 0.032));
  const vertMap = new Uint8Array(w * h);
  const vertSegments: PixelSegment[] = [];

  for (let x = 4; x < w - 4; x++) {
    let runStart = -1;
    for (let y = 4; y < h - 4; y++) {
      const hasInk =
        ink[y * w + x] === 1 ||
        ink[y * w + (x - 1)] === 1 ||
        ink[y * w + (x + 1)] === 1;
      if (hasInk) {
        if (runStart < 0) runStart = y;
      } else if (runStart >= 0) {
        const runLen = y - runStart;
        if (runLen >= vertKernel) {
          vertSegments.push({ x0: x, y0: runStart, x1: x, y1: y - 1 });
          for (let ry = runStart; ry < y; ry++) vertMap[ry * w + x] = 1;
        }
        runStart = -1;
      }
    }
    if (runStart >= 0 && h - 4 - runStart >= vertKernel) {
      vertSegments.push({ x0: x, y0: runStart, x1: x, y1: h - 5 });
      for (let ry = runStart; ry < h - 4; ry++) vertMap[ry * w + x] = 1;
    }
  }

  const mergedVert = mergeNearbySegments(vertSegments, false, 4);

  // 4. Detect Table Grids from intersecting Horizontal & Vertical segments
  const usedHoriz = new Uint8Array(mergedHoriz.length);
  const usedVert = new Uint8Array(mergedVert.length);

  for (let hi = 0; hi < mergedHoriz.length; hi++) {
    if (usedHoriz[hi]) continue;
    const seedH = mergedHoriz[hi];

    // Find all vertical lines intersecting seedH
    const groupH: number[] = [hi];
    const groupV: number[] = [];

    for (let vi = 0; vi < mergedVert.length; vi++) {
      const v = mergedVert[vi];
      if (
        v.x0 >= seedH.x0 - 6 &&
        v.x0 <= seedH.x1 + 6 &&
        seedH.y0 >= v.y0 - 6 &&
        seedH.y0 <= v.y1 + 6
      ) {
        groupV.push(vi);
      }
    }

    if (groupV.length >= 2) {
      // Expand to all horizontal lines intersecting any vertical line in groupV
      const vMinY = Math.min(...groupV.map((idx) => mergedVert[idx].y0));
      const vMaxY = Math.max(...groupV.map((idx) => mergedVert[idx].y1));
      const vMinX = Math.min(...groupV.map((idx) => mergedVert[idx].x0));
      const vMaxX = Math.max(...groupV.map((idx) => mergedVert[idx].x1));

      for (let hj = 0; hj < mergedHoriz.length; hj++) {
        if (hj === hi || usedHoriz[hj]) continue;
        const hCand = mergedHoriz[hj];
        if (
          hCand.y0 >= vMinY - 8 &&
          hCand.y0 <= vMaxY + 8 &&
          Math.max(hCand.x0, vMinX) < Math.min(hCand.x1, vMaxX)
        ) {
          groupH.push(hj);
        }
      }

      if (groupH.length >= 3 && groupV.length >= 3) {
        // Valid table grid detected!
        groupH.forEach((idx) => (usedHoriz[idx] = 1));
        groupV.forEach((idx) => (usedVert[idx] = 1));

        const yCoords = clusterSortedCoordinates(
          groupH.map((idx) => mergedHoriz[idx].y0),
          6
        );
        const xCoords = clusterSortedCoordinates(
          groupV.map((idx) => mergedVert[idx].x0),
          6
        );

        if (yCoords.length >= 2 && xCoords.length >= 2) {
          const tX = xCoords[0];
          const tY = yCoords[0];
          const tW = Math.max(20, xCoords[xCoords.length - 1] - tX);
          const tH = Math.max(20, yCoords[yCoords.length - 1] - tY);

          const rowHeights: number[] = [];
          for (let r = 0; r < yCoords.length - 1; r++) {
            rowHeights.push(
              Math.round(((yCoords[r + 1] - yCoords[r]) / tH) * 1000) / 1000
            );
          }

          const colWidths: number[] = [];
          for (let c = 0; c < xCoords.length - 1; c++) {
            colWidths.push(
              Math.round(((xCoords[c + 1] - xCoords[c]) / tW) * 1000) / 1000
            );
          }

          measuredBoxes.push({
            id: `measured_table_${measuredBoxes.length + 1}`,
            kind: 'table',
            bbox: [
              Math.round((tX / w) * 1000),
              Math.round((tY / h) * 1000),
              Math.round((tW / w) * 1000),
              Math.round((tH / h) * 1000),
            ],
            tableGrid: {
              rows: rowHeights.length,
              cols: colWidths.length,
              rowHeights,
              colWidths,
            },
          });
        }
      } else if (groupH.length === 2 && groupV.length === 2) {
        // Framed rectangular box (2 horizontal + 2 vertical perimeter lines)
        groupH.forEach((idx) => (usedHoriz[idx] = 1));
        groupV.forEach((idx) => (usedVert[idx] = 1));

        const bX = Math.min(...groupV.map((idx) => mergedVert[idx].x0));
        const bY = Math.min(...groupH.map((idx) => mergedHoriz[idx].y0));
        const bW = Math.max(...groupV.map((idx) => mergedVert[idx].x1)) - bX;
        const bH = Math.max(...groupH.map((idx) => mergedHoriz[idx].y1)) - bY;

        const normW = Math.round((bW / w) * 1000);
        const normH = Math.round((bH / h) * 1000);

        if (normW >= 10 && normW <= 34 && normH >= 10 && normH <= 34) {
          // Measured Checkbox!
          const isChecked = measureInteriorInkRatio(ink, w, bX + 3, bY + 3, bW - 6, bH - 6) > 0.12;
          measuredBoxes.push({
            id: `measured_checkbox_${measuredBoxes.length + 1}`,
            kind: 'checkbox',
            bbox: [
              Math.round((bX / w) * 1000),
              Math.round((bY / h) * 1000),
              normW,
              normH,
            ],
            checked: isChecked,
          });
        } else if (normW > 34 && normH > 18) {
          measuredBoxes.push({
            id: `measured_box_${measuredBoxes.length + 1}`,
            kind: 'box',
            bbox: [
              Math.round((bX / w) * 1000),
              Math.round((bY / h) * 1000),
              normW,
              normH,
            ],
          });
        }
      }
    }
  }

  // 5. Remaining standalone horizontal lines -> 'line'
  for (let hi = 0; hi < mergedHoriz.length; hi++) {
    if (usedHoriz[hi]) continue;
    const seg = mergedHoriz[hi];
    const normW = Math.round(((seg.x1 - seg.x0) / w) * 1000);
    if (normW >= 60) {
      measuredBoxes.push({
        id: `measured_line_${measuredBoxes.length + 1}`,
        kind: 'line',
        bbox: [
          Math.round((seg.x0 / w) * 1000),
          Math.round((seg.y0 / h) * 1000),
          normW,
          Math.max(2, Math.round(((seg.y1 - seg.y0 + 2) / h) * 1000)),
        ],
      });
    }
  }

  // 6. Detect Dotted / Dashed Fill Lines ('dotted_line')
  for (let y = 12; y < h - 12; y += 3) {
    let transitions = 0;
    let firstX = -1;
    let lastX = -1;
    let prevInk = 0;
    let shortRunCount = 0;
    let runLen = 0;

    for (let x = 15; x < w - 15; x++) {
      const cur = ink[y * w + x] || ink[(y + 1) * w + x] ? 1 : 0;
      if (cur !== prevInk) {
        transitions++;
        if (cur === 1) {
          if (firstX < 0) firstX = x;
          runLen = 1;
        } else {
          lastX = x;
          if (runLen >= 1 && runLen <= 6) shortRunCount++;
        }
        prevInk = cur;
      } else if (cur === 1) {
        runLen++;
      }
    }

    const spanPx = lastX - firstX;
    if (transitions >= 22 && shortRunCount >= 10 && spanPx >= w * 0.14) {
      const normX = Math.round((firstX / w) * 1000);
      const normY = Math.round((y / h) * 1000);
      const normW = Math.round((spanPx / w) * 1000);
      const alreadyExists = measuredBoxes.some(
        (b) => b.kind === 'dotted_line' && Math.abs(b.bbox[1] - normY) < 12
      );
      if (!alreadyExists) {
        measuredBoxes.push({
          id: `measured_dotted_${measuredBoxes.length + 1}`,
          kind: 'dotted_line',
          bbox: [normX, normY, normW, 4],
        });
      }
    }
  }

  // 7. Detect Text-Block Bounding Boxes via Run-Length Smoothing (RLSA)
  // Exclude regions already covered by tables
  const rowTextInk = new Float32Array(h);
  for (let y = 10; y < h - 10; y++) {
    let count = 0;
    for (let x = 12; x < w - 12; x++) {
      if (ink[y * w + x] && !horizMap[y * w + x] && !vertMap[y * w + x]) {
        count++;
      }
    }
    rowTextInk[y] = count / w;
  }

  let inBand = false;
  let bandStart = 0;
  for (let y = 10; y < h - 10; y++) {
    if (rowTextInk[y] > 0.014) {
      if (!inBand) {
        inBand = true;
        bandStart = y;
      }
    } else if (inBand) {
      const bandH = y - bandStart;
      if (bandH >= 6) {
        // Measure horizontal extent [minX..maxX] inside this band
        let minX = w;
        let maxX = 0;
        for (let by = bandStart; by < y; by++) {
          for (let bx = 10; bx < w - 10; bx++) {
            if (ink[by * w + bx]) {
              if (bx < minX) minX = bx;
              if (bx > maxX) maxX = bx;
            }
          }
        }
        if (maxX > minX + 12) {
          const normX = Math.round((minX / w) * 1000);
          const normY = Math.round((bandStart / h) * 1000);
          const normW = Math.round(((maxX - minX) / w) * 1000);
          const normH = Math.max(14, Math.round((bandH / h) * 1000));

          const insideTable = measuredBoxes.some(
            (b) =>
              b.kind === 'table' &&
              normY >= b.bbox[1] - 6 &&
              normY + normH <= b.bbox[1] + b.bbox[3] + 6
          );

          if (!insideTable) {
            measuredBoxes.push({
              id: `measured_text_${measuredBoxes.length + 1}`,
              kind: 'text',
              bbox: [normX, normY, normW, normH],
            });
          }
        }
      }
      inBand = false;
    }
  }

  // 8. Append measured handwriting layers from Step 4
  for (const hw of handwritingLayers) {
    measuredBoxes.push({
      id: hw.id,
      kind: 'handwriting',
      bbox: hw.bbox,
      croppedImageDataUrl: hw.croppedTransparentDataUrl,
    });
  }

  // 9. Compute exact measured page margins in 0..1000 units from all detected bboxes
  let minTop = 1000;
  let minLeft = 1000;
  let maxRight = 0;
  let maxBottom = 0;

  for (const mb of measuredBoxes) {
    const [x, y, bw, bh] = mb.bbox;
    if (y < minTop) minTop = y;
    if (x < minLeft) minLeft = x;
    if (x + bw > maxRight) maxRight = x + bw;
    if (y + bh > maxBottom) maxBottom = y + bh;
  }

  const measuredMargins =
    measuredBoxes.length > 0
      ? {
          top: Math.max(10, Math.min(200, minTop)),
          right: Math.max(10, Math.min(200, 1000 - maxRight)),
          bottom: Math.max(10, Math.min(200, 1000 - maxBottom)),
          left: Math.max(10, Math.min(200, minLeft)),
        }
      : { top: 45, right: 55, bottom: 45, left: 55 };

  return {
    measuredBoxes,
    measuredMargins,
  };
}

function mergeNearbySegments(
  segments: PixelSegment[],
  isHorizontal: boolean,
  tolerancePx: number
): PixelSegment[] {
  if (segments.length === 0) return [];
  const sorted = [...segments].sort((a, b) =>
    isHorizontal ? a.y0 - b.y0 || a.x0 - b.x0 : a.x0 - b.x0 || a.y0 - b.y0
  );

  const merged: PixelSegment[] = [sorted[0]];
  for (let i = 1; i < sorted.length; i++) {
    const cur = sorted[i];
    const last = merged[merged.length - 1];
    if (isHorizontal) {
      if (
        Math.abs(cur.y0 - last.y0) <= tolerancePx &&
        cur.x0 <= last.x1 + tolerancePx * 2
      ) {
        last.x0 = Math.min(last.x0, cur.x0);
        last.x1 = Math.max(last.x1, cur.x1);
        last.y1 = Math.max(last.y1, cur.y1);
      } else {
        merged.push({ ...cur });
      }
    } else {
      if (
        Math.abs(cur.x0 - last.x0) <= tolerancePx &&
        cur.y0 <= last.y1 + tolerancePx * 2
      ) {
        last.y0 = Math.min(last.y0, cur.y0);
        last.y1 = Math.max(last.y1, cur.y1);
        last.x1 = Math.max(last.x1, cur.x1);
      } else {
        merged.push({ ...cur });
      }
    }
  }
  return merged;
}

function clusterSortedCoordinates(coords: number[], minGap: number): number[] {
  if (coords.length === 0) return [];
  const sorted = [...coords].sort((a, b) => a - b);
  const clusters: number[][] = [[sorted[0]]];
  for (let i = 1; i < sorted.length; i++) {
    const prevCluster = clusters[clusters.length - 1];
    if (sorted[i] - prevCluster[prevCluster.length - 1] <= minGap) {
      prevCluster.push(sorted[i]);
    } else {
      clusters.push([sorted[i]]);
    }
  }
  return clusters.map((c) => Math.round(c.reduce((a, b) => a + b, 0) / c.length));
}

function measureInteriorInkRatio(
  ink: Uint8Array,
  strideW: number,
  x0: number,
  y0: number,
  w: number,
  h: number
): number {
  if (w <= 0 || h <= 0) return 0;
  let count = 0;
  for (let y = y0; y < y0 + h; y++) {
    for (let x = x0; x < x0 + w; x++) {
      if (ink[y * strideW + x]) count++;
    }
  }
  return count / (w * h);
}
