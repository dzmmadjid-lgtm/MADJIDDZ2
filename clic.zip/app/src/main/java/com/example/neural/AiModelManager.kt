package com.example.neural

import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

/**
 * Diagnostic state of the Neural Audio Source Separation model.
 */
data class ModelDiagnosticInfo(
    val modelName: String = "Spleeter 2-Stems Deep U-Net",
    val modelVersion: String = "2-Stems Stereo v1.0",
    val vocalsModelSizeMb: Float = 37.5f,
    val accompanimentModelSizeMb: Float = 37.5f,
    val isVocalsModelLoaded: Boolean = false,
    val isAccompanimentModelLoaded: Boolean = false,
    val isLoading: Boolean = false,
    val loadingProgressText: String = "",
    val executionEngine: String = "ONNX Runtime Android v1.20.0 (ARM64/NEON/CPU)",
    val inputShape: String = "[2, NumSplits, 512, 1024] (Stereo STFT Magnitudes)",
    val outputShape: String = "[2, NumSplits, 512, 1024] (Predicted Stem Spectra)",
    val isNeuralInferenceActive: Boolean = false,
    val vocalsModelFile: String = "",
    val vocalsSha256: String = "",
    val lastError: String? = null
)

/**
 * Manages the loading, extraction, and ONNX Runtime Sessions for trained deep learning models.
 */
class AiModelManager(private val context: Context) {

    private val tag = "AiModelManager"

    private val _modelInfo = MutableStateFlow(ModelDiagnosticInfo())
    val modelInfo: StateFlow<ModelDiagnosticInfo> = _modelInfo.asStateFlow()

    private var ortEnv: OrtEnvironment? = null
    var vocalsSession: OrtSession? = null
        private set
    var accompanimentSession: OrtSession? = null
        private set

    /**
     * Initializes ONNX Runtime and loads the deep neural network models.
     */
    suspend fun initializeModels(forceReload: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        if (!forceReload && vocalsSession != null && accompanimentSession != null) {
            return@withContext true
        }

        try {
            _modelInfo.value = _modelInfo.value.copy(
                isLoading = true,
                loadingProgressText = "جاري تهيئة نماذج الذكاء الاصطناعي (75 MB)..."
            )
            Log.i(tag, "Initializing ONNX Runtime Environment...")
            val env = ortEnv ?: OrtEnvironment.getEnvironment().also { ortEnv = it }

            val modelsDir = File(context.filesDir, "models")
            if (!modelsDir.exists()) {
                modelsDir.mkdirs()
            }

            val vocalsDest = File(modelsDir, "vocals.onnx")
            val accompanimentDest = File(modelsDir, "accompaniment.onnx")

            _modelInfo.value = _modelInfo.value.copy(
                loadingProgressText = "التحقق من ملفات الأوزان العصبية وتجهيزها..."
            )
            // Unpack models from APK assets to app files storage or download if missing
            extractOrDownloadModel("models/vocals.onnx", vocalsDest, expectedMinBytes = 35_000_000L, displayName = "صوت المغني (Vocals)")
            extractOrDownloadModel("models/accompaniment.onnx", accompanimentDest, expectedMinBytes = 35_000_000L, displayName = "الموسيقى (Accompaniment)")

            val sessionOptions = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(2)
                setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            }

            _modelInfo.value = _modelInfo.value.copy(
                loadingProgressText = "تحميل جلسة استدلال الغناء (Vocals U-Net)..."
            )
            Log.i(tag, "Loading Vocals ONNX Session from ${vocalsDest.absolutePath} (${vocalsDest.length()} bytes)...")
            vocalsSession = env.createSession(vocalsDest.absolutePath, sessionOptions)

            _modelInfo.value = _modelInfo.value.copy(
                loadingProgressText = "تحميل جلسة استدلال الموسيقى (Accompaniment U-Net)..."
            )
            Log.i(tag, "Loading Accompaniment ONNX Session from ${accompanimentDest.absolutePath} (${accompanimentDest.length()} bytes)...")
            accompanimentSession = env.createSession(accompanimentDest.absolutePath, sessionOptions)

            val vocalsSha = computeSha256(vocalsDest)
            val vocalsSizeMb = vocalsDest.length().toFloat() / (1024f * 1024f)
            val accompSizeMb = accompanimentDest.length().toFloat() / (1024f * 1024f)

            _modelInfo.value = ModelDiagnosticInfo(
                modelName = "Spleeter 2-Stems Deep U-Net (Deezer / ONNX)",
                modelVersion = "2-Stems Stereo v1.0",
                vocalsModelSizeMb = vocalsSizeMb,
                accompanimentModelSizeMb = accompSizeMb,
                isVocalsModelLoaded = true,
                isAccompanimentModelLoaded = true,
                isLoading = false,
                loadingProgressText = "",
                executionEngine = "ONNX Runtime Android v1.20.0 (ARM64/NEON/CPU)",
                inputShape = "[2, NumSplits, 512, 1024] (Stereo STFT Magnitudes)",
                outputShape = "[2, NumSplits, 512, 1024] (Predicted Stem Spectra)",
                isNeuralInferenceActive = true,
                vocalsModelFile = vocalsDest.name,
                vocalsSha256 = vocalsSha,
                lastError = null
            )

            Log.i(tag, "Deep Neural Source Separation Models successfully loaded and verified!")
            true
        } catch (e: Exception) {
            Log.e(tag, "Error loading ONNX models: ${e.message}", e)
            val userFriendlyError = when {
                e.message?.contains("vocals.onnx") == true || e.message?.contains("accompaniment.onnx") == true ->
                    "تعذر العثور على أوزان النموذج محلياً. يرجى الاتصال بالإنترنت والنقر على زر التحديث 🔄 لتنزيلها (75 MB)."
                else -> e.localizedMessage ?: e.message ?: "خطأ في تهيئة نموذج الذكاء الاصطناعي"
            }
            _modelInfo.value = _modelInfo.value.copy(
                isVocalsModelLoaded = false,
                isAccompanimentModelLoaded = false,
                isNeuralInferenceActive = false,
                isLoading = false,
                loadingProgressText = "",
                lastError = userFriendlyError
            )
            false
        }
    }

    private fun extractOrDownloadModel(assetPath: String, destination: File, expectedMinBytes: Long, displayName: String) {
        if (destination.exists() && destination.length() >= expectedMinBytes) {
            Log.d(tag, "Model ${destination.name} already ready at ${destination.absolutePath} (${destination.length()} bytes)")
            return
        }

        var extractedFromAssets = false
        try {
            Log.i(tag, "Attempting to extract $assetPath from APK assets...")
            _modelInfo.value = _modelInfo.value.copy(
                loadingProgressText = "استخراج $displayName من أصول التطبيق..."
            )
            context.assets.open(assetPath).use { input ->
                val tempDest = File(destination.parentFile, "${destination.name}.tmp")
                FileOutputStream(tempDest).use { output ->
                    val buffer = ByteArray(128 * 1024)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                    }
                }
                if (tempDest.length() >= expectedMinBytes) {
                    tempDest.renameTo(destination)
                    extractedFromAssets = true
                    Log.i(tag, "Successfully extracted $displayName from APK assets (${destination.length()} bytes)")
                } else {
                    tempDest.delete()
                }
            }
        } catch (e: Exception) {
            Log.w(tag, "Asset $assetPath not available in APK: ${e.message}. Attempting network download fallback...")
        }

        if (!extractedFromAssets && (!destination.exists() || destination.length() < expectedMinBytes)) {
            downloadModelFromMirror(destination, expectedMinBytes, displayName)
        }
    }

    private fun downloadModelFromMirror(destination: File, expectedMinBytes: Long, displayName: String) {
        val modelUrl = "https://huggingface.co/csukuangfj/sherpa-onnx-spleeter-2stems/resolve/main/${destination.name}"
        Log.i(tag, "Downloading $displayName from $modelUrl...")
        _modelInfo.value = _modelInfo.value.copy(
            loadingProgressText = "جاري تنزيل أوزان $displayName (37 MB)..."
        )
        val tempDest = File(destination.parentFile, "${destination.name}.download.tmp")
        try {
            val url = java.net.URL(modelUrl)
            val connection = url.openConnection() as java.net.HttpURLConnection
            connection.instanceFollowRedirects = true
            connection.connectTimeout = 15000
            connection.readTimeout = 40000
            connection.connect()

            val responseCode = connection.responseCode
            val finalUrl = if (responseCode in 300..399) connection.getHeaderField("Location") else null
            val inputStream = if (finalUrl != null) {
                val redirectUrl = java.net.URL(finalUrl)
                val redirectConn = redirectUrl.openConnection() as java.net.HttpURLConnection
                redirectConn.connectTimeout = 15000
                redirectConn.readTimeout = 40000
                redirectConn.inputStream
            } else {
                connection.inputStream
            }

            inputStream.use { input ->
                FileOutputStream(tempDest).use { output ->
                    val buffer = ByteArray(128 * 1024)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                    }
                }
            }

            if (tempDest.length() >= expectedMinBytes) {
                if (destination.exists()) destination.delete()
                tempDest.renameTo(destination)
                Log.i(tag, "Successfully downloaded $displayName (${destination.length()} bytes)")
            } else {
                tempDest.delete()
                throw java.io.IOException("حجم الملف المنزّل أصغر من المتوقع (${tempDest.length()} بايت)")
            }
        } catch (e: Exception) {
            tempDest.delete()
            Log.e(tag, "Download failed for $displayName: ${e.message}", e)
            throw java.io.IOException("فشل تنزيل ملف $displayName: ${e.localizedMessage ?: e.message}")
        }
    }

    private fun computeSha256(file: File): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { fis ->
                val buffer = ByteArray(16 * 1024)
                var read: Int
                while (fis.read(buffer).also { read = it } != -1) {
                    digest.update(buffer, 0, read)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "Unavailable: ${e.message}"
        }
    }

    fun release() {
        try {
            vocalsSession?.close()
            accompanimentSession?.close()
            ortEnv?.close()
        } catch (e: Exception) {
            Log.w(tag, "Error releasing ORT resources: ${e.message}")
        } finally {
            vocalsSession = null
            accompanimentSession = null
            ortEnv = null
        }
    }
}
