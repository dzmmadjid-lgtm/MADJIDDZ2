package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.scanner.DiscoveredScannerDevice
import com.example.core.scanner.ScanJobOptions
import com.example.core.scanner.ScannerManager
import com.example.core.scanner.TransportType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class ScannerViewModel(application: Application) : AndroidViewModel(application) {

    private val scannerManager = ScannerManager(application)

    private val _discoveredScanners = MutableStateFlow<List<DiscoveredScannerDevice>>(emptyList())
    val discoveredScanners: StateFlow<List<DiscoveredScannerDevice>> = _discoveredScanners.asStateFlow()

    private val _selectedScanner = MutableStateFlow<DiscoveredScannerDevice?>(null)
    val selectedScanner: StateFlow<DiscoveredScannerDevice?> = _selectedScanner.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _scanStatusLogs = MutableStateFlow<List<String>>(emptyList())
    val scanStatusLogs: StateFlow<List<String>> = _scanStatusLogs.asStateFlow()

    private val _scanError = MutableStateFlow<String?>(null)
    val scanError: StateFlow<String?> = _scanError.asStateFlow()

    private val _scannedBitmap = MutableStateFlow<Bitmap?>(null)
    val scannedBitmap: StateFlow<Bitmap?> = _scannedBitmap.asStateFlow()

    private val _editedBitmap = MutableStateFlow<Bitmap?>(null)
    val editedBitmap: StateFlow<Bitmap?> = _editedBitmap.asStateFlow()

    private val _savedScanPages = MutableStateFlow<List<Bitmap>>(emptyList())
    val savedScanPages: StateFlow<List<Bitmap>> = _savedScanPages.asStateFlow()

    private val _lastSavedImageFile = MutableStateFlow<File?>(null)
    val lastSavedImageFile: StateFlow<File?> = _lastSavedImageFile.asStateFlow()

    private val _lastGeneratedPdfFile = MutableStateFlow<File?>(null)
    val lastGeneratedPdfFile: StateFlow<File?> = _lastGeneratedPdfFile.asStateFlow()

        private fun appendScanLog(msg: String) {
        val current = _scanStatusLogs.value.toMutableList()
        current.add(msg)
        _scanStatusLogs.value = current
    }

    fun refreshUsbScanners() {
        viewModelScope.launch(Dispatchers.IO) {
            val usbDevices: List<DiscoveredScannerDevice> = scannerManager.discoverUsbScanners()
            val existingWifi: List<DiscoveredScannerDevice> = _discoveredScanners.value.filter {
                it.transportType == TransportType.WIFI_ESCL || it.transportType == TransportType.WIFI_MFNP
            }
            val combined: List<DiscoveredScannerDevice> = usbDevices + existingWifi
            _discoveredScanners.value = combined

            if (_selectedScanner.value == null && combined.isNotEmpty()) {
                _selectedScanner.value = combined.firstOrNull {
                    it.vendorId == ScannerManager.CANON_VENDOR_ID
                } ?: combined.first()
            } else if (_selectedScanner.value != null) {
                val updated = combined.find { it.id == _selectedScanner.value?.id }
                if (updated != null) {
                    _selectedScanner.value = updated
                }
            }

            if (usbDevices.isEmpty()) {
                appendScanLog("[USB] لم يتم العثور على أجهزة USB متصلة حالياً. تأكد من توصيل كابل USB OTG بجهاز Canon MF440.")
            } else {
                usbDevices.forEach { dev ->
                    val vidPid = String.format("0x%04X:0x%04X", dev.vendorId, dev.productId)
                    appendScanLog("[USB] تم اكتشاف: ${dev.name} ($vidPid) | النقل: ${dev.transportType.name}")
                }
            }
        }
    }

    fun selectScannerDevice(device: DiscoveredScannerDevice) {
        _selectedScanner.value = device
        _scanError.value = null
        appendScanLog("[Device] تم اختيار الماسح: ${device.name} (${device.transportType.name})")
    }

    fun requestScannerUsbPermission(device: DiscoveredScannerDevice) {
        val usbDevice = device.usbDevice ?: return
        appendScanLog("[USB] جاري طلب صلاحية الوصول إلى USB لجهاز ${device.name}...")
        scannerManager.requestUsbPermission(usbDevice) { granted ->
            refreshUsbScanners()
            if (granted) {
                val intfSummary = device.interfaces.joinToString { "Intf #${it.id}: ${it.classDescription}" }
                appendScanLog("[USB] تم منح صلاحية USB بنجاح! الواجهات المكتشفة: $intfSummary")
            } else {
                _scanError.value = "تم رفض صلاحية الوصول إلى USB من نظام Android."
                appendScanLog("[USB] خطأ: تم رفض صلاحية USB.")
            }
        }
    }

    fun probeNetworkScanner(ipOrHost: String) {
        viewModelScope.launch(Dispatchers.IO) {
            appendScanLog("[Wi-Fi eSCL/MFNP] جاري فحص الماسح الشبكي على العنوان: $ipOrHost ...")
            val netDevice = scannerManager.probeNetworkScanner(ipOrHost)
            if (netDevice != null) {
                val filtered = _discoveredScanners.value.filterNot { it.id == netDevice.id }
                val updated: List<DiscoveredScannerDevice> = filtered + netDevice
                _discoveredScanners.value = updated
                _selectedScanner.value = netDevice
                _scanError.value = null
                appendScanLog("[Wi-Fi] تم الاتصال بماسح Canon بنجاح: ${netDevice.name} (${netDevice.serialOrAddress})")
            } else {
                _scanError.value = "تعذر العثور على خدمة مسح eSCL/AirScan أو MFNP على العنوان $ipOrHost. تأكد من أن الهاتف والماسح على نفس الشبكة."
                appendScanLog("[Wi-Fi] فشل الاتصال بالعنوان $ipOrHost.")
            }
        }
    }

    fun executeHardwareScan(options: ScanJobOptions) {
        val device = _selectedScanner.value
        if (device == null) {
            _scanError.value = "يرجى اختيار جهاز Canon Scanner أولاً (عبر USB أو Wi-Fi)."
            return
        }
        if (_isScanning.value) return

        _isScanning.value = true
        _scanError.value = null
        appendScanLog(">>> بدء جلسة مسح حقيقية على ${device.name} (${options.resolutionDpi} DPI, ${options.colorMode}, ${options.source})...")

        viewModelScope.launch(Dispatchers.IO) {
            val result = scannerManager.executeScan(
                scanner = device,
                options = options,
                onProgress = { statusMsg ->
                    appendScanLog(statusMsg)
                }
            )
            _isScanning.value = false
            if (result.success && result.bitmap != null) {
                val bmp: Bitmap = result.bitmap
                _scannedBitmap.value = bmp
                _editedBitmap.value = bmp
                _lastSavedImageFile.value = result.rawFile
                appendScanLog("<<< اكتملت عملية المسح بنجاح عبر ${result.protocolUsed}! أبعاد الصورة المستلمة: ${bmp.width}x${bmp.height} بكسل.")
            } else {
                val err = result.errorReason ?: "حدث خطأ غير معروف أثناء المسح."
                _scanError.value = err
                appendScanLog("<<< فشل المسح: $err")
            }
        }
    }

    fun applyScanImageTransform(
        rotationDeg: Float,
        flipH: Boolean,
        flipV: Boolean,
        cropL: Float,
        cropT: Float,
        cropR: Float,
        cropB: Float,
        contrast: Float
    ) {
        val sourceBmp = _scannedBitmap.value ?: return
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val transformed = scannerManager.transformScannedBitmap(
                    source = sourceBmp,
                    rotationDegrees = rotationDeg,
                    flipHorizontal = flipH,
                    flipVertical = flipV,
                    cropLeftRatio = cropL,
                    cropTopRatio = cropT,
                    cropRightRatio = cropR,
                    cropBottomRatio = cropB,
                    contrastBoost = contrast
                )
                _editedBitmap.value = transformed
                appendScanLog("[Editor] تم تطبيق التعديلات على الصورة الممسوحة (${transformed.width}x${transformed.height} px).")
            } catch (e: Exception) {
                _scanError.value = "فشل تعديل الصورة: ${e.message}"
            }
        }
    }

    fun resetEditedScanBitmap() {
        _editedBitmap.value = _scannedBitmap.value
        appendScanLog("[Editor] تمت استعادة الصورة الأصلية الممسوحة.")
    }

    fun saveEditedScanImage() {
        val bmp = _editedBitmap.value ?: _scannedBitmap.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val savedFile = scannerManager.saveRawScanToDisk(bmp, "canon_mf440_edited")
                _lastSavedImageFile.value = savedFile
                appendScanLog("[Storage] تم حفظ الصورة المعدلة في الهاتف: ${savedFile.absolutePath}")
            } catch (e: Exception) {
                _scanError.value = "فشل حفظ الصورة: ${e.message}"
            }
        }
    }

    fun addCurrentScanPageToPdfQueue() {
        val bmp = _editedBitmap.value ?: _scannedBitmap.value ?: return
        val pages = _savedScanPages.value.toMutableList()
        pages.add(bmp)
        _savedScanPages.value = pages
        appendScanLog("[PDF Queue] تمت إضافة الصفحة إلى قائمة بناء الـ PDF (إجمالي الصفحات: ${pages.size}).")
    }

    fun buildPdfFromScannedPages(outputFileName: String = "Canon_MF440_Scan.pdf") {
        val currentBmp = _editedBitmap.value ?: _scannedBitmap.value
        val pagesToBuild: List<Bitmap> = if (_savedScanPages.value.isNotEmpty()) {
            _savedScanPages.value
        } else if (currentBmp != null) {
            listOf(currentBmp)
        } else {
            _scanError.value = "لا توجد صور ممسوحة لإنشاء ملف PDF."
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            try {
                appendScanLog("[PDF Builder] جاري إعادة بناء ملف PDF ($outputFileName) من ${pagesToBuild.size} صفحة ممسوحة...")
                val pdfFile = scannerManager.generatePdfFromScannedBitmaps(
                    pages = pagesToBuild,
                    outputPdfName = outputFileName
                )
                _lastGeneratedPdfFile.value = pdfFile
                _scanError.value = null
                appendScanLog("[PDF Builder] تم إنشاء ملف PDF بنجاح: ${pdfFile.absolutePath} (${pdfFile.length() / 1024} KB)")
            } catch (e: Exception) {
                _scanError.value = "فشل إنشاء ملف PDF: ${e.message}"
                appendScanLog("[PDF Builder] خطأ: ${e.message}")
            }
        }
    }

    fun clearSavedPdfPages() {
        _savedScanPages.value = emptyList()
        appendScanLog("[PDF Builder] تم تفريغ قائمة صفحات PDF المؤقتة.")
    }
}
