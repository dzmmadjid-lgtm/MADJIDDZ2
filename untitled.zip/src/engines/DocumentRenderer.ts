import {
  BorderProperties,
  BorderSide,
  PageLayoutObject,
  TableStructureModel,
  TextAlignment,
  TextDirection,
} from '../models/DocumentModel';
import { loadImageElement } from './ImagePreprocessor';

export interface RenderPageOptions {
  widthPx: number;
  heightPx: number;
  keepHandwriting?: boolean;
  highlightSelectedId?: string | null;
  highlightLowConfidence?: boolean;
  poorBlockIds?: Set<string>;
  showBoundingBoxes?: boolean;
  /** Optional simulated camera/scanner artifacts when generating source test photos */
  simulateScannedPhoto?: {
    angleDeg: number;
    noiseLevel: number; // 0 to 1
    shadowStrength: number; // 0 to 1
    warmPaperTint?: boolean;
    includeHandwritingInSource?: boolean;
    bleedThroughText?: string;
  };
}

/**
 * Converts any Eastern Arabic-Indic (٠-٩) or Extended Arabic-Indic (۰-۹) digits
 * into Western European-style Arabic numerals (0123456789).
 */
export function toWesternDigits(input: string): string {
  if (!input) return '';
  return input
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0));
}

function drawBorderSide(
  ctx: CanvasRenderingContext2D,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  side: BorderSide,
  scaleFactor: number
) {
  if (!side || side.style === 'none' || side.width <= 0) return;

  ctx.save();
  ctx.strokeStyle = side.color || '#0F172A';
  ctx.lineWidth = Math.max(0.8, side.width * scaleFactor);
  ctx.lineCap = side.style === 'dotted' ? 'round' : 'butt';

  if (side.style === 'dashed') {
    ctx.setLineDash([5 * scaleFactor, 3.5 * scaleFactor]);
  } else if (side.style === 'dotted') {
    ctx.setLineDash([1.5 * scaleFactor, 3.2 * scaleFactor]);
  } else {
    ctx.setLineDash([]);
  }

  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  if (side.style === 'double') {
    const offset = 2.5 * scaleFactor;
    const isHorizontal = Math.abs(y2 - y1) < Math.abs(x2 - x1);
    ctx.beginPath();
    if (isHorizontal) {
      ctx.moveTo(x1, y1 + offset);
      ctx.lineTo(x2, y2 + offset);
    } else {
      ctx.moveTo(x1 + offset, y1);
      ctx.lineTo(x2 + offset, y2);
    }
    ctx.stroke();
  }

  ctx.restore();
}

function drawBoxBorders(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  borders: BorderProperties,
  scaleFactor: number
) {
  drawBorderSide(ctx, x, y, x + w, y, borders.top, scaleFactor);
  drawBorderSide(ctx, x + w, y, x + w, y + h, borders.right, scaleFactor);
  drawBorderSide(ctx, x, y + h, x + w, y + h, borders.bottom, scaleFactor);
  drawBorderSide(ctx, x, y, x, y + h, borders.left, scaleFactor);
}

function wrapTextLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const rawParagraphs = text.split('\n');
  const lines: string[] = [];

  for (const para of rawParagraphs) {
    if (!para.trim()) {
      lines.push('');
      continue;
    }
    const words = para.split(/\s+/);
    let currentLine = words[0] || '';

    for (let i = 1; i < words.length; i++) {
      const candidate = `${currentLine} ${words[i]}`;
      const width = ctx.measureText(candidate).width;
      if (width <= maxWidth || maxWidth <= 20) {
        currentLine = candidate;
      } else {
        lines.push(currentLine);
        currentLine = words[i];
      }
    }
    lines.push(currentLine);
  }

  return lines;
}

/**
 * Draws text fitted to its measured bounding box height/width.
 * Any residual typed dot sequences (".....") are stripped and drawn as real vector dotted lines.
 */
function drawMultilineText(
  ctx: CanvasRenderingContext2D,
  rawText: string,
  x: number,
  y: number,
  w: number,
  h: number,
  options: {
    fontFamily: string;
    fontSizePx: number;
    fontWeight: 'normal' | 'bold';
    fontStyle?: 'normal' | 'italic';
    color: string;
    alignment: TextAlignment;
    direction: TextDirection;
    lineHeight: number;
    verticalAlignment?: 'top' | 'middle' | 'bottom';
    paddingPx?: number;
  },
  scaleFactor: number
) {
  if (!rawText) return;
  const text = toWesternDigits(rawText);

  ctx.save();
  const pad = options.paddingPx ?? 4;
  const innerX = x + pad;
  const innerY = y + pad;
  const innerW = Math.max(10, w - pad * 2);
  const innerH = Math.max(10, h - pad * 2);

  ctx.direction = options.direction;
  ctx.fillStyle = options.color || '#0F172A';
  ctx.textBaseline = 'top';

  const stylePrefix = options.fontStyle === 'italic' ? 'italic ' : '';
  let activeFontSize = Math.max(6.5, options.fontSizePx);
  const minFontSize = 6.5;
  let lines: string[] = [];

  while (activeFontSize >= minFontSize) {
    ctx.font = `${stylePrefix}${options.fontWeight} ${Math.round(activeFontSize * 10) / 10}px "${options.fontFamily}", "Cairo", "Amiri", sans-serif`;
    lines = wrapTextLines(ctx, text.replace(/[.…]{5,}/g, '            '), innerW);
    const totalH = lines.length * activeFontSize * (options.lineHeight || 1.35);
    if (totalH <= innerH + 2 || activeFontSize <= minFontSize) {
      break;
    }
    activeFontSize -= 0.75;
  }

  const lineStep = activeFontSize * (options.lineHeight || 1.35);
  const totalTextHeight = lines.length * lineStep;

  let startY = innerY;
  if (options.verticalAlignment === 'middle') {
    startY = innerY + Math.max(0, (innerH - totalTextHeight) / 2);
  } else if (options.verticalAlignment === 'bottom') {
    startY = innerY + Math.max(0, innerH - totalTextHeight);
  }

  const rawLines = text.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const lineY = startY + i * lineStep;
    if (lineY > y + h + 2) break;

    const rawLine = rawLines[i] || lines[i];
    const hasDotsRun = /[.…]{5,}/.test(rawLine);
    const cleanLine = lines[i].replace(/[.…]{5,}/g, '');

    let anchorX = innerX;
    if (options.alignment === 'center') {
      ctx.textAlign = 'center';
      anchorX = innerX + innerW / 2;
    } else if (options.alignment === 'right') {
      ctx.textAlign = 'right';
      anchorX = innerX + innerW;
    } else if (options.alignment === 'left') {
      ctx.textAlign = 'left';
      anchorX = innerX;
    } else {
      ctx.textAlign = options.direction === 'rtl' ? 'right' : 'left';
      anchorX = options.direction === 'rtl' ? innerX + innerW : innerX;
    }

    if (cleanLine.trim()) {
      ctx.fillText(cleanLine, anchorX, lineY);
    }

    // If the source line had a dotted fill rule, draw a real vector dotted line!
    if (hasDotsRun) {
      const baselineY = lineY + activeFontSize * 0.88;
      const dotStart = cleanLine.trim()
        ? options.direction === 'rtl'
          ? innerX
          : innerX + Math.min(innerW * 0.65, ctx.measureText(cleanLine).width + 8 * scaleFactor)
        : innerX;
      const dotEnd = cleanLine.trim()
        ? options.direction === 'rtl'
          ? Math.max(innerX + 20, innerX + innerW - ctx.measureText(cleanLine).width - 8 * scaleFactor)
          : innerX + innerW
        : innerX + innerW;

      drawBorderSide(
        ctx,
        dotStart,
        baselineY,
        dotEnd,
        baselineY,
        { width: 1.3, style: 'dotted', color: '#334155' },
        scaleFactor
      );
    }
  }

  ctx.restore();
}

function renderStructuredTable(
  ctx: CanvasRenderingContext2D,
  obj: PageLayoutObject,
  x: number,
  y: number,
  w: number,
  h: number,
  scaleFactor: number,
  highlightLowConfidence: boolean
) {
  const table: TableStructureModel | undefined = obj.tableStructure;
  if (!table) return;

  const { rows, cols, rowHeights, colWidths, direction, cells } = table;

  // Use measured rowHeights and colWidths directly
  const sumR = rowHeights.reduce((a, b) => a + b, 0) || 1;
  const normRowH =
    rowHeights.length === rows
      ? rowHeights.map((rh) => rh / sumR)
      : Array.from({ length: rows }, () => 1 / rows);

  const sumC = colWidths.reduce((a, b) => a + b, 0) || 1;
  const normColW =
    colWidths.length === cols
      ? colWidths.map((cw) => cw / sumC)
      : Array.from({ length: cols }, () => 1 / cols);

  const rowY: number[] = [y];
  for (let r = 0; r < rows; r++) {
    rowY.push(rowY[r] + normRowH[r] * h);
  }

  const colX: number[] = [];
  const colW: number[] = [];

  if (direction === 'rtl') {
    let cursorRight = x + w;
    for (let c = 0; c < cols; c++) {
      const cw = normColW[c] * w;
      colW.push(cw);
      colX.push(cursorRight - cw);
      cursorRight -= cw;
    }
  } else {
    let cursorLeft = x;
    for (let c = 0; c < cols; c++) {
      const cw = normColW[c] * w;
      colW.push(cw);
      colX.push(cursorLeft);
      cursorLeft += cw;
    }
  }

  for (const cell of cells) {
    if (cell.hiddenByMerge) continue;

    const rStart = Math.max(0, Math.min(rows - 1, cell.row));
    const rEnd = Math.max(rStart + 1, Math.min(rows, rStart + (cell.rowSpan || 1)));
    const cStart = Math.max(0, Math.min(cols - 1, cell.col));
    const cEnd = Math.max(cStart + 1, Math.min(cols, cStart + (cell.colSpan || 1)));

    const cellY = rowY[rStart];
    const cellH = rowY[rEnd] - rowY[rStart];

    let cellX = colX[cStart];
    let cellW = 0;
    if (direction === 'rtl') {
      cellX = colX[cEnd - 1];
      for (let c = cStart; c < cEnd; c++) {
        cellW += colW[c];
      }
    } else {
      cellX = colX[cStart];
      for (let c = cStart; c < cEnd; c++) {
        cellW += colW[c];
      }
    }

    if (cell.backgroundColor && cell.backgroundColor !== 'transparent') {
      ctx.save();
      ctx.fillStyle = cell.backgroundColor;
      ctx.fillRect(cellX, cellY, cellW, cellH);
      ctx.restore();
    }

    if (highlightLowConfidence && cell.confidence < 0.78) {
      ctx.save();
      ctx.fillStyle = 'rgba(245, 158, 11, 0.16)';
      ctx.fillRect(cellX, cellY, cellW, cellH);
      ctx.restore();
    }

    drawBoxBorders(ctx, cellX, cellY, cellW, cellH, cell.borders, scaleFactor);

    drawMultilineText(
      ctx,
      cell.content,
      cellX,
      cellY,
      cellW,
      cellH,
      {
        fontFamily: obj.fontProperties.family,
        fontSizePx: (cell.fontSizePt || obj.fontProperties.sizePt) * scaleFactor * 1.33,
        fontWeight: cell.fontWeight || 'normal',
        color: obj.fontProperties.color || '#0F172A',
        alignment: cell.alignment,
        direction: cell.direction,
        lineHeight: 1.25,
        verticalAlignment: cell.verticalAlignment || 'middle',
        paddingPx: (cell.padding || 5) * scaleFactor,
      },
      scaleFactor
    );
  }

  drawBoxBorders(ctx, x, y, w, h, obj.borderProperties, scaleFactor);
}

function drawVectorStampOrDiagram(
  ctx: CanvasRenderingContext2D,
  obj: PageLayoutObject,
  x: number,
  y: number,
  w: number,
  h: number,
  scaleFactor: number
) {
  ctx.save();

  // If custom simple SVG path is provided, draw it cleanly as vector geometry
  if (obj.svgPathData) {
    ctx.translate(x, y);
    ctx.scale(w / 100, h / 100);
    ctx.strokeStyle = obj.stampColor || obj.fontProperties.color || '#0F172A';
    ctx.lineWidth = 2.2;
    const path2d = new Path2D(obj.svgPathData);
    ctx.stroke(path2d);
    ctx.restore();
    return;
  }

  const centerX = x + w / 2;
  const centerY = y + h / 2;
  const radiusX = w / 2 - 4 * scaleFactor;
  const radiusY = h / 2 - 4 * scaleFactor;
  const stampColor = obj.stampColor || '#1D4ED8';

  ctx.translate(centerX, centerY);
  ctx.rotate(-0.06);

  ctx.strokeStyle = stampColor;
  ctx.lineWidth = 2.2 * scaleFactor;
  ctx.beginPath();
  ctx.ellipse(0, 0, Math.max(8, radiusX), Math.max(8, radiusY), 0, 0, Math.PI * 2);
  ctx.stroke();

  ctx.lineWidth = 1 * scaleFactor;
  ctx.setLineDash([3 * scaleFactor, 2 * scaleFactor]);
  ctx.beginPath();
  ctx.ellipse(
    0,
    0,
    Math.max(4, radiusX - 5 * scaleFactor),
    Math.max(4, radiusY - 5 * scaleFactor),
    0,
    0,
    Math.PI * 2
  );
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.fillStyle = stampColor;
  ctx.direction = 'rtl';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const lines = toWesternDigits(obj.content || 'ختم رسمي معتمد').split('\n');
  const fontSize = Math.max(9, obj.fontProperties.sizePt * scaleFactor * 1.1);
  ctx.font = `bold ${Math.round(fontSize)}px "${obj.fontProperties.family}", "Cairo", sans-serif`;

  const step = fontSize * 1.25;
  const startY = -((lines.length - 1) * step) / 2;
  lines.forEach((line, idx) => {
    ctx.fillText(line, 0, startY + idx * step);
  });

  ctx.restore();
}

function drawSignatureOrHandwriting(
  ctx: CanvasRenderingContext2D,
  obj: PageLayoutObject,
  x: number,
  y: number,
  w: number,
  h: number,
  scaleFactor: number,
  keepHandwriting: boolean
) {
  drawBoxBorders(ctx, x, y, w, h, obj.borderProperties, scaleFactor);

  // Printed label inside signature box is always rendered as clean typography
  if (obj.content && obj.type !== 'HANDWRITING') {
    drawMultilineText(
      ctx,
      obj.content,
      x,
      y,
      w,
      h * 0.48,
      {
        fontFamily: obj.fontProperties.family,
        fontSizePx: obj.fontProperties.sizePt * scaleFactor * 1.3,
        fontWeight: obj.fontProperties.weight,
        color: obj.fontProperties.color,
        alignment: obj.alignment,
        direction: obj.direction,
        lineHeight: 1.2,
        paddingPx: 4 * scaleFactor,
      },
      scaleFactor
    );
  }

  // Step 4: Handwriting ink strokes are only drawn if keepHandwriting is true (or when simulating raw source scan)
  if (!keepHandwriting) return;

  ctx.save();
  ctx.strokeStyle = obj.stampColor || '#1D4ED8';
  ctx.lineWidth = 2.0 * scaleFactor;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  const sx = x + w * 0.18;
  const sy = obj.type === 'HANDWRITING' ? y + h * 0.55 : y + h * 0.72;
  ctx.beginPath();
  ctx.moveTo(sx, sy);
  ctx.bezierCurveTo(
    sx + w * 0.16,
    sy - h * 0.28,
    sx + w * 0.32,
    sy + h * 0.2,
    sx + w * 0.52,
    sy - h * 0.12
  );
  ctx.bezierCurveTo(
    sx + w * 0.64,
    sy - h * 0.22,
    sx + w * 0.42,
    sy + h * 0.16,
    sx + w * 0.72,
    sy + h * 0.04
  );
  ctx.stroke();

  if (obj.type === 'HANDWRITING' && obj.content) {
    ctx.fillStyle = obj.stampColor || '#1D4ED8';
    ctx.font = `italic bold ${Math.round(11.5 * scaleFactor)}px "Cairo", sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText(toWesternDigits(obj.content), x + w / 2, y + h * 0.35);
  }
  ctx.restore();
}

export function renderPageToCanvas(
  canvas: HTMLCanvasElement,
  objects: PageLayoutObject[],
  options: RenderPageOptions
) {
  const {
    widthPx,
    heightPx,
    keepHandwriting = false,
    highlightSelectedId,
    highlightLowConfidence = false,
    poorBlockIds,
    showBoundingBoxes = false,
    simulateScannedPhoto,
  } = options;

  canvas.width = widthPx;
  canvas.height = heightPx;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const scaleFactor = widthPx / 794;
  const shouldDrawHandwriting =
    simulateScannedPhoto?.includeHandwritingInSource !== undefined
      ? simulateScannedPhoto.includeHandwritingInSource
      : keepHandwriting;

  ctx.save();
  if (simulateScannedPhoto) {
    ctx.fillStyle = simulateScannedPhoto.warmPaperTint !== false ? '#F6F3EC' : '#FFFFFF';
    ctx.fillRect(0, 0, widthPx, heightPx);

    const rad = (simulateScannedPhoto.angleDeg * Math.PI) / 180;
    ctx.translate(widthPx / 2, heightPx / 2);
    ctx.rotate(rad);
    ctx.translate(-widthPx / 2, -heightPx / 2);

    ctx.fillStyle = simulateScannedPhoto.warmPaperTint !== false ? '#F6F3EC' : '#FFFFFF';
    ctx.fillRect(0, 0, widthPx, heightPx);

    // Optional faint reverse-side bleed-through simulation (removed in Step 1)
    if (simulateScannedPhoto.bleedThroughText) {
      ctx.save();
      ctx.translate(widthPx, 0);
      ctx.scale(-1, 1);
      ctx.fillStyle = 'rgba(100, 116, 139, 0.13)';
      ctx.font = `bold ${Math.round(18 * scaleFactor)}px "Cairo", sans-serif`;
      ctx.fillText(simulateScannedPhoto.bleedThroughText, widthPx * 0.18, heightPx * 0.32);
      ctx.fillText(simulateScannedPhoto.bleedThroughText, widthPx * 0.18, heightPx * 0.62);
      ctx.restore();
    }
  } else {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, widthPx, heightPx);
  }

  const sorted = [...objects].sort((a, b) => a.zOrder - b.zOrder);

  for (const obj of sorted) {
    if (obj.type === 'HANDWRITING' && !shouldDrawHandwriting) {
      continue;
    }

    const x = (obj.x / 1000) * widthPx;
    const y = (obj.y / 1000) * heightPx;
    const w = (obj.width / 1000) * widthPx;
    const h = (obj.height / 1000) * heightPx;

    if (
      obj.backgroundProperties.fill &&
      obj.backgroundProperties.fill !== 'transparent' &&
      obj.backgroundProperties.opacity > 0
    ) {
      ctx.save();
      ctx.globalAlpha = obj.backgroundProperties.opacity;
      ctx.fillStyle = obj.backgroundProperties.fill;
      ctx.fillRect(x, y, w, h);
      ctx.restore();
    }

    const isPoorBlock = poorBlockIds?.has(obj.id) || (highlightLowConfidence && obj.confidence < 0.78 && !obj.userCorrected);
    if (isPoorBlock && !simulateScannedPhoto) {
      ctx.save();
      ctx.fillStyle = 'rgba(245, 158, 11, 0.14)';
      ctx.fillRect(x, y, w, h);
      ctx.strokeStyle = '#D97706';
      ctx.lineWidth = 1.6 * scaleFactor;
      ctx.setLineDash([4 * scaleFactor, 3 * scaleFactor]);
      ctx.strokeRect(x, y, w, h);
      ctx.restore();
    }

    switch (obj.type) {
      case 'TABLE':
        renderStructuredTable(ctx, obj, x, y, w, h, scaleFactor, highlightLowConfidence);
        break;

      case 'DOTTED_LINE': {
        drawBorderSide(
          ctx,
          x,
          y + h / 2,
          x + w,
          y + h / 2,
          {
            width: obj.borderProperties.top.width || 1.4,
            style: 'dotted',
            color: obj.borderProperties.top.color || '#334155',
          },
          scaleFactor
        );
        break;
      }

      case 'LINE': {
        const isHorizontal = w >= h;
        const side: BorderSide =
          obj.borderProperties.top.width > 0
            ? obj.borderProperties.top
            : {
                width: 1.5,
                style: 'solid',
                color: obj.fontProperties.color || '#0F172A',
              };
        if (isHorizontal) {
          drawBorderSide(ctx, x, y + h / 2, x + w, y + h / 2, side, scaleFactor);
        } else {
          drawBorderSide(ctx, x + w / 2, y, x + w / 2, y + h, side, scaleFactor);
        }
        break;
      }

      case 'CHECKBOX': {
        const boxSize = Math.min(w, h, 18 * scaleFactor);
        const boxX =
          obj.direction === 'rtl' ? x + w - boxSize - 4 * scaleFactor : x + 4 * scaleFactor;
        const boxY = y + (h - boxSize) / 2;

        ctx.save();
        ctx.strokeStyle = obj.fontProperties.color || '#0F172A';
        ctx.lineWidth = 1.5 * scaleFactor;
        ctx.strokeRect(boxX, boxY, boxSize, boxSize);

        if (obj.checked) {
          ctx.beginPath();
          ctx.lineWidth = 2 * scaleFactor;
          ctx.moveTo(boxX + boxSize * 0.2, boxY + boxSize * 0.52);
          ctx.lineTo(boxX + boxSize * 0.44, boxY + boxSize * 0.76);
          ctx.lineTo(boxX + boxSize * 0.82, boxY + boxSize * 0.22);
          ctx.stroke();
        }
        ctx.restore();

        const labelX = obj.direction === 'rtl' ? x : boxX + boxSize + 6 * scaleFactor;
        const labelW = Math.max(10, w - boxSize - 12 * scaleFactor);
        drawMultilineText(
          ctx,
          obj.content,
          labelX,
          y,
          labelW,
          h,
          {
            fontFamily: obj.fontProperties.family,
            fontSizePx: obj.fontProperties.sizePt * scaleFactor * 1.33,
            fontWeight: obj.fontProperties.weight,
            color: obj.fontProperties.color,
            alignment: obj.alignment,
            direction: obj.direction,
            lineHeight: obj.fontProperties.lineHeight,
            verticalAlignment: 'middle',
            paddingPx: 2 * scaleFactor,
          },
          scaleFactor
        );
        break;
      }

      case 'IMAGE':
      case 'DRAWING':
        drawVectorStampOrDiagram(ctx, obj, x, y, w, h, scaleFactor);
        break;

      case 'SIGNATURE_AREA':
      case 'HANDWRITING':
        drawSignatureOrHandwriting(
          ctx,
          obj,
          x,
          y,
          w,
          h,
          scaleFactor,
          shouldDrawHandwriting
        );
        break;

      case 'RECTANGLE':
      case 'TEXT':
      case 'PARAGRAPH':
      default: {
        drawBoxBorders(ctx, x, y, w, h, obj.borderProperties, scaleFactor);
        drawMultilineText(
          ctx,
          obj.content,
          x,
          y,
          w,
          h,
          {
            fontFamily: obj.fontProperties.family,
            fontSizePx: obj.fontProperties.sizePt * scaleFactor * 1.33,
            fontWeight: obj.fontProperties.weight,
            fontStyle: obj.fontProperties.style,
            color: obj.fontProperties.color,
            alignment: obj.alignment,
            direction: obj.direction,
            lineHeight: obj.fontProperties.lineHeight || 1.4,
            verticalAlignment: obj.type === 'RECTANGLE' ? 'middle' : 'top',
            paddingPx: obj.type === 'RECTANGLE' ? 8 * scaleFactor : 3 * scaleFactor,
          },
          scaleFactor
        );
        break;
      }
    }

    if (showBoundingBoxes || highlightSelectedId === obj.id) {
      const isSelected = highlightSelectedId === obj.id;
      ctx.save();
      ctx.strokeStyle = isSelected ? '#DC2626' : 'rgba(59, 130, 246, 0.45)';
      ctx.lineWidth = isSelected ? 2 * scaleFactor : 1 * scaleFactor;
      ctx.setLineDash(isSelected ? [] : [3 * scaleFactor, 3 * scaleFactor]);
      ctx.strokeRect(x, y, w, h);

      if (isSelected) {
        const handleSize = 6 * scaleFactor;
        ctx.fillStyle = '#DC2626';
        ctx.fillRect(x - handleSize / 2, y - handleSize / 2, handleSize, handleSize);
        ctx.fillRect(x + w - handleSize / 2, y - handleSize / 2, handleSize, handleSize);
        ctx.fillRect(x - handleSize / 2, y + h - handleSize / 2, handleSize, handleSize);
        ctx.fillRect(x + w - handleSize / 2, y + h - handleSize / 2, handleSize, handleSize);
      }
      ctx.restore();
    }
  }

  if (simulateScannedPhoto && simulateScannedPhoto.shadowStrength > 0) {
    const grad = ctx.createLinearGradient(0, 0, widthPx, heightPx);
    grad.addColorStop(0, `rgba(15, 23, 42, ${simulateScannedPhoto.shadowStrength * 0.22})`);
    grad.addColorStop(0.55, 'rgba(15, 23, 42, 0.02)');
    grad.addColorStop(1, `rgba(15, 23, 42, ${simulateScannedPhoto.shadowStrength * 0.14})`);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, widthPx, heightPx);
  }

  ctx.restore();
}

/**
 * Async version that also draws any transparent raster crops (`croppedImageDataUrl`)
 * for HANDWRITING (when `keepHandwriting` is true) or complex DRAWING objects.
 */
export async function renderPageToCanvasAsync(
  canvas: HTMLCanvasElement,
  objects: PageLayoutObject[],
  options: RenderPageOptions
): Promise<void> {
  renderPageToCanvas(canvas, objects, options);
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const { widthPx, heightPx, keepHandwriting = false } = options;
  for (const obj of objects) {
    if (obj.type === 'HANDWRITING' && !keepHandwriting) continue;
    if (obj.croppedImageDataUrl) {
      try {
        const cropImg = await loadImageElement(obj.croppedImageDataUrl);
        const x = (obj.x / 1000) * widthPx;
        const y = (obj.y / 1000) * heightPx;
        const w = (obj.width / 1000) * widthPx;
        const h = (obj.height / 1000) * heightPx;
        ctx.drawImage(cropImg, x, y, w, h);
      } catch {
        // Ignore broken dataUrl
      }
    }
  }
}

export function renderObjectsToDataUrl(
  objects: PageLayoutObject[],
  options: RenderPageOptions,
  mimeType: 'image/png' | 'image/jpeg' = 'image/png',
  quality = 0.95
): string {
  const canvas = document.createElement('canvas');
  renderPageToCanvas(canvas, objects, options);
  return canvas.toDataURL(mimeType, quality);
}
