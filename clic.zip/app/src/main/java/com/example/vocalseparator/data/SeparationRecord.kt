package com.example.vocalseparator.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Persisted record of an audio separation project.
 */
@Entity(tableName = "separations")
data class SeparationRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val originalFilePath: String,
    val vocalsFilePath: String,
    val instrumentalFilePath: String,
    val sampleRate: Int,
    val fileSizeBytes: Long,
    val createdAtTimestamp: Long = System.currentTimeMillis()
)
