package com.example.core.demo

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.core.image.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object DemoDocumentFactory {

    data class DemoDocItem(
        val id: String,
        val title: String,
        val description: String,
        val badge: String
    )

    val SAMPLE_DOCUMENTS = listOf(
        DemoDocItem(
            id = "demo_multilingual",
            title = "مستند ثلاثي اللغات (عربي - English - Français)",
            description = "عنوان، فقرة عربية بمفردات إنجليزية، جملة فرنسية وأرقام",
            badge = "عربي / EN / FR"
        ),
        DemoDocItem(
            id = "demo_invoice",
            title = "فاتورة رسمية وجدول حسابي",
            description = "ترويسة شركة، جدول مشتريات، أرقام ومجاميع",
            badge = "جدول وأرقام"
        ),
        DemoDocItem(
            id = "demo_article",
            title = "تقرير أعمال دولي وملاحظات",
            description = "قوائم نقطية، نصوص تقنية، وتوصيات ختامية",
            badge = "قوائم وفقرات"
        )
    )

    suspend fun createDemoDocumentBitmap(context: Context, demoId: String): File = withContext(Dispatchers.Default) {
        val width = 1200
        val height = 1650
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Paper background (slight warm document tone)
        canvas.drawColor(Color.rgb(253, 252, 249))

        when (demoId) {
            "demo_multilingual" -> renderMultilingualDoc(canvas, width, height)
            "demo_invoice" -> renderInvoiceDoc(canvas, width, height)
            else -> renderArticleDoc(canvas, width, height)
        }

        ImageUtils.saveBitmapToCache(context, bitmap, "demo_$demoId")
    }

    private fun renderMultilingualDoc(canvas: Canvas, width: Int, height: Int) {
        val margin = 80f
        val contentWidth = (width - margin * 2).toInt()

        // Decorative subtle border
        val borderPaint = Paint().apply {
            color = Color.rgb(220, 220, 225)
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRect(margin - 20f, margin - 20f, width - margin + 20f, height - margin + 20f, borderPaint)

        // 1. Top Title (Arabic)
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(183, 28, 28) // Red PDF accent
            textSize = 52f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val titleText = "التقرير الأكاديمي الدولي للتوثيق الرقمي"
        val titleLayout = StaticLayout.Builder.obtain(titleText, 0, titleText.length, titlePaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .build()

        canvas.save()
        canvas.translate(margin, 120f)
        titleLayout.draw(canvas)
        canvas.restore()

        // 2. Arabic paragraph with English words inside
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 35, 40)
            textSize = 34f
            typeface = Typeface.DEFAULT
        }
        val paragraph1 = "تعتبر تقنيات الذكاء الاصطناعي ومعالجة المستندات Document Analysis حجر الأساس في التحول الرقمي الحديث. يوفر هذا النظام إمكانية OCR فائقة الدقة للتعرف على الحروف والكلمات داخل الصور واستخراج البيانات Structured Data بسلاسة تامة مع الحفاظ على التنسيق الأصلي للملف."
        val p1Layout = StaticLayout.Builder.obtain(paragraph1, 0, paragraph1.length, bodyPaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
            .setLineSpacing(8f, 1.25f)
            .build()

        canvas.save()
        canvas.translate(margin, 240f)
        p1Layout.draw(canvas)
        canvas.restore()

        // 3. Graphic / Photo placeholder (Stamp or Logo) to test TEXT vs GRAPHIC separation
        val stampPaint = Paint().apply {
            color = Color.rgb(220, 53, 69)
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        val stampRect = RectF(margin + 50f, 480f, margin + 260f, 620f)
        canvas.drawRoundRect(stampRect, 16f, 16f, stampPaint)
        val stampTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(220, 53, 69)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("مستند معتمد", margin + 75f, 545f, stampTextPaint)
        canvas.drawText("OFFICIAL SEAL", margin + 65f, 585f, stampTextPaint)

        // 4. French Section
        val frenchTitlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(21, 101, 192)
            textSize = 40f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("Certification de Conformité Numérique", margin, 700f, frenchTitlePaint)

        val frenchText = "Ce document certifie l'intégration complète des algorithmes d'analyse d'images et de reconnaissance optique des caractères. Tous les éléments textuels et graphiques sont traités avec succès conformément aux normes internationales."
        val frLayout = StaticLayout.Builder.obtain(frenchText, 0, frenchText.length, bodyPaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(8f, 1.25f)
            .build()

        canvas.save()
        canvas.translate(margin, 740f)
        frLayout.draw(canvas)
        canvas.restore()

        // 5. English bullet points
        val enTitlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(46, 125, 50)
            textSize = 38f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("Key Performance Indicators (KPIs):", margin, 960f, enTitlePaint)

        val bulletItems = listOf(
            "• High accuracy multi-language OCR pipeline",
            "• Real-time layout analysis and reading order sorting",
            "• Dual PDF engine: Searchable Original and Clean Text PDF"
        )
        var bulletY = 1020f
        for (item in bulletItems) {
            canvas.drawText(item, margin + 20f, bulletY, bodyPaint)
            bulletY += 60f
        }

        // 6. Bottom numbers and codes
        val codeBoxPaint = Paint().apply {
            color = Color.rgb(240, 242, 245)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(margin, 1260f, width - margin, 1370f), 12f, 12f, codeBoxPaint)

        val numberPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 30, 35)
            textSize = 32f
            typeface = Typeface.MONOSPACE
        }
        canvas.drawText("REF: DOC-2026-984210  |  DATE: 30/09/2026  |  TOTAL: 1,450.00 EUR", margin + 30f, 1325f, numberPaint)

        // Footer
        val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.GRAY
            textSize = 26f
        }
        canvas.drawText("صفحة 1 من 1  -  DocScan OCR Intelligence Engine", margin, 1480f, footerPaint)
    }

    private fun renderInvoiceDoc(canvas: Canvas, width: Int, height: Int) {
        val margin = 80f
        val contentWidth = (width - margin * 2).toInt()

        val headerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(183, 28, 28)
            textSize = 50f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("فاتورة ضريبية رسمية - TAX INVOICE", margin, 130f, headerPaint)

        val normalPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(40, 40, 45)
            textSize = 32f
        }
        canvas.drawText("رقم الفاتورة: INV-2026-4491", margin, 200f, normalPaint)
        canvas.drawText("التاريخ: 30 سبتمبر 2026", width - margin - 320f, 200f, normalPaint)

        // Table Header
        val tableHeaderPaint = Paint().apply {
            color = Color.rgb(240, 242, 248)
            style = Paint.Style.FILL
        }
        canvas.drawRect(margin, 280f, width - margin, 350f, tableHeaderPaint)

        val colTitlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(20, 20, 30)
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("البند / Description", margin + 20f, 330f, colTitlePaint)
        canvas.drawText("الكمية", margin + 550f, 330f, colTitlePaint)
        canvas.drawText("السعر", margin + 720f, 330f, colTitlePaint)
        canvas.drawText("المجموع", width - margin - 150f, 330f, colTitlePaint)

        // Rows
        val items = listOf(
            Triple("خدمة الفحص الضوئي الذكي OCR Pro", "1", "350.00"),
            Triple("اشتراك سحابي لمعالجة المستندات", "2", "120.00"),
            Triple("تصدير ملفات PDF أصلية قابلة للبحث", "1", "90.00")
        )

        var rowY = 420f
        for (item in items) {
            canvas.drawText(item.first, margin + 20f, rowY, normalPaint)
            canvas.drawText(item.second, margin + 570f, rowY, normalPaint)
            val subtotal = (item.third.toFloat() * item.second.toInt()).toString()
            canvas.drawText(item.third, margin + 720f, rowY, normalPaint)
            canvas.drawText(subtotal, width - margin - 150f, rowY, normalPaint)

            canvas.drawLine(margin, rowY + 30f, width - margin, rowY + 30f, Paint().apply {
                color = Color.rgb(230, 230, 235)
                strokeWidth = 2f
            })
            rowY += 90f
        }

        // Totals
        val totalBox = RectF(width - margin - 400f, rowY + 40f, width - margin, rowY + 160f)
        canvas.drawRoundRect(totalBox, 8f, 8f, Paint().apply {
            color = Color.rgb(255, 235, 238)
            style = Paint.Style.FILL
        })
        val totalPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(183, 28, 28)
            textSize = 38f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("الإجمالي الكلي:", width - margin - 380f, rowY + 110f, totalPaint)
        canvas.drawText("680.00 ر.س", width - margin - 180f, rowY + 110f, totalPaint)
    }

    private fun renderArticleDoc(canvas: Canvas, width: Int, height: Int) {
        val margin = 80f
        val contentWidth = (width - margin * 2).toInt()

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 30, 30)
            textSize = 48f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("دليل التحول الرقمي وإدارة الوثائق 2026", margin, 130f, titlePaint)

        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(50, 50, 55)
            textSize = 32f
        }
        val text = "يهدف هذا الدليل إلى تبسيط رقمنة الأوراق والملفات عبر تكنولوجيا المسح الضوئي المتقدمة. يستطيع المستخدم تحويل أي صورة مستند إلى ملف PDF تفاعلي أصلي مع الحفاظ على كل عنصر نصي، أو إنشاء ملف نصي نقي قابل للنسخ والتعديل الفوري."
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, bodyPaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
            .setLineSpacing(6f, 1.2f)
            .build()

        canvas.save()
        canvas.translate(margin, 180f)
        layout.draw(canvas)
        canvas.restore()

        val listHeaderPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(183, 28, 28)
            textSize = 36f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("المزايا الأساسية لنظام DocScan OCR:", margin, 420f, listHeaderPaint)

        val items = listOf(
            "1. دعم فوري للغة العربية والفرنسية والإنجليزية.",
            "2. فصل الصور والرسومات عن كتل النصوص تلقائياً.",
            "3. تصدير مزدوج: PDF أصلي مدمج بـ OCR أو PDF نصي خالص.",
            "4. محرك بحث داخلي وتحديد فوري للكلمات والجمل والفقرات."
        )

        var y = 490f
        for (item in items) {
            canvas.drawText(item, margin + 20f, y, bodyPaint)
            y += 65f
        }
    }
}
