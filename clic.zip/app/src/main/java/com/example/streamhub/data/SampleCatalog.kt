package com.example.streamhub.data

import com.example.R
import com.example.streamhub.model.Episode
import com.example.streamhub.model.MediaItem
import com.example.streamhub.model.MediaType

object SampleCatalog {

    val allMedia: List<MediaItem> = listOf(
        // Featured Hero 1: Cyberpunk Neon Frontier
        MediaItem(
            id = "movie_cyberpunk",
            title = "Cyberpunk: Neon Frontier",
            titleAr = "سايبربانك: آفاق النيون",
            type = MediaType.MOVIE,
            year = 2026,
            durationOrSeasons = "2h 24m",
            rating = 9.2,
            genres = listOf("Sci-Fi", "Action", "Cyberpunk", "Thriller"),
            description = "في مدينة متطورة غارقة بأنوار النيون والذكاء الاصطناعي الفائق، يخوض محقق سيبراني سباقاً مع الزمن لكشف مؤامرة تهدد بفصل الوعي البشري عن الواقع.",
            director = "Elena Vance",
            cast = listOf("Alex Rivera", "Kaelen Chen", "Maya Sterling", "Viktor Stone"),
            videoQuality = "4K HDR Dolby Vision",
            audioFormat = "Dolby Atmos 7.1",
            backdropRes = R.drawable.hero_cyber_movie_1788878278085,
            posterPlaceholderColor = 0xFF0D1B2A,
            isFeatured = true,
            trendingRank = 1,
            downloadSizeMb = 3120
        ),

        // Featured Hero 2: Interstellar Horizon
        MediaItem(
            id = "movie_interstellar_horizon",
            title = "Interstellar Horizon: The Void",
            titleAr = "الأفق بين النجوم: الفراغ الكوني",
            type = MediaType.MOVIE,
            year = 2025,
            durationOrSeasons = "2h 45m",
            rating = 8.9,
            genres = listOf("Sci-Fi", "Adventure", "Drama"),
            description = "رحلة فضائية ملحمية إلى أطراف مجرة مجهولة بعد رصد إشارة كونية غامضة تحمل أسرار نشأة الكون ومصير البشرية جمعاء.",
            director = "Marcus Sterling",
            cast = listOf("Sarah Connor", "David Oyelowo", "Hiroshi Tanaka"),
            videoQuality = "4K UHD IMAX",
            audioFormat = "Dolby Atmos",
            backdropRes = R.drawable.hero_galaxy_epic_1788878297921,
            posterPlaceholderColor = 0xFF1E1B4B,
            isFeatured = true,
            trendingRank = 2,
            watchProgress = 0.45f,
            downloadSizeMb = 3850
        ),

        // 3: Chronicles of Al-Andalus
        MediaItem(
            id = "series_andalus",
            title = "Chronicles of Al-Andalus",
            titleAr = "أسرار الأندلس المفقودة",
            type = MediaType.SERIES,
            year = 2025,
            durationOrSeasons = "3 Seasons",
            rating = 9.4,
            genres = listOf("History", "Drama", "Mystery"),
            description = "ملحمة تاريخية مشوقة تسبر أغوار قرطبة وغرناطة في عصورها الذهبية، وتكشف أسرار العلماء والفلكيين وصراع الحكم والمعرفة.",
            director = "Tariq Mansoor",
            cast = listOf("Zaid Al-Husseini", "Nour El-Sherif", "Clara Morales"),
            videoQuality = "4K UHD HDR10+",
            audioFormat = "Dolby Digital 5.1",
            posterPlaceholderColor = 0xFF312E81,
            isFeatured = false,
            trendingRank = 3,
            watchProgress = 0.75f,
            downloadSizeMb = 2100,
            episodes = listOf(
                Episode(1, "بوابة قرطبة", "54m", "وصول المخطوطة الغامضة إلى دار الحكمة."),
                Episode(2, "نجوم قصر الحمراء", "58m", "العثور على الإسطرلاب الفلكي المخفي."),
                Episode(3, "همسات الوادي الكبير", "50m", "مؤامرة لسرقة خريطة البحار السبعة.")
            )
        ),

        // 4: Shadow Dynasty
        MediaItem(
            id = "movie_shadow_dynasty",
            title = "Shadow Dynasty: The Ronin",
            titleAr = "سلالة الظلال: الساموراي الأخير",
            type = MediaType.MOVIE,
            year = 2025,
            durationOrSeasons = "2h 12m",
            rating = 8.7,
            genres = listOf("Action", "Martial Arts", "History"),
            description = "محارب ساموراي منعزل يخرج من عزلته للدفاع عن قرية ريفية وصد تحالف من قطاع الطرق وأمراء الحرب الأقوياء.",
            director = "Kenji Sato",
            cast = listOf("Renjiro Takahashi", "Aoi Miyazaki", "Takeshi Kaneshiro"),
            videoQuality = "4K UHD",
            audioFormat = "DTS-HD Master",
            posterPlaceholderColor = 0xFF450A0A,
            trendingRank = 4,
            downloadSizeMb = 2400
        ),

        // 5: Neon Tokyo 2099 (Anime)
        MediaItem(
            id = "anime_neon_tokyo",
            title = "Neon Tokyo 2099",
            titleAr = "نيون طوكيو ٢٠٩٩",
            type = MediaType.ANIME,
            year = 2026,
            durationOrSeasons = "24 Episodes",
            rating = 9.1,
            genres = listOf("Anime", "Cyberpunk", "Action"),
            description = "أنمي مستقبلي مبهر بصرياً يتابع فتاة موهوبة في البرمجة العصبية تخوض معارك سيبرانية حامية في شوارع طوكيو المعلقة.",
            director = "Shinichiro Watanabe",
            cast = listOf("Rie Takahashi", "Mamoru Miyano", "Yuki Kaji"),
            videoQuality = "1080p 60fps",
            audioFormat = "FLAC Stereo",
            posterPlaceholderColor = 0xFF3B0764,
            trendingRank = 5,
            watchProgress = 0.30f,
            downloadSizeMb = 1200
        ),

        // 6: Deep Oceanic Blue (Documentary)
        MediaItem(
            id = "doc_deep_oceanic",
            title = "Deep Oceanic: The Abyss",
            titleAr = "أعماق المحيط: الهاوية الزرقاء",
            type = MediaType.MOVIE,
            year = 2025,
            durationOrSeasons = "1h 50m",
            rating = 9.5,
            genres = listOf("Documentary", "Nature", "Exploration"),
            description = "تصوير فائق الدقة بتقنية 4K HDR لأغرب المخلوقات المضيئة في خندق ماريانا على عمق ١١ ألف متر تحت سطح البحر.",
            director = "David Attenborough Team",
            cast = listOf("Dr. Sylvia Earle", "James Cameron"),
            videoQuality = "4K UHD 60fps HDR",
            audioFormat = "Dolby Atmos",
            posterPlaceholderColor = 0xFF082F49,
            trendingRank = 6,
            downloadSizeMb = 3400
        ),

        // 7: Formula Velocity
        MediaItem(
            id = "series_velocity",
            title = "Formula Velocity: Redline",
            titleAr = "سرعة الفورمولا: الخط الأحمر",
            type = MediaType.SERIES,
            year = 2026,
            durationOrSeasons = "2 Seasons",
            rating = 8.8,
            genres = listOf("Sports", "Documentary", "Speed"),
            description = "كواليس مثيرة وحصرية لأشرس منافسات سباقات السرعة العالمية والضغوط النفسية الهائلة على السائقين والمهندسين.",
            director = "Jean Todt Studios",
            cast = listOf("Lewis H.", "Max V.", "Charles L."),
            videoQuality = "4K UHD",
            audioFormat = "Dolby 5.1 Surround",
            posterPlaceholderColor = 0xFF7F1D1D,
            trendingRank = 7,
            downloadSizeMb = 2600
        ),

        // 8: The Quantum Heist
        MediaItem(
            id = "movie_quantum_heist",
            title = "The Quantum Heist",
            titleAr = "سرقة الكوانتوم",
            type = MediaType.MOVIE,
            year = 2024,
            durationOrSeasons = "2h 05m",
            rating = 8.4,
            genres = listOf("Thriller", "Sci-Fi", "Crime"),
            description = "فريق من القراصنة النخبة يخطط لاختراق أمن كمبيوتر كمومي فائق الدقة محمي في خزانة تحت جبال الألب السويسرية.",
            director = "Christian Nolan",
            cast = listOf("Robert Pattinson", "Zendaya", "Oscar Isaac"),
            videoQuality = "4K UHD",
            audioFormat = "Dolby Atmos",
            posterPlaceholderColor = 0xFF14532D,
            trendingRank = 8,
            downloadSizeMb = 2750
        ),

        // Live Channels:
        MediaItem(
            id = "live_cinema_4k",
            title = "StreamHub Cinema 4K",
            titleAr = "سينما ستريم هاب 4K المباشرة",
            type = MediaType.LIVE_TV,
            year = 2026,
            durationOrSeasons = "LIVE 24/7",
            rating = 9.6,
            genres = listOf("Live", "Movies", "Premiere"),
            description = "بث مباشر مستمر لأحدث الأفلام السينمائية العالمية بدقة 4K فائقة وصوت سينمائي محيطي بدون انقطاع.",
            director = "StreamHub Broadcast",
            cast = listOf("Host: Cinema Crew"),
            videoQuality = "4K UHD 60fps Live",
            audioFormat = "Dolby 5.1",
            posterPlaceholderColor = 0xFF701A75,
            channelNumber = 101
        ),
        MediaItem(
            id = "live_action_prime",
            title = "Action Prime Live",
            titleAr = "أكشن برايم لايف",
            type = MediaType.LIVE_TV,
            year = 2026,
            durationOrSeasons = "LIVE 24/7",
            rating = 9.0,
            genres = listOf("Live", "Action", "Thriller"),
            description = "قناة البث الحي لأقوى أفلام الحركة والمطاردات والفنون القتالية مع برامج تحليلية حصرية.",
            director = "StreamHub Broadcast",
            cast = listOf("Action Crew"),
            videoQuality = "1080p 60fps Live",
            audioFormat = "Dolby 5.1",
            posterPlaceholderColor = 0xFF831843,
            channelNumber = 102
        )
    )

    val genres: List<String> = listOf(
        "All",
        "Sci-Fi",
        "Action",
        "Drama",
        "Anime",
        "History",
        "Thriller",
        "Documentary",
        "Sports",
        "Live"
    )
}
