package com.example.vocalseparator.audio

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs

/**
 * Professional Multi-Track Studio Player.
 * Synchronizes playback across Original, Vocals, and Instrumental audio tracks,
 * allowing live stem mixing, solo/mute capabilities, and real-time waveform visualization.
 */
class StudioMultiTrackPlayer(
    private val context: Context,
    private val coroutineScope: CoroutineScope
) {

    enum class TrackSoloMode {
        CUSTOM_MIX,
        SOLO_VOCALS,
        SOLO_INSTRUMENTAL,
        SOLO_ORIGINAL
    }

    data class PlayerPlaybackState(
        val isPlaying: Boolean = false,
        val currentPositionMs: Long = 0L,
        val durationMs: Long = 0L,
        val soloMode: TrackSoloMode = TrackSoloMode.CUSTOM_MIX,
        val vocalsVolume: Float = 1.0f,
        val instrumentalVolume: Float = 1.0f,
        val originalVolume: Float = 0.0f,
        val masterVolume: Float = 1.0f,
        val vocalsMuted: Boolean = false,
        val instrumentalMuted: Boolean = false,
        val isReady: Boolean = false
    )

    private val _playbackState = MutableStateFlow(PlayerPlaybackState())
    val playbackState: StateFlow<PlayerPlaybackState> = _playbackState.asStateFlow()

    private var playerOriginal: MediaPlayer? = null
    private var playerVocals: MediaPlayer? = null
    private var playerInstrumental: MediaPlayer? = null

    private var syncJob: Job? = null
    private var isPrepared = false

    /**
     * Prepares the three audio stems for synchronized studio playback.
     */
    fun loadTracks(
        originalFile: File,
        vocalsFile: File,
        instrumentalFile: File,
        durationMs: Long
    ) {
        release()

        try {
            playerOriginal = MediaPlayer().apply {
                setDataSource(context, Uri.fromFile(originalFile))
                prepare()
            }
            playerVocals = MediaPlayer().apply {
                setDataSource(context, Uri.fromFile(vocalsFile))
                prepare()
            }
            playerInstrumental = MediaPlayer().apply {
                setDataSource(context, Uri.fromFile(instrumentalFile))
                prepare()
            }

            val actualDuration = playerOriginal?.duration?.toLong() ?: durationMs
            isPrepared = true

            // Set onCompletion on original
            playerOriginal?.setOnCompletionListener {
                pause()
                seekTo(0)
            }

            _playbackState.value = _playbackState.value.copy(
                isReady = true,
                durationMs = actualDuration,
                currentPositionMs = 0
            )

            applyVolumes()
            startPositionSyncLoop()
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing multi-track audio players", e)
        }
    }

    fun play() {
        if (!isPrepared) return
        try {
            val syncPos = playerOriginal?.currentPosition ?: 0
            playerVocals?.seekTo(syncPos)
            playerInstrumental?.seekTo(syncPos)

            playerOriginal?.start()
            playerVocals?.start()
            playerInstrumental?.start()

            _playbackState.value = _playbackState.value.copy(isPlaying = true)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting playback", e)
        }
    }

    fun pause() {
        try {
            playerOriginal?.pause()
            playerVocals?.pause()
            playerInstrumental?.pause()
            _playbackState.value = _playbackState.value.copy(isPlaying = false)
        } catch (e: Exception) {
            Log.e(TAG, "Error pausing playback", e)
        }
    }

    fun togglePlayPause() {
        if (_playbackState.value.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    fun seekTo(positionMs: Long) {
        val target = positionMs.toInt()
        try {
            playerOriginal?.seekTo(target)
            playerVocals?.seekTo(target)
            playerInstrumental?.seekTo(target)
            _playbackState.value = _playbackState.value.copy(currentPositionMs = positionMs)
        } catch (e: Exception) {
            Log.e(TAG, "Error seeking playback", e)
        }
    }

    fun seekRelative(offsetMs: Long) {
        val newPos = (_playbackState.value.currentPositionMs + offsetMs).coerceIn(0L, _playbackState.value.durationMs)
        seekTo(newPos)
    }

    fun setVocalsVolume(volume: Float) {
        _playbackState.value = _playbackState.value.copy(
            vocalsVolume = volume.coerceIn(0f, 1f),
            soloMode = TrackSoloMode.CUSTOM_MIX
        )
        applyVolumes()
    }

    fun setInstrumentalVolume(volume: Float) {
        _playbackState.value = _playbackState.value.copy(
            instrumentalVolume = volume.coerceIn(0f, 1f),
            soloMode = TrackSoloMode.CUSTOM_MIX
        )
        applyVolumes()
    }

    fun setMasterVolume(volume: Float) {
        _playbackState.value = _playbackState.value.copy(
            masterVolume = volume.coerceIn(0f, 1f)
        )
        applyVolumes()
    }

    fun toggleVocalsMute() {
        val newMute = !_playbackState.value.vocalsMuted
        _playbackState.value = _playbackState.value.copy(
            vocalsMuted = newMute,
            soloMode = TrackSoloMode.CUSTOM_MIX
        )
        applyVolumes()
    }

    fun toggleInstrumentalMute() {
        val newMute = !_playbackState.value.instrumentalMuted
        _playbackState.value = _playbackState.value.copy(
            instrumentalMuted = newMute,
            soloMode = TrackSoloMode.CUSTOM_MIX
        )
        applyVolumes()
    }

    fun setSoloMode(mode: TrackSoloMode) {
        _playbackState.value = _playbackState.value.copy(soloMode = mode)
        applyVolumes()
    }

    private fun applyVolumes() {
        val state = _playbackState.value
        val master = state.masterVolume

        val (vocVol, instVol, origVol) = when (state.soloMode) {
            TrackSoloMode.SOLO_VOCALS -> Triple(1.0f * master, 0.0f, 0.0f)
            TrackSoloMode.SOLO_INSTRUMENTAL -> Triple(0.0f, 1.0f * master, 0.0f)
            TrackSoloMode.SOLO_ORIGINAL -> Triple(0.0f, 0.0f, 1.0f * master)
            TrackSoloMode.CUSTOM_MIX -> {
                val v = if (state.vocalsMuted) 0f else state.vocalsVolume * master
                val i = if (state.instrumentalMuted) 0f else state.instrumentalVolume * master
                Triple(v, i, 0.0f)
            }
        }

        try {
            playerVocals?.setVolume(vocVol, vocVol)
            playerInstrumental?.setVolume(instVol, instVol)
            playerOriginal?.setVolume(origVol, origVol)
        } catch (e: Exception) {
            Log.e(TAG, "Error adjusting track volumes", e)
        }
    }

    private fun startPositionSyncLoop() {
        syncJob?.cancel()
        syncJob = coroutineScope.launch(Dispatchers.Main) {
            while (isActive) {
                if (isPrepared && _playbackState.value.isPlaying) {
                    val pos = playerOriginal?.currentPosition?.toLong() ?: 0L
                    _playbackState.value = _playbackState.value.copy(currentPositionMs = pos)

                    // Ensure micro-alignment between players
                    val vocPos = playerVocals?.currentPosition ?: 0
                    val instPos = playerInstrumental?.currentPosition ?: 0
                    val origPos = pos.toInt()

                    if (abs(vocPos - origPos) > 45) {
                        playerVocals?.seekTo(origPos)
                    }
                    if (abs(instPos - origPos) > 45) {
                        playerInstrumental?.seekTo(origPos)
                    }
                }
                delay(60)
            }
        }
    }

    fun release() {
        syncJob?.cancel()
        syncJob = null
        isPrepared = false

        try { playerOriginal?.stop(); playerOriginal?.release() } catch (_: Exception) {}
        try { playerVocals?.stop(); playerVocals?.release() } catch (_: Exception) {}
        try { playerInstrumental?.stop(); playerInstrumental?.release() } catch (_: Exception) {}

        playerOriginal = null
        playerVocals = null
        playerInstrumental = null

        _playbackState.value = PlayerPlaybackState()
    }

    companion object {
        private const val TAG = "StudioMultiTrackPlayer"
    }
}
