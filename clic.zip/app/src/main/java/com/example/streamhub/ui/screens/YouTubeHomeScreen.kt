package com.example.streamhub.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DesktopMac
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// معرّف متصفح Chrome النقي الأصلي لمنع نظام الحماية من الروبوتات واشتراط تسجيل الدخول
private const val CHROME_MOBILE_UA =
    "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"
private const val CHROME_DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"

/**
 * دالة ذكية لاستخراج معرف الفيديو (Video ID) من أي رابط يوتيوب
 */
fun extractYouTubeVideoId(url: String): String? {
    return try {
        when {
            url.contains("/embed/") -> url.substringAfter("/embed/").substringBefore("?").substringBefore("&")
            url.contains("/shorts/") -> url.substringAfter("/shorts/").substringBefore("?").substringBefore("&")
            url.contains("watch?v=") -> url.substringAfter("watch?v=").substringBefore("&").substringBefore("#")
            url.contains("youtu.be/") -> url.substringAfter("youtu.be/").substringBefore("?").substringBefore("&")
            else -> null
        }
    } catch (e: Exception) {
        null
    }
}

/**
 * جسر التواصل بين واجهة JavaScript داخل YouTube وتطبيق Android لتتبع الروابط وتخطي فحص الروبوت
 */
class YoutubMBridge(
    private val onUrlChanged: (String) -> Unit,
    private val onBotBlocked: (String) -> Unit
) {
    @android.webkit.JavascriptInterface
    fun notifyUrl(url: String) {
        onUrlChanged(url)
    }

    @android.webkit.JavascriptInterface
    fun notifyBotBlock(videoId: String) {
        onBotBlocked(videoId)
    }
}

/**
 * شاشة youtub M السحرية والمتطورة:
 * - حل مشكلة تسجيل الدخول وفحص الروبوت نهائياً (Google Bot & Sign-in Bypass)
 * - وضع التضمين المباشر (Embed Mode) لتشغيل أي فيديو بدون أي قيود أو تسجيل دخول
 * - تصفح سريع لـ YouTube Mobile مع دعم التكبير والتصغير بالإصبع
 * - وضع ملء الشاشة الحقيقي (HTML5 Fullscreen Video) بدعم دوران الشاشة
 * - وضع OLED الأسود الفاحم الحقيقي الموفر للبطارية (#000000)
 * - حماية من لافتات "فتح في التطبيق" والترويج المزعجة (Clean Shield Mode)
 * - التبديل الفوري بين وضع الهاتف ووضع سطح المكتب (Desktop View)
 */
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeHomeScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()

    // حالات التصفح والتحكم
    var isLoading by remember { mutableStateOf(true) }
    var loadingProgress by remember { mutableFloatStateOf(0f) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var canGoBackState by remember { mutableStateOf(false) }
    var canGoForwardState by remember { mutableStateOf(false) }
    var currentUrl by remember { mutableStateOf("https://m.youtube.com") }

    // اللمسات السحرية
    var isDesktopMode by remember { mutableStateOf(false) }
    var isOledBlackMode by remember { mutableStateOf(true) }
    var isCleanShieldEnabled by remember { mutableStateOf(true) }
    var autoDismissLoginBanners by remember { mutableStateOf(true) }
    var autoBypassBotBlock by remember { mutableStateOf(true) }
    var showQuickSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showMagicMenu by remember { mutableStateOf(false) }

    // التحقق مما إذا كان الرابط الحالي يشير إلى فيديو يمكن تشغيله عبر التضمين
    val currentVideoId = remember(currentUrl) { extractYouTubeVideoId(currentUrl) }
    val isCurrentlyInEmbedMode = remember(currentUrl) { currentUrl.contains("/embed/") }

    // معالجة وضع ملء الشاشة الكامل (HTML5 Fullscreen)
    var customFullscreenView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }
    val isFullscreen = customFullscreenView != null

    // إدارة ضغط زر الرجوع (Double back to exit)
    var lastBackPressTime by remember { mutableStateOf(0L) }

    // إبقاء الشاشة مضاءة أثناء تشغيل التطبيق لمنع انطفاء الهاتف أثناء المشاهدة
    DisposableEffect(activity) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // تنظيف الموارد عند مغادرة الشاشة
    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.apply {
                stopLoading()
                onPause()
                pauseTimers()
                destroy()
            }
            webViewRef = null
        }
    }

    // إدارة الرجوع الذكي
    BackHandler(enabled = true) {
        if (isFullscreen) {
            customViewCallback?.onCustomViewHidden()
            customFullscreenView = null
            customViewCallback = null
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        } else if (isCurrentlyInEmbedMode && currentVideoId != null) {
            // الرجوع من وضع التضمين إلى صفحة الفيديو العادية
            webViewRef?.loadUrl("https://m.youtube.com/watch?v=$currentVideoId")
        } else if (webViewRef?.canGoBack() == true) {
            webViewRef?.goBack()
        } else {
            val now = System.currentTimeMillis()
            if (now - lastBackPressTime < 2000) {
                activity?.finish()
            } else {
                lastBackPressTime = now
                Toast.makeText(context, "اضغط مرة أخرى للخروج من youtub M", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // حقن كود CSS & JS السحري (OLED الأسود النقي + إخفاء الإعلانات واللافتات + تخطي تسجيل الدخول التلقائي)
    fun injectMagicStyles(webView: WebView) {
        var css = ""
        if (isOledBlackMode) {
            css += """
                html, body, #app, ytm-app, .background-color-base-background,
                .page-container, ytm-mobile-topbar-renderer {
                    background-color: #000000 !important;
                    background: #000000 !important;
                    color: #FFFFFF !important;
                }
                .compact-media-item-metadata, .ytm-item-section-renderer {
                    background-color: #000000 !important;
                }
            """.trimIndent()
        }
        if (isCleanShieldEnabled) {
            css += """
                /* إخفاء لافتة افتح في التطبيق المزعجة وإعلانات الترويج */
                ytm-open-app-button-renderer,
                ytm-mealbar-promo-renderer,
                .standalone-collection-badge-renderer,
                .ytm-promoted-sparkles-web-renderer,
                .ad-container,
                .video-ads,
                ytm-pivot-bar-renderer ytm-pivot-bar-item-renderer:nth-child(3)[aria-label*="Create"] {
                    display: none !important;
                    visibility: hidden !important;
                }
            """.trimIndent()
        }
        if (autoDismissLoginBanners) {
            css += """
                /* إخفاء نوافذ تسجيل الدخول المنبثقة وحظر المشاهدة */
                .yt-spec-touch-feedback-shape,
                ytm-consent-bump-v2-renderer,
                #lightbox,
                .upsell-dialog,
                tp-yt-paper-dialog,
                ytd-popup-container {
                    display: none !important;
                }
            """.trimIndent()
        }

        val escapedCss = css.replace("`", "\\`").replace("\\", "\\\\").replace("\n", " ")

        val js = """
            (function() {
                // 1. حقن الأنماط المظهرية
                var styleId = 'youtubm-magic-styles';
                var existingStyle = document.getElementById(styleId);
                if (!existingStyle) {
                    existingStyle = document.createElement('style');
                    existingStyle.id = styleId;
                    document.head.appendChild(existingStyle);
                }
                existingStyle.innerHTML = '$escapedCss';

                // 2. إغلاق تلقائي للنوافذ المنبثقة الترويجية وأزرار الرفض
                try {
                    var dismissSelectors = [
                        'button[aria-label*="Dismiss"]',
                        'button[aria-label*="رفض"]',
                        'button[aria-label*="ليس الآن"]',
                        'button[aria-label*="Not now"]',
                        '.yt-spec-button-shape-next--tonal'
                    ];
                    dismissSelectors.forEach(function(sel) {
                        var btn = document.querySelector(sel);
                        if (btn) { btn.click(); }
                    });
                } catch(e) {}

                // 3. ربط تنقلات التطبيق SPA والتعامل مع فحص الروبوت
                if (!window.__youtubm_hooked) {
                    window.__youtubm_hooked = true;

                    function getVid(url) {
                        var target = url || window.location.href;
                        var match = target.match(/[?&]v=([^&#]+)/);
                        if (match && match[1]) return match[1];
                        var sMatch = target.match(/\/shorts\/([^/?#]+)/);
                        if (sMatch && sMatch[1]) return sMatch[1];
                        var eMatch = target.match(/\/embed\/([^/?#]+)/);
                        if (eMatch && eMatch[1]) return eMatch[1];
                        return null;
                    }

                    window.replacePlayerOnPage = function(vid) {
                        if (!vid) vid = getVid();
                        if (!vid) return false;

                        var player = document.querySelector('ytm-player') ||
                                     document.getElementById('player') ||
                                     document.querySelector('#player-control-overlay') ||
                                     document.querySelector('.player-container') ||
                                     document.querySelector('.html5-video-player');

                        if (player) {
                            var existing = document.getElementById('youtubm-embed-iframe');
                            if (existing && existing.getAttribute('data-vid') === vid) return true;

                            var iframe = document.createElement('iframe');
                            iframe.id = 'youtubm-embed-iframe';
                            iframe.setAttribute('data-vid', vid);
                            iframe.src = 'https://www.youtube-nocookie.com/embed/' + vid + '?autoplay=1&playsinline=1&modestbranding=1&rel=0';
                            iframe.style.width = '100%';
                            iframe.style.height = '100%';
                            iframe.style.minHeight = '230px';
                            iframe.style.border = 'none';
                            iframe.style.display = 'block';
                            iframe.style.position = 'relative';
                            iframe.style.zIndex = '99999';
                            iframe.style.backgroundColor = '#000000';
                            iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share');
                            iframe.setAttribute('allowfullscreen', 'true');

                            player.innerHTML = '';
                            player.appendChild(iframe);
                            return true;
                        }
                        return false;
                    };

                    function checkUrlAndBlock() {
                        var href = window.location.href;
                        var vid = getVid(href);
                        if (window.YoutubMBridge && window.YoutubMBridge.notifyUrl) {
                            window.YoutubMBridge.notifyUrl(href);
                        }

                        var text = document.body ? document.body.innerText : '';
                        var hasBotBlock = text.indexOf("confirm you're not a bot") !== -1 ||
                                          text.indexOf("برنامج روبوت") !== -1 ||
                                          text.indexOf("Sign in to confirm") !== -1;

                        if (hasBotBlock && vid) {
                            window.replacePlayerOnPage(vid);
                            if (window.YoutubMBridge && window.YoutubMBridge.notifyBotBlock) {
                                window.YoutubMBridge.notifyBotBlock(vid);
                            }
                        }
                    }

                    var origPush = history.pushState;
                    history.pushState = function() {
                        var res = origPush.apply(this, arguments);
                        setTimeout(checkUrlAndBlock, 100);
                        return res;
                    };

                    var origReplace = history.replaceState;
                    history.replaceState = function() {
                        var res = origReplace.apply(this, arguments);
                        setTimeout(checkUrlAndBlock, 100);
                        return res;
                    };

                    window.addEventListener('popstate', checkUrlAndBlock);
                    window.addEventListener('hashchange', checkUrlAndBlock);
                    window.addEventListener('yt-navigate-finish', checkUrlAndBlock);

                    setInterval(checkUrlAndBlock, 1000);
                    checkUrlAndBlock();
                }
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    // تحديث نمط العرض عند تغيير إعدادات OLED أو Clean Shield
    LaunchedEffect(isOledBlackMode, isCleanShieldEnabled, autoDismissLoginBanners, autoBypassBotBlock) {
        webViewRef?.let { injectMagicStyles(it) }
    }

    // مشاركة رابط الفيديو الحالي
    fun shareCurrentUrl() {
        val url = currentUrl
        val intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "شاهد عبر youtub M:\n$url")
            type = "text/plain"
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة رابط الفيديو"))
    }

    // فتح الرابط في المتصفح الخارجي
    fun openInExternalBrowser() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر فتح المتصفح", Toast.LENGTH_SHORT).show()
        }
    }

    // التحويل الفوري لوضع التضمين المباشر الخالي من تسجيل الدخول
    fun switchVideoEmbedMode(videoId: String, toEmbed: Boolean) {
        if (toEmbed) {
            val embedUrl = "https://www.youtube-nocookie.com/embed/$videoId?autoplay=1&playsinline=1&modestbranding=1"
            webViewRef?.loadUrl(embedUrl)
            Toast.makeText(context, "تم تفعيل مشغل التضمين المباشر (بدون تسجيل دخول) ⚡", Toast.LENGTH_SHORT).show()
        } else {
            val normalUrl = "https://m.youtube.com/watch?v=$videoId"
            webViewRef?.loadUrl(normalUrl)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // شريط العنوان الزجاجي الفاخر مع زر البحث والإعدادات السحرية
            if (!isFullscreen) {
                Surface(
                    color = Color.Black,
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .shadow(8.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // شعار youtub M
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        webViewRef?.loadUrl("https://m.youtube.com")
                                    }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0xFFFF0000), Color(0xFFCC0000))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "شعار youtub M",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "youtub",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.White,
                                            letterSpacing = (-0.5).sp
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color(0xFFFF0000))
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = "M",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Black,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }

                            // أزرار التحكم السريعة
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                IconButton(
                                    onClick = { webViewRef?.goBack() },
                                    enabled = canGoBackState,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "رجوع",
                                        tint = if (canGoBackState) Color.White else Color.White.copy(alpha = 0.3f),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { webViewRef?.goForward() },
                                    enabled = canGoForwardState,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = "تقدم",
                                        tint = if (canGoForwardState) Color.White else Color.White.copy(alpha = 0.3f),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { showQuickSearch = !showQuickSearch },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "بحث سريع",
                                        tint = if (showQuickSearch) Color(0xFFFF0000) else Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { webViewRef?.reload() },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "تحديث",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                // زر فوري لتخطي فحص الروبوت وتبديل المشغل
                                IconButton(
                                    onClick = {
                                        if (currentVideoId != null) {
                                            switchVideoEmbedMode(currentVideoId, !isCurrentlyInEmbedMode)
                                        } else {
                                            webViewRef?.evaluateJavascript("if (window.replacePlayerOnPage) window.replacePlayerOnPage();", null)
                                            Toast.makeText(context, "جاري فحص وتخطي أي حظر...", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FlashOn,
                                        contentDescription = "تخطي قيود الفيديو",
                                        tint = if (isCurrentlyInEmbedMode) Color(0xFF4CAF50) else Color(0xFFFFD700),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { showMagicMenu = true },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "اللمسات السحرية",
                                        tint = Color(0xFFFF0000),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        // لافتة ذكية وسحرية: تظهر عند تشغيل أي فيديو لتخطي فحص الروبوت بضغطة زر
                        if (currentVideoId != null) {
                            Surface(
                                color = if (isCurrentlyInEmbedMode) Color(0xFF16381D) else Color(0xFF2C1014),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = if (isCurrentlyInEmbedMode) Icons.Default.LockOpen else Icons.Default.FlashOn,
                                            contentDescription = null,
                                            tint = if (isCurrentlyInEmbedMode) Color(0xFF4CAF50) else Color(0xFFFF5252),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isCurrentlyInEmbedMode)
                                                "مشغل التضمين المستقل نشط (بدون تسجيل دخول أو فحص)"
                                            else
                                                "يطلب تسجيل الدخول أو فحص روبوت؟",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    if (isCurrentlyInEmbedMode) {
                                        Surface(
                                            color = Color(0xFF2E7D32),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.clickable {
                                                switchVideoEmbedMode(currentVideoId, false)
                                            }
                                        ) {
                                            Text(
                                                text = "الوضع العادي ↩",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    } else {
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            // 1. استبدال المشغل داخل نفس الصفحة
                                            Surface(
                                                color = Color(0xFF333333),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.clickable {
                                                    webViewRef?.evaluateJavascript(
                                                        "if(window.replacePlayerOnPage) window.replacePlayerOnPage('$currentVideoId');",
                                                        null
                                                    )
                                                    Toast.makeText(context, "جاري استبدال المشغل بمشغل خالي من القيود...", Toast.LENGTH_SHORT).show()
                                                }
                                            ) {
                                                Text(
                                                    text = "استبدال المشغل 🛠️",
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                                )
                                            }

                                            // 2. التحويل للمشغل المستقل
                                            Surface(
                                                color = Color(0xFFFF0000),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.clickable {
                                                    switchVideoEmbedMode(currentVideoId, true)
                                                }
                                            ) {
                                                Text(
                                                    text = "تخطي ⚡",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = Color.White,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // حقل البحث السريع المنبثق
                        AnimatedVisibility(
                            visible = showQuickSearch,
                            enter = slideInVertically() + fadeIn(),
                            exit = slideOutVertically() + fadeOut()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder = { Text("ابحث في YouTube...", fontSize = 13.sp, color = Color.Gray) },
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = Color(0xFF1E1E1E),
                                        unfocusedContainerColor = Color(0xFF1E1E1E),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedIndicatorColor = Color(0xFFFF0000),
                                        unfocusedIndicatorColor = Color.Transparent
                                    ),
                                    shape = RoundedCornerShape(24.dp),
                                    singleLine = true,
                                    trailingIcon = {
                                        if (searchQuery.isNotBlank()) {
                                            IconButton(onClick = {
                                                val encoded = Uri.encode(searchQuery)
                                                webViewRef?.loadUrl("https://m.youtube.com/results?search_query=$encoded")
                                                showQuickSearch = false
                                            }) {
                                                Icon(
                                                    imageVector = Icons.Default.Search,
                                                    contentDescription = "بحث",
                                                    tint = Color(0xFFFF0000)
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp)
                                )
                            }
                        }

                        // شريط تصنيفات وأقسام YouTube السريعة
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            QuickCategoryChip(
                                icon = Icons.Default.Home,
                                label = "الرئيسية",
                                onClick = { webViewRef?.loadUrl("https://m.youtube.com") }
                            )
                            QuickCategoryChip(
                                icon = Icons.Default.Speed,
                                label = "Shorts ⚡",
                                onClick = { webViewRef?.loadUrl("https://m.youtube.com/shorts") }
                            )
                            QuickCategoryChip(
                                icon = Icons.Default.Whatshot,
                                label = "الرائج 🔥",
                                onClick = { webViewRef?.loadUrl("https://m.youtube.com/feed/trending") }
                            )
                            QuickCategoryChip(
                                icon = Icons.Default.VideoLibrary,
                                label = "الاشتراكات",
                                onClick = { webViewRef?.loadUrl("https://m.youtube.com/feed/subscriptions") }
                            )
                            QuickCategoryChip(
                                icon = Icons.Default.PlayArrow,
                                label = "الموسيقى 🎵",
                                onClick = { webViewRef?.loadUrl("https://m.youtube.com/channel/UC-9-kyTW8ZkZNDHQJ6FgpwQ") }
                            )
                            QuickCategoryChip(
                                icon = Icons.Default.VideoLibrary,
                                label = "المكتبة 📚",
                                onClick = { webViewRef?.loadUrl("https://m.youtube.com/feed/library") }
                            )
                        }

                        // شريط تحميل أحمر نيون متحرك مثل يوتيوب الرسمي
                        if (isLoading) {
                            LinearProgressIndicator(
                                progress = { loadingProgress },
                                color = Color(0xFFFF0000),
                                trackColor = Color(0x33FF0000),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(2.5.dp)
                            )
                        }
                    }
                }
            }

            // نافذة العرض الأساسية لـ WebView
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            // تهيئة إدارة الكوكيز الرسمية والطرف الثالث
                            val cookieManager = CookieManager.getInstance()
                            cookieManager.setAcceptCookie(true)
                            cookieManager.setAcceptThirdPartyCookies(this, true)

                            // حقن كوكيز الموافقة الرسمية لتخطي نوافذ الترحيب وتسجيل الدخول
                            try {
                                cookieManager.setCookie("https://m.youtube.com", "CONSENT=YES+cb; domain=.youtube.com; path=/")
                                cookieManager.setCookie("https://youtube.com", "CONSENT=YES+cb; domain=.youtube.com; path=/")
                                cookieManager.setCookie("https://m.youtube.com", "SOCS=CAESEwgDEgk2MTQyNjYzNjcaAmVuIAEaBgiA_LyaBg; domain=.youtube.com; path=/")
                            } catch (e: Exception) {
                                // تجاهل في حالة عدم دعمها
                            }

                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                loadWithOverviewMode = true
                                useWideViewPort = true
                                cacheMode = WebSettings.LOAD_DEFAULT

                                // تفعيل التكبير والتصغير بالإصبع
                                setSupportZoom(true)
                                builtInZoomControls = true
                                displayZoomControls = false

                                setSupportMultipleWindows(true)
                                javaScriptCanOpenWindowsAutomatically = true
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

                                // نستخدم معرّف متصفح Chrome النقي الأصلي لمنع نظام الحماية من الروبوتات
                                userAgentString = CHROME_MOBILE_UA
                            }

                            // تسجيل جسر التواصل مع JavaScript لتتبع التنقل الفوري وتخطي الروبوت
                            addJavascriptInterface(
                                YoutubMBridge(
                                    onUrlChanged = { newUrl ->
                                        activity?.runOnUiThread {
                                            if (currentUrl != newUrl) {
                                                currentUrl = newUrl
                                            }
                                        }
                                    },
                                    onBotBlocked = { videoId ->
                                        activity?.runOnUiThread {
                                            if (autoBypassBotBlock && videoId.isNotBlank()) {
                                                switchVideoEmbedMode(videoId, true)
                                            }
                                        }
                                    }
                                ),
                                "YoutubMBridge"
                            )

                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    val url = request?.url?.toString().orEmpty()
                                    val isExternalIntent = url.startsWith("intent://") ||
                                        url.startsWith("vnd.youtube:") ||
                                        url.startsWith("market://") ||
                                        url.contains("play.google.com/store")
                                    return isExternalIntent
                                }

                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    isLoading = true
                                    url?.let { currentUrl = it }
                                    view?.let { injectMagicStyles(it) }
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    isLoading = false
                                    canGoBackState = view?.canGoBack() == true
                                    canGoForwardState = view?.canGoForward() == true
                                    url?.let { currentUrl = it }
                                    // تطبيق النمط السحري وتخطي النوافذ
                                    view?.let { injectMagicStyles(it) }
                                }
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    loadingProgress = newProgress / 100f
                                    if (newProgress >= 25) {
                                        view?.let { injectMagicStyles(it) }
                                    }
                                    if (newProgress >= 100) {
                                        isLoading = false
                                        view?.let { injectMagicStyles(it) }
                                    }
                                }

                                // دعم ملء الشاشة الكامل HTML5 لجميع مقاطع الفيديو
                                override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                                    customFullscreenView = view
                                    customViewCallback = callback
                                    activity?.let { act ->
                                        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                        val windowInsetsController = WindowCompat.getInsetsController(act.window, act.window.decorView)
                                        windowInsetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                                        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())
                                    }
                                }

                                override fun onHideCustomView() {
                                    customViewCallback?.onCustomViewHidden()
                                    customFullscreenView = null
                                    customViewCallback = null
                                    activity?.let { act ->
                                        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                        val windowInsetsController = WindowCompat.getInsetsController(act.window, act.window.decorView)
                                        windowInsetsController.show(WindowInsetsCompat.Type.systemBars())
                                    }
                                }

                                override fun onCreateWindow(
                                    view: WebView?,
                                    isDialog: Boolean,
                                    isUserGesture: Boolean,
                                    resultMsg: android.os.Message?
                                ): Boolean {
                                    val newWebView = WebView(ctx).apply {
                                        settings.javaScriptEnabled = true
                                        webViewClient = object : WebViewClient() {
                                            override fun shouldOverrideUrlLoading(
                                                v: WebView?,
                                                req: WebResourceRequest?
                                            ): Boolean {
                                                req?.url?.let { uri ->
                                                    view?.loadUrl(uri.toString())
                                                }
                                                return true
                                            }
                                        }
                                    }
                                    val transport = resultMsg?.obj as? WebView.WebViewTransport
                                    transport?.webView = newWebView
                                    resultMsg?.sendToTarget()
                                    return true
                                }
                            }

                            loadUrl("https://m.youtube.com")
                            webViewRef = this
                        }
                    },
                    update = { view ->
                        canGoBackState = view.canGoBack()
                        canGoForwardState = view.canGoForward()
                    }
                )

                // مؤشر تحميل دائري أحمر عند الفتح لأول مرة
                if (isLoading && loadingProgress < 0.2f) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                color = Color(0xFFFF0000),
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(42.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "جاري تحميل youtub M...",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        // عارض وضع ملء الشاشة الكامل للفيديو (Full Screen Video Overlay)
        if (customFullscreenView != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = {
                        FrameLayout(it).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            customFullscreenView?.let { cv ->
                                (cv.parent as? ViewGroup)?.removeView(cv)
                                addView(cv, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            }
                        }
                    }
                )

                // زر إغلاق وضع ملء الشاشة
                IconButton(
                    onClick = {
                        customViewCallback?.onCustomViewHidden()
                        customFullscreenView = null
                        customViewCallback = null
                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.65f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق ملء الشاشة",
                        tint = Color.White
                    )
                }
            }
        }

        // القائمة السحرية المتطورة (Magic Bottom Sheet)
        if (showMagicMenu) {
            ModalBottomSheet(
                onDismissRequest = { showMagicMenu = false },
                sheetState = rememberModalBottomSheetState(),
                containerColor = Color(0xFF141414),
                contentColor = Color.White,
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .padding(bottom = 32.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color(0xFFFF0000),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "لمسات youtub M السحرية",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        IconButton(onClick = { showMagicMenu = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق", tint = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 1. خيار تخطي تسجيل الدخول والنوافذ المنبثقة
                    MagicSettingItem(
                        icon = Icons.Default.LockOpen,
                        title = "تخطي تسجيل الدخول الإجباري",
                        subtitle = "إغلاق وإخفاء نوافذ تسجيل الدخول المنبثقة واللافتات الترويجية تلقائياً",
                        trailing = {
                            Switch(
                                checked = autoDismissLoginBanners,
                                onCheckedChange = {
                                    autoDismissLoginBanners = it
                                    webViewRef?.let { wv -> injectMagicStyles(wv) }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFFFF0000)
                                )
                            )
                        }
                    )

                    HorizontalDivider(color = Color(0xFF262626), modifier = Modifier.padding(vertical = 10.dp))

                    // 2. خيار التخطي التلقائي الذكي لفحص الروبوت
                    MagicSettingItem(
                        icon = Icons.Default.FlashOn,
                        title = "تخطي فحص الروبوت الذكي (Anti-Bot Bypass)",
                        subtitle = "تجاوز شاشة 'Confirm you're not a bot' واستبدال المشغل فوراً بمشغل حر لتشغيل الفيديو بدون توقف",
                        trailing = {
                            Switch(
                                checked = autoBypassBotBlock,
                                onCheckedChange = {
                                    autoBypassBotBlock = it
                                    webViewRef?.let { wv -> injectMagicStyles(wv) }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFFFF0000)
                                )
                            )
                        }
                    )

                    HorizontalDivider(color = Color(0xFF262626), modifier = Modifier.padding(vertical = 10.dp))

                    // 3. خيار وضع OLED الأسود الفاحم
                    MagicSettingItem(
                        icon = Icons.Default.DarkMode,
                        title = "وضع OLED الأسود الحقيقي",
                        subtitle = "يحول رمادي يوتيوب إلى أسود فاحم نقي #000000 لتوفير البطارية وراحة العينين",
                        trailing = {
                            Switch(
                                checked = isOledBlackMode,
                                onCheckedChange = {
                                    isOledBlackMode = it
                                    webViewRef?.let { wv -> injectMagicStyles(wv) }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFFFF0000)
                                )
                            )
                        }
                    )

                    HorizontalDivider(color = Color(0xFF262626), modifier = Modifier.padding(vertical = 10.dp))

                    // 3. خيار وضع المشاهدة النقية Clean Shield
                    MagicSettingItem(
                        icon = Icons.Default.Shield,
                        title = "درع المشاهدة النقية",
                        subtitle = "إخفاء لافتات 'افتح في التطبيق' والرسائل المنبثقة المزعجة",
                        trailing = {
                            Switch(
                                checked = isCleanShieldEnabled,
                                onCheckedChange = {
                                    isCleanShieldEnabled = it
                                    webViewRef?.let { wv -> injectMagicStyles(wv) }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFFFF0000)
                                )
                            )
                        }
                    )

                    HorizontalDivider(color = Color(0xFF262626), modifier = Modifier.padding(vertical = 10.dp))

                    // 4. خيار التبديل بين الهاتف وسطح المكتب Desktop View
                    MagicSettingItem(
                        icon = if (isDesktopMode) Icons.Default.DesktopMac else Icons.Default.Smartphone,
                        title = if (isDesktopMode) "وضع سطح المكتب مفعل (Desktop)" else "وضع الهاتف الذكي (Mobile)",
                        subtitle = "يتيح تصفح واجهة يوتيوب للكمبيوتر بدقة فائقة وميزات موسعة",
                        trailing = {
                            Switch(
                                checked = isDesktopMode,
                                onCheckedChange = { enabled ->
                                    isDesktopMode = enabled
                                    webViewRef?.let { wv ->
                                        wv.settings.userAgentString = if (enabled) CHROME_DESKTOP_UA else CHROME_MOBILE_UA
                                        wv.reload()
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFFFF0000)
                                )
                            )
                        }
                    )

                    HorizontalDivider(color = Color(0xFF262626), modifier = Modifier.padding(vertical = 10.dp))

                    // 5. أزرار المشاركة والفتح الخارجي
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = Color(0xFF222222),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    shareCurrentUrl()
                                    showMagicMenu = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "مشاركة الرابط", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        Surface(
                            color = Color(0xFF222222),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    openInExternalBrowser()
                                    showMagicMenu = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.OpenInBrowser, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "فتح بالمتصفح", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickCategoryChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        color = Color(0xFF1F1F1F),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .clickable(onClick = onClick)
            .border(1.dp, Color(0xFF333333), RoundedCornerShape(16.dp))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color(0xFFFF0000),
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
private fun MagicSettingItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF262626)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFFFF0000),
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Color(0xFFAAAAAA),
                    lineHeight = 15.sp
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        trailing()
    }
}
