package com.example.vocalseparator.data

import android.content.Context
import android.net.Uri
import com.example.vocalseparator.audio.AudioDecoder
import com.example.vocalseparator.audio.SourceSeparationEngine
import com.example.vocalseparator.audio.WavAudioWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class AudioRepository(
    private val context: Context,
    private val database: AppDatabase
) {
    val separationDao: SeparationDao = database.separationDao()
    private val decoder = AudioDecoder(context)
    private val engine = SourceSeparationEngine(context)
    private val wavWriter = WavAudioWriter(context)

    fun getSeparations(): Flow<List<SeparationRecord>> = separationDao.getAllSeparations()

    fun extractMetadata(uri: Uri): AudioDecoder.AudioMetadata = decoder.extractMetadata(uri)

    suspend fun separateAudio(
        uri: Uri,
        onProgress: suspend (SourceSeparationEngine.SeparationProgress) -> Unit
    ): SeparationRecord = withContext(Dispatchers.Default) {
        val metadata = decoder.extractMetadata(uri)

        // Step 1: Decode input audio to temporary PCM file
        onProgress(
            SourceSeparationEngine.SeparationProgress(
                stage = SourceSeparationEngine.Stage.DECODING_AUDIO,
                progressPercent = 5,
                elapsedSeconds = 0,
                estimatedRemainingSeconds = 0,
                currentChunk = 0,
                totalChunks = 100
            )
        )

        val decodedData = decoder.decodeToPcmFile(uri) { decodeFraction ->
            val decodePercent = (5 + decodeFraction * 15).toInt()
            onProgress(
                SourceSeparationEngine.SeparationProgress(
                    stage = SourceSeparationEngine.Stage.DECODING_AUDIO,
                    progressPercent = decodePercent,
                    elapsedSeconds = 0,
                    estimatedRemainingSeconds = 0,
                    currentChunk = (decodeFraction * 100).toInt(),
                    totalChunks = 100
                )
            )
        }

        // Step 2: Run Neural DSP separation
        val result = engine.separatePcmFile(
            rawPcmFile = decodedData.pcmFile,
            sampleRate = decodedData.sampleRate,
            durationMs = decodedData.durationMs,
            totalFrames = decodedData.totalSampleCount,
            onProgress = { sepProgress ->
                // Scale progress from 20% to 100%
                val scaledPercent = (20 + (sepProgress.progressPercent * 0.8f)).toInt().coerceIn(20, 100)
                onProgress(
                    sepProgress.copy(
                        progressPercent = scaledPercent
                    )
                )
            }
        )

        // Step 3: Insert into Room database
        val record = SeparationRecord(
            title = metadata.title,
            artist = metadata.artist,
            durationMs = result.durationMs,
            originalFilePath = result.originalFile.absolutePath,
            vocalsFilePath = result.vocalsFile.absolutePath,
            instrumentalFilePath = result.instrumentalFile.absolutePath,
            sampleRate = result.sampleRate,
            fileSizeBytes = metadata.fileSizeBytes
        )

        val insertedId = separationDao.insertSeparation(record)
        record.copy(id = insertedId)
    }

    suspend fun exportTrackToMusicFolder(file: File, trackTitle: String): Uri? {
        return wavWriter.exportToMediaStore(file, trackTitle)
    }

    fun getShareUri(file: File): Uri {
        return wavWriter.getSharableUri(file)
    }

    suspend fun deleteSeparation(record: SeparationRecord) = withContext(Dispatchers.IO) {
        try { File(record.originalFilePath).delete() } catch (_: Exception) {}
        try { File(record.vocalsFilePath).delete() } catch (_: Exception) {}
        try { File(record.instrumentalFilePath).delete() } catch (_: Exception) {}
        separationDao.deleteSeparation(record)
    }
}
