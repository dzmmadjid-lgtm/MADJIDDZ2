package com.example.ui.components

import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.SeparationEntity
import com.example.player.MultiTrackPlayer
import com.example.player.MultiTrackPlayerState
import java.io.File

@Composable
fun MultiTrackStudioView(
    separation: SeparationEntity,
    player: MultiTrackPlayer,
    playerState: MultiTrackPlayerState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("multi_track_studio_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Title & Duration
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = separation.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "فُصل بـ: ${separation.modelName} • وقت الاستدلال: ${separation.inferenceTimeMs}ms",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF10B981).copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "استوديو متعدد المسارات",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF10B981)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Master Transport: Play/Pause and Seek Bar
            MasterTransportControl(
                player = player,
                playerState = playerState
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Channel 1: Vocals Stem
            StemChannelRow(
                title = "صوت الغناء (Vocals)",
                icon = Icons.Default.Mic,
                accentColor = Color(0xFF8B5CF6), // Purple
                volume = playerState.vocalsVolume,
                isMuted = playerState.isVocalsMuted,
                isSolo = playerState.isVocalsSolo,
                onVolumeChange = { player.setVocalsVolume(it) },
                onToggleMute = { player.toggleVocalsMute() },
                onToggleSolo = { player.toggleVocalsSolo() },
                onShare = { shareAudioFile(context, File(separation.vocalsPath), "مشاركة مسار الغناء") },
                testTagPrefix = "vocals"
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Channel 2: Instrumental Stem
            StemChannelRow(
                title = "الموسيقى والمؤثرات (Instrumental)",
                icon = Icons.Default.MusicNote,
                accentColor = Color(0xFF06B6D4), // Cyan
                volume = playerState.instrumentalVolume,
                isMuted = playerState.isInstrumentalMuted,
                isSolo = playerState.isInstrumentalSolo,
                onVolumeChange = { player.setInstrumentalVolume(it) },
                onToggleMute = { player.toggleInstrumentalMute() },
                onToggleSolo = { player.toggleInstrumentalSolo() },
                onShare = { shareAudioFile(context, File(separation.instrumentalPath), "مشاركة مسار الموسيقى") },
                testTagPrefix = "instrumental"
            )
        }
    }
}

@Composable
private fun MasterTransportControl(
    player: MultiTrackPlayer,
    playerState: MultiTrackPlayerState
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledTonalIconButton(
                onClick = { player.togglePlayPause() },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("master_play_pause_button"),
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Icon(
                    imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (playerState.isPlaying) "إيقاف مؤقت" else "تشغيل",
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Slider(
                    value = playerState.currentPositionMs.toFloat(),
                    onValueChange = { player.seekTo(it.toInt()) },
                    valueRange = 0f..maxOf(1f, playerState.totalDurationMs.toFloat()),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("timeline_slider"),
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatTime(playerState.currentPositionMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatTime(playerState.totalDurationMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun StemChannelRow(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    volume: Float,
    isMuted: Boolean,
    isSolo: Boolean,
    onVolumeChange: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onToggleSolo: () -> Unit,
    onShare: () -> Unit,
    testTagPrefix: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, if (isSolo) accentColor else Color.Transparent, RoundedCornerShape(12.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${(volume * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Slider(
                value = if (isMuted) 0f else volume,
                onValueChange = onVolumeChange,
                enabled = !isMuted,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("${testTagPrefix}_volume_slider"),
                colors = SliderDefaults.colors(
                    thumbColor = accentColor,
                    activeTrackColor = accentColor
                )
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Mute Toggle Button
        IconButton(
            onClick = onToggleMute,
            modifier = Modifier
                .size(34.dp)
                .testTag("${testTagPrefix}_mute_button"),
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = if (isMuted) Color(0xFFEF4444).copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Icon(
                imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                contentDescription = "كتم",
                tint = if (isMuted) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Solo Toggle Button
        Button(
            onClick = onToggleSolo,
            modifier = Modifier
                .height(34.dp)
                .testTag("${testTagPrefix}_solo_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isSolo) accentColor else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (isSolo) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            ),
            shape = RoundedCornerShape(8.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp)
        ) {
            Text("SOLO", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Share/Export Button
        IconButton(
            onClick = onShare,
            modifier = Modifier
                .size(34.dp)
                .testTag("${testTagPrefix}_share_button")
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "مشاركة المسار",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

private fun formatTime(millis: Int): String {
    val totalSeconds = millis / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%02d:%02d".format(minutes, seconds)
}

private fun shareAudioFile(context: Context, file: File, title: String) {
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/wav"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, title))
    } catch (e: Exception) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(Intent.EXTRA_TEXT, "تم فصل الصوت باستخدام نموذج الذكاء الاصطناعي العصبي: ${file.name}")
        }
        context.startActivity(Intent.createChooser(intent, title))
    }
}
