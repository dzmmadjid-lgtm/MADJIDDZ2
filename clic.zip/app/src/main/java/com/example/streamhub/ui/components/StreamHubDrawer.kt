package com.example.streamhub.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.streamhub.model.NavigationDestination
import com.example.streamhub.theme.AppThemeMode
import com.example.streamhub.theme.StreamTheme

@Composable
fun StreamHubDrawer(
    currentDestination: NavigationDestination,
    themeMode: AppThemeMode,
    onSelectDestination: (NavigationDestination) -> Unit,
    onSetThemeMode: (AppThemeMode) -> Unit,
    onCloseDrawer: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StreamTheme.colors

    Surface(
        color = colors.drawerBackground,
        modifier = modifier
            .fillMaxHeight()
            .width(320.dp)
            .statusBarsPadding()
            .navigationBarsPadding() // ضمان عدم تداخل أزرار الهاتف السفلية
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 24.dp)
        ) {
            // ترويسة الحساب (Header) المستوحاة من الصورة ولكن بلمسة سينمائية فائقة الإبهار
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                if (colors.isOled) Color(0xFF141724) else Color(0xFFF1F5F9),
                                colors.drawerBackground
                            )
                        )
                    )
                    .padding(horizontal = 20.dp, vertical = 24.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        // الصورة الرمزية للمستخدم (Avatar) بأبعاد وتوهج سينمائي
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            Color(0xFF6366F1),
                                            Color(0xFF8B5CF6),
                                            colors.primaryAccent
                                        )
                                    )
                                )
                                .border(
                                    width = 2.dp,
                                    color = if (colors.isOled) colors.secondaryAccent.copy(alpha = 0.5f) else Color.White,
                                    shape = RoundedCornerShape(16.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "SH",
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        IconButton(
                            onClick = onCloseDrawer,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(colors.surfaceVariant)
                                .testTag("btn_close_drawer")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = colors.textPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "StreamHub",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(colors.primaryAccent.copy(alpha = 0.2f))
                                .border(1.dp, colors.primaryAccent.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "VIP 4K",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.primaryAccent
                            )
                        }
                    }

                    Text(
                        text = "streamhub@app.com",
                        fontSize = 14.sp,
                        color = colors.textSecondary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            // عنصر اختيار الثيم السحري (OLED / النهاري) داخل القائمة مباشرة
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.surfaceVariant)
                    .border(1.dp, colors.cardBorder, RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "نمط العرض السحري",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeOptionButton(
                            title = "OLED فاحم",
                            icon = Icons.Default.DarkMode,
                            isSelected = themeMode == AppThemeMode.OLED,
                            accentColor = Color(0xFF00F0FF),
                            onClick = { onSetThemeMode(AppThemeMode.OLED) },
                            modifier = Modifier.weight(1f)
                        )

                        ThemeOptionButton(
                            title = "نهاري ناصع",
                            icon = Icons.Default.LightMode,
                            isSelected = themeMode == AppThemeMode.LIGHT,
                            accentColor = Color(0xFFE11D48),
                            onClick = { onSetThemeMode(AppThemeMode.LIGHT) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // عناصر التنقل الأساسية مطابقة لصورة المستخدم تماماً
            DrawerNavigationRow(
                label = "Home",
                icon = Icons.Default.Home,
                isSelected = currentDestination == NavigationDestination.HOME,
                testTag = "drawer_home",
                onClick = { onSelectDestination(NavigationDestination.HOME) }
            )

            DrawerNavigationRow(
                label = "Search",
                icon = Icons.Default.Search,
                isSelected = currentDestination == NavigationDestination.SEARCH,
                testTag = "drawer_search",
                onClick = { onSelectDestination(NavigationDestination.SEARCH) }
            )

            DrawerNavigationRow(
                label = "Library",
                icon = Icons.Default.VideoLibrary,
                isSelected = currentDestination == NavigationDestination.LIBRARY,
                testTag = "drawer_library",
                onClick = { onSelectDestination(NavigationDestination.LIBRARY) }
            )

            DrawerNavigationRow(
                label = "Profile",
                icon = Icons.Default.Person,
                isSelected = currentDestination == NavigationDestination.PROFILE,
                testTag = "drawer_profile",
                onClick = { onSelectDestination(NavigationDestination.PROFILE) }
            )

            // الفاصل وقسم الإعدادات كما في لقطة شاشة المستخدم
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 20.dp),
                color = colors.dividerColor,
                thickness = 1.dp
            )
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Settings",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textMuted,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )

            DrawerNavigationRow(
                label = "Settings",
                icon = Icons.Default.Settings,
                isSelected = currentDestination == NavigationDestination.SETTINGS,
                testTag = "drawer_settings",
                onClick = { onSelectDestination(NavigationDestination.SETTINGS) }
            )

            DrawerNavigationRow(
                label = "Help",
                icon = Icons.AutoMirrored.Filled.HelpOutline,
                isSelected = currentDestination == NavigationDestination.HELP,
                testTag = "drawer_help",
                onClick = { onSelectDestination(NavigationDestination.HELP) }
            )

            DrawerNavigationRow(
                label = "About",
                icon = Icons.Default.Info,
                isSelected = currentDestination == NavigationDestination.ABOUT,
                testTag = "drawer_about",
                onClick = { onSelectDestination(NavigationDestination.ABOUT) }
            )

            DrawerNavigationRow(
                label = "Logout",
                icon = Icons.AutoMirrored.Filled.ExitToApp,
                isSelected = false,
                isDestructive = true,
                testTag = "drawer_logout",
                onClick = onLogout
            )
        }
    }
}

@Composable
private fun ThemeOptionButton(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StreamTheme.colors

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) accentColor.copy(alpha = 0.15f) else Color.Transparent)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) accentColor else colors.cardBorder,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) accentColor else colors.textSecondary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) colors.textPrimary else colors.textSecondary
            )
            if (isSelected) {
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
private fun DrawerNavigationRow(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    isDestructive: Boolean = false,
    testTag: String,
    onClick: () -> Unit
) {
    val colors = StreamTheme.colors

    val itemBg = if (isSelected) {
        if (colors.isOled) colors.primaryAccent.copy(alpha = 0.15f) else colors.primaryAccent.copy(alpha = 0.1f)
    } else {
        Color.Transparent
    }

    val itemContentColor = when {
        isDestructive -> Color(0xFFEF4444)
        isSelected -> colors.primaryAccent
        else -> colors.textPrimary
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(itemBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                fontSize = 16.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = itemContentColor
            )

            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = itemContentColor,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
