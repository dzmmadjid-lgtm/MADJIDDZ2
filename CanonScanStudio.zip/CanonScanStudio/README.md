# CanonScan Studio

تطبيق أندرويد (Kotlin + Compose) للتحكم في ماسح Canon MF440 عبر USB أو Wi-Fi (eSCL)،
مع تعديل الصورة (قص، تدوير، تباين) وتصدير PDF.

البناء: `./gradlew assembleDebug`
