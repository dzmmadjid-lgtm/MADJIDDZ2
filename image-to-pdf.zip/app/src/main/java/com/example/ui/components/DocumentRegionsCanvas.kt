package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.data.model.RectNormalized
import com.example.data.model.RegionType
import com.example.data.model.TextRegion
import com.example.ui.theme.RegionGraphicColor
import com.example.ui.theme.RegionListColor
import com.example.ui.theme.RegionNumberColor
import com.example.ui.theme.RegionParagraphColor
import com.example.ui.theme.RegionTableCellColor
import com.example.ui.theme.RegionTitleColor
import kotlin.math.min

@Composable
fun DocumentRegionsCanvas(
    bitmap: Bitmap,
    regions: List<TextRegion>,
    selectedRegionId: String?,
    onRegionSelected: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E24)),
        contentAlignment = Alignment.Center
    ) {
        val containerWidth = maxWidth.value
        val containerHeight = maxHeight.value

        val imageAspect = bitmap.width.toFloat() / bitmap.height.toFloat()
        val containerAspect = containerWidth / containerHeight

        val displayWidth: Float
        val displayHeight: Float

        if (imageAspect > containerAspect) {
            displayWidth = containerWidth
            displayHeight = containerWidth / imageAspect
        } else {
            displayHeight = containerHeight
            displayWidth = containerHeight * imageAspect
        }

        Box(
            modifier = Modifier
                .size(displayWidth.dp, displayHeight.dp)
                .clip(RoundedCornerShape(8.dp))
        ) {
            // Document Image
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Document Scan",
                modifier = Modifier.fillMaxSize()
            )

            // Interactive Text Regions Overlay
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(regions, selectedRegionId) {
                        detectTapGestures { tapOffset ->
                            val normX = tapOffset.x / size.width
                            val normY = tapOffset.y / size.height

                            val tappedRegion = regions.find { region ->
                                val box = region.boundingBox
                                normX in box.left..box.right && normY in box.top..box.bottom
                            }

                            onRegionSelected(tappedRegion?.id)
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                for (region in regions) {
                    val isSelected = region.id == selectedRegionId
                    val box = region.boundingBox

                    val left = box.left * canvasWidth
                    val top = box.top * canvasHeight
                    val width = box.width * canvasWidth
                    val height = box.height * canvasHeight

                    val color = when (region.type) {
                        RegionType.TITLE -> RegionTitleColor
                        RegionType.PARAGRAPH -> RegionParagraphColor
                        RegionType.LIST_ITEM -> RegionListColor
                        RegionType.NUMBER -> RegionNumberColor
                        RegionType.TABLE_CELL -> RegionTableCellColor
                        RegionType.GRAPHIC_OR_PHOTO -> RegionGraphicColor
                        RegionType.SHORT_TEXT -> Color(0xFF00897B)
                    }

                    // Fill overlay
                    val fillAlpha = if (isSelected) 0.35f else if (region.isGraphic) 0.12f else 0.18f
                    drawRect(
                        color = color.copy(alpha = fillAlpha),
                        topLeft = Offset(left, top),
                        size = Size(width, height)
                    )

                    // Border outline
                    val strokeWidth = if (isSelected) 3.5f else 1.8f
                    drawRect(
                        color = if (isSelected) Color.White else color.copy(alpha = 0.85f),
                        topLeft = Offset(left, top),
                        size = Size(width, height),
                        style = Stroke(width = strokeWidth)
                    )

                    // Draw inner badge dot for region type
                    if (isSelected) {
                        drawCircle(
                            color = color,
                            radius = 6f,
                            center = Offset(left + 8f, top + 8f)
                        )
                    }
                }
            }
        }
    }
}
