package com.example.theme

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "click_school_settings")

enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK,
    OLED
}

class ThemePreferences(private val context: Context) {
    companion object {
        val THEME_MODE_KEY = stringPreferencesKey("app_theme_mode")
        val DEFAULT_PAGE_SIZE_KEY = stringPreferencesKey("default_page_size")
        val DEFAULT_IMAGE_FORMAT_KEY = stringPreferencesKey("default_image_format")
        val DEFAULT_IMAGE_QUALITY_KEY = intPreferencesKey("default_image_quality")
    }

    val themeMode: Flow<AppThemeMode> = context.dataStore.data.map { preferences ->
        when (preferences[THEME_MODE_KEY]) {
            "light" -> AppThemeMode.LIGHT
            "dark" -> AppThemeMode.DARK
            "oled" -> AppThemeMode.OLED
            else -> AppThemeMode.SYSTEM
        }
    }

    val defaultPageSize: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[DEFAULT_PAGE_SIZE_KEY] ?: "A4"
    }

    val defaultImageFormat: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[DEFAULT_IMAGE_FORMAT_KEY] ?: "JPG"
    }

    val defaultImageQuality: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[DEFAULT_IMAGE_QUALITY_KEY] ?: 90
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { preferences ->
            preferences[THEME_MODE_KEY] = when (mode) {
                AppThemeMode.LIGHT -> "light"
                AppThemeMode.DARK -> "dark"
                AppThemeMode.OLED -> "oled"
                AppThemeMode.SYSTEM -> "system"
            }
        }
    }

    suspend fun setDefaultPageSize(pageSize: String) {
        context.dataStore.edit { preferences ->
            preferences[DEFAULT_PAGE_SIZE_KEY] = pageSize
        }
    }

    suspend fun setDefaultImageFormat(format: String) {
        context.dataStore.edit { preferences ->
            preferences[DEFAULT_IMAGE_FORMAT_KEY] = format
        }
    }

    suspend fun setDefaultImageQuality(quality: Int) {
        context.dataStore.edit { preferences ->
            preferences[DEFAULT_IMAGE_QUALITY_KEY] = quality
        }
    }
}
