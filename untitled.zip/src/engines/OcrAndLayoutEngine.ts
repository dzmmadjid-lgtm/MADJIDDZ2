import {
  BorderProperties,
  createDefaultBorder,
  LayoutObjectType,
  MeasuredBox,
  PageLayoutObject,
  PipelineElementKind,
  TableCellModel,
  TextAlignment,
  TextDirection,
} from '../models/DocumentModel';
import { toWesternDigits } from './DocumentRenderer';
import { DetectedHandwritingLayer } from './ImagePreprocessor';
import { measureCleanedPageLayout } from './LayoutMeasurer';

export interface VisionAnalysisResult {
  objects: PageLayoutObject[];
  measuredBoxes: MeasuredBox[];
  margins: { top: number; right: number; bottom: number; left: number };
  usedServerVision: boolean;
  noticeAr?: string;
}

/**
 * Step 3: Cleans OCR scan noise inside words (e.g., "suivar tes" -> "suivantes")
 * without inventing content, and converts numerals to Western digits (0-9).
 */
export function cleanScanNoiseInText(rawText: string): string {
  if (!rawText) return '';
  let text = toWesternDigits(rawText);

  // Fix common scan-split word artifacts in French/English/Arabic
  const noiseReplacements: Array<[RegExp, string]> = [
    [/\bsuivar\s*tes\b/gi, 'suivantes'],
    [/\bques\s+tions\b/gi, 'questions'],
    [/\bdocu\s+ment\b/gi, 'document'],
    [/\brépon\s+ses\b/gi, 'réponses'],
    [/\bexer\s+cice\b/gi, 'exercice'],
    [/\bشها\s+دة\b/g, 'شهادة'],
    [/\bالمؤ\s+سسة\b/g, 'المؤسسة'],
    [/\bالوط\s+نية\b/g, 'الوطنية'],
  ];

  for (const [pattern, replacement] of noiseReplacements) {
    text = text.replace(pattern, replacement);
  }

  return text;
}

/**
 * FORBIDDEN RULE ENFORCEMENT:
 * Dotted lines must NEVER be typed dot characters ("....." or "……").
 * This function strips typed dot runs (>= 5 consecutive dots) from text blocks
 * and emits real vector DOTTED_LINE layout objects at their measured coordinates.
 */
export function convertTypedDotsToVectorDottedLines(
  objects: PageLayoutObject[]
): PageLayoutObject[] {
  const result: PageLayoutObject[] = [];

  for (const obj of objects) {
    const cleanedText = cleanScanNoiseInText(obj.content || '');
    const dotPattern = /([.…]{5,})/g;

    if (
      (obj.type === 'TEXT' || obj.type === 'PARAGRAPH' || obj.type === 'RECTANGLE') &&
      dotPattern.test(cleanedText)
    ) {
      const lines = cleanedText.split('\n');
      const keptTextLines: string[] = [];
      const lineCount = Math.max(1, lines.length);
      const lineHeightNorm = obj.height / lineCount;

      lines.forEach((line, lineIdx) => {
        const trimmed = line.trim();
        // If the entire line is just dots, convert the full line span into a real vector DOTTED_LINE
        if (/^[.…\s]+$/.test(trimmed) && trimmed.length >= 5) {
          keptTextLines.push('');
          const dotY = Math.round(obj.y + (lineIdx + 0.78) * lineHeightNorm);
          result.push({
            id: `${obj.id}_vec_dotted_${lineIdx}`,
            type: 'DOTTED_LINE',
            pipelineKind: 'dotted_line',
            x: obj.x + 12,
            y: dotY,
            width: Math.max(40, obj.width - 24),
            height: 3,
            content: '',
            confidence: 0.98,
            uncertainTokens: [],
            alignment: obj.alignment,
            direction: obj.direction,
            fontProperties: { ...obj.fontProperties },
            borderProperties: {
              top: { width: 1.5, style: 'dotted', color: '#334155' },
              right: { width: 0, style: 'none', color: 'transparent' },
              bottom: { width: 0, style: 'none', color: 'transparent' },
              left: { width: 0, style: 'none', color: 'transparent' },
            },
            backgroundProperties: { fill: 'transparent', opacity: 0 },
            zOrder: obj.zOrder + 1,
          });
        } else if (dotPattern.test(line)) {
          // Inline label + dotted fill line (e.g. "اسم التلميذ(ة): ....................")
          const withoutDots = line.replace(/[.…]{5,}/g, '                    ');
          keptTextLines.push(withoutDots);

          const dotY = Math.round(obj.y + (lineIdx + 0.78) * lineHeightNorm);
          const dotX = obj.direction === 'rtl' ? obj.x + 25 : obj.x + Math.round(obj.width * 0.32);
          const dotW = Math.round(obj.width * 0.36);

          result.push({
            id: `${obj.id}_inline_dotted_${lineIdx}`,
            type: 'DOTTED_LINE',
            pipelineKind: 'dotted_line',
            x: dotX,
            y: dotY,
            width: Math.max(50, dotW),
            height: 3,
            content: '',
            confidence: 0.98,
            uncertainTokens: [],
            alignment: obj.alignment,
            direction: obj.direction,
            fontProperties: { ...obj.fontProperties },
            borderProperties: {
              top: { width: 1.4, style: 'dotted', color: '#475569' },
              right: { width: 0, style: 'none', color: 'transparent' },
              bottom: { width: 0, style: 'none', color: 'transparent' },
              left: { width: 0, style: 'none', color: 'transparent' },
            },
            backgroundProperties: { fill: 'transparent', opacity: 0 },
            zOrder: obj.zOrder + 1,
          });
        } else {
          keptTextLines.push(line);
        }
      });

      result.push({
        ...obj,
        content: keptTextLines.join('\n'),
      });
    } else if (obj.type === 'TABLE' && obj.tableStructure) {
      result.push({
        ...obj,
        pipelineKind: 'table',
        tableStructure: {
          ...obj.tableStructure,
          cells: obj.tableStructure.cells.map((c) => ({
            ...c,
            content: cleanScanNoiseInText(c.content || '').replace(/[.…]{4,}/g, ''),
          })),
        },
      });
    } else {
      result.push({
        ...obj,
        content: cleanedText,
      });
    }
  }

  return result;
}

function mapVisionElementToLayoutObject(raw: any, index: number): PageLayoutObject {
  const rawKind = String(raw.type || 'text').toLowerCase() as PipelineElementKind;

  const typeMap: Record<string, LayoutObjectType> = {
    text: 'PARAGRAPH',
    line: 'LINE',
    dotted_line: 'DOTTED_LINE',
    table: 'TABLE',
    box: 'RECTANGLE',
    checkbox: 'CHECKBOX',
    drawing: 'DRAWING',
    handwriting: 'HANDWRITING',
  };

  const mappedType: LayoutObjectType =
    typeMap[rawKind] || ((raw.type as LayoutObjectType) ?? 'PARAGRAPH');

  const bbox = Array.isArray(raw.bbox) && raw.bbox.length === 4
    ? raw.bbox.map((n: any) => Number(n) || 0)
    : [
        Number(raw.x) || 60,
        Number(raw.y) || 60 + index * 65,
        Number(raw.width) || 880,
        Number(raw.height) || 45,
      ];

  const x = Math.max(0, Math.min(990, bbox[0]));
  const y = Math.max(0, Math.min(990, bbox[1]));
  const width = Math.max(8, Math.min(1000 - x, bbox[2]));
  const height = Math.max(3, Math.min(1000 - y, bbox[3]));

  const direction: TextDirection = raw.dir === 'ltr' || raw.direction === 'ltr' ? 'ltr' : 'rtl';
  const alignment: TextAlignment =
    raw.align === 'center' || raw.align === 'left' || raw.align === 'justify'
      ? raw.align
      : raw.alignment === 'center' || raw.alignment === 'left' || raw.alignment === 'justify'
      ? raw.alignment
      : direction === 'rtl'
      ? 'right'
      : 'left';

  const hasBox = mappedType === 'RECTANGLE' || mappedType === 'TABLE' || rawKind === 'box';
  const borderProps: BorderProperties =
    mappedType === 'DOTTED_LINE'
      ? {
          top: { width: 1.5, style: 'dotted', color: '#334155' },
          right: { width: 0, style: 'none', color: 'transparent' },
          bottom: { width: 0, style: 'none', color: 'transparent' },
          left: { width: 0, style: 'none', color: 'transparent' },
        }
      : mappedType === 'LINE'
      ? {
          top: { width: 1.5, style: 'solid', color: '#0F172A' },
          right: { width: 0, style: 'none', color: 'transparent' },
          bottom: { width: 0, style: 'none', color: 'transparent' },
          left: { width: 0, style: 'none', color: 'transparent' },
        }
      : hasBox
      ? createDefaultBorder(1.5, 'solid', '#0F172A')
      : createDefaultBorder(0);

  // Fit font size mathematically to measured bbox height and line count
  const cleanText = cleanScanNoiseInText(typeof raw.text === 'string' ? raw.text : raw.content || '');
  const lineCount = Math.max(1, cleanText.split('\n').length);
  const bboxHeightMm = (height / 1000) * 297;
  const fittedSizePt = Math.max(
    8.5,
    Math.min(22, Math.round(((bboxHeightMm / lineCount) * 2.15) * 10) / 10)
  );

  let tableStructure = undefined;
  if (mappedType === 'TABLE' && raw.tableData) {
    const rows = Math.max(1, Number(raw.tableData.rows) || 2);
    const cols = Math.max(1, Number(raw.tableData.cols) || 2);
    const rowHeights: number[] =
      Array.isArray(raw.tableData.rowHeights) && raw.tableData.rowHeights.length === rows
        ? raw.tableData.rowHeights
        : Array.from({ length: rows }, () => 1 / rows);
    const colWidths: number[] =
      Array.isArray(raw.tableData.colWidths) && raw.tableData.colWidths.length === cols
        ? raw.tableData.colWidths
        : Array.from({ length: cols }, () => 1 / cols);

    const cells: TableCellModel[] = Array.isArray(raw.tableData.cells)
      ? raw.tableData.cells.map((c: any, ci: number) => ({
          id: `cell_${index}_${ci}`,
          row: Number(c.row) || 0,
          col: Number(c.col) || 0,
          rowSpan: Math.max(1, Number(c.rowSpan) || 1),
          colSpan: Math.max(1, Number(c.colSpan) || 1),
          content: cleanScanNoiseInText(typeof c.text === 'string' ? c.text : c.content || ''),
          confidence: 0.96,
          alignment:
            c.align === 'center' || c.align === 'left'
              ? c.align
              : c.alignment === 'center' || c.alignment === 'left'
              ? c.alignment
              : 'right',
          verticalAlignment: 'middle',
          direction: c.dir === 'ltr' || c.direction === 'ltr' ? 'ltr' : 'rtl',
          padding: 5,
          fontSizePt: 10.5,
          fontWeight: c.font_weight === 'bold' || c.isHeader ? 'bold' : 'normal',
          borders: {
            top: {
              width: c.hasTopBorder !== false ? 1 : 0,
              style: c.hasTopBorder !== false ? 'solid' : 'none',
              color: '#1E293B',
            },
            right: {
              width: c.hasRightBorder !== false ? 1 : 0,
              style: c.hasRightBorder !== false ? 'solid' : 'none',
              color: '#1E293B',
            },
            bottom: {
              width: c.hasBottomBorder !== false ? 1 : 0,
              style: c.hasBottomBorder !== false ? 'solid' : 'none',
              color: '#1E293B',
            },
            left: {
              width: c.hasLeftBorder !== false ? 1 : 0,
              style: c.hasLeftBorder !== false ? 'solid' : 'none',
              color: '#1E293B',
            },
          },
          backgroundColor: c.isHeader ? '#F1F5F9' : 'transparent',
        }))
      : [];

    tableStructure = {
      rows,
      cols,
      rowHeights,
      colWidths,
      direction,
      cells,
    };
  }

  return {
    id: raw.id || `elem_${index + 1}`,
    type: mappedType,
    pipelineKind: rawKind,
    x,
    y,
    width,
    height,
    content: cleanText,
    lang: raw.lang || (direction === 'rtl' ? 'ar' : 'fr'),
    confidence: 0.95,
    uncertainTokens: [],
    alignment,
    direction,
    fontProperties: {
      family: direction === 'ltr' ? 'IBM Plex Sans Arabic' : 'Cairo',
      sizePt: Number(raw.estimatedFontSizePt) || fittedSizePt,
      weight: raw.font_weight === 'bold' || raw.fontWeight === 'bold' ? 'bold' : 'normal',
      style: raw.font_style === 'italic' ? 'italic' : 'normal',
      role: 'normal',
      color: '#0F172A',
      lineHeight: 1.35,
    },
    borderProperties: borderProps,
    backgroundProperties: {
      fill: raw.backgroundColor || 'transparent',
      opacity: raw.backgroundColor && raw.backgroundColor !== 'transparent' ? 1 : 0,
    },
    zOrder: index + 1,
    checked: Boolean(raw.checked),
    svgPathData: raw.svgPath || undefined,
    tableStructure,
  };
}

/**
 * Converts measured morphological boxes (Step 2) directly into structured layout objects
 * when operating offline.
 */
function buildObjectsFromMeasuredBoxes(measuredBoxes: MeasuredBox[]): PageLayoutObject[] {
  return measuredBoxes.map((mb, idx) => {
    const [x, y, width, height] = mb.bbox;

    if (mb.kind === 'table' && mb.tableGrid) {
      const { rows, cols, rowHeights, colWidths } = mb.tableGrid;
      const cells: TableCellModel[] = [];
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          cells.push({
            id: `mcell_${idx}_${r}_${c}`,
            row: r,
            col: c,
            rowSpan: 1,
            colSpan: 1,
            content: '',
            confidence: 0.92,
            alignment: 'center',
            verticalAlignment: 'middle',
            direction: 'rtl',
            padding: 5,
            fontSizePt: 10,
            fontWeight: r === 0 ? 'bold' : 'normal',
            borders: createDefaultBorder(1, 'solid', '#1E293B'),
            backgroundColor: r === 0 ? '#F1F5F9' : 'transparent',
          });
        }
      }
      return {
        id: mb.id,
        type: 'TABLE',
        pipelineKind: 'table',
        x,
        y,
        width,
        height,
        content: '',
        confidence: 0.94,
        uncertainTokens: [],
        alignment: 'right',
        direction: 'rtl',
        fontProperties: {
          family: 'Cairo',
          sizePt: 10.5,
          weight: 'normal',
          role: 'table',
          color: '#0F172A',
          lineHeight: 1.3,
        },
        borderProperties: createDefaultBorder(1.5, 'solid', '#0F172A'),
        backgroundProperties: { fill: '#FFFFFF', opacity: 1 },
        zOrder: idx + 1,
        tableStructure: {
          rows,
          cols,
          rowHeights,
          colWidths,
          direction: 'rtl',
          cells,
        },
      };
    }

    if (mb.kind === 'dotted_line') {
      return {
        id: mb.id,
        type: 'DOTTED_LINE',
        pipelineKind: 'dotted_line',
        x,
        y,
        width,
        height: Math.max(3, height),
        content: '',
        confidence: 0.98,
        uncertainTokens: [],
        alignment: 'right',
        direction: 'rtl',
        fontProperties: {
          family: 'Cairo',
          sizePt: 10,
          weight: 'normal',
          role: 'normal',
          color: '#0F172A',
          lineHeight: 1.2,
        },
        borderProperties: {
          top: { width: 1.5, style: 'dotted', color: '#334155' },
          right: { width: 0, style: 'none', color: 'transparent' },
          bottom: { width: 0, style: 'none', color: 'transparent' },
          left: { width: 0, style: 'none', color: 'transparent' },
        },
        backgroundProperties: { fill: 'transparent', opacity: 0 },
        zOrder: idx + 1,
      };
    }

    if (mb.kind === 'line') {
      return {
        id: mb.id,
        type: 'LINE',
        pipelineKind: 'line',
        x,
        y,
        width,
        height: Math.max(2, height),
        content: '',
        confidence: 0.98,
        uncertainTokens: [],
        alignment: 'center',
        direction: 'rtl',
        fontProperties: {
          family: 'Cairo',
          sizePt: 10,
          weight: 'normal',
          role: 'normal',
          color: '#0F172A',
          lineHeight: 1,
        },
        borderProperties: {
          top: { width: 1.5, style: 'solid', color: '#0F172A' },
          right: { width: 0, style: 'none', color: 'transparent' },
          bottom: { width: 0, style: 'none', color: 'transparent' },
          left: { width: 0, style: 'none', color: 'transparent' },
        },
        backgroundProperties: { fill: 'transparent', opacity: 0 },
        zOrder: idx + 1,
      };
    }

    if (mb.kind === 'checkbox') {
      return {
        id: mb.id,
        type: 'CHECKBOX',
        pipelineKind: 'box',
        x,
        y,
        width,
        height,
        content: '',
        checked: Boolean(mb.checked),
        confidence: 0.97,
        uncertainTokens: [],
        alignment: 'right',
        direction: 'rtl',
        fontProperties: {
          family: 'Cairo',
          sizePt: 10.5,
          weight: 'normal',
          role: 'normal',
          color: '#0F172A',
          lineHeight: 1.2,
        },
        borderProperties: createDefaultBorder(1.5, 'solid', '#0F172A'),
        backgroundProperties: { fill: 'transparent', opacity: 0 },
        zOrder: idx + 1,
      };
    }

    if (mb.kind === 'handwriting') {
      return {
        id: mb.id,
        type: 'HANDWRITING',
        pipelineKind: 'handwriting',
        x,
        y,
        width,
        height,
        content: 'خط يدوي مكتشف',
        croppedImageDataUrl: mb.croppedImageDataUrl,
        confidence: 0.96,
        uncertainTokens: [],
        alignment: 'right',
        direction: 'rtl',
        fontProperties: {
          family: 'Cairo',
          sizePt: 10,
          weight: 'normal',
          role: 'normal',
          color: '#1D4ED8',
          lineHeight: 1.2,
        },
        borderProperties: createDefaultBorder(0),
        backgroundProperties: { fill: 'transparent', opacity: 0 },
        zOrder: idx + 10,
      };
    }

    return {
      id: mb.id,
      type: mb.kind === 'box' ? 'RECTANGLE' : 'PARAGRAPH',
      pipelineKind: mb.kind === 'box' ? 'box' : 'text',
      x,
      y,
      width,
      height,
      content: '',
      confidence: 0.85,
      uncertainTokens: [],
      alignment: 'right',
      direction: 'rtl',
      fontProperties: {
        family: 'Cairo',
        sizePt: 11.5,
        weight: 'normal',
        role: 'normal',
        color: '#0F172A',
        lineHeight: 1.35,
      },
      borderProperties:
        mb.kind === 'box' ? createDefaultBorder(1.5, 'solid', '#0F172A') : createDefaultBorder(0),
      backgroundProperties: { fill: 'transparent', opacity: 0 },
      zOrder: idx + 1,
    };
  });
}

/**
 * Step 2 (MEASURE) + Step 3 (EXTRACT) + Step 4 (HANDWRITING attachment):
 * Measures all geometric objects in 0..1000 coordinates first, then extracts
 * text and structured table cells anchored to those measured bounding boxes.
 */
export async function analyzeDocumentWithVisionEngine(
  preprocessedImageDataUrl: string,
  presetObjects?: PageLayoutObject[],
  handwritingLayers: DetectedHandwritingLayer[] = []
): Promise<VisionAnalysisResult> {
  // Always run Step 2 morphological measurement on the cleaned image
  const measurement = await measureCleanedPageLayout(
    preprocessedImageDataUrl,
    handwritingLayers
  );

  if (presetObjects && presetObjects.length > 0) {
    const cloned = presetObjects.map((o) => JSON.parse(JSON.stringify(o)) as PageLayoutObject);
    const cleanedObjects = convertTypedDotsToVectorDottedLines(cloned);

    // Append any detected transparent handwriting layers not already present
    for (const hw of handwritingLayers) {
      if (!cleanedObjects.some((o) => o.type === 'HANDWRITING' && o.id === hw.id)) {
        cleanedObjects.push({
          id: hw.id,
          type: 'HANDWRITING',
          pipelineKind: 'handwriting',
          x: hw.bbox[0],
          y: hw.bbox[1],
          width: hw.bbox[2],
          height: hw.bbox[3],
          content: 'كتابة يدوية (Handwriting Layer)',
          croppedImageDataUrl: hw.croppedTransparentDataUrl,
          confidence: 0.97,
          uncertainTokens: [],
          alignment: 'right',
          direction: 'rtl',
          fontProperties: {
            family: 'Cairo',
            sizePt: 10,
            weight: 'normal',
            role: 'normal',
            color: '#1D4ED8',
            lineHeight: 1.2,
          },
          borderProperties: createDefaultBorder(0),
          backgroundProperties: { fill: 'transparent', opacity: 0 },
          zOrder: 30,
        });
      }
    }

    return {
      objects: cleanedObjects,
      measuredBoxes: measurement.measuredBoxes,
      margins: measurement.measuredMargins,
      usedServerVision: false,
    };
  }

  try {
    const base64Data = preprocessedImageDataUrl.replace(/^data:image\/\w+;base64,/, '');
    const res = await fetch('/api/extract-elements', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        imageBase64: base64Data,
        mimeType: 'image/png',
        measuredBoxes: measurement.measuredBoxes.map((b) => ({
          id: b.id,
          kind: b.kind,
          bbox: b.bbox,
          tableGrid: b.tableGrid,
          checked: b.checked,
        })),
      }),
    });

    if (res.ok) {
      const payload = await res.json();
      const rawList = payload?.data?.elements || payload?.data?.objects || [];
      if (payload?.success && Array.isArray(rawList) && rawList.length > 0) {
        const mapped = rawList.map((raw: any, i: number) =>
          mapVisionElementToLayoutObject(raw, i)
        );
        const vectorCleaned = convertTypedDotsToVectorDottedLines(mapped);

        // Attach transparent handwriting crops from Step 4
        for (const hw of handwritingLayers) {
          vectorCleaned.push({
            id: hw.id,
            type: 'HANDWRITING',
            pipelineKind: 'handwriting',
            x: hw.bbox[0],
            y: hw.bbox[1],
            width: hw.bbox[2],
            height: hw.bbox[3],
            content: 'طبقة خط اليد (Handwriting)',
            croppedImageDataUrl: hw.croppedTransparentDataUrl,
            confidence: 0.97,
            uncertainTokens: [],
            alignment: 'right',
            direction: 'rtl',
            fontProperties: {
              family: 'Cairo',
              sizePt: 10,
              weight: 'normal',
              role: 'normal',
              color: '#1D4ED8',
              lineHeight: 1.2,
            },
            borderProperties: createDefaultBorder(0),
            backgroundProperties: { fill: 'transparent', opacity: 0 },
            zOrder: 30,
          });
        }

        return {
          objects: vectorCleaned,
          measuredBoxes: measurement.measuredBoxes,
          margins: measurement.measuredMargins,
          usedServerVision: true,
        };
      }
    }
  } catch {
    // Offline fallback uses the measured morphological boxes directly
  }

  const measuredObjects = buildObjectsFromMeasuredBoxes(measurement.measuredBoxes);
  return {
    objects: measuredObjects,
    measuredBoxes: measurement.measuredBoxes,
    margins: measurement.measuredMargins,
    usedServerVision: false,
    noticeAr: `تم قياس (${measurement.measuredBoxes.length}) عنصر تخطيطي (خطوط، جداول، صناديق، وكتل نصية) بإحداثيات 0..1000 مباشرة من الصورة المنظفة.`,
  };
}
