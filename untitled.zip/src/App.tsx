import React, { useEffect, useRef, useState } from 'react';
import {
  PageLayoutObject,
  PipelineStage,
  ProcessingMode,
  PreprocessingConfig,
  ReconstructedPage,
  ThemeMode,
  createDefaultPreprocessingConfig,
} from './models/DocumentModel';
import {
  ACCEPTANCE_TEST_SPECS,
  getSampleDocumentObjects,
} from './engines/SampleDocumentsGenerator';
import { renderObjectsToDataUrl, renderPageToCanvas } from './engines/DocumentRenderer';
import { runStep1PreprocessPipeline } from './engines/ImagePreprocessor';
import { measureCleanedPageLayout } from './engines/LayoutMeasurer';
import {
  analyzeDocumentWithVisionEngine,
  convertTypedDotsToVectorDottedLines,
} from './engines/OcrAndLayoutEngine';
import { runIterativeVisualValidation } from './engines/IterativeValidator';
import {
  ExportDpi,
  ExportFormat,
  exportReconstructedDocument,
} from './engines/ExportEngine';
import { CrimsonPdfIcon } from './components/CrimsonPdfIcon';
import { ManualInspectorPanel } from './components/ManualInspectorPanel';
import { HtmlA4PageBuilder } from './components/HtmlA4PageBuilder';
import { AndroidArchitectureModal } from './components/AndroidArchitectureModal';
import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  Code2,
  Download,
  Eye,
  FileCheck2,
  FileSpreadsheet,
  FileText,
  Layers,
  Moon,
  PenTool,
  RefreshCw,
  RotateCw,
  ScanLine,
  Sliders,
  Smartphone,
  Sparkles,
  SplitSquareHorizontal,
  Sun,
  Upload,
} from 'lucide-react';

type ViewportComparisonMode =
  | 'RECONSTRUCTED_MODE_A'
  | 'CLEANED_MODE_B'
  | 'SIDE_BY_SIDE'
  | 'DIFF_HEATMAP'
  | 'SOURCE_ORIGINAL';

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>('oled');
  const [activeStage, setActiveStage] = useState<PipelineStage>('IMPORT');
  const [processingMode, setProcessingMode] = useState<ProcessingMode>(
    'MODE_A_CLEAN_RECONSTRUCTION'
  );
  const [comparisonMode, setComparisonMode] =
    useState<ViewportComparisonMode>('SIDE_BY_SIDE');

  const [selectedTestId, setSelectedTestId] = useState<string>('arabic_table');
  const [pages, setPages] = useState<ReconstructedPage[]>([]);
  const [activePageIdx, setActivePageIdx] = useState<number>(0);
  const [selectedObjectId, setSelectedObjectId] = useState<string | null>(null);

  // Step 4: Handwriting toggle (Default = false -> remove handwriting by inpainting)
  const [keepHandwriting, setKeepHandwriting] = useState<boolean>(false);
  // Step 5: Render engine mode (HTML/SVG 210mmx297mm vector builder vs interactive drag canvas)
  const [useVectorHtmlBuilder, setUseVectorHtmlBuilder] = useState<boolean>(true);

  const [showBoundingBoxes, setShowBoundingBoxes] = useState<boolean>(false);
  const [highlightLowConfidence, setHighlightLowConfidence] = useState<boolean>(true);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [statusBanner, setStatusBanner] = useState<{
    type: 'info' | 'success' | 'warning';
    text: string;
  } | null>(null);

  // Export state
  const [exportFormat, setExportFormat] = useState<ExportFormat>('PDF');
  const [exportDpi, setExportDpi] = useState<ExportDpi>(300);
  const [jpgQuality, setJpgQuality] = useState<number>(0.95);
  const [lastExportResult, setLastExportResult] = useState<{
    filename: string;
    sizeKb: number;
    dimensionsLabel: string;
  } | null>(null);

  // Modals
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState<boolean>(false);
  const [isCameraOpen, setIsCameraOpen] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const interactiveCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Dragging object on canvas
  const [dragState, setDragState] = useState<{
    objId: string;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);

  const currentPage: ReconstructedPage | undefined = pages[activePageIdx];

  // Build and initialize a sample test document through the 7-stage measured pipeline
  const loadAcceptanceTestDocument = async (testId: string) => {
    setIsProcessing(true);
    setSelectedTestId(testId);
    setSelectedObjectId(null);
    setLastExportResult(null);

    try {
      const spec =
        ACCEPTANCE_TEST_SPECS.find((s) => s.id === testId) || ACCEPTANCE_TEST_SPECS[0];
      const builtPages: ReconstructedPage[] = [];

      for (let p = 0; p < spec.pageCount; p++) {
        const sample = getSampleDocumentObjects(testId, p);
        const prepWithHandwriting: PreprocessingConfig = {
          ...sample.preprocessing,
          keepHandwriting,
        };

        // Convert any typed dot runs in sample definitions into real vector DOTTED_LINE objects
        const vectorizedSampleObjects = convertTypedDotsToVectorDottedLines(sample.objects);

        // Render realistic photographed/scanned source image
        const sourceDataUrl = renderObjectsToDataUrl(vectorizedSampleObjects, {
          widthPx: 900,
          heightPx: 1273,
          keepHandwriting: true,
          simulateScannedPhoto: {
            angleDeg: sample.simulateAngleDeg,
            noiseLevel: sample.simulateNoiseLevel,
            shadowStrength: sample.simulateShadowStrength,
          },
        });

        // STEP 1: PREPROCESS (OpenCV.js / morphological orientation, split, deskew, shadow & bleed-through removal, handwriting inpainting)
        const prepResults = await runStep1PreprocessPipeline(
          sourceDataUrl,
          prepWithHandwriting
        );

        for (const prepPage of prepResults) {
          const activeCleanedDataUrl = keepHandwriting
            ? prepPage.cleanedWithHandwritingDataUrl
            : prepPage.inpaintedCleanedDataUrl;

          // STEP 2: MEASURE (morphological H/V lines, table grids, boxes, checkboxes, text bboxes in 0-1000)
          const measurement = await measureCleanedPageLayout(
            activeCleanedDataUrl,
            prepPage.handwritingLayers
          );

          // Attach any detected handwriting layers as HANDWRITING objects so toggling "Keep Handwriting" works at the exact bbox
          const combinedObjects: PageLayoutObject[] = [...vectorizedSampleObjects];
          prepPage.handwritingLayers.forEach((hw, hwIdx) => {
            const exists = combinedObjects.some(
              (o) =>
                (o.type === 'HANDWRITING' || o.type === 'SIGNATURE_AREA') &&
                Math.abs(o.x - hw.bbox[0]) < 45 &&
                Math.abs(o.y - hw.bbox[1]) < 45
            );
            if (!exists) {
              combinedObjects.push({
                id: `hw_${p + 1}_${hwIdx + 1}`,
                type: 'HANDWRITING',
                pipelineKind: 'handwriting',
                x: hw.bbox[0],
                y: hw.bbox[1],
                width: hw.bbox[2],
                height: hw.bbox[3],
                content: 'توقيع / خط يدوي مستخرج كطبقة شفافة',
                confidence: 1,
                uncertainTokens: [],
                alignment: 'right',
                direction: 'rtl',
                fontProperties: {
                  family: 'Cairo',
                  sizePt: 10,
                  weight: 'normal',
                  role: 'caption',
                  color: '#1E3A8A',
                  lineHeight: 1.2,
                },
                borderProperties: {
                  top: { width: 0, style: 'none', color: 'transparent' },
                  right: { width: 0, style: 'none', color: 'transparent' },
                  bottom: { width: 0, style: 'none', color: 'transparent' },
                  left: { width: 0, style: 'none', color: 'transparent' },
                },
                backgroundProperties: { fill: 'transparent', opacity: 0 },
                zOrder: 30 + hwIdx,
                croppedImageDataUrl: hw.croppedTransparentDataUrl,
              });
            }
          });

          // STEP 6: VERIFY LOOP (up to 3 iterations: render at source res, compute real SSIM + line-position error + per-block IoU, apply patch)
          const validation = await runIterativeVisualValidation(
            activeCleanedDataUrl,
            combinedObjects,
            true,
            keepHandwriting,
            2
          );

          builtPages.push({
            pageNumber: builtPages.length + 1,
            widthMm: 210,
            heightMm: 297,
            aspectRatio: 210 / 297,
            sourceImageDataUrl: sourceDataUrl,
            preprocessedImageDataUrl: activeCleanedDataUrl,
            cleanedModeBImageDataUrl: prepPage.cleanedWithHandwritingDataUrl,
            direction: 'rtl',
            margins: measurement.measuredMargins,
            measuredBoxes: measurement.measuredBoxes,
            detectedOrientationDeg: prepPage.detectedOrientationDeg,
            wasSplitFromTwoPageScan: prepPage.wasSplitFromTwoPageScan,
            objects: validation.refinedObjects,
            preprocessing: prepWithHandwriting,
            validationReport: validation.report,
          });
        }
      }

      setPages(builtPages);
      setActivePageIdx(0);
      if (builtPages[0]?.objects.length > 0) {
        setSelectedObjectId(builtPages[0].objects[0].id);
      }

      const poorBlocksTotal = builtPages.reduce(
        (acc, pg) => acc + pg.validationReport.lowConfidenceRegionsCount,
        0
      );
      const r0 = builtPages[0]?.validationReport;

      if (poorBlocksTotal > 0 && r0) {
        setStatusBanner({
          type: 'warning',
          text: `تم قياس وإعادة بناء "${spec.titleAr}" — النتيجة المقاسة: ${(r0.combinedScore ?? 0).toFixed(3)} (SSIM: ${(r0.ssimScore ?? 0).toFixed(3)} · Mean IoU: ${(r0.meanBlockIoU ?? 0).toFixed(3)}) مع إبراز (${poorBlocksTotal}) كتلة تحتاج مراجعة هندسية.`,
        });
      } else if (r0) {
        setStatusBanner({
          type: 'success',
          text: `تم قياس وإعادة بناء "${spec.titleAr}" (${builtPages.length} ص) — النتيجة المقاسة: ${(r0.combinedScore ?? 0).toFixed(3)} (SSIM: ${(r0.ssimScore ?? 0).toFixed(3)} · Line Err: ${(r0.linePositionErrorNorm ?? 0).toFixed(1)} · Mean IoU: ${(r0.meanBlockIoU ?? 0).toFixed(3)}).`,
        });
      }
    } finally {
      setIsProcessing(false);
    }
  };

  useEffect(() => {
    loadAcceptanceTestDocument('arabic_table');
  }, []);

  // Re-render interactive canvas whenever currentPage or overlays change
  useEffect(() => {
    if (!currentPage || !interactiveCanvasRef.current) return;
    renderPageToCanvas(interactiveCanvasRef.current, currentPage.objects, {
      widthPx: 900,
      heightPx: 1273,
      highlightSelectedId:
        activeStage === 'VALIDATE_EDIT' || showBoundingBoxes ? selectedObjectId : null,
      highlightLowConfidence,
      showBoundingBoxes,
      keepHandwriting,
    });
  }, [
    currentPage,
    selectedObjectId,
    activeStage,
    highlightLowConfidence,
    showBoundingBoxes,
    comparisonMode,
    processingMode,
    keepHandwriting,
    useVectorHtmlBuilder,
  ]);

  // Handle custom uploaded photo/scan file
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setSelectedTestId('custom_upload');
    setStatusBanner({
      type: 'info',
      text: 'جاري تشغيل خط الأنابيب المقاس (1. المعالجة المسبقة ← 2. القياس المورفولوجي ← 3. الاستخراج الهيكلي ← 4. عزل الخط اليدوي ← 5. البناء المتجهي ← 6. حلقة التحقق SSIM/IoU)...',
    });

    try {
      const reader = new FileReader();
      const sourceDataUrl: string = await new Promise((resolve, reject) => {
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      await processCustomSourceImage(sourceDataUrl, file.name);
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const processCustomSourceImage = async (sourceDataUrl: string, labelName: string) => {
    const defaultPrep: PreprocessingConfig = {
      ...createDefaultPreprocessingConfig(),
      keepHandwriting,
    };

    // STEP 1: PREPROCESS (detect orientation 0/90/180/270, split two-page scans, deskew, remove shadows/bleed-through, separate handwriting)
    const prepPages = await runStep1PreprocessPipeline(sourceDataUrl, defaultPrep);
    const rebuiltPages: ReconstructedPage[] = [];

    for (let i = 0; i < prepPages.length; i++) {
      const prepPage = prepPages[i];
      const activeCleanedDataUrl = keepHandwriting
        ? prepPage.cleanedWithHandwritingDataUrl
        : prepPage.inpaintedCleanedDataUrl;

      // STEP 2 (MEASURE) + STEP 3 (EXTRACT via Vision JSON + Measured Boxes) + STEP 4 (HANDWRITING)
      const analysis = await analyzeDocumentWithVisionEngine(
        activeCleanedDataUrl,
        undefined,
        prepPage.handwritingLayers
      );

      // STEP 6: MANDATORY VERIFY LOOP (up to 3 iterations: SSIM + line-position error + per-block IoU + Vision JSON patch)
      const validation = await runIterativeVisualValidation(
        activeCleanedDataUrl,
        analysis.objects,
        true,
        keepHandwriting,
        3
      );

      rebuiltPages.push({
        pageNumber: i + 1,
        widthMm: 210,
        heightMm: 297,
        aspectRatio: 210 / 297,
        sourceImageDataUrl: sourceDataUrl,
        preprocessedImageDataUrl: activeCleanedDataUrl,
        cleanedModeBImageDataUrl: prepPage.cleanedWithHandwritingDataUrl,
        direction: 'rtl',
        margins: analysis.margins,
        measuredBoxes: analysis.measuredBoxes,
        detectedOrientationDeg: prepPage.detectedOrientationDeg,
        wasSplitFromTwoPageScan: prepPage.wasSplitFromTwoPageScan,
        objects: validation.refinedObjects,
        preprocessing: {
          ...defaultPrep,
          deskewAngleDeg: prepPage.measuredSkewDeg,
        },
        validationReport: validation.report,
      });
    }

    setPages(rebuiltPages);
    setActivePageIdx(0);
    setSelectedObjectId(rebuiltPages[0]?.objects[0]?.id || null);

    const r0 = rebuiltPages[0]?.validationReport;
    const splitNotice = rebuiltPages[0]?.wasSplitFromTwoPageScan
      ? ` (تم اكتشاف صفحتين في المسح الضوئي وفصلهما تلقائياً إلى ${rebuiltPages.length} صفحات)`
      : '';

    setStatusBanner({
      type: r0 && r0.lowConfidenceRegionsCount > 0 ? 'warning' : 'success',
      text: `تمت إعادة بناء "${labelName}"${splitNotice} — النتيجة المقاسة: ${(r0?.combinedScore ?? 0).toFixed(3)} (SSIM: ${(r0?.ssimScore ?? 0).toFixed(3)} · Line Err: ${(r0?.linePositionErrorNorm ?? 0).toFixed(1)} · Mean IoU: ${(r0?.meanBlockIoU ?? 0).toFixed(3)}).`,
    });
  };

  // Toggle Step 4 "Keep Handwriting" across current pages
  const handleToggleKeepHandwriting = async (nextKeep: boolean) => {
    setKeepHandwriting(nextKeep);
    if (!currentPage) return;
    await handleUpdatePreprocessing({ keepHandwriting: nextKeep });
  };

  // Update preprocessing settings for current page
  const handleUpdatePreprocessing = async (partial: Partial<PreprocessingConfig>) => {
    if (!currentPage) return;
    const updatedPrep: PreprocessingConfig = {
      ...currentPage.preprocessing,
      ...partial,
    };

    setIsProcessing(true);
    try {
      const prepPages = await runStep1PreprocessPipeline(
        currentPage.sourceImageDataUrl,
        updatedPrep
      );
      const prepPage = prepPages[0];
      const effectiveKeepHw = updatedPrep.keepHandwriting ?? keepHandwriting;
      const preprocessedDataUrl = effectiveKeepHw
        ? prepPage.cleanedWithHandwritingDataUrl
        : prepPage.inpaintedCleanedDataUrl;

      const validation = await runIterativeVisualValidation(
        preprocessedDataUrl,
        currentPage.objects,
        false,
        effectiveKeepHw,
        1
      );

      const nextPages = pages.map((pg, idx) =>
        idx === activePageIdx
          ? {
              ...pg,
              preprocessing: updatedPrep,
              preprocessedImageDataUrl: preprocessedDataUrl,
              cleanedModeBImageDataUrl: prepPage.cleanedWithHandwritingDataUrl,
              validationReport: validation.report,
            }
          : pg
      );
      setPages(nextPages);
    } finally {
      setIsProcessing(false);
    }
  };

  // Trigger Step 6 Verify Loop (up to 3 iterations) manually
  const handleRunIterativeRefinement = async () => {
    if (!currentPage) return;
    setIsProcessing(true);
    try {
      const validation = await runIterativeVisualValidation(
        currentPage.preprocessedImageDataUrl,
        currentPage.objects,
        true,
        keepHandwriting,
        3
      );
      const nextPages = pages.map((pg, idx) =>
        idx === activePageIdx
          ? {
              ...pg,
              objects: validation.refinedObjects,
              validationReport: validation.report,
            }
          : pg
      );
      setPages(nextPages);
      const r = validation.report;
      setStatusBanner({
        type: r.lowConfidenceRegionsCount > 0 ? 'warning' : 'success',
        text: `اكتملت حلقة التحقق (${r.iterationsRun || 1} دورات) — Combined Score: ${(r.combinedScore ?? 0).toFixed(3)} · SSIM: ${(r.ssimScore ?? 0).toFixed(3)} · Line Err: ${(r.linePositionErrorNorm ?? 0).toFixed(1)} · Mean IoU: ${(r.meanBlockIoU ?? 0).toFixed(3)}.`,
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Update a single layout object on the active page without touching unrelated elements
  const handleUpdateObject = (updatedObj: PageLayoutObject) => {
    if (!currentPage) return;
    const nextObjects = currentPage.objects.map((o) =>
      o.id === updatedObj.id ? updatedObj : o
    );
    setPages(
      pages.map((pg, idx) =>
        idx === activePageIdx ? { ...pg, objects: nextObjects } : pg
      )
    );
  };

  const handleAddObject = (newObj: PageLayoutObject) => {
    if (!currentPage) return;
    setPages(
      pages.map((pg, idx) =>
        idx === activePageIdx ? { ...pg, objects: [...pg.objects, newObj] } : pg
      )
    );
  };

  const handleDeleteObject = (id: string) => {
    if (!currentPage) return;
    const nextObjects = currentPage.objects.filter((o) => o.id !== id);
    setPages(
      pages.map((pg, idx) =>
        idx === activePageIdx ? { ...pg, objects: nextObjects } : pg
      )
    );
    setSelectedObjectId(nextObjects[0]?.id || null);
  };

  // Interactive canvas click & drag to select/move objects directly on the reconstructed page
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!currentPage || !interactiveCanvasRef.current) return;
    const rect = interactiveCanvasRef.current.getBoundingClientRect();
    const normX = ((e.clientX - rect.left) / rect.width) * 1000;
    const normY = ((e.clientY - rect.top) / rect.height) * 1000;

    // Find topmost object containing (normX, normY)
    const clicked = [...currentPage.objects]
      .reverse()
      .find(
        (obj) =>
          normX >= obj.x &&
          normX <= obj.x + obj.width &&
          normY >= obj.y &&
          normY <= obj.y + Math.max(12, obj.height)
      );

    if (clicked) {
      setSelectedObjectId(clicked.id);
      setDragState({
        objId: clicked.id,
        startX: normX,
        startY: normY,
        origX: clicked.x,
        origY: clicked.y,
      });
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!dragState || !currentPage || !interactiveCanvasRef.current) return;
    const rect = interactiveCanvasRef.current.getBoundingClientRect();
    const normX = ((e.clientX - rect.left) / rect.width) * 1000;
    const normY = ((e.clientY - rect.top) / rect.height) * 1000;

    const dx = Math.round(normX - dragState.startX);
    const dy = Math.round(normY - dragState.startY);

    const targetObj = currentPage.objects.find((o) => o.id === dragState.objId);
    if (!targetObj) return;

    handleUpdateObject({
      ...targetObj,
      x: Math.max(0, Math.min(1000 - targetObj.width, dragState.origX + dx)),
      y: Math.max(0, Math.min(1000 - targetObj.height, dragState.origY + dy)),
    });
  };

  const handleCanvasMouseUp = () => {
    setDragState(null);
  };

  // Camera capture handlers
  const openCameraModal = async () => {
    setIsCameraOpen(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch {
      setStatusBanner({
        type: 'warning',
        text: 'تعذر الوصول إلى الكاميرا المباشرة في هذا المتصفح — يمكنك رفع صورة أو اختيار أحد اختبارات القبول العشرة.',
      });
      setIsCameraOpen(false);
    }
  };

  const closeCameraModal = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((t) => t.stop());
    }
    setIsCameraOpen(false);
  };

  const captureCameraFrame = async () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 1000;
    canvas.height = videoRef.current.videoHeight || 1414;
    const ctx = canvas.getContext('2d');
    ctx?.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/png');
    closeCameraModal();
    setIsProcessing(true);
    try {
      await processCustomSourceImage(dataUrl, 'camera_capture');
    } finally {
      setIsProcessing(false);
    }
  };

  // Step 7: Handle Vector PDF / PNG / JPG Export
  const handleExportDocument = async (formatOverride?: ExportFormat) => {
    if (!pages.length) return;
    const fmt = formatOverride || exportFormat;
    setIsProcessing(true);
    try {
      const res = await exportReconstructedDocument(pages, {
        format: fmt,
        dpi: exportDpi,
        jpgQuality,
        processingMode,
        keepHandwriting,
        filenamePrefix: `CrimsonPDF_${selectedTestId}`,
      });
      setLastExportResult(res);
      setStatusBanner({
        type: 'success',
        text: `تم تصدير المستند بنجاح: ${res.filename} (${res.sizeKb} KB · ${res.dimensionsLabel}).`,
      });
    } catch (err: any) {
      setStatusBanner({
        type: 'warning',
        text: err?.message || 'حدث خطأ أثناء تصدير المستند.',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Theme classes (Day / Night / Pure OLED)
  const rootThemeClass =
    theme === 'oled'
      ? 'bg-black text-white'
      : theme === 'night'
      ? 'bg-slate-950 text-slate-100'
      : 'bg-slate-50 text-slate-900';

  const headerThemeClass =
    theme === 'oled'
      ? 'bg-[#050505] border-[#1F1F1F]'
      : theme === 'night'
      ? 'bg-slate-900 border-slate-800'
      : 'bg-white border-slate-200';

  const panelThemeClass =
    theme === 'oled'
      ? 'bg-[#0A0A0A] border-[#1F1F1F]'
      : theme === 'night'
      ? 'bg-slate-900 border-slate-800'
      : 'bg-white border-slate-200';

  const mutedTextClass =
    theme === 'oled'
      ? 'text-neutral-400'
      : theme === 'night'
      ? 'text-slate-400'
      : 'text-slate-500';

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-150 ${rootThemeClass}`}>
      {/* STRICT 3-ZONE TOP BAR CONTRACT */}
      <header
        className={`flex items-center justify-between px-6 py-3.5 border-b sticky top-0 z-30 ${headerThemeClass}`}
      >
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveStage('IMPORT');
          }}
          className="text-lg font-bold tracking-tight text-red-600 whitespace-nowrap"
        >
          CrimsonPDF Reconstruct
        </a>

        {/* Zone 2: 5 clean stage navigation links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium">
          {(
            [
              { id: 'IMPORT', label: 'استيراد وفحص' },
              { id: 'PREPROCESS', label: 'المعالجة والمنظور' },
              { id: 'ANALYZE_RECONSTRUCT', label: 'إعادة البناء الهيكلي' },
              { id: 'VALIDATE_EDIT', label: 'المقارنة والضبط اليدوي' },
              { id: 'EXPORT', label: 'التصدير الطباعي' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveStage(item.id)}
              className={`py-1 border-b-2 transition-colors whitespace-nowrap ${
                activeStage === item.id
                  ? 'border-red-600 text-red-600 font-semibold'
                  : 'border-transparent opacity-75 hover:opacity-100'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Primary Actions (Theme Segmented Control + Export PDF) */}
        <div className="flex items-center gap-2.5">
          <div
            className={`flex items-center p-1 rounded-lg border ${
              theme === 'oled'
                ? 'bg-black border-[#242424]'
                : theme === 'night'
                ? 'bg-slate-950 border-slate-800'
                : 'bg-slate-100 border-slate-200'
            }`}
          >
            <button
              type="button"
              onClick={() => setTheme('day')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md flex items-center gap-1 transition-colors whitespace-nowrap ${
                theme === 'day'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              <Sun className="w-3.5 h-3.5" />
              <span>نهاري</span>
            </button>
            <button
              type="button"
              onClick={() => setTheme('night')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md flex items-center gap-1 transition-colors whitespace-nowrap ${
                theme === 'night'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              <Moon className="w-3.5 h-3.5" />
              <span>ليلي</span>
            </button>
            <button
              type="button"
              onClick={() => setTheme('oled')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md flex items-center gap-1 transition-colors whitespace-nowrap ${
                theme === 'oled'
                  ? 'bg-red-600 text-white shadow-sm'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>OLED</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => handleExportDocument('PDF')}
            disabled={isProcessing}
            className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير Vector PDF</span>
          </button>
        </div>
      </header>

      {/* Sub-header Identity & Processing Mode Strip */}
      <div className={`border-b px-6 py-3 ${panelThemeClass}`}>
        <div className="max-w-[1440px] mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <CrimsonPdfIcon className="w-10 h-10 shrink-0" />
            <div>
              <div className="flex items-center gap-2 text-xs font-mono opacity-75">
                <span>com.crimsonpdf.reconstructor</span>
                <span aria-hidden="true">·</span>
                <span>خط أنابيب القياس الهندسي (0-1000 → 210×297mm)</span>
                <span aria-hidden="true">·</span>
                <span>Verification Loop (SSIM + Line Error + IoU)</span>
              </div>
              <h1 className="text-base font-bold mt-0.5">
                إعادة بناء المستندات الممسوحة ضوئياً كنسخة A4 متجهية مقاسة (Vector PDF / HTML / SVG)
              </h1>
            </div>
          </div>

          {/* Processing Mode Switcher + Keep Handwriting Toggle + Android Code Button */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Step 4: Keep Handwriting Toggle */}
            <label
              className={`px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center gap-2 cursor-pointer transition-colors ${
                keepHandwriting
                  ? 'border-red-600 bg-red-600/15 text-red-400'
                  : 'border-current/20 hover:bg-current/5'
              }`}
              title="الافتراضي: إزالة الخط اليدوي بالترميم (Inpainting). عند التفعيل: الاحتفاظ بالخط اليدوي كطبقة شفافة في نفس الإحداثيات المقاسة."
            >
              <input
                type="checkbox"
                checked={keepHandwriting}
                onChange={(e) => handleToggleKeepHandwriting(e.target.checked)}
                className="accent-red-600 w-3.5 h-3.5"
              />
              <PenTool className="w-3.5 h-3.5" />
              <span>الاحتفاظ بالخط اليدوي (Keep Handwriting)</span>
            </label>

            <div
              className={`flex items-center p-1 rounded-lg border ${
                theme === 'oled'
                  ? 'bg-black border-[#242424]'
                  : theme === 'night'
                  ? 'bg-slate-950 border-slate-800'
                  : 'bg-slate-100 border-slate-200'
              }`}
            >
              <button
                type="button"
                onClick={() => {
                  setProcessingMode('MODE_A_CLEAN_RECONSTRUCTION');
                  setComparisonMode('SIDE_BY_SIDE');
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  processingMode === 'MODE_A_CLEAN_RECONSTRUCTION'
                    ? 'bg-red-600 text-white'
                    : 'opacity-75 hover:opacity-100'
                }`}
              >
                الوضع (أ): إعادة بناء متجهي مقاس (210×297mm)
              </button>
              <button
                type="button"
                onClick={() => {
                  setProcessingMode('MODE_B_IMAGE_CLEANING');
                  setComparisonMode('CLEANED_MODE_B');
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  processingMode === 'MODE_B_IMAGE_CLEANING'
                    ? 'bg-red-600 text-white'
                    : 'opacity-75 hover:opacity-100'
                }`}
              >
                الوضع (ب): تنظيف الصورة الأصلية (Mode B)
              </button>
            </div>

            <button
              type="button"
              onClick={() => setIsAndroidModalOpen(true)}
              className="px-3 py-2 text-xs font-medium rounded-lg border border-current/20 hover:bg-current/5 transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <Code2 className="w-4 h-4 text-red-500" />
              <span>كود مشروع Android (Kotlin)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Status Notification Bar */}
      {statusBanner && (
        <div
          className={`px-6 py-2.5 text-xs border-b flex items-center justify-between ${
            statusBanner.type === 'warning'
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
              : statusBanner.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-blue-500/10 border-blue-500/30 text-blue-400'
          }`}
        >
          <div className="max-w-[1440px] mx-auto w-full flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              {statusBanner.type === 'warning' ? (
                <AlertTriangle className="w-4 h-4 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              )}
              <span>{statusBanner.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setStatusBanner(null)}
              className="text-xs underline opacity-80 hover:opacity-100 whitespace-nowrap"
            >
              إخفاء
            </button>
          </div>
        </div>
      )}

      {/* MAIN WORKSPACE CONTAINER (1440px Baseline) */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* RIGHT COLUMN (Controls, Pipeline Stages, 10 Test Cases, Preprocessing, Inspector) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Pipeline Stage Tabs for Quick Access */}
          <div className={`p-1.5 rounded-lg border grid grid-cols-5 gap-1 ${panelThemeClass}`}>
            {(
              [
                { id: 'IMPORT', label: '1. الاستيراد', icon: Upload },
                { id: 'PREPROCESS', label: '2. المعالجة', icon: Sliders },
                { id: 'ANALYZE_RECONSTRUCT', label: '3. القياس', icon: ScanLine },
                { id: 'VALIDATE_EDIT', label: '4. التحقق', icon: Layers },
                { id: 'EXPORT', label: '5. التصدير', icon: FileCheck2 },
              ] as const
            ).map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                type="button"
                onClick={() => setActiveStage(id)}
                className={`py-2 px-1.5 rounded-md text-xs font-medium flex flex-col items-center gap-1 transition-colors whitespace-nowrap ${
                  activeStage === id
                    ? 'bg-red-600 text-white'
                    : 'opacity-75 hover:opacity-100 hover:bg-current/5'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{label}</span>
              </button>
            ))}
          </div>

          {/* STAGE 1: IMPORT IMAGE & 10 ACCEPTANCE TEST DOCUMENTS */}
          {activeStage === 'IMPORT' && (
            <div className={`border rounded-lg p-4 space-y-4 ${panelThemeClass}`}>
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold">
                    01. استيراد صورة وثيقة أو اختبار حالات القبول العشر
                  </h2>
                  <p className={`text-xs mt-0.5 ${mutedTextClass}`}>
                    ارفع مسحاً ضوئياً (يدعم فصل الصفحتين تلقائياً وتصحيح الاتجاه 0/90/180/270) أو اختبر النماذج العشرة
                  </p>
                </div>
              </div>

              {/* Upload & Camera Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="py-3 px-4 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
                >
                  <Upload className="w-4 h-4" />
                  <span>رفع صورة مستند / مسح ضوئي</span>
                </button>
                <button
                  type="button"
                  onClick={openCameraModal}
                  className="py-3 px-4 rounded-lg border border-current/20 hover:bg-current/5 text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
                >
                  <Camera className="w-4 h-4 text-red-500" />
                  <span>التقاط وثيقة بالكاميرا</span>
                </button>
              </div>

              {/* 10 Real Acceptance Test Documents */}
              <div className="space-y-2 pt-2 border-t border-current/10">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold">
                    حالات الاختبار المعيارية العشر (Measured Pipeline Test Suite)
                  </span>
                  <span className={`text-xs font-mono tabular-nums ${mutedTextClass}`}>
                    10 / 10 جاهزة
                  </span>
                </div>

                <div className="space-y-1.5 max-h-[380px] overflow-y-auto pr-1">
                  {ACCEPTANCE_TEST_SPECS.map((spec) => {
                    const isSelected = selectedTestId === spec.id;
                    return (
                      <button
                        key={spec.id}
                        type="button"
                        onClick={() => loadAcceptanceTestDocument(spec.id)}
                        className={`w-full text-right p-3 rounded-lg border transition-colors flex flex-col gap-1 ${
                          isSelected
                            ? 'border-red-600 bg-red-600/10'
                            : 'border-current/10 hover:border-current/30 hover:bg-current/[0.03]'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-bold">{spec.titleAr}</span>
                          <span className={`text-[11px] font-mono ${mutedTextClass}`}>
                            {spec.categoryAr} · {spec.pageCount === 2 ? 'صفحتان' : 'صفحة 1'}
                          </span>
                        </div>
                        <p className={`text-xs leading-relaxed ${mutedTextClass}`}>
                          {spec.descriptionAr}
                        </p>
                        <div className="text-[11px] text-red-500/90 font-medium">
                          التحدي الهندسي المحاكى: {spec.simulatedIssueAr}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* STAGE 2: STEP 1 PREPROCESS (OpenCV.js, Orientation, Split, Bleed-through, Shadows, Handwriting) */}
          {activeStage === 'PREPROCESS' && currentPage && (
            <div className={`border rounded-lg p-4 space-y-4 ${panelThemeClass}`}>
              <div className="flex items-center justify-between border-b pb-3 border-current/10">
                <div>
                  <h2 className="text-sm font-bold">
                    02. المعالجة المسبقة المقاسة (Step 1: OpenCV.js Preprocess)
                  </h2>
                  <p className={`text-xs mt-0.5 ${mutedTextClass}`}>
                    كشف الاتجاه (0/90/180/270)، فصل الصفحتين، إزالة الظلال ونزف الوجه الخلفي، وعزل الخط اليدوي
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    handleUpdatePreprocessing(createDefaultPreprocessingConfig())
                  }
                  className="px-2.5 py-1 text-xs rounded border border-current/20 hover:bg-current/5 whitespace-nowrap"
                >
                  إعادة الضبط
                </button>
              </div>

              {/* Deskew Angle Slider */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium">تصحيح زاوية الميلان المقاسة (Deskew Angle)</span>
                  <span className="font-mono tabular-nums" dir="ltr">
                    {currentPage.preprocessing.deskewAngleDeg.toFixed(2)}°
                  </span>
                </div>
                <input
                  type="range"
                  min={-12}
                  max={12}
                  step={0.2}
                  value={currentPage.preprocessing.deskewAngleDeg}
                  onChange={(e) =>
                    handleUpdatePreprocessing({
                      deskewAngleDeg: Number(e.target.value),
                    })
                  }
                  className="w-full accent-red-600"
                />
              </div>

              {/* 90-degree Rotation Buttons */}
              <div className="flex items-center justify-between text-xs pt-1">
                <span className="font-medium">تدوير الصفحة (0 / 90 / 180 / 270)</span>
                <div className="flex items-center gap-1.5">
                  {([0, 90, 180, 270] as const).map((deg) => (
                    <button
                      key={deg}
                      type="button"
                      onClick={() => handleUpdatePreprocessing({ rotationDeg: deg })}
                      className={`px-2.5 py-1 rounded border font-mono tabular-nums flex items-center gap-1 ${
                        currentPage.preprocessing.rotationDeg === deg
                          ? 'bg-red-600 text-white border-red-600'
                          : 'border-current/20 hover:bg-current/5'
                      }`}
                    >
                      <RotateCw className="w-3 h-3" />
                      <span>{deg}°</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Shadow Removal, Background Normalization, Bleed-through, Keep Handwriting */}
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-current/10">
                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={currentPage.preprocessing.removeShadows}
                    onChange={(e) =>
                      handleUpdatePreprocessing({ removeShadows: e.target.checked })
                    }
                    className="accent-red-600 w-4 h-4"
                  />
                  <span>إزالة الظلال وخطوط الماسح (Shadows/Bands)</span>
                </label>

                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={currentPage.preprocessing.normalizeBackground}
                    onChange={(e) =>
                      handleUpdatePreprocessing({
                        normalizeBackground: e.target.checked,
                      })
                    }
                    className="accent-red-600 w-4 h-4"
                  />
                  <span>منع نزف الوجه الخلفي وتوحيد البياض</span>
                </label>

                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={currentPage.preprocessing.cropToPageBorder !== false}
                    onChange={(e) =>
                      handleUpdatePreprocessing({
                        cropToPageBorder: e.target.checked,
                      })
                    }
                    className="accent-red-600 w-4 h-4"
                  />
                  <span>قص تلقائي لحدود الورقة (Crop to Border)</span>
                </label>

                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={keepHandwriting}
                    onChange={(e) => handleToggleKeepHandwriting(e.target.checked)}
                    className="accent-red-600 w-4 h-4"
                  />
                  <span>الاحتفاظ بالخط اليدوي (Keep Handwriting)</span>
                </label>
              </div>

              {/* Shadow Strength Slider */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span>قوة إزالة الظل وتوحيد الإضاءة المحلية</span>
                  <span className="font-mono tabular-nums">
                    {currentPage.preprocessing.shadowStrength}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={currentPage.preprocessing.shadowStrength}
                  onChange={(e) =>
                    handleUpdatePreprocessing({
                      shadowStrength: Number(e.target.value),
                    })
                  }
                  className="w-full accent-red-600"
                />
              </div>

              {/* Contrast Normalization Slider */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span>العتبة التكيفية وحدة الحبر (Adaptive Threshold & Ink)</span>
                  <span className="font-mono tabular-nums">
                    {currentPage.preprocessing.contrastBoost}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={currentPage.preprocessing.contrastBoost}
                  onChange={(e) =>
                    handleUpdatePreprocessing({
                      contrastBoost: Number(e.target.value),
                    })
                  }
                  className="w-full accent-red-600"
                />
              </div>
            </div>
          )}

          {/* STAGE 3: STEP 2 MEASURE & STEP 3 EXTRACT */}
          {activeStage === 'ANALYZE_RECONSTRUCT' && currentPage && (
            <div className={`border rounded-lg p-4 space-y-4 ${panelThemeClass}`}>
              <div>
                <h2 className="text-sm font-bold">
                  03. القياس المورفولوجي والاستخراج الهيكلي (Steps 2 & 3: Measure + Extract)
                </h2>
                <p className={`text-xs mt-0.5 ${mutedTextClass}`}>
                  جميع الإحداثيات مقاسة بنظام 0-1000 من الصورة المنظفة ومطابقة لأبعاد 210mm × 297mm
                </p>
              </div>

              {/* Measured Margins & Morphological Boxes Summary */}
              <div className="p-3 rounded-lg border border-current/15 bg-current/[0.02] space-y-1.5 text-xs">
                <div className="font-semibold text-red-500">
                  الهوامش المقاسة فعلياً من حدود الحبر (0-1000 → mm):
                </div>
                <div className="font-mono text-[11px] grid grid-cols-4 gap-2 pt-1" dir="ltr">
                  <div>
                    Top: {currentPage.margins.top} (
                    {((currentPage.margins.top / 1000) * 297).toFixed(1)}mm)
                  </div>
                  <div>
                    Bottom: {currentPage.margins.bottom} (
                    {((currentPage.margins.bottom / 1000) * 297).toFixed(1)}mm)
                  </div>
                  <div>
                    Right: {currentPage.margins.right} (
                    {((currentPage.margins.right / 1000) * 210).toFixed(1)}mm)
                  </div>
                  <div>
                    Left: {currentPage.margins.left} (
                    {((currentPage.margins.left / 1000) * 210).toFixed(1)}mm)
                  </div>
                </div>
              </div>

              {/* Object Type Breakdown Summary */}
              <div className="grid grid-cols-3 gap-2.5">
                {[
                  {
                    label: 'إجمالي الكتل المقاسة',
                    count: currentPage.objects.length,
                  },
                  {
                    label: 'الجداول والخطوط المتجهة',
                    count: currentPage.objects.filter(
                      (o) =>
                        o.type === 'TABLE' ||
                        o.type === 'LINE' ||
                        o.type === 'DOTTED_LINE'
                    ).length,
                  },
                  {
                    label: 'كتل بقياس ضعيف (Poor)',
                    count: currentPage.validationReport.lowConfidenceRegionsCount,
                  },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="p-3 rounded-lg border border-current/10 flex flex-col gap-1"
                  >
                    <span className={`text-xs ${mutedTextClass}`}>{stat.label}</span>
                    <span className="text-lg font-bold font-mono tabular-nums">
                      {stat.count}
                    </span>
                  </div>
                ))}
              </div>

              {/* Re-run Step 2 Measure + Step 3 Extract + Step 6 Verify Loop */}
              <div className="space-y-2 pt-2 border-t border-current/10">
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={async () => {
                    setIsProcessing(true);
                    try {
                      const res = await analyzeDocumentWithVisionEngine(
                        currentPage.preprocessedImageDataUrl,
                        currentPage.objects
                      );
                      const val = await runIterativeVisualValidation(
                        currentPage.preprocessedImageDataUrl,
                        res.objects,
                        true,
                        keepHandwriting,
                        3
                      );
                      setPages(
                        pages.map((pg, idx) =>
                          idx === activePageIdx
                            ? {
                                ...pg,
                                margins: res.margins,
                                measuredBoxes: res.measuredBoxes,
                                objects: val.refinedObjects,
                                validationReport: val.report,
                              }
                            : pg
                        )
                      );
                      setStatusBanner({
                        type: 'success',
                        text: `تمت إعادة القياس المورفولوجي والاستخراج والتحقق (${val.refinedObjects.length} عنصر — Combined Score: ${(val.report.combinedScore ?? 0).toFixed(3)}).`,
                      });
                    } finally {
                      setIsProcessing(false);
                    }
                  }}
                  className="w-full py-2.5 px-4 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>تشغيل القياس والاستخراج الهيكلي + حلقة التحقق (3 دورات)</span>
                </button>
              </div>
            </div>
          )}

          {/* STAGE 4: STEP 6 VERIFY LOOP & MEASURED PER-BLOCK REPORT */}
          {activeStage === 'VALIDATE_EDIT' && currentPage && (
            <div className="space-y-4">
              {/* Step 6: Verify Loop & Measured Report Card */}
              <div className={`border rounded-lg p-4 space-y-3 ${panelThemeClass}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-sm font-bold">
                      04. حلقة التحقق وتقرير القياس الفعلي للكتل (Step 6: Verify Loop & Report)
                    </h2>
                    <p className={`text-xs ${mutedTextClass}`}>
                      قياسات حقيقية فقط: SSIM + خطأ مواقع الخطوط + IoU لكل كتلة (تتوقف عند ≥ 0.95 أو 3 دورات)
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleRunIterativeRefinement}
                    disabled={isProcessing}
                    className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-medium flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${isProcessing ? 'animate-spin' : ''}`}
                    />
                    <span>تشغيل Verify Loop (3 دورات)</span>
                  </button>
                </div>

                {/* Global Measured Verify Loop Summary */}
                <div className="grid grid-cols-4 gap-2 font-mono text-xs pt-1" dir="ltr">
                  <div className="p-2 rounded border border-current/15">
                    <div className="text-[10px] opacity-70">Combined Score</div>
                    <div
                      className={`text-sm font-bold ${
                        (currentPage.validationReport.combinedScore ?? 0) >= 0.95
                          ? 'text-emerald-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {(currentPage.validationReport.combinedScore ?? 0).toFixed(4)}
                    </div>
                  </div>
                  <div className="p-2 rounded border border-current/15">
                    <div className="text-[10px] opacity-70">Real SSIM</div>
                    <div className="text-sm font-bold">
                      {(currentPage.validationReport.ssimScore ?? 0).toFixed(4)}
                    </div>
                  </div>
                  <div className="p-2 rounded border border-current/15">
                    <div className="text-[10px] opacity-70">Line Pos Err</div>
                    <div className="text-sm font-bold">
                      {(currentPage.validationReport.linePositionErrorNorm ?? 0).toFixed(2)}
                    </div>
                  </div>
                  <div className="p-2 rounded border border-current/15">
                    <div className="text-[10px] opacity-70">Mean Block IoU</div>
                    <div className="text-sm font-bold">
                      {(currentPage.validationReport.meanBlockIoU ?? 0).toFixed(4)}
                    </div>
                  </div>
                </div>

                {/* Iteration History Log */}
                {currentPage.validationReport.iterationHistory &&
                  currentPage.validationReport.iterationHistory.length > 0 && (
                    <div className="space-y-1 pt-1">
                      <div className="text-[11px] font-semibold opacity-80">
                        سجل دورات التحقق (Verify Loop Iterations):
                      </div>
                      <div className="space-y-1 font-mono text-[11px]" dir="ltr">
                        {currentPage.validationReport.iterationHistory.map((it) => (
                          <div
                            key={it.iteration}
                            className="px-2.5 py-1.5 rounded border border-current/10 flex items-center justify-between"
                          >
                            <span>
                              Iter #{it.iteration}: Score {it.combinedScore.toFixed(4)} (SSIM{' '}
                              {it.ssim.toFixed(3)}, LineErr {it.linePositionErrorNorm.toFixed(1)},
                              IoU {it.meanIoU.toFixed(3)})
                            </span>
                            <span className="opacity-75">
                              Patches: {it.appliedPatchesCount}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                {/* Per-Block Measured Report Table (Geometry Error, Text Accuracy, Table Accuracy) */}
                {currentPage.validationReport.blockReports &&
                  currentPage.validationReport.blockReports.length > 0 && (
                    <div className="space-y-1.5 pt-2 border-t border-current/10">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold">
                          تقرير القياس الفعلي لكل كتلة (Geometry Error / Text Acc / Table Acc)
                        </span>
                        <span className={`font-mono text-[11px] ${mutedTextClass}`}>
                          انقر على أي كتلة لإبرازها وتحريرها
                        </span>
                      </div>
                      <div className="max-h-52 overflow-y-auto space-y-1 pr-1">
                        {currentPage.validationReport.blockReports.map((br) => (
                          <button
                            key={br.blockId}
                            type="button"
                            onClick={() => setSelectedObjectId(br.blockId)}
                            className={`w-full text-right p-2 rounded border text-xs flex flex-col gap-1 transition-colors ${
                              selectedObjectId === br.blockId
                                ? 'border-red-600 bg-red-600/15'
                                : br.isPoor
                                ? 'border-amber-500/60 bg-amber-500/10'
                                : 'border-current/10 hover:bg-current/5'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-semibold truncate max-w-[210px]">
                                {br.isPoor ? '⚠️ ' : ''}
                                {br.label}
                              </span>
                              <span className="font-mono text-[11px] shrink-0" dir="ltr">
                                Δ{br.geometryErrorMm.toFixed(2)}mm · IoU {br.iouScore.toFixed(2)}
                                {br.textAccuracy !== null
                                  ? ` · Txt ${br.textAccuracy.toFixed(2)}`
                                  : ''}
                                {br.tableAccuracy !== null
                                  ? ` · Tbl ${br.tableAccuracy.toFixed(2)}`
                                  : ''}
                              </span>
                            </div>
                            {br.isPoor && br.poorReasonAr && (
                              <div className="text-[11px] text-amber-400 font-medium">
                                {br.poorReasonAr}
                              </div>
                            )}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
              </div>

              {/* Manual Coordinate & Table Inspector */}
              <ManualInspectorPanel
                theme={theme}
                objects={currentPage.objects}
                blockReports={currentPage.validationReport.blockReports}
                selectedObjectId={selectedObjectId}
                onSelectObject={setSelectedObjectId}
                onUpdateObject={handleUpdateObject}
                onAddObject={handleAddObject}
                onDeleteObject={handleDeleteObject}
              />
            </div>
          )}

          {/* STAGE 5: STEP 7 EXPORT VECTOR PDF / PNG / JPG */}
          {activeStage === 'EXPORT' && currentPage && (
            <div className={`border rounded-lg p-4 space-y-4 ${panelThemeClass}`}>
              <div>
                <h2 className="text-sm font-bold">
                  05. التصدير المتجهي (Step 7: Vector PDF · A4 · 0 Margins · Selectable Text)
                </h2>
                <p className={`text-xs mt-0.5 ${mutedTextClass}`}>
                  ملف PDF متجهي بحجم A4 (210mm × 297mm) بهوامش 0، نصوص قابلة للتحديد، وخطوط مدمجة
                </p>
              </div>

              {/* Format Selection */}
              <div className="grid grid-cols-3 gap-2.5">
                {(['PDF', 'PNG', 'JPG'] as const).map((fmt) => (
                  <button
                    key={fmt}
                    type="button"
                    onClick={() => setExportFormat(fmt)}
                    className={`p-3 rounded-lg border text-center transition-colors ${
                      exportFormat === fmt
                        ? 'border-red-600 bg-red-600/15 font-bold'
                        : 'border-current/15 hover:bg-current/5'
                    }`}
                  >
                    <div className="text-sm font-mono">{fmt}</div>
                    <div className={`text-[11px] mt-0.5 ${mutedTextClass}`}>
                      {fmt === 'PDF'
                        ? `Vector A4 (${pages.length} ص)`
                        : fmt === 'PNG'
                        ? 'صورة غير مضغوطة'
                        : 'صورة قياسية'}
                    </div>
                  </button>
                ))}
              </div>

              {/* Resolution / DPI Selector */}
              <div className="space-y-1.5">
                <label className="block text-xs font-medium">
                  دقة التصدير والطباعة (Print Resolution DPI)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { dpi: 150, desc: '150 DPI · سريعة' },
                      { dpi: 300, desc: '300 DPI · طباعة قياسية' },
                      { dpi: 400, desc: '400 DPI · أرشفة فائقة' },
                    ] as const
                  ).map((item) => (
                    <button
                      key={item.dpi}
                      type="button"
                      onClick={() => setExportDpi(item.dpi)}
                      className={`py-2 px-2.5 rounded border text-xs font-mono tabular-nums transition-colors ${
                        exportDpi === item.dpi
                          ? 'bg-red-600 text-white border-red-600'
                          : 'border-current/20 hover:bg-current/5'
                      }`}
                    >
                      {item.desc}
                    </button>
                  ))}
                </div>
              </div>

              {/* JPG Quality slider if JPG */}
              {exportFormat === 'JPG' && (
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span>جودة ضغط الصورة (JPG Quality)</span>
                    <span className="font-mono tabular-nums">
                      {Math.round(jpgQuality * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.8}
                    max={1}
                    step={0.05}
                    value={jpgQuality}
                    onChange={(e) => setJpgQuality(Number(e.target.value))}
                    className="w-full accent-red-600"
                  />
                </div>
              )}

              {/* Primary Export Action Button */}
              <button
                type="button"
                onClick={() => handleExportDocument()}
                disabled={isProcessing}
                className="w-full py-3 px-4 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>
                  تصدير وتنزيل المستند بصيغة {exportFormat}{' '}
                  {exportFormat === 'PDF' ? '(Vector A4 · 0 Margins)' : `(${exportDpi} DPI)`}
                </span>
              </button>

              {lastExportResult && (
                <div className="p-3 rounded-lg border border-emerald-500/40 bg-emerald-500/10 text-xs space-y-1">
                  <div className="font-semibold text-emerald-400">
                    تم تجهيز وتنزيل الملف بنجاح:
                  </div>
                  <div className="font-mono tabular-nums" dir="ltr">
                    {lastExportResult.filename} — {lastExportResult.sizeKb} KB —{' '}
                    {lastExportResult.dimensionsLabel}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Always show Manual Inspector below if not in VALIDATE_EDIT for rapid editing */}
          {activeStage !== 'VALIDATE_EDIT' && currentPage && (
            <ManualInspectorPanel
              theme={theme}
              objects={currentPage.objects}
              blockReports={currentPage.validationReport.blockReports}
              selectedObjectId={selectedObjectId}
              onSelectObject={setSelectedObjectId}
              onUpdateObject={handleUpdateObject}
              onAddObject={handleAddObject}
              onDeleteObject={handleDeleteObject}
            />
          )}
        </div>

        {/* LEFT COLUMN (Interactive Document Viewport & Side-by-Side Comparison) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          {/* Viewport Toolbar */}
          <div
            className={`border rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 ${panelThemeClass}`}
          >
            {/* View Mode Selector */}
            <div className="flex flex-wrap items-center gap-1.5">
              {(
                [
                  {
                    id: 'SIDE_BY_SIDE',
                    label: 'مقارنة جنباً إلى جنب',
                    icon: SplitSquareHorizontal,
                  },
                  {
                    id: 'RECONSTRUCTED_MODE_A',
                    label: 'صفحة A4 المتجهة (210×297mm)',
                    icon: FileText,
                  },
                  {
                    id: 'CLEANED_MODE_B',
                    label: 'تنظيف الصورة (Mode B)',
                    icon: Eye,
                  },
                  {
                    id: 'DIFF_HEATMAP',
                    label: 'خريطة الفروقات البصرية (Verify Diff)',
                    icon: FileSpreadsheet,
                  },
                ] as const
              ).map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setComparisonMode(id)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                    comparisonMode === id
                      ? 'bg-red-600 text-white'
                      : 'border border-current/15 hover:bg-current/5'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{label}</span>
                </button>
              ))}
            </div>

            {/* Canvas Overlay Toggles & Multi-page Selector */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setUseVectorHtmlBuilder((v) => !v)}
                className={`px-2.5 py-1.5 rounded text-xs border transition-colors whitespace-nowrap ${
                  useVectorHtmlBuilder
                    ? 'border-red-600 bg-red-600/15 font-semibold'
                    : 'border-current/20 opacity-75'
                }`}
                title="التبديل بين عارض HTML/SVG المتجهي القابل لتحديد النص وعارض Canvas القابل للسحب"
              >
                {useVectorHtmlBuilder ? 'HTML/SVG 210×297mm' : 'Canvas تفاعلي'}
              </button>

              <button
                type="button"
                onClick={() => setShowBoundingBoxes((v) => !v)}
                className={`px-2.5 py-1.5 rounded text-xs border transition-colors whitespace-nowrap ${
                  showBoundingBoxes
                    ? 'border-red-600 bg-red-600/15 font-semibold'
                    : 'border-current/20 opacity-75'
                }`}
              >
                إظهار الإحداثيات (0-1000)
              </button>

              {pages.length > 1 && (
                <div className="flex items-center gap-1 border-r pr-2 border-current/15">
                  {pages.map((pg, idx) => (
                    <button
                      key={pg.pageNumber}
                      type="button"
                      onClick={() => {
                        setActivePageIdx(idx);
                        setSelectedObjectId(pages[idx].objects[0]?.id || null);
                      }}
                      className={`px-2.5 py-1 rounded text-xs font-mono tabular-nums ${
                        activePageIdx === idx
                          ? 'bg-red-600 text-white font-bold'
                          : 'border border-current/20'
                      }`}
                    >
                      ص {pg.pageNumber}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Document Stage */}
          {currentPage && (
            <div
              className={`border rounded-lg p-4 flex-1 flex flex-col justify-center ${panelThemeClass}`}
            >
              {comparisonMode === 'SIDE_BY_SIDE' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                  {/* Source Photograph */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs px-1">
                      <span className="font-semibold">
                        1. الصورة المصدرية الممسوحة (Source Image)
                      </span>
                      <span className={`font-mono ${mutedTextClass}`} dir="ltr">
                        Orientation: {currentPage.detectedOrientationDeg ?? 0}°
                      </span>
                    </div>
                    <div className="rounded-lg overflow-hidden border border-current/20 bg-neutral-900 shadow-md">
                      <img
                        src={currentPage.sourceImageDataUrl}
                        alt="الصورة المصدرية للمستند"
                        referrerPolicy="no-referrer"
                        className="w-full h-auto block"
                      />
                    </div>
                  </div>

                  {/* Step 5: Rebuilt A4 Page (Vector HTML/SVG 210mm x 297mm or Interactive Canvas) */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs px-1">
                      <span className="font-semibold text-red-500">
                        2. النسخة المتجهة المعاد بناؤها (210mm × 297mm)
                      </span>
                      <span
                        className="font-mono tabular-nums text-emerald-500 font-semibold"
                        dir="ltr"
                      >
                        Score {(currentPage.validationReport.combinedScore ?? 0).toFixed(3)} ·
                        SSIM {(currentPage.validationReport.ssimScore ?? 0).toFixed(3)}
                      </span>
                    </div>
                    <div className="rounded-lg overflow-hidden border-2 border-red-600/60 bg-white shadow-md">
                      {useVectorHtmlBuilder ? (
                        <HtmlA4PageBuilder
                          objects={currentPage.objects}
                          blockReports={currentPage.validationReport.blockReports}
                          keepHandwriting={keepHandwriting}
                          showMeasuredBoxes={showBoundingBoxes}
                          highlightPoorBlocks={highlightLowConfidence}
                          selectedObjectId={
                            activeStage === 'VALIDATE_EDIT' || showBoundingBoxes
                              ? selectedObjectId
                              : null
                          }
                          onSelectObject={setSelectedObjectId}
                        />
                      ) : (
                        <canvas
                          ref={interactiveCanvasRef}
                          onMouseDown={handleCanvasMouseDown}
                          onMouseMove={handleCanvasMouseMove}
                          onMouseUp={handleCanvasMouseUp}
                          onMouseLeave={handleCanvasMouseUp}
                          className="w-full h-auto block cursor-pointer"
                        />
                      )}
                    </div>
                  </div>
                </div>
              ) : comparisonMode === 'RECONSTRUCTED_MODE_A' ? (
                <div className="max-w-2xl mx-auto w-full space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold">
                      الصفحة المتجهة المعاد بناؤها (Step 5: 210mm × 297mm Vector HTML/SVG — نصوص قابلة للتحديد وخطوط متجهة)
                    </span>
                    <span className="font-mono tabular-nums" dir="ltr">
                      A4 · 210 × 297 mm · 0 Margins
                    </span>
                  </div>
                  <div className="rounded-lg overflow-hidden border border-current/20 bg-white shadow-lg">
                    {useVectorHtmlBuilder ? (
                      <HtmlA4PageBuilder
                        objects={currentPage.objects}
                        blockReports={currentPage.validationReport.blockReports}
                        keepHandwriting={keepHandwriting}
                        showMeasuredBoxes={showBoundingBoxes}
                        highlightPoorBlocks={highlightLowConfidence}
                        selectedObjectId={
                          activeStage === 'VALIDATE_EDIT' || showBoundingBoxes
                            ? selectedObjectId
                            : null
                        }
                        onSelectObject={setSelectedObjectId}
                      />
                    ) : (
                      <canvas
                        ref={interactiveCanvasRef}
                        onMouseDown={handleCanvasMouseDown}
                        onMouseMove={handleCanvasMouseMove}
                        onMouseUp={handleCanvasMouseUp}
                        onMouseLeave={handleCanvasMouseUp}
                        className="w-full h-auto block cursor-pointer"
                      />
                    )}
                  </div>
                </div>
              ) : comparisonMode === 'CLEANED_MODE_B' ? (
                <div className="max-w-2xl mx-auto w-full space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold">
                      الصورة المنظفة بعد Step 1 (إزالة الظلال ونزف الخلفية وتصحيح الميلان)
                    </span>
                    <span className="font-mono tabular-nums">
                      {keepHandwriting
                        ? 'مع الاحتفاظ بالخط اليدوي'
                        : 'مع إزالة الخط اليدوي بالترميم (Inpainted)'}
                    </span>
                  </div>
                  <div className="rounded-lg overflow-hidden border border-current/20 bg-white shadow-lg">
                    <img
                      src={currentPage.preprocessedImageDataUrl}
                      alt="الوثيقة المنظفة"
                      referrerPolicy="no-referrer"
                      className="w-full h-auto block"
                    />
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                  <div className="space-y-2">
                    <div className="text-xs font-semibold">
                      الصورة المنظفة المقاسة (Cleaned Source)
                    </div>
                    <div className="rounded-lg overflow-hidden border border-current/20 bg-white">
                      <img
                        src={currentPage.preprocessedImageDataUrl}
                        alt="الصورة بعد المعالجة"
                        referrerPolicy="no-referrer"
                        className="w-full h-auto block"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-xs font-semibold">
                      خريطة الفروقات البصرية لحلقة التحقق (أخضر: تطابق · أحمر: حبر مصدري · أزرق: انزياح)
                    </div>
                    <div className="rounded-lg overflow-hidden border border-current/20 bg-white">
                      {currentPage.validationReport.diffHeatmapDataUrl && (
                        <img
                          src={currentPage.validationReport.diffHeatmapDataUrl}
                          alt="خريطة الفروقات البصرية"
                          referrerPolicy="no-referrer"
                          className="w-full h-auto block"
                        />
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      {/* Camera Capture Modal */}
      {isCameraOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className={`w-full max-w-lg rounded-xl border p-4 space-y-4 ${panelThemeClass}`}>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold">التقاط صورة وثيقة لإعادة بنائها</h3>
              <button
                type="button"
                onClick={closeCameraModal}
                className="text-xs underline opacity-80"
              >
                إلغاء
              </button>
            </div>
            <div className="rounded-lg overflow-hidden bg-black aspect-[3/4] flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
            </div>
            <button
              type="button"
              onClick={captureCameraFrame}
              className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-bold"
            >
              التقاط وبدء القياس وإعادة البناء
            </button>
          </div>
        </div>
      )}

      {/* Native Android Project Source & SDK Modal */}
      <AndroidArchitectureModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
        theme={theme}
      />
    </div>
  );
}
