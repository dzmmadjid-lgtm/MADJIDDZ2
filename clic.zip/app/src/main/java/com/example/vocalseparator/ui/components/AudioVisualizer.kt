package com.example.vocalseparator.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.vocalseparator.ui.theme.CyanAccent
import com.example.vocalseparator.ui.theme.VocalPink
import kotlin.random.Random

/**
 * Animated dynamic audio visualizer simulating stereo frequency spectrum bars.
 */
@Composable
fun AudioVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 36,
    accentColor: Color = CyanAccent,
    secondaryColor: Color = VocalPink
) {
    val phaseAnim = remember { Animatable(0f) }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            phaseAnim.animateTo(
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 1200, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        } else {
            phaseAnim.snapTo(0f)
        }
    }

    val staticHeights = remember {
        val random = Random(42)
        FloatArray(barCount) { 0.25f + random.nextFloat() * 0.55f }
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
    ) {
        val totalWidth = size.width
        val maxHeight = size.height
        val barWidth = (totalWidth / (barCount * 1.5f)).coerceAtLeast(3f)
        val gap = (totalWidth - (barWidth * barCount)) / (barCount - 1).coerceAtLeast(1)

        val brush = Brush.verticalGradient(
            colors = listOf(secondaryColor, accentColor),
            startY = 0f,
            endY = maxHeight
        )

        for (i in 0 until barCount) {
            val baseH = staticHeights[i]
            val dynamicScale = if (isPlaying) {
                // Wave oscillation equation
                val wave = Math.sin((phaseAnim.value * Math.PI * 2) + (i * 0.45)).toFloat()
                (baseH * (0.6f + 0.4f * wave)).coerceIn(0.12f, 0.98f)
            } else {
                (baseH * 0.35f).coerceIn(0.1f, 0.4f)
            }

            val barHeight = maxHeight * dynamicScale
            val x = i * (barWidth + gap)
            val y = (maxHeight - barHeight) / 2f

            drawRoundRect(
                brush = brush,
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2, barWidth / 2)
            )
        }
    }
}
