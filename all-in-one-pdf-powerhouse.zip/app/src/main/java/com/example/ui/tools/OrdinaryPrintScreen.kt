package com.example.ui.tools

import android.app.Activity
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.theme.AccentYellow
import com.example.utils.PdfEngine
import com.example.utils.PrintHelper
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdinaryPrintScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var documentName by remember { mutableStateOf("مستند PDF") }
    var totalPages by remember { mutableIntStateOf(0) }

    val pdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            pdfUri = uri
            coroutineScope.launch {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && idx != -1) {
                        documentName = cursor.getString(idx)
                    }
                }
                totalPages = PdfEngine.getPageCount(context, uri)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الطباعة العادية (نظام أندرويد)", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Explanatory card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF9C3).copy(alpha = 0.7f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(Icons.Outlined.Print, contentDescription = null, tint = Color(0xFF854D0E))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الطباعة عبر خادم طباعة أندرويد (الزر الأصفر)", fontWeight = FontWeight.Bold, color = Color(0xFF713F12))
                        Text(
                            text = "يتيح هذا المسار طباعة المستند عبر خدمات الطباعة المثبتة في هاتفك (مثل Google Cloud Print، أو HP Print Service Plugin، أو Mopria Print Service)، مع التحكم الكامل في عدد النسخ وحجم الورق والطباعة على الوجهين.",
                            fontSize = 12.sp,
                            color = Color(0xFF854D0E)
                        )
                    }
                }
            }

            // Document Selector
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (pdfUri != null) documentName else "لم يتم اختيار مستند بعد",
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        if (totalPages > 0) {
                            Text("عدد الصفحات: $totalPages", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Button(
                        onClick = { pdfPicker.launch(arrayOf("application/pdf")) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentYellow),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("اختيار ملف", color = Color(0xFF713F12), fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Prominent Yellow Print Button
            Button(
                onClick = {
                    if (pdfUri == null) {
                        Toast.makeText(context, "الرجاء اختيار مستند PDF أولاً", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    (context as? Activity)?.let { activity ->
                        PrintHelper.printOrdinary(activity, pdfUri!!, documentName)
                    }
                },
                enabled = pdfUri != null,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFACC15),
                    disabledContainerColor = Color(0xFFE2E8F0)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("ordinary_yellow_print_action_button")
            ) {
                Icon(Icons.Default.Print, contentDescription = null, tint = Color(0xFF713F12))
                Spacer(modifier = Modifier.width(8.dp))
                Text("بدء الطباعة العادية (الزر الأصفر)", fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color(0xFF713F12))
            }
        }
    }
}
