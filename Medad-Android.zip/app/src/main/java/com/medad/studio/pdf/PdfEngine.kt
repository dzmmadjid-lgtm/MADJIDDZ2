package com.medad.studio.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class PagePreview(
    val index: Int,
    val bitmap: Bitmap,
    val widthPt: Int,
    val heightPt: Int,
)

object PdfEngine {

    suspend fun pageCount(context: Context, uri: Uri): Int = withContext(Dispatchers.IO) {
        openRenderer(context, uri).use { it.pageCount }
    }

    suspend fun renderPage(
        context: Context,
        uri: Uri,
        index: Int,
        maxWidth: Int = 1080,
        nightInvert: Boolean = false,
    ): PagePreview = withContext(Dispatchers.IO) {
        openRenderer(context, uri).use { renderer ->
            renderer.openPage(index).use { page ->
                val scale = maxWidth.toFloat() / page.width.coerceAtLeast(1)
                val w = (page.width * scale).toInt().coerceAtLeast(1)
                val h = (page.height * scale).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                val matrix = Matrix().apply { postScale(scale, scale) }
                page.render(bmp, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                val out = if (nightInvert) invertForOled(bmp) else bmp
                PagePreview(index, out, page.width, page.height)
            }
        }
    }

    suspend fun renderAll(
        context: Context,
        uri: Uri,
        maxWidth: Int = 1400,
        onProgress: (Int, Int) -> Unit = { _, _ -> },
    ): List<Bitmap> = withContext(Dispatchers.IO) {
        openRenderer(context, uri).use { renderer ->
            (0 until renderer.pageCount).map { i ->
                onProgress(i + 1, renderer.pageCount)
                renderer.openPage(i).use { page ->
                    val scale = maxWidth.toFloat() / page.width.coerceAtLeast(1)
                    val w = (page.width * scale).toInt().coerceAtLeast(1)
                    val h = (page.height * scale).toInt().coerceAtLeast(1)
                    Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { bmp ->
                        bmp.eraseColor(Color.WHITE)
                        val matrix = Matrix().apply { postScale(scale, scale) }
                        page.render(bmp, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    }
                }
            }
        }
    }

    suspend fun imagesToPdf(
        context: Context,
        imageUris: List<Uri>,
        outFile: File,
        onProgress: (Int, Int) -> Unit = { _, _ -> },
    ): File = withContext(Dispatchers.IO) {
        val document = PdfDocument()
        imageUris.forEachIndexed { index, uri ->
            onProgress(index + 1, imageUris.size)
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@forEachIndexed
            val src = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: return@forEachIndexed
            val pageWidth = 595
            val pageHeight = 842
            val info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
            val page = document.startPage(info)
            val canvas: Canvas = page.canvas
            canvas.drawColor(Color.WHITE)
            val scale = minOf(
                pageWidth.toFloat() / src.width,
                pageHeight.toFloat() / src.height,
            )
            val dw = src.width * scale
            val dh = src.height * scale
            val left = (pageWidth - dw) / 2f
            val top = (pageHeight - dh) / 2f
            val fitted = Bitmap.createScaledBitmap(src, dw.toInt().coerceAtLeast(1), dh.toInt().coerceAtLeast(1), true)
            canvas.drawBitmap(fitted, left, top, null)
            document.finishPage(page)
            if (fitted !== src) fitted.recycle()
            src.recycle()
        }
        FileOutputStream(outFile).use { document.writeTo(it) }
        document.close()
        outFile
    }

    suspend fun pdfToJpegFiles(
        context: Context,
        uri: Uri,
        outDir: File,
        quality: Int = 92,
        onProgress: (Int, Int) -> Unit = { _, _ -> },
    ): List<File> = withContext(Dispatchers.IO) {
        outDir.mkdirs()
        val bitmaps = renderAll(context, uri, maxWidth = 1600, onProgress = onProgress)
        bitmaps.mapIndexed { i, bmp ->
            val file = File(outDir, "page_${(i + 1).toString().padStart(3, '0')}.jpg")
            FileOutputStream(file).use { out ->
                bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
            }
            bmp.recycle()
            file
        }
    }

    private fun invertForOled(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val c = pixels[i]
            val a = c ushr 24
            val r = 255 - ((c shr 16) and 0xFF)
            val g = 255 - ((c shr 8) and 0xFF)
            val b = 255 - (c and 0xFF)
            pixels[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        if (out !== src) src.recycle()
        return out
    }

    private fun openRenderer(context: Context, uri: Uri): PdfRenderer {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("تعذر فتح الملف")
        return PdfRenderer(pfd)
    }

    fun copyToCache(context: Context, uri: Uri, name: String = "working.pdf"): File {
        val file = File(context.cacheDir, name)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(file).use { output -> input.copyTo(output) }
        } ?: error("تعذر قراءة الملف")
        return file
    }

    fun fileDescriptor(file: File): ParcelFileDescriptor {
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }
}
