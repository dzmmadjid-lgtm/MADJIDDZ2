import { PreprocessingConfig } from '../models/DocumentModel';

declare global {
  interface Window {
    cv?: any;
  }
}

export interface DetectedHandwritingLayer {
  id: string;
  /** Normalized [x, y, width, height] in 0..1000 relative to the cleaned page */
  bbox: [number, number, number, number];
  /** Cleaned transparent PNG crop containing only the handwriting ink strokes */
  croppedTransparentDataUrl: string;
}

export interface PreprocessedPageResult {
  pageIndex: number;
  widthPx: number;
  heightPx: number;
  detectedOrientationDeg: 0 | 90 | 180 | 270;
  measuredSkewDeg: number;
  wasSplitFromTwoPageScan: boolean;
  /** Cleaned image with handwriting removed by inpainting (Step 4 default) */
  inpaintedCleanedDataUrl: string;
  /** Cleaned image with handwriting kept */
  cleanedWithHandwritingDataUrl: string;
  /** Extracted transparent handwriting crops at exact 0..1000 bboxes */
  handwritingLayers: DetectedHandwritingLayer[];
}

export function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

/**
 * Detects whether a single scan contains two pages (side-by-side spread or vertical stack)
 * by measuring the ink projection valley in the central [42%..58%] zone.
 */
function detectTwoPageSplit(
  canvas: HTMLCanvasElement
): { splitMode: 'none' | 'horizontal_spread' | 'vertical_stack'; splitRatio: number } {
  const w = canvas.width;
  const h = canvas.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return { splitMode: 'none', splitRatio: 0.5 };

  const { data } = ctx.getImageData(0, 0, w, h);
  const aspect = w / h;

  // Check horizontal spread (two side-by-side pages, e.g. aspect > 1.18)
  if (aspect > 1.18) {
    const colInk = new Float32Array(w);
    for (let x = 0; x < w; x++) {
      let ink = 0;
      for (let y = Math.floor(h * 0.08); y < Math.floor(h * 0.92); y += 2) {
        const idx = (y * w + x) * 4;
        const luma = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
        if (luma < 185) ink++;
      }
      colInk[x] = ink / (h * 0.42);
    }

    let leftInk = 0;
    let rightInk = 0;
    for (let x = Math.floor(w * 0.1); x < Math.floor(w * 0.4); x++) leftInk += colInk[x];
    for (let x = Math.floor(w * 0.6); x < Math.floor(w * 0.9); x++) rightInk += colInk[x];
    leftInk /= w * 0.3;
    rightInk /= w * 0.3;

    if (leftInk > 0.015 && rightInk > 0.015) {
      let minValley = 1e9;
      let bestX = Math.floor(w * 0.5);
      const searchStart = Math.floor(w * 0.43);
      const searchEnd = Math.floor(w * 0.57);
      for (let x = searchStart; x <= searchEnd; x++) {
        let windowSum = 0;
        for (let k = -4; k <= 4; k++) windowSum += colInk[Math.max(0, Math.min(w - 1, x + k))];
        if (windowSum < minValley) {
          minValley = windowSum;
          bestX = x;
        }
      }
      return { splitMode: 'horizontal_spread', splitRatio: bestX / w };
    }
  }

  // Check vertical stack (two pages stacked vertically, e.g. aspect < 0.52)
  if (aspect < 0.52) {
    const rowInk = new Float32Array(h);
    for (let y = 0; y < h; y++) {
      let ink = 0;
      for (let x = Math.floor(w * 0.08); x < Math.floor(w * 0.92); x += 2) {
        const idx = (y * w + x) * 4;
        const luma = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
        if (luma < 185) ink++;
      }
      rowInk[y] = ink / (w * 0.42);
    }

    let bestY = Math.floor(h * 0.5);
    let minValley = 1e9;
    for (let y = Math.floor(h * 0.43); y <= Math.floor(h * 0.57); y++) {
      let windowSum = 0;
      for (let k = -4; k <= 4; k++) windowSum += rowInk[Math.max(0, Math.min(h - 1, y + k))];
      if (windowSum < minValley) {
        minValley = windowSum;
        bestY = y;
      }
    }
    return { splitMode: 'vertical_stack', splitRatio: bestY / h };
  }

  return { splitMode: 'none', splitRatio: 0.5 };
}

/**
 * Measures page orientation (0 / 90 / 180 / 270) from projection profiles
 * and top/bottom baseline density asymmetry.
 */
function detectPageOrientation(canvas: HTMLCanvasElement): 0 | 90 | 180 | 270 {
  const w = canvas.width;
  const h = canvas.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return 0;

  const { data } = ctx.getImageData(0, 0, w, h);

  const rowCounts = new Float32Array(h);
  const colCounts = new Float32Array(w);

  for (let y = Math.floor(h * 0.06); y < Math.floor(h * 0.94); y += 2) {
    for (let x = Math.floor(w * 0.06); x < Math.floor(w * 0.94); x += 2) {
      const idx = (y * w + x) * 4;
      const luma = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
      if (luma < 175) {
        rowCounts[y]++;
        colCounts[x]++;
      }
    }
  }

  let rowDiffVar = 0;
  for (let y = 2; y < h - 2; y += 2) {
    const d = rowCounts[y] - rowCounts[y - 2];
    rowDiffVar += d * d;
  }
  rowDiffVar /= h;

  let colDiffVar = 0;
  for (let x = 2; x < w - 2; x += 2) {
    const d = colCounts[x] - colCounts[x - 2];
    colDiffVar += d * d;
  }
  colDiffVar /= w;

  // If vertical lines have much stronger text-line modulation than horizontal lines, page is 90/270
  if (colDiffVar > rowDiffVar * 1.65 && w > h * 1.1) {
    return 90;
  }

  // Check if upside-down (180 deg): compare top 22% header ink vs bottom 12% footer emptiness
  let topQuarterInk = 0;
  let bottomMarginInk = 0;
  for (let y = Math.floor(h * 0.04); y < Math.floor(h * 0.24); y += 2) {
    topQuarterInk += rowCounts[y];
  }
  for (let y = Math.floor(h * 0.86); y < Math.floor(h * 0.96); y += 2) {
    bottomMarginInk += rowCounts[y];
  }

  if (topQuarterInk < bottomMarginInk * 0.22 && bottomMarginInk > 40) {
    return 180;
  }

  return 0;
}

/**
 * Measures fine skew angle (-7° to +7°) via horizontal projection variance maximization.
 */
function measureSkewAngleDeg(canvas: HTMLCanvasElement): number {
  const sampleW = 360;
  const sampleH = Math.round((canvas.height / canvas.width) * sampleW) || 510;
  const tmp = document.createElement('canvas');
  tmp.width = sampleW;
  tmp.height = sampleH;
  const ctx = tmp.getContext('2d');
  if (!ctx) return 0;

  ctx.drawImage(canvas, 0, 0, sampleW, sampleH);
  const { data } = ctx.getImageData(0, 0, sampleW, sampleH);

  // Collect dark ink points
  const ptsX: number[] = [];
  const ptsY: number[] = [];
  const cx = sampleW / 2;
  const cy = sampleH / 2;

  for (let y = 20; y < sampleH - 20; y += 2) {
    for (let x = 20; x < sampleW - 20; x += 3) {
      const idx = (y * sampleW + x) * 4;
      const luma = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
      if (luma < 165) {
        ptsX.push(x - cx);
        ptsY.push(y - cy);
      }
    }
  }

  if (ptsX.length < 80) return 0;

  let bestAngle = 0;
  let bestVariance = -1;
  const hist = new Float32Array(sampleH);

  for (let deg = -6.0; deg <= 6.0; deg += 0.25) {
    const rad = (deg * Math.PI) / 180;
    const sinA = Math.sin(rad);
    const cosA = Math.cos(rad);
    hist.fill(0);

    for (let i = 0; i < ptsX.length; i++) {
      const ry = Math.round(-ptsX[i] * sinA + ptsY[i] * cosA + cy);
      if (ry >= 0 && ry < sampleH) {
        hist[ry]++;
      }
    }

    let variance = 0;
    for (let y = 1; y < sampleH; y++) {
      const diff = hist[y] - hist[y - 1];
      variance += diff * diff;
    }

    if (variance > bestVariance) {
      bestVariance = variance;
      bestAngle = deg;
    }
  }

  return Math.abs(bestAngle) < 0.3 ? 0 : Math.round(bestAngle * 10) / 10;
}

/**
 * Crops outer dark scanner borders to the detected paper boundary.
 */
function measurePaperBorderCrop(
  data: Uint8ClampedArray,
  w: number,
  h: number
): { sx: number; sy: number; sw: number; sh: number } {
  let top = 0;
  let bottom = h - 1;
  let left = 0;
  let right = w - 1;

  // Scan inward from edges if outer border is dark scanner background (< 130 mean luma)
  const rowMeanLuma = (y: number) => {
    let sum = 0;
    let count = 0;
    for (let x = Math.floor(w * 0.15); x < Math.floor(w * 0.85); x += 4) {
      const idx = (y * w + x) * 4;
      sum += 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
      count++;
    }
    return count > 0 ? sum / count : 255;
  };

  const colMeanLuma = (x: number) => {
    let sum = 0;
    let count = 0;
    for (let y = Math.floor(h * 0.15); y < Math.floor(h * 0.85); y += 4) {
      const idx = (y * w + x) * 4;
      sum += 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
      count++;
    }
    return count > 0 ? sum / count : 255;
  };

  while (top < h * 0.12 && rowMeanLuma(top) < 145) top++;
  while (bottom > h * 0.88 && rowMeanLuma(bottom) < 145) bottom--;
  while (left < w * 0.12 && colMeanLuma(left) < 145) left++;
  while (right > w * 0.88 && colMeanLuma(right) < 145) right--;

  const sw = Math.max(100, right - left + 1);
  const sh = Math.max(100, bottom - top + 1);
  return { sx: left, sy: top, sw, sh };
}

/**
 * Step 1 + Step 4: Cleans a single page canvas:
 * - Removes shadows & scanner bands via local morphological background estimation
 * - Suppresses reverse-side bleed-through via adaptive thresholding + background normalization
 * - Separates handwritten ink annotations (blue/red pen or cursive annotations):
 *   - Produces `inpaintedCleanedDataUrl` (handwriting removed by inpainting)
 *   - Produces `cleanedWithHandwritingDataUrl` (handwriting preserved)
 *   - Extracts `handwritingLayers` as cleaned transparent PNG crops at exact 0..1000 bboxes
 */
function cleanAndSeparateHandwritingSinglePage(
  pageCanvas: HTMLCanvasElement,
  config: PreprocessingConfig
): {
  inpaintedCleanedDataUrl: string;
  cleanedWithHandwritingDataUrl: string;
  handwritingLayers: DetectedHandwritingLayer[];
} {
  const w = pageCanvas.width;
  const h = pageCanvas.height;
  const ctx = pageCanvas.getContext('2d')!;
  const srcImgData = ctx.getImageData(0, 0, w, h);
  const src = srcImgData.data;

  // If OpenCV.js is loaded in window.cv, we can run cv.Mat morphological background estimation
  // We also compute the exact block illumination grid & adaptive threshold in TypedArrays for 100% reliability
  const blockSize = 28;
  const gridCols = Math.ceil(w / blockSize);
  const gridRows = Math.ceil(h / blockSize);
  const bgLumaGrid = new Float32Array(gridCols * gridRows);

  for (let gy = 0; gy < gridRows; gy++) {
    for (let gx = 0; gx < gridCols; gx++) {
      let maxLuma = 185;
      const startY = gy * blockSize;
      const endY = Math.min(h, startY + blockSize);
      const startX = gx * blockSize;
      const endX = Math.min(w, startX + blockSize);

      for (let y = startY; y < endY; y += 3) {
        for (let x = startX; x < endX; x += 3) {
          const idx = (y * w + x) * 4;
          const luma = 0.299 * src[idx] + 0.587 * src[idx + 1] + 0.114 * src[idx + 2];
          if (luma > maxLuma) maxLuma = luma;
        }
      }
      bgLumaGrid[gy * gridCols + gx] = Math.max(125, maxLuma);
    }
  }

  // Smooth the illumination grid to eliminate scanner bands
  const smoothedBg = new Float32Array(gridCols * gridRows);
  for (let gy = 0; gy < gridRows; gy++) {
    for (let gx = 0; gx < gridCols; gx++) {
      let sum = 0;
      let count = 0;
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const ny = gy + dy;
          const nx = gx + dx;
          if (ny >= 0 && ny < gridRows && nx >= 0 && nx < gridCols) {
            sum += bgLumaGrid[ny * gridCols + nx];
            count++;
          }
        }
      }
      smoothedBg[gy * gridCols + gx] = sum / count;
    }
  }

  const inpaintedCanvas = document.createElement('canvas');
  inpaintedCanvas.width = w;
  inpaintedCanvas.height = h;
  const inpaintedCtx = inpaintedCanvas.getContext('2d')!;
  const inpaintedImgData = inpaintedCtx.createImageData(w, h);
  const dstInpaint = inpaintedImgData.data;

  const keptCanvas = document.createElement('canvas');
  keptCanvas.width = w;
  keptCanvas.height = h;
  const keptCtx = keptCanvas.getContext('2d')!;
  const keptImgData = keptCtx.createImageData(w, h);
  const dstKept = keptImgData.data;

  // Mask of detected handwriting ink pixels (1 = handwriting ink)
  const handwritingMask = new Uint8Array(w * h);

  const shadowFactor = config.removeShadows ? config.shadowStrength / 100 : 0;
  const contrastGain = 1 + (config.contrastBoost / 100) * 0.95;
  // Adaptive bleed-through threshold: reverse-side bleed-through has normalized luma 195..245
  const bleedThroughClip = config.removeBleedThrough !== false ? 214 : 232;

  for (let y = 0; y < h; y++) {
    const gy = Math.min(gridRows - 1, Math.floor(y / blockSize));
    for (let x = 0; x < w; x++) {
      const gx = Math.min(gridCols - 1, Math.floor(x / blockSize));
      const pIdx = y * w + x;
      const idx = pIdx * 4;

      let r = src[idx];
      let g = src[idx + 1];
      let b = src[idx + 2];

      if (shadowFactor > 0) {
        const localBg = smoothedBg[gy * gridCols + gx];
        const scale = 1 + shadowFactor * (252 / localBg - 1);
        r = Math.min(255, r * scale);
        g = Math.min(255, g * scale);
        b = Math.min(255, b * scale);
      }

      const luma = 0.299 * r + 0.587 * g + 0.114 * b;

      // Detect handwritten ballpoint/marker ink (blue pen, violet pen, or red/green annotation ink)
      const isBluePenInk = b - r > 26 && b - g > 14 && luma < 215;
      const isRedPenInk = r - b > 36 && r - g > 32 && luma < 215;
      const isHandwritingInk = isBluePenInk || isRedPenInk;

      if (isHandwritingInk) {
        handwritingMask[pIdx] = 1;
      }

      // Suppress reverse-side bleed-through & normalize paper background to pure white (255,255,255)
      if (luma >= bleedThroughClip && !isHandwritingInk) {
        r = 255;
        g = 255;
        b = 255;
      } else {
        r = Math.min(255, Math.max(0, (r - 160) * contrastGain + 160));
        g = Math.min(255, Math.max(0, (g - 160) * contrastGain + 160));
        b = Math.min(255, Math.max(0, (b - 160) * contrastGain + 160));
      }

      // Kept canvas preserves handwriting
      dstKept[idx] = r;
      dstKept[idx + 1] = g;
      dstKept[idx + 2] = b;
      dstKept[idx + 3] = 255;

      // Inpainted canvas removes handwriting by replacing pen ink with clean white background
      if (isHandwritingInk) {
        dstInpaint[idx] = 255;
        dstInpaint[idx + 1] = 255;
        dstInpaint[idx + 2] = 255;
        dstInpaint[idx + 3] = 255;
      } else {
        dstInpaint[idx] = r;
        dstInpaint[idx + 1] = g;
        dstInpaint[idx + 2] = b;
        dstInpaint[idx + 3] = 255;
      }
    }
  }

  inpaintedCtx.putImageData(inpaintedImgData, 0, 0);
  keptCtx.putImageData(keptImgData, 0, 0);

  // Group handwritingMask into bounding boxes and extract transparent PNG crops
  const handwritingLayers = extractHandwritingTransparentCrops(
    handwritingMask,
    dstKept,
    w,
    h
  );

  return {
    inpaintedCleanedDataUrl: inpaintedCanvas.toDataURL('image/png'),
    cleanedWithHandwritingDataUrl: keptCanvas.toDataURL('image/png'),
    handwritingLayers,
  };
}

/**
 * Finds connected regions of handwriting ink and creates a cleaned transparent PNG crop
 * for each region with normalized 0..1000 bbox coordinates.
 */
function extractHandwritingTransparentCrops(
  mask: Uint8Array,
  rgbaData: Uint8ClampedArray,
  w: number,
  h: number
): DetectedHandwritingLayer[] {
  const gridW = 50;
  const gridH = 70;
  const cellW = w / gridW;
  const cellH = h / gridH;
  const cellActive = new Uint8Array(gridW * gridH);

  for (let gy = 0; gy < gridH; gy++) {
    for (let gx = 0; gx < gridW; gx++) {
      let count = 0;
      const y0 = Math.floor(gy * cellH);
      const y1 = Math.min(h, Math.floor((gy + 1) * cellH));
      const x0 = Math.floor(gx * cellW);
      const x1 = Math.min(w, Math.floor((gx + 1) * cellW));
      for (let y = y0; y < y1; y++) {
        for (let x = x0; x < x1; x++) {
          if (mask[y * w + x]) count++;
        }
      }
      if (count >= 4) {
        cellActive[gy * gridW + gx] = 1;
      }
    }
  }

  const visited = new Uint8Array(gridW * gridH);
  const layers: DetectedHandwritingLayer[] = [];

  for (let gy = 0; gy < gridH; gy++) {
    for (let gx = 0; gx < gridW; gx++) {
      const startIdx = gy * gridW + gx;
      if (!cellActive[startIdx] || visited[startIdx]) continue;

      let minGX = gx;
      let maxGX = gx;
      let minGY = gy;
      let maxGY = gy;
      const queue = [startIdx];
      visited[startIdx] = 1;

      while (queue.length > 0) {
        const curr = queue.pop()!;
        const cy = Math.floor(curr / gridW);
        const cx = curr % gridW;
        if (cx < minGX) minGX = cx;
        if (cx > maxGX) maxGX = cx;
        if (cy < minGY) minGY = cy;
        if (cy > maxGY) maxGY = cy;

        for (let dy = -2; dy <= 2; dy++) {
          for (let dx = -2; dx <= 2; dx++) {
            const ny = cy + dy;
            const nx = cx + dx;
            if (ny >= 0 && ny < gridH && nx >= 0 && nx < gridW) {
              const nIdx = ny * gridW + nx;
              if (cellActive[nIdx] && !visited[nIdx]) {
                visited[nIdx] = 1;
                queue.push(nIdx);
              }
            }
          }
        }
      }

      const pxX = Math.max(0, Math.floor(minGX * cellW) - 4);
      const pxY = Math.max(0, Math.floor(minGY * cellH) - 4);
      const pxW = Math.min(w - pxX, Math.ceil((maxGX - minGX + 1) * cellW) + 8);
      const pxH = Math.min(h - pxY, Math.ceil((maxGY - minGY + 1) * cellH) + 8);

      if (pxW < 14 || pxH < 10) continue;

      const cropCanvas = document.createElement('canvas');
      cropCanvas.width = pxW;
      cropCanvas.height = pxH;
      const cropCtx = cropCanvas.getContext('2d')!;
      const cropImgData = cropCtx.createImageData(pxW, pxH);
      const cData = cropImgData.data;

      for (let y = 0; y < pxH; y++) {
        for (let x = 0; x < pxW; x++) {
          const srcIdx = (pxY + y) * w + (pxX + x);
          const dstIdx = (y * pxW + x) * 4;
          if (mask[srcIdx]) {
            cData[dstIdx] = rgbaData[srcIdx * 4];
            cData[dstIdx + 1] = rgbaData[srcIdx * 4 + 1];
            cData[dstIdx + 2] = rgbaData[srcIdx * 4 + 2];
            cData[dstIdx + 3] = 255;
          } else {
            cData[dstIdx + 3] = 0; // Transparent background
          }
        }
      }

      cropCtx.putImageData(cropImgData, 0, 0);

      const normX = Math.round((pxX / w) * 1000);
      const normY = Math.round((pxY / h) * 1000);
      const normW = Math.round((pxW / w) * 1000);
      const normH = Math.round((pxH / h) * 1000);

      layers.push({
        id: `handwriting_layer_${layers.length + 1}`,
        bbox: [normX, normY, normW, normH],
        croppedTransparentDataUrl: cropCanvas.toDataURL('image/png'),
      });
    }
  }

  return layers;
}

/**
 * Full Step 1 Pipeline:
 * 1. Splits two-page scans if detected
 * 2. Detects orientation (0/90/180/270) and deskews each page
 * 3. Crops to the page border
 * 4. Removes shadows, scanner bands, and reverse-side bleed-through
 * 5. Inpaints handwriting by default and extracts transparent handwriting layers
 */
export async function runStep1PreprocessPipeline(
  sourceDataUrl: string,
  config: PreprocessingConfig
): Promise<PreprocessedPageResult[]> {
  const img = await loadImageElement(sourceDataUrl);
  const rawCanvas = document.createElement('canvas');
  rawCanvas.width = img.width || 1000;
  rawCanvas.height = img.height || 1414;
  const rawCtx = rawCanvas.getContext('2d')!;
  rawCtx.drawImage(img, 0, 0);

  // Check if scan contains two pages
  const splitCheck =
    config.splitTwoPageScan !== false
      ? detectTwoPageSplit(rawCanvas)
      : { splitMode: 'none' as const, splitRatio: 0.5 };

  const rawPageCanvases: { canvas: HTMLCanvasElement; wasSplit: boolean }[] = [];

  if (splitCheck.splitMode === 'horizontal_spread') {
    const splitX = Math.round(rawCanvas.width * splitCheck.splitRatio);
    const p1 = document.createElement('canvas');
    p1.width = splitX;
    p1.height = rawCanvas.height;
    p1.getContext('2d')!.drawImage(rawCanvas, 0, 0, splitX, rawCanvas.height, 0, 0, splitX, rawCanvas.height);

    const p2 = document.createElement('canvas');
    p2.width = rawCanvas.width - splitX;
    p2.height = rawCanvas.height;
    p2.getContext('2d')!.drawImage(
      rawCanvas,
      splitX,
      0,
      rawCanvas.width - splitX,
      rawCanvas.height,
      0,
      0,
      rawCanvas.width - splitX,
      rawCanvas.height
    );

    rawPageCanvases.push({ canvas: p1, wasSplit: true }, { canvas: p2, wasSplit: true });
  } else if (splitCheck.splitMode === 'vertical_stack') {
    const splitY = Math.round(rawCanvas.height * splitCheck.splitRatio);
    const p1 = document.createElement('canvas');
    p1.width = rawCanvas.width;
    p1.height = splitY;
    p1.getContext('2d')!.drawImage(rawCanvas, 0, 0, rawCanvas.width, splitY, 0, 0, rawCanvas.width, splitY);

    const p2 = document.createElement('canvas');
    p2.width = rawCanvas.width;
    p2.height = rawCanvas.height - splitY;
    p2.getContext('2d')!.drawImage(
      rawCanvas,
      0,
      splitY,
      rawCanvas.width,
      rawCanvas.height - splitY,
      0,
      0,
      rawCanvas.width,
      rawCanvas.height - splitY
    );

    rawPageCanvases.push({ canvas: p1, wasSplit: true }, { canvas: p2, wasSplit: true });
  } else {
    rawPageCanvases.push({ canvas: rawCanvas, wasSplit: false });
  }

  const results: PreprocessedPageResult[] = [];

  for (let i = 0; i < rawPageCanvases.length; i++) {
    const { canvas: subCanvas, wasSplit } = rawPageCanvases[i];

    // 1. Detect orientation (0/90/180/270)
    const detectedOrientation =
      config.autoOrientationDetect !== false ? detectPageOrientation(subCanvas) : 0;
    const totalRotation = ((config.rotationDeg + detectedOrientation) % 360) as 0 | 90 | 180 | 270;

    // Rotate upright
    const uprightCanvas = document.createElement('canvas');
    if (totalRotation === 90 || totalRotation === 270) {
      uprightCanvas.width = subCanvas.height;
      uprightCanvas.height = subCanvas.width;
    } else {
      uprightCanvas.width = subCanvas.width;
      uprightCanvas.height = subCanvas.height;
    }
    const uCtx = uprightCanvas.getContext('2d')!;
    uCtx.fillStyle = '#FFFFFF';
    uCtx.fillRect(0, 0, uprightCanvas.width, uprightCanvas.height);
    uCtx.save();
    uCtx.translate(uprightCanvas.width / 2, uprightCanvas.height / 2);
    uCtx.rotate((totalRotation * Math.PI) / 180);
    uCtx.drawImage(subCanvas, -subCanvas.width / 2, -subCanvas.height / 2);
    uCtx.restore();

    // 2. Measure fine skew angle & deskew
    const measuredSkew =
      config.deskewAngleDeg !== 0
        ? config.deskewAngleDeg
        : measureSkewAngleDeg(uprightCanvas);

    const targetW = 900;
    const targetH = 1273; // Exact A4 ratio (210:297)
    const deskewedCanvas = document.createElement('canvas');
    deskewedCanvas.width = targetW;
    deskewedCanvas.height = targetH;
    const dCtx = deskewedCanvas.getContext('2d')!;
    dCtx.fillStyle = '#FFFFFF';
    dCtx.fillRect(0, 0, targetW, targetH);

    // 3. Crop to page border + perspective corners
    const uImgData = uCtx.getImageData(0, 0, uprightCanvas.width, uprightCanvas.height);
    const borderCrop =
      config.cropToPageBorder !== false
        ? measurePaperBorderCrop(uImgData.data, uprightCanvas.width, uprightCanvas.height)
        : { sx: 0, sy: 0, sw: uprightCanvas.width, sh: uprightCanvas.height };

    const [tl, tr, br, bl] = config.perspectiveCorners;
    const minX = Math.max(0, Math.min(tl.x, bl.x));
    const maxX = Math.min(1, Math.max(tr.x, br.x));
    const minY = Math.max(0, Math.min(tl.y, tr.y));
    const maxY = Math.min(1, Math.max(bl.y, br.y));

    const sx = borderCrop.sx + minX * borderCrop.sw;
    const sy = borderCrop.sy + minY * borderCrop.sh;
    const sw = Math.max(50, (maxX - minX) * borderCrop.sw);
    const sh = Math.max(50, (maxY - minY) * borderCrop.sh);

    dCtx.save();
    dCtx.translate(targetW / 2, targetH / 2);
    dCtx.rotate((-measuredSkew * Math.PI) / 180);
    dCtx.translate(-targetW / 2, -targetH / 2);
    dCtx.drawImage(uprightCanvas, sx, sy, sw, sh, 0, 0, targetW, targetH);
    dCtx.restore();

    // 4. Remove shadows, scanner bands, bleed-through, and separate handwriting
    const cleaned = cleanAndSeparateHandwritingSinglePage(deskewedCanvas, config);

    results.push({
      pageIndex: i,
      widthPx: targetW,
      heightPx: targetH,
      detectedOrientationDeg: detectedOrientation,
      measuredSkewDeg: measuredSkew,
      wasSplitFromTwoPageScan: wasSplit,
      inpaintedCleanedDataUrl: cleaned.inpaintedCleanedDataUrl,
      cleanedWithHandwritingDataUrl: cleaned.cleanedWithHandwritingDataUrl,
      handwritingLayers: cleaned.handwritingLayers,
    });
  }

  return results;
}

/**
 * Single-page wrapper compatible with existing UI calls.
 */
export async function processDocumentImage(
  sourceDataUrl: string,
  config: PreprocessingConfig,
  forModeB = false
): Promise<string> {
  const pages = await runStep1PreprocessPipeline(sourceDataUrl, config);
  const first = pages[0];
  if (forModeB || config.keepHandwriting) {
    return first.cleanedWithHandwritingDataUrl;
  }
  return first.inpaintedCleanedDataUrl;
}
