package com.example.streamhub.ui

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.streamhub.data.SampleCatalog
import com.example.streamhub.model.NavigationDestination
import com.example.streamhub.theme.StreamHubAppTheme
import com.example.streamhub.theme.StreamTheme
import com.example.streamhub.ui.components.StreamHubBottomBar
import com.example.streamhub.ui.components.StreamHubDrawer
import com.example.streamhub.ui.components.StreamHubTopBar
import com.example.streamhub.ui.components.VideoPlayerSheet
import com.example.streamhub.ui.screens.AboutDialog
import com.example.streamhub.ui.screens.HelpDialog
import com.example.streamhub.ui.screens.HomeScreen
import com.example.streamhub.ui.screens.LibraryScreen
import com.example.streamhub.ui.screens.ProfileSettingsScreen
import com.example.streamhub.ui.screens.SearchScreen
import com.example.streamhub.viewmodel.StreamHubViewModel

@Composable
fun StreamHubApp(
    viewModel: StreamHubViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val activeDestination by viewModel.activeDestination.collectAsStateWithLifecycle()
    val isDrawerOpen by viewModel.isDrawerOpen.collectAsStateWithLifecycle()
    val selectedMedia by viewModel.selectedMedia.collectAsStateWithLifecycle()
    val isPlayerActive by viewModel.isPlayerActive.collectAsStateWithLifecycle()

    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val playbackProgress by viewModel.playbackProgress.collectAsStateWithLifecycle()
    val playbackSeconds by viewModel.playbackSeconds.collectAsStateWithLifecycle()
    val totalDurationSeconds by viewModel.totalDurationSeconds.collectAsStateWithLifecycle()
    val selectedQuality by viewModel.selectedQuality.collectAsStateWithLifecycle()
    val selectedAudio by viewModel.selectedAudio.collectAsStateWithLifecycle()
    val selectedSubtitle by viewModel.selectedSubtitle.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedGenre by viewModel.selectedGenre.collectAsStateWithLifecycle()
    val filter4KOnly by viewModel.filter4KOnly.collectAsStateWithLifecycle()
    val filteredMedia by viewModel.filteredMedia.collectAsStateWithLifecycle()

    val watchlist by viewModel.watchlist.collectAsStateWithLifecycle()
    val downloads by viewModel.downloads.collectAsStateWithLifecycle()

    var showHelpDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    // حل مشكلة زر الرجوع الفعلي للهاتف بشكل كامل (BackHandler):
    // عند الضغط على زر الرجوع في الهاتف:
    // 1. يغلق مشغل الفيديو أولاً إذا كان مفتوحاً.
    // 2. يغلق تفاصيل الفيلم إذا كانت معروضة.
    // 3. يغلق القائمة الجانبية (Drawer) إذا كانت مفتوحة.
    // 4. يعود إلى الصفحة الرئيسية (Home) إذا كان في البحث أو المكتبة أو الحساب.
    // 5. إذا كان في الرئيسية، يقوم بالخروج المنظم.
    BackHandler(enabled = true) {
        val handled = viewModel.handleSystemBackPress()
        if (!handled) {
            (context as? Activity)?.finish()
        }
    }

    StreamHubAppTheme(themeMode = themeMode) {
        val colors = StreamTheme.colors

        Box(
            modifier = modifier
                .fillMaxSize()
                .background(colors.background)
        ) {
            Scaffold(
                containerColor = colors.background,
                topBar = {
                    StreamHubTopBar(
                        themeMode = themeMode,
                        onToggleTheme = { viewModel.toggleThemeMode() },
                        onOpenDrawer = { viewModel.openDrawer() },
                        onOpenSearch = { viewModel.navigateTo(NavigationDestination.SEARCH) }
                    )
                },
                bottomBar = {
                    // شريط التنقل السفلي المطور والمزود بـ navigationBarsPadding
                    // بحيث يستحيل أن يتداخل مع أزرار الهاتف السفلية (Recents, Home, Back)!
                    StreamHubBottomBar(
                        currentDestination = activeDestination,
                        onSelectDestination = { destination ->
                            viewModel.navigateTo(destination)
                        }
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    AnimatedContent(
                        targetState = activeDestination,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "screenTransition"
                    ) { destination ->
                        when (destination) {
                            NavigationDestination.HOME -> {
                                HomeScreen(
                                    featuredMedia = SampleCatalog.allMedia.first { it.isFeatured },
                                    trendingMedia = viewModel.trendingMedia,
                                    continueWatching = viewModel.continueWatching,
                                    liveChannels = viewModel.liveChannels,
                                    allMedia = filteredMedia,
                                    selectedCategory = selectedCategory,
                                    watchlist = watchlist,
                                    onSelectCategory = { viewModel.setSelectedCategory(it) },
                                    onPlayMedia = { viewModel.playMedia(it) },
                                    onOpenMediaDetails = { viewModel.openMediaDetail(it) },
                                    onToggleWatchlist = { viewModel.toggleWatchlist(it) }
                                )
                            }
                            NavigationDestination.SEARCH -> {
                                SearchScreen(
                                    searchQuery = searchQuery,
                                    selectedGenre = selectedGenre,
                                    filter4KOnly = filter4KOnly,
                                    results = filteredMedia,
                                    onSearchQueryChange = { viewModel.setSearchQuery(it) },
                                    onSelectGenre = { viewModel.setSelectedGenre(it) },
                                    onToggle4K = { viewModel.toggleFilter4K() },
                                    onOpenMediaDetails = { viewModel.openMediaDetail(it) }
                                )
                            }
                            NavigationDestination.LIBRARY -> {
                                LibraryScreen(
                                    watchlistIds = watchlist,
                                    downloads = downloads,
                                    onPlayMedia = { viewModel.playMedia(it) },
                                    onOpenMediaDetails = { viewModel.openMediaDetail(it) },
                                    onRemoveFromWatchlist = { viewModel.toggleWatchlist(it) },
                                    onDeleteDownload = { viewModel.deleteDownload(it) }
                                )
                            }
                            NavigationDestination.PROFILE, NavigationDestination.SETTINGS -> {
                                ProfileSettingsScreen(
                                    themeMode = themeMode,
                                    onSetThemeMode = { viewModel.setThemeMode(it) },
                                    onLogout = {
                                        Toast.makeText(context, "تم تسجيل الخروج بنجاح من حساب StreamHub", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                            NavigationDestination.HELP -> {
                                showHelpDialog = true
                                // العودة تلقائياً للشاشة السابقة بعد فتح الحوار
                                viewModel.navigateTo(NavigationDestination.HOME)
                            }
                            NavigationDestination.ABOUT -> {
                                showAboutDialog = true
                                viewModel.navigateTo(NavigationDestination.HOME)
                            }
                        }
                    }
                }
            }

            // القائمة الجانبية المعتمة (Drawer Modal Overlay)
            AnimatedVisibility(
                visible = isDrawerOpen,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.65f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = { viewModel.closeDrawer() }
                        )
                )
            }

            AnimatedVisibility(
                visible = isDrawerOpen,
                enter = slideInHorizontally(initialOffsetX = { -it }),
                exit = slideOutHorizontally(targetOffsetX = { -it }),
                modifier = Modifier.align(Alignment.CenterStart)
            ) {
                StreamHubDrawer(
                    currentDestination = activeDestination,
                    themeMode = themeMode,
                    onSelectDestination = { dest ->
                        when (dest) {
                            NavigationDestination.HELP -> {
                                viewModel.closeDrawer()
                                showHelpDialog = true
                            }
                            NavigationDestination.ABOUT -> {
                                viewModel.closeDrawer()
                                showAboutDialog = true
                            }
                            else -> viewModel.navigateTo(dest)
                        }
                    },
                    onSetThemeMode = { viewModel.setThemeMode(it) },
                    onCloseDrawer = { viewModel.closeDrawer() },
                    onLogout = {
                        viewModel.closeDrawer()
                        Toast.makeText(context, "تم تسجيل الخروج", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // طبقة تفاصيل العمل السينمائي ومشغل الفيديو
            AnimatedVisibility(
                visible = (selectedMedia != null || isPlayerActive),
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val media = selectedMedia
                if (media != null) {
                    VideoPlayerSheet(
                        media = media,
                        isPlaying = isPlaying,
                        playbackProgress = playbackProgress,
                        playbackSeconds = playbackSeconds,
                        totalDurationSeconds = totalDurationSeconds,
                        selectedQuality = selectedQuality,
                        selectedAudio = selectedAudio,
                        selectedSubtitle = selectedSubtitle,
                        isInWatchlist = watchlist.contains(media.id),
                        downloadProgress = downloads[media.id],
                        onTogglePlay = { viewModel.togglePlayPause() },
                        onSeek = { viewModel.seekTo(it) },
                        onSkipForward = { viewModel.skipForward10() },
                        onSkipBackward = { viewModel.skipBackward10() },
                        onSelectQuality = { viewModel.setQuality(it) },
                        onSelectAudio = { viewModel.setAudio(it) },
                        onSelectSubtitle = { viewModel.setSubtitle(it) },
                        onToggleWatchlist = { viewModel.toggleWatchlist(media.id) },
                        onDownload = { viewModel.startOrToggleDownload(media.id) },
                        onClose = {
                            viewModel.closePlayer()
                            viewModel.closeMediaDetail()
                        }
                    )
                }
            }

            // حوارات المساعدة وحول التطبيق
            if (showHelpDialog) {
                HelpDialog(onDismiss = { showHelpDialog = false })
            }
            if (showAboutDialog) {
                AboutDialog(onDismiss = { showAboutDialog = false })
            }
        }
    }
}
