package com.example.core.termux

data class TermuxStatus(
    val isInstalled: Boolean = false,
    val hasRunCommandPermission: Boolean = false,
    val isJdkInstalled: Boolean = false,
    val javaVersionOutput: String = "",
    val lastCheckMessage: String = "",
    val isChecking: Boolean = false
) {
    val isReadyForJava: Boolean
        get() = isInstalled && hasRunCommandPermission && isJdkInstalled
}

data class TermuxExecutionResult(
    val executionId: String,
    val stdout: String,
    val stderr: String,
    val exitCode: Int,
    val errCode: Int,
    val errMsg: String?,
    val isSuccess: Boolean = (exitCode == 0 && errCode == 0)
)
