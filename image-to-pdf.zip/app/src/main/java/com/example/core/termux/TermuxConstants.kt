package com.example.core.termux

object TermuxConstants {
    const val TERMUX_PACKAGE_NAME = "com.termux"
    const val TERMUX_APP_NAME = "Termux"
    const val TERMUX_RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
    const val PERMISSION_RUN_COMMAND = "com.termux.permission.RUN_COMMAND"

    const val ACTION_RUN_COMMAND = "com.termux.RUN_COMMAND"
    const val EXTRA_COMMAND_PATH = "com.termux.RUN_COMMAND_PATH"
    const val EXTRA_ARGUMENTS = "com.termux.RUN_COMMAND_ARGUMENTS"
    const val EXTRA_WORKDIR = "com.termux.RUN_COMMAND_WORKDIR"
    const val EXTRA_BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND"
    const val EXTRA_SESSION_ACTION = "com.termux.RUN_COMMAND_SESSION_ACTION"
    const val EXTRA_PENDING_INTENT = "com.termux.RUN_COMMAND_PENDING_INTENT"

    // Result bundle keys returned by Termux
    const val EXTRA_PLUGIN_RESULT_BUNDLE = "resultBundle"
    const val EXTRA_PLUGIN_RESULT_BUNDLE_STDOUT = "stdout"
    const val EXTRA_PLUGIN_RESULT_BUNDLE_STDERR = "stderr"
    const val EXTRA_PLUGIN_RESULT_BUNDLE_EXIT_CODE = "exitCode"
    const val EXTRA_PLUGIN_RESULT_BUNDLE_ERR = "err"
    const val EXTRA_PLUGIN_RESULT_BUNDLE_ERRMSG = "errmsg"

    // Default executable paths inside Termux
    const val TERMUX_PREFIX = "/data/data/com.termux/files/usr"
    const val TERMUX_HOME = "/data/data/com.termux/files/home"
    const val TERMUX_BASH_BIN = "/data/data/com.termux/files/usr/bin/bash"
    const val TERMUX_SH_BIN = "/data/data/com.termux/files/usr/bin/sh"

    // Action used for our PendingIntent callback
    const val ACTION_RESULT_BROADCAST = "com.example.termux.RUN_COMMAND_RESULT"
    const val EXTRA_EXECUTION_ID = "execution_id"

    // F-Droid official download link
    const val FDROID_TERMUX_URL = "https://f-droid.org/packages/com.termux/"
}
