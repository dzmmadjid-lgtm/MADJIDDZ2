package com.example.data

import kotlinx.coroutines.flow.Flow

class SeparationRepository(private val dao: SeparationDao) {

    val allSeparations: Flow<List<SeparationEntity>> = dao.getAllSeparations()

    suspend fun saveSeparation(entity: SeparationEntity): Long {
        return dao.insertSeparation(entity)
    }

    suspend fun getById(id: Long): SeparationEntity? {
        return dao.getSeparationById(id)
    }

    suspend fun delete(entity: SeparationEntity) {
        dao.deleteSeparation(entity)
    }

    suspend fun clearAll() {
        dao.clearAll()
    }
}
