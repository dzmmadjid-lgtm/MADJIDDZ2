package com.medad.studio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.medad.studio.ui.components.FeatureTile
import com.medad.studio.ui.components.GoldChip
import com.medad.studio.ui.components.Hairline
import com.medad.studio.ui.components.MedadCard
import com.medad.studio.ui.components.StatCell
import com.medad.studio.ui.theme.LocalPalette

@Composable
fun HomeScreen(
    oledNight: Boolean,
    onToggleTheme: () -> Unit,
    onOpenReader: () -> Unit,
    onOpenImagesToPdf: () -> Unit,
    onOpenPdfToImages: () -> Unit,
    onOpenPrint: () -> Unit,
) {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxSize()
            .background(p.canvas)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 18.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GoldChip("مداد · STUDIO")
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .border(1.dp, p.line, CircleShape)
                    .clickable(onClick = onToggleTheme),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (oledNight) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                    contentDescription = "تبديل الوضع",
                    tint = p.gold,
                )
            }
        }

        Spacer(Modifier.height(28.dp))
        Text("ورقٌ رقمي", color = p.muted, fontSize = 13.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "اقرأ. حوّل.\nاطبع بلمسة.",
            color = p.ink,
            fontSize = 40.sp,
            fontWeight = FontWeight.Light,
            lineHeight = 46.sp,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "قارئ PDF فاخر، تحويل صور ↔ مستندات، وطباعة عادية أو مباشرة عبر الواي فاي.",
            color = p.muted,
            fontSize = 14.sp,
            lineHeight = 22.sp,
        )

        Spacer(Modifier.height(28.dp))
        MedadCard {
            Row(Modifier.fillMaxWidth()) {
                StatCell("الوضع", if (oledNight) "ليلي OLED" else "نهاري")
                StatCell("الطباعة", "نظام + IPP")
                StatCell("التحويل", "صور ↔ PDF")
            }
        }

        Spacer(Modifier.height(22.dp))
        Text("المراسم", color = p.muted, fontSize = 12.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(12.dp))

        FeatureTile(
            title = "قارئ المستندات",
            subtitle = "فتح PDF، تصفّح الصفحات، تكبير، ووضع قراءة ليلي مقلوب للشاشة.",
            icon = Icons.Outlined.MenuBook,
            modifier = Modifier.fillMaxWidth(),
            onClick = onOpenReader,
        )
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureTile(
                title = "صور إلى PDF",
                subtitle = "اجمع صوراً في مستند A4 أنيق.",
                icon = Icons.Outlined.PictureAsPdf,
                modifier = Modifier.weight(1f),
                onClick = onOpenImagesToPdf,
            )
            FeatureTile(
                title = "PDF إلى صور",
                subtitle = "استخرج كل صفحة كصورة JPEG.",
                icon = Icons.Outlined.Image,
                modifier = Modifier.weight(1f),
                onClick = onOpenPdfToImages,
            )
        }
        Spacer(Modifier.height(12.dp))
        FeatureTile(
            title = "الطباعة",
            subtitle = "طباعة عادية عبر نظام أندرويد، أو اكتشاف طابعات الواي فاي (IPP) للطباعة المباشرة.",
            icon = Icons.Outlined.Print,
            modifier = Modifier.fillMaxWidth(),
            onClick = onOpenPrint,
        )

        Spacer(Modifier.height(28.dp))
        Hairline()
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Wifi, null, tint = p.gold, modifier = Modifier.size(16.dp))
            Text(
                "  الطباعة المباشرة تتطلب طابعة على نفس الشبكة تدعم IPP / AirPrint.",
                color = p.muted,
                fontSize = 12.sp,
            )
        }
        Spacer(Modifier.height(32.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(p.panel)
                .border(1.dp, p.line, RoundedCornerShape(18.dp))
                .padding(18.dp),
        ) {
            Column {
                Text("مداد", color = p.gold, fontWeight = FontWeight.SemiBold, letterSpacing = 4.sp)
                Spacer(Modifier.height(6.dp))
                Text("صُمم للسكون البصري. أسود مطلق في الليل، ورق دافئ في النهار.", color = p.muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
