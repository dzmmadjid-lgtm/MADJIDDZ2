package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.neural.ModelDiagnosticInfo

@Composable
fun ModelStatusCard(
    modelInfo: ModelDiagnosticInfo,
    onReloadModel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showDetailsDialog by remember { mutableStateOf(false) }

    val isReady = modelInfo.isVocalsModelLoaded && modelInfo.isAccompanimentModelLoaded
    val statusColor = when {
        modelInfo.isLoading -> Color(0xFFF59E0B) // Amber
        isReady -> Color(0xFF10B981) // Emerald
        else -> Color(0xFFEF4444) // Red
    }
    val statusBg = when {
        modelInfo.isLoading -> Color(0xFF78350F)
        isReady -> Color(0xFF064E3B)
        else -> Color(0xFF450A0A)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("model_status_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (modelInfo.isLoading) {
                        androidx.compose.material3.CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            strokeWidth = 2.dp,
                            color = statusColor
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when {
                            modelInfo.isLoading -> "جاري تحميل النموذج العصبي..."
                            isReady -> "استدلال عصبي حقيقي (Neural AI Active)"
                            else -> "النموذج غير محمّل"
                        },
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onReloadModel,
                        enabled = !modelInfo.isLoading,
                        modifier = Modifier.size(32.dp).testTag("reload_model_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "إعادة تحميل النموذج",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = { showDetailsDialog = true },
                        modifier = Modifier.size(32.dp).testTag("model_info_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "تفاصيل النموذج",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = modelInfo.modelName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            if (modelInfo.isLoading && modelInfo.loadingProgressText.isNotEmpty()) {
                Text(
                    text = modelInfo.loadingProgressText,
                    style = MaterialTheme.typography.bodySmall,
                    color = statusColor
                )
            } else {
                Text(
                    text = "الإصدار: ${modelInfo.modelVersion} • المحرك: ONNX Runtime v1.20.0 • الحجم: ${(modelInfo.vocalsModelSizeMb + modelInfo.accompanimentModelSizeMb).toInt()} MB",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (!isReady && modelInfo.lastError != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(statusBg)
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "خطأ",
                            tint = statusColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = modelInfo.lastError,
                            style = MaterialTheme.typography.bodySmall,
                            color = statusColor
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    androidx.compose.material3.Button(
                        onClick = onReloadModel,
                        enabled = !modelInfo.isLoading,
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تحميل أوزان النموذج الآن (75 MB)")
                    }
                }
            }
        }
    }

    if (showDetailsDialog) {
        ModelDetailsDialog(
            modelInfo = modelInfo,
            onDismiss = { showDetailsDialog = false }
        )
    }
}

@Composable
fun ModelDetailsDialog(
    modelInfo: ModelDiagnosticInfo,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF10B981)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("تقرير التحقق من نموذج الذكاء الاصطناعي", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "معلومات النموذج العصبي المدرّب فعلياً داخل التطبيق:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                DetailItem(label = "اسم النموذج", value = modelInfo.modelName)
                DetailItem(label = "الإصدار والمصدر", value = "${modelInfo.modelVersion} (Deezer / Sherpa-ONNX)")
                DetailItem(label = "نوع الفصل", value = "Neural Source Separation (U-Net Deep Network)")
                DetailItem(label = "حجم نموذج الغناء (Vocals)", value = "${modelInfo.vocalsModelSizeMb} MB")
                DetailItem(label = "حجم نموذج الموسيقى (Accomp)", value = "${modelInfo.accompanimentModelSizeMb} MB")
                DetailItem(label = "مكان النموذج بالمشروع", value = "assets/models/vocals.onnx & accompaniment.onnx")
                DetailItem(label = "مكتبة التشغيل", value = modelInfo.executionEngine)
                DetailItem(label = "ملف كود الاستدلال", value = "com.example.neural.NeuralSourceSeparator.kt")
                DetailItem(label = "شكل موتر الإدخال (Input)", value = modelInfo.inputShape)
                DetailItem(label = "شكل موتر الإخراج (Output)", value = modelInfo.outputShape)
                DetailItem(label = "حالة التشغيل", value = if (modelInfo.isNeuralInferenceActive) "استدلال عصبي نشط ومؤكد 100%" else "غير نشط")
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("dismiss_dialog_button")
            ) {
                Text("إغلاق")
            }
        }
    )
}

@Composable
private fun DetailItem(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.onSurface
        )
        HorizontalDivider(modifier = Modifier.padding(top = 4.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    }
}
