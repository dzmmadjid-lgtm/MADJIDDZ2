package com.example.core.scanner

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

enum class TransportType {
    USB_BULK_SCANNER,
    USB_IPP_OVER_USB,
    WIFI_ESCL,
    WIFI_MFNP
}

data class UsbInterfaceDescriptorInfo(
    val id: Int,
    val interfaceClass: Int,
    val interfaceSubclass: Int,
    val interfaceProtocol: Int,
    val classDescription: String,
    val isScannerCandidate: Boolean,
    val isPrinterInterface: Boolean,
    val bulkInEndpointAddress: Int?,
    val bulkOutEndpointAddress: Int?,
    val maxPacketSizeIn: Int,
    val maxPacketSizeOut: Int
)

data class DiscoveredScannerDevice(
    val id: String,
    val name: String,
    val vendorId: Int,
    val productId: Int,
    val serialOrAddress: String,
    val transportType: TransportType,
    val hasUsbPermission: Boolean,
    val usbDevice: UsbDevice? = null,
    val interfaces: List<UsbInterfaceDescriptorInfo> = emptyList(),
    val scannerInterfaceIndex: Int? = null,
    val technicalStatusNote: String = ""
)

data class ScanJobOptions(
    val resolutionDpi: Int = 300,
    val colorMode: String = "RGB24", // "RGB24", "Grayscale8", "BlackAndWhite1"
    val source: String = "Platen",   // "Platen" (Flatbed) or "Feeder" (ADF)
    val pageSize: String = "A4"      // 210 x 297 mm
)

data class ScanAcquisitionResult(
    val success: Boolean,
    val bitmap: Bitmap? = null,
    val rawFile: File? = null,
    val protocolUsed: String = "",
    val diagnosticLog: List<String> = emptyList(),
    val errorReason: String? = null
)

class ScannerManager(private val context: Context) {

    companion object {
        const val ACTION_USB_SCANNER_PERMISSION = "com.canon.mf440.scanner.USB_SCANNER_PERMISSION"
        const val CANON_VENDOR_ID = 0x04A9 // 1193 decimal (Canon Inc.)

        // Known Canon MF440 Series & Laser MFPs Product IDs
        val KNOWN_CANON_MF_PIDS = setOf(
            0x27F4, // Canon MF440 Series
            0x27F5, // Canon MF440 / MF445dw
            0x27F6, // Canon MF443dw / MF441dw
            0x27D1, // Canon MF420 Series
            0x27E8, // Canon MF450 Series
            0x2802  // Canon i-SENSYS MF Series
        )
    }

    private val usbManager: UsbManager =
        context.getSystemService(Context.USB_SERVICE) as UsbManager

    /**
     * Inspects all connected USB devices and classifies their USB Interfaces.
     * Explicitly distinguishes between:
     * - USB Class 7 (0x07): Printer ("Canon Generic Plus UFR II V250" print interface - NOT used for scanning)
     * - USB Class 255 (0xFF): Vendor-Specific Canon ScanGear / MFNP Bulk Scanner Interface
     * - USB Class 6 (0x06): Still Image Capture (PTP/WIA Scanner Interface)
     * - USB Class 7 Subclass 1 Protocol 4: IPP-over-USB (7/1/4) carrying eSCL / Scan Service
     */
    fun discoverUsbScanners(): List<DiscoveredScannerDevice> {
        val result = mutableListOf<DiscoveredScannerDevice>()
        val deviceList = usbManager.deviceList ?: return emptyList()

        for ((_, device) in deviceList) {
            val interfacesInfo = mutableListOf<UsbInterfaceDescriptorInfo>()
            var bestScannerInterfaceIdx: Int? = null
            var detectedTransport = TransportType.USB_BULK_SCANNER

            for (i in 0 until device.interfaceCount) {
                val intf: UsbInterface = device.getInterface(i)
                val cls = intf.interfaceClass
                val sub = intf.interfaceSubclass
                val proto = intf.interfaceProtocol

                var bulkIn: UsbEndpoint? = null
                var bulkOut: UsbEndpoint? = null

                for (e in 0 until intf.endpointCount) {
                    val ep = intf.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) {
                            bulkIn = ep
                        } else if (ep.direction == UsbConstants.USB_DIR_OUT) {
                            bulkOut = ep
                        }
                    }
                }

                val isPrinter712 = (cls == UsbConstants.USB_CLASS_PRINTER && proto != 4)
                val isIppUsb714 = (cls == UsbConstants.USB_CLASS_PRINTER && sub == 1 && proto == 4)
                val isVendorScanner = (cls == UsbConstants.USB_CLASS_VENDOR_SPEC && bulkIn != null && bulkOut != null)
                val isStillImageScanner = (cls == UsbConstants.USB_CLASS_STILL_IMAGE && bulkIn != null && bulkOut != null)

                val isScannerCandidate = isVendorScanner || isStillImageScanner || isIppUsb714

                val classDesc = when {
                    isIppUsb714 -> "IPP-over-USB (Class 7/1/4 - eSCL/HTTP Tunnel)"
                    isPrinter712 -> "USB Printer Interface (Class 7 - UFR II Print Only - Ignored)"
                    isVendorScanner -> "Canon Vendor-Specific Scanner Interface (Class 0xFF ScanGear/MFNP)"
                    isStillImageScanner -> "USB Still Image Scanner Interface (Class 0x06 WIA/PTP)"
                    else -> "USB Interface (Class 0x${cls.toString(16)}, Sub 0x${sub.toString(16)}, Proto 0x${proto.toString(16)})"
                }

                if (isScannerCandidate && bestScannerInterfaceIdx == null) {
                    bestScannerInterfaceIdx = i
                    detectedTransport = if (isIppUsb714) {
                        TransportType.USB_IPP_OVER_USB
                    } else {
                        TransportType.USB_BULK_SCANNER
                    }
                }

                interfacesInfo.add(
                    UsbInterfaceDescriptorInfo(
                        id = intf.id,
                        interfaceClass = cls,
                        interfaceSubclass = sub,
                        interfaceProtocol = proto,
                        classDescription = classDesc,
                        isScannerCandidate = isScannerCandidate,
                        isPrinterInterface = isPrinter712,
                        bulkInEndpointAddress = bulkIn?.address,
                        bulkOutEndpointAddress = bulkOut?.address,
                        maxPacketSizeIn = bulkIn?.maxPacketSize ?: 0,
                        maxPacketSizeOut = bulkOut?.maxPacketSize ?: 0
                    )
                )
            }

            val isCanon = device.vendorId == CANON_VENDOR_ID
            val hasScannerIntf = bestScannerInterfaceIdx != null

            if (isCanon || hasScannerIntf || interfacesInfo.isNotEmpty()) {
                val hasPerm = usbManager.hasPermission(device)
                val prodName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    device.productName ?: "Canon MF440 Series USB Device"
                } else {
                    "Canon MF440 Series USB Device"
                }

                val note = buildString {
                    if (isCanon) {
                        append("Canon USB Device (VID: 0x04A9, PID: 0x${device.productId.toString(16).uppercase()}). ")
                    }
                    if (bestScannerInterfaceIdx != null) {
                        append("Scanner Interface #$bestScannerInterfaceIdx ready (${detectedTransport.name}). ")
                        append("Print-only UFR II interface bypassed.")
                    } else {
                        append("No dedicated scanner bulk interface exposed; inspect descriptors.")
                    }
                }

                result.add(
                    DiscoveredScannerDevice(
                        id = "USB_${device.deviceId}",
                        name = if (isCanon && !prodName.contains("Canon", ignoreCase = true)) "Canon $prodName" else prodName,
                        vendorId = device.vendorId,
                        productId = device.productId,
                        serialOrAddress = device.deviceName,
                        transportType = detectedTransport,
                        hasUsbPermission = hasPerm,
                        usbDevice = device,
                        interfaces = interfacesInfo,
                        scannerInterfaceIndex = bestScannerInterfaceIdx,
                        technicalStatusNote = note
                    )
                )
            }
        }

        return result
    }

    /**
     * Requests Android USB Host permission for the target UsbDevice.
     */
    fun requestUsbPermission(device: UsbDevice, onResult: (Boolean) -> Unit) {
        if (usbManager.hasPermission(device)) {
            onResult(true)
            return
        }

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (ACTION_USB_SCANNER_PERMISSION == intent.action) {
                    try {
                        context.unregisterReceiver(this)
                    } catch (_: Exception) {}
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    onResult(granted || usbManager.hasPermission(device))
                }
            }
        }

        val filter = IntentFilter(ACTION_USB_SCANNER_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val permissionIntent = PendingIntent.getBroadcast(
            context,
            device.deviceId,
            Intent(ACTION_USB_SCANNER_PERMISSION),
            flags
        )
        usbManager.requestPermission(device, permissionIntent)
    }

    /**
     * Probes a network IP address for Canon MF440 Series eSCL (AirScan / HTTP XML) or Canon MFNP port 8610.
     */
    suspend fun probeNetworkScanner(ipAddress: String): DiscoveredScannerDevice? = withContext(Dispatchers.IO) {
        val cleanIp = ipAddress.trim()
        if (cleanIp.isEmpty()) return@withContext null

        // 1. Check eSCL / AirScan Capabilities endpoint: http://<ip>:80/eSCL/ScannerCapabilities
        val esclUrls = listOf(
            "http://$cleanIp/eSCL/ScannerCapabilities",
            "http://$cleanIp:80/eSCL/ScannerCapabilities",
            "http://$cleanIp:8080/eSCL/ScannerCapabilities"
        )
        for (urlStr in esclUrls) {
            try {
                val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 2500
                    readTimeout = 2500
                }
                val code = conn.responseCode
                if (code in 200..299) {
                    val xml = conn.inputStream.bufferedReader().use { it.readText() }
                    val modelMatch = Regex("<(?:pwg:|scan:)?MakeAndModel>(.*?)</(?:pwg:|scan:)?MakeAndModel>")
                        .find(xml)?.groupValues?.get(1) ?: "Canon MF440 Series (eSCL)"
                    return@withContext DiscoveredScannerDevice(
                        id = "WIFI_ESCL_$cleanIp",
                        name = modelMatch,
                        vendorId = CANON_VENDOR_ID,
                        productId = 0x27F4,
                        serialOrAddress = cleanIp,
                        transportType = TransportType.WIFI_ESCL,
                        hasUsbPermission = true,
                        technicalStatusNote = "Verified eSCL / Mopria XML Scanner service at $urlStr"
                    )
                }
            } catch (_: Exception) {}
        }

        // 2. Check Canon MFNP UDP/TCP Port 8610 (Canon Multi-Function Network Protocol)
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(cleanIp, 8610), 2000)
                return@withContext DiscoveredScannerDevice(
                    id = "WIFI_MFNP_$cleanIp",
                    name = "Canon MF440 Series (MFNP :8610)",
                    vendorId = CANON_VENDOR_ID,
                    productId = 0x27F4,
                    serialOrAddress = cleanIp,
                    transportType = TransportType.WIFI_MFNP,
                    hasUsbPermission = true,
                    technicalStatusNote = "Connected to Canon MFNP Scanner Port TCP 8610 at $cleanIp"
                )
            }
        } catch (_: Exception) {}

        null
    }

    /**
     * Executes a real scan job against the selected Canon scanner device.
     * Supports:
     * 1. USB IPP-over-USB (Class 7/1/4 eSCL HTTP tunnel over USB bulk endpoints)
     * 2. USB Canon Vendor-Specific Class 0xFF (MFNP-over-USB / Canon ScanGear Bulk Command Packet)
     * 3. Wi-Fi eSCL (`POST /eSCL/ScanJobs` -> `GET /NextDocument`)
     * 4. Wi-Fi Canon MFNP TCP 8610
     */
    suspend fun executeScan(
        scanner: DiscoveredScannerDevice,
        options: ScanJobOptions,
        onProgress: (String) -> Unit
    ): ScanAcquisitionResult = withContext(Dispatchers.IO) {
        val logs = mutableListOf<String>()
        fun log(msg: String) {
            logs.add(msg)
            onProgress(msg)
        }

        log("Initializing scan session for ${scanner.name} (${scanner.transportType})...")
        log("Note: Windows 'Canon Generic Plus UFR II V250' is the print driver; selecting real scanner interface...")

        when (scanner.transportType) {
            TransportType.WIFI_ESCL -> {
                return@withContext executeWifiEsclScan(scanner.serialOrAddress, options, ::log, logs)
            }
            TransportType.WIFI_MFNP -> {
                return@withContext executeWifiMfnpScan(scanner.serialOrAddress, options, ::log, logs)
            }
            TransportType.USB_IPP_OVER_USB, TransportType.USB_BULK_SCANNER -> {
                val usbDev = scanner.usbDevice
                    ?: return@withContext ScanAcquisitionResult(
                        success = false,
                        diagnosticLog = logs,
                        errorReason = "USB Device handle is null. Reconnect USB OTG cable."
                    )
                if (!usbManager.hasPermission(usbDev)) {
                    return@withContext ScanAcquisitionResult(
                        success = false,
                        diagnosticLog = logs,
                        errorReason = "USB Permission not granted by Android OS. Tap 'Grant USB Permission' first."
                    )
                }
                return@withContext executeDirectUsbScan(usbDev, scanner, options, ::log, logs)
            }
        }
    }

    /**
     * Direct USB Host execution on Canon MF440 Series:
     * Claims the non-printer scanner interface (Class 0xFF Vendor-Specific or Class 7/1/4 IPP-USB)
     * and attempts:
     *  Step A: eSCL HTTP over USB Bulk Tunnel (supported by modern Canon MF440 firmware via IPP-USB)
     *  Step B: Canon MFNP / ScanGear binary framing over USB Bulk-OUT / Bulk-IN
     */
    private suspend fun executeDirectUsbScan(
        usbDevice: UsbDevice,
        scanner: DiscoveredScannerDevice,
        options: ScanJobOptions,
        log: (String) -> Unit,
        logs: MutableList<String>
    ): ScanAcquisitionResult {
        val intfIdx = scanner.scannerInterfaceIndex
        if (intfIdx == null || intfIdx !in 0 until usbDevice.interfaceCount) {
            val err = "No valid Scanner USB Interface found on device. " +
                "Interfaces found: ${scanner.interfaces.joinToString { "Intf #${it.id}: ${it.classDescription}" }}. " +
                "Verify Canon MF440 is not in print-only mode."
            log(err)
            return ScanAcquisitionResult(false, diagnosticLog = logs, errorReason = err)
        }

        val usbInterface = usbDevice.getInterface(intfIdx)
        log("Opening UsbDeviceConnection and claiming Interface #${usbInterface.id} (Class 0x${usbInterface.interfaceClass.toString(16)})...")

        val connection = usbManager.openDevice(usbDevice)
            ?: return ScanAcquisitionResult(
                false,
                diagnosticLog = logs,
                errorReason = "usbManager.openDevice() returned null. Check USB OTG connection."
            )

        try {
            if (!connection.claimInterface(usbInterface, true)) {
                return ScanAcquisitionResult(
                    false,
                    diagnosticLog = logs,
                    errorReason = "Failed to claim USB Scanner Interface #${usbInterface.id}. Another process may hold the lock."
                )
            }

            var epOut: UsbEndpoint? = null
            var epIn: UsbEndpoint? = null
            for (i in 0 until usbInterface.endpointCount) {
                val ep = usbInterface.getEndpoint(i)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_OUT) epOut = ep
                    if (ep.direction == UsbConstants.USB_DIR_IN) epIn = ep
                }
            }

            if (epOut == null || epIn == null) {
                return ScanAcquisitionResult(
                    false,
                    diagnosticLog = logs,
                    errorReason = "Scanner Interface #${usbInterface.id} is missing Bulk IN/OUT endpoints."
                )
            }

            log("Claimed Bulk OUT (0x${epOut.address.toString(16)}) & Bulk IN (0x${epIn.address.toString(16)}).")

            // Strategy 1: If IPP-over-USB (7/1/4) or eSCL-capable USB interface, send eSCL ScanJobs HTTP request over USB Bulk
            if (usbInterface.interfaceClass == UsbConstants.USB_CLASS_PRINTER &&
                usbInterface.interfaceSubclass == 1 &&
                usbInterface.interfaceProtocol == 4
            ) {
                log("Detected IPP-over-USB (7/1/4). Sending eSCL /eSCL/ScanJobs XML request over USB Bulk tunnel...")
                val esclResult = performEsclOverUsbBulk(connection, epOut, epIn, options, log, logs)
                if (esclResult.success) return esclResult
            }

            // Strategy 2: Canon MFNP / ScanGear Vendor-Specific USB Bulk Protocol (Class 0xFF)
            log("Sending Canon MFNP/ScanGear session initialization packet (32-byte header + Job Parameters)...")
            val mfnpInitPacket = buildCanonUsbScanInitPacket(options)
            val sent = connection.bulkTransfer(epOut, mfnpInitPacket, mfnpInitPacket.size, 4000)
            if (sent < 0) {
                // Also try eSCL over USB as fallback in case the vendor interface tunnels HTTP
                log("Vendor Bulk INIT returned $sent; attempting eSCL-over-USB fallback...")
                val fallback = performEsclOverUsbBulk(connection, epOut, epIn, options, log, logs)
                if (fallback.success) return fallback

                return ScanAcquisitionResult(
                    false,
                    diagnosticLog = logs,
                    errorReason = "USB Bulk OUT transfer failed (code $sent). Canon MF440 may require waking from sleep mode or Wi-Fi eSCL."
                )
            }

            log("Sent $sent bytes to Canon USB Scanner. Reading response blocks from Bulk IN...")
            val rawStream = ByteArrayOutputStream()
            val buffer = ByteArray(16384)
            var totalRead = 0
            var emptyReads = 0

            // Start scan acquisition command after handshake ACK
            val ackLen = connection.bulkTransfer(epIn, buffer, buffer.size, 5000)
            if (ackLen > 0) {
                log("Received $ackLen-byte handshake response from Canon scanner.")
                val startScanPacket = buildCanonUsbStartDataPacket(options)
                connection.bulkTransfer(epOut, startScanPacket, startScanPacket.size, 4000)
            }

            while (emptyReads < 5) {
                val read = connection.bulkTransfer(epIn, buffer, buffer.size, 6000)
                if (read > 0) {
                    emptyReads = 0
                    // Check if payload contains JPEG SOI (FF D8) or raw raster header
                    rawStream.write(buffer, 0, read)
                    totalRead += read
                    if (totalRead % (64 * 1024) < 16384) {
                        log("Receiving scan stream... ${totalRead / 1024} KB transferred")
                    }
                    // Check for JPEG EOI (FF D9) at end of transfer
                    if (read >= 2 && buffer[read - 2] == 0xFF.toByte() && buffer[read - 1] == 0xD9.toByte()) {
                        log("Detected JPEG EOI marker (0xFFD9). Scan page complete.")
                        break
                    }
                } else {
                    emptyReads++
                    if (totalRead > 0 && emptyReads >= 2) break
                }
            }

            val payload = rawStream.toByteArray()
            if (payload.isNotEmpty()) {
                val bitmap = decodeScannerPayloadToBitmap(payload, options, log)
                if (bitmap != null) {
                    val savedFile = saveRawScanToDisk(bitmap)
                    log("Successfully decoded scanned page (${bitmap.width}x${bitmap.height} px).")
                    return ScanAcquisitionResult(
                        success = true,
                        bitmap = bitmap,
                        rawFile = savedFile,
                        protocolUsed = "USB Direct (${scanner.transportType})",
                        diagnosticLog = logs
                    )
                }
            }

            val techMessage = "Canon MF440 responded on USB ($totalRead bytes), but did not return a standard raster/JPEG frame. " +
                "Technical Note: Some Canon MF440 firmware revisions require proprietary encrypted ScanGear II host drivers on USB Class 0xFF, " +
                "while exposing standard driverless eSCL (AirScan) over Wi-Fi/LAN or IPP-over-USB."
            log(techMessage)
            return ScanAcquisitionResult(
                success = false,
                diagnosticLog = logs,
                errorReason = techMessage
            )
        } finally {
            try {
                connection.releaseInterface(usbInterface)
                connection.close()
            } catch (_: Exception) {}
        }
    }

    /**
     * Performs an eSCL (AirScan) HTTP transaction directly over a USB 7/1/4 Bulk endpoint pair.
     */
    private fun performEsclOverUsbBulk(
        connection: android.hardware.usb.UsbDeviceConnection,
        epOut: UsbEndpoint,
        epIn: UsbEndpoint,
        options: ScanJobOptions,
        log: (String) -> Unit,
        logs: MutableList<String>
    ): ScanAcquisitionResult {
        val xmlBody = buildEsclScanJobXml(options)
        val httpPost = buildString {
            append("POST /eSCL/ScanJobs HTTP/1.1\r\n")
            append("Host: localhost\r\n")
            append("Content-Type: text/xml\r\n")
            append("Content-Length: ${xmlBody.toByteArray(Charsets.UTF_8).size}\r\n")
            append("Connection: keep-alive\r\n\r\n")
            append(xmlBody)
        }.toByteArray(Charsets.UTF_8)

        val sent = connection.bulkTransfer(epOut, httpPost, httpPost.size, 4000)
        if (sent <= 0) {
            return ScanAcquisitionResult(false, diagnosticLog = logs, errorReason = "IPP-USB eSCL POST failed ($sent)")
        }

        val respBuf = ByteArray(8192)
        val read = connection.bulkTransfer(epIn, respBuf, respBuf.size, 5000)
        if (read <= 0) {
            return ScanAcquisitionResult(false, diagnosticLog = logs, errorReason = "No HTTP response on IPP-USB")
        }

        val headerText = String(respBuf, 0, read, Charsets.UTF_8)
        val locationPath = Regex("Location:\\s*(?:https?://[^/]+)?(/eSCL/ScanJobs/[^\\r\\n]+)", RegexOption.IGNORE_CASE)
            .find(headerText)?.groupValues?.get(1)?.trim() ?: "/eSCL/ScanJobs/1"

        val nextDocPath = "${locationPath.trimEnd('/')}/NextDocument"
        log("eSCL USB Job created at $locationPath. Requesting $nextDocPath ...")

        val httpGet = "GET $nextDocPath HTTP/1.1\r\nHost: localhost\r\nAccept: image/jpeg\r\n\r\n"
            .toByteArray(Charsets.UTF_8)
        connection.bulkTransfer(epOut, httpGet, httpGet.size, 4000)

        val imageStream = ByteArrayOutputStream()
        val chunk = ByteArray(16384)
        var emptyCount = 0
        while (emptyCount < 4) {
            val r = connection.bulkTransfer(epIn, chunk, chunk.size, 6000)
            if (r > 0) {
                emptyCount = 0
                imageStream.write(chunk, 0, r)
            } else {
                emptyCount++
                if (imageStream.size() > 1024) break
            }
        }

        val fullBytes = imageStream.toByteArray()
        val bitmap = decodeScannerPayloadToBitmap(fullBytes, options, log)
        return if (bitmap != null) {
            val saved = saveRawScanToDisk(bitmap)
            ScanAcquisitionResult(
                success = true,
                bitmap = bitmap,
                rawFile = saved,
                protocolUsed = "IPP-over-USB (eSCL)",
                diagnosticLog = logs
            )
        } else {
            ScanAcquisitionResult(false, diagnosticLog = logs, errorReason = "Could not decode eSCL USB image stream")
        }
    }

    /**
     * Executes a standard eSCL / AirScan scan job over Wi-Fi / LAN against Canon MF440 Series.
     * Canon MF440 natively supports Mopria / AirScan eSCL over HTTP.
     */
    private suspend fun executeWifiEsclScan(
        ipAddress: String,
        options: ScanJobOptions,
        log: (String) -> Unit,
        logs: MutableList<String>
    ): ScanAcquisitionResult {
        try {
            val cleanIp = ipAddress.trim()
            val jobUrl = URL("http://$cleanIp/eSCL/ScanJobs")
            val xmlPayload = buildEsclScanJobXml(options)

            log("POST $jobUrl (${options.resolutionDpi} DPI, ${options.colorMode}, ${options.source})...")
            val postConn = (jobUrl.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 8000
                readTimeout = 15000
                setRequestProperty("Content-Type", "text/xml; charset=utf-8")
            }

            postConn.outputStream.use { it.write(xmlPayload.toByteArray(Charsets.UTF_8)) }
            val code = postConn.responseCode
            val locationHeader = postConn.getHeaderField("Location")

            if (code !in 200..299 && locationHeader == null) {
                return ScanAcquisitionResult(
                    false,
                    diagnosticLog = logs,
                    errorReason = "Canon eSCL server returned HTTP $code. Make sure Remote UI / AirScan is enabled on Canon MF440."
                )
            }

            val nextDocUrl = when {
                locationHeader != null && locationHeader.startsWith("http") -> "${locationHeader.trimEnd('/')}/NextDocument"
                locationHeader != null -> "http://$cleanIp/${locationHeader.trimStart('/').trimEnd('/')}/NextDocument"
                else -> "http://$cleanIp/eSCL/ScanJobs/1/NextDocument"
            }

            log("Scan job accepted by Canon MF440. Optical lamp warming up & scanning...")
            delay(1200)

            log("Downloading scanned image from $nextDocUrl ...")
            val getConn = (URL(nextDocUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 30000
            }

            if (getConn.responseCode in 200..299) {
                val bytes = getConn.inputStream.use { it.readBytes() }
                log("Received ${bytes.size / 1024} KB from Canon MF440 eSCL endpoint.")
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: decodeScannerPayloadToBitmap(bytes, options, log)

                if (bmp != null) {
                    val savedFile = saveRawScanToDisk(bmp)
                    log("Scan completed! Image dimensions: ${bmp.width}x${bmp.height} px.")
                    return ScanAcquisitionResult(
                        success = true,
                        bitmap = bmp,
                        rawFile = savedFile,
                        protocolUsed = "Wi-Fi eSCL (Canon AirScan)",
                        diagnosticLog = logs
                    )
                }
            }

            return ScanAcquisitionResult(
                false,
                diagnosticLog = logs,
                errorReason = "Failed to retrieve NextDocument (HTTP ${getConn.responseCode})."
            )
        } catch (e: Exception) {
            return ScanAcquisitionResult(
                false,
                diagnosticLog = logs,
                errorReason = "Wi-Fi eSCL Scan error: ${e.message}"
            )
        }
    }

    /**
     * Executes Canon MFNP (TCP Port 8610) scan session over LAN/Wi-Fi.
     */
    private fun executeWifiMfnpScan(
        ipAddress: String,
        options: ScanJobOptions,
        log: (String) -> Unit,
        logs: MutableList<String>
    ): ScanAcquisitionResult {
        try {
            log("Connecting to Canon MF440 MFNP TCP Port 8610 at $ipAddress...")
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ipAddress.trim(), 8610), 5000)
                socket.soTimeout = 15000
                val out = socket.getOutputStream()
                val inp = socket.getInputStream()

                val initPkt = buildCanonUsbScanInitPacket(options)
                out.write(initPkt)
                out.flush()

                val ack = ByteArray(1024)
                val ackRead = inp.read(ack)
                if (ackRead > 0) {
                    log("Received MFNP session ACK ($ackRead bytes). Triggering optical scan...")
                    val startPkt = buildCanonUsbStartDataPacket(options)
                    out.write(startPkt)
                    out.flush()
                }

                val baos = ByteArrayOutputStream()
                val buf = ByteArray(16384)
                while (true) {
                    val r = inp.read(buf)
                    if (r <= 0) break
                    baos.write(buf, 0, r)
                    if (r >= 2 && buf[r - 2] == 0xFF.toByte() && buf[r - 1] == 0xD9.toByte()) break
                }

                val data = baos.toByteArray()
                val bmp = decodeScannerPayloadToBitmap(data, options, log)
                if (bmp != null) {
                    val savedFile = saveRawScanToDisk(bmp)
                    return ScanAcquisitionResult(
                        success = true,
                        bitmap = bmp,
                        rawFile = savedFile,
                        protocolUsed = "Canon MFNP (TCP 8610)",
                        diagnosticLog = logs
                    )
                }
            }
        } catch (e: Exception) {
            log("MFNP TCP 8610 error: ${e.message}")
        }
        return ScanAcquisitionResult(
            false,
            diagnosticLog = logs,
            errorReason = "Canon MFNP Port 8610 did not return an image frame. Try Wi-Fi eSCL mode (Port 80)."
        )
    }

    /**
     * Builds the standard Mopria / AirScan eSCL XML payload supported by Canon MF440 Series.
     */
    private fun buildEsclScanJobXml(options: ScanJobOptions): String {
        // 300 DPI units in eSCL are expressed in 1/300th of an inch:
        // A4 width = 8.27 in * 300 = 2480, height = 11.69 in * 300 = 3508
        val widthUnits = 2480
        val heightUnits = 3508
        return """
            <?xml version="1.0" encoding="UTF-8"?>
            <scan:ScanSettings xmlns:pwg="http://www.pwg.org/schemas/2010/12/sm" xmlns:scan="http://schemas.hp.com/imaging/escl/2011/05/03">
                <pwg:Version>2.6</pwg:Version>
                <pwg:ScanRegions>
                    <pwg:ScanRegion>
                        <pwg:ContentRegionUnits>escl:ThreeHundredthsOfInches</pwg:ContentRegionUnits>
                        <pwg:XOffset>0</pwg:XOffset>
                        <pwg:YOffset>0</pwg:YOffset>
                        <pwg:Width>$widthUnits</pwg:Width>
                        <pwg:Height>$heightUnits</pwg:Height>
                    </pwg:ScanRegion>
                </pwg:ScanRegions>
                <pwg:InputSource>${options.source}</pwg:InputSource>
                <scan:ColorMode>${options.colorMode}</scan:ColorMode>
                <scan:XResolution>${options.resolutionDpi}</scan:XResolution>
                <scan:YResolution>${options.resolutionDpi}</scan:YResolution>
                <pwg:DocumentFormat>image/jpeg</pwg:DocumentFormat>
            </scan:ScanSettings>
        """.trimIndent()
    }

    /**
     * Builds a Canon MFNP / ScanGear binary initialization packet for USB Class 0xFF / TCP 8610.
     * Magic: 'M','F','N','P' (0x4D, 0x46, 0x4E, 0x50)
     */
    private fun buildCanonUsbScanInitPacket(options: ScanJobOptions): ByteArray {
        val buf = ByteBuffer.allocate(32).order(ByteOrder.BIG_ENDIAN)
        // MFNP Magic Header
        buf.put(0x4D.toByte()) // 'M'
        buf.put(0x46.toByte()) // 'F'
        buf.put(0x4E.toByte()) // 'N'
        buf.put(0x50.toByte()) // 'P'
        buf.putShort(0x0201)   // Command class: Scanner Session Open
        buf.putShort(0x0001)   // Sequence 1
        buf.putInt(0)          // Reserved
        buf.putInt(16)         // Payload length (16 bytes)
        // Payload: DPI X, DPI Y, ColorMode, Source
        buf.putShort(options.resolutionDpi.toShort())
        buf.putShort(options.resolutionDpi.toShort())
        val colorCode: Short = when (options.colorMode) {
            "Grayscale8" -> 2
            "BlackAndWhite1" -> 1
            else -> 3 // RGB24
        }
        buf.putShort(colorCode)
        val sourceCode: Short = if (options.source.equals("Feeder", ignoreCase = true)) 2 else 1
        buf.putShort(sourceCode)
        buf.putInt(2480) // A4 width @ 300dpi
        buf.putInt(3508) // A4 height @ 300dpi
        return buf.array()
    }

    private fun buildCanonUsbStartDataPacket(options: ScanJobOptions): ByteArray {
        val buf = ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN)
        buf.put(0x4D.toByte())
        buf.put(0x46.toByte())
        buf.put(0x4E.toByte())
        buf.put(0x50.toByte())
        buf.putShort(0x0204) // Command: Start Optical Scan & Stream Image Blocks
        buf.putShort(0x0002) // Sequence 2
        buf.putInt(options.resolutionDpi)
        buf.putInt(0)
        return buf.array()
    }

    /**
     * Extracts JPEG stream (from 0xFFD8 SOI marker) or raw RGB/Grayscale raster from scanner response bytes.
     */
    private fun decodeScannerPayloadToBitmap(
        payload: ByteArray,
        options: ScanJobOptions,
        log: (String) -> Unit
    ): Bitmap? {
        if (payload.size < 64) return null

        // 1. Search for embedded JPEG SOI marker (0xFF 0xD8 0xFF)
        for (i in 0 until payload.size - 3) {
            if (payload[i] == 0xFF.toByte() &&
                payload[i + 1] == 0xD8.toByte() &&
                payload[i + 2] == 0xFF.toByte()
            ) {
                log("Found JPEG SOI marker at byte offset $i. Decoding JPEG stream...")
                val jpegLen = payload.size - i
                val bmp = BitmapFactory.decodeByteArray(payload, i, jpegLen)
                if (bmp != null) return bmp
            }
        }

        // 2. Try direct BitmapFactory decode
        BitmapFactory.decodeByteArray(payload, 0, payload.size)?.let { return it }

        return null
    }

    /**
     * Saves the raw scanned Bitmap to internal app storage under /files/scans/
     */
    fun saveRawScanToDisk(bitmap: Bitmap, prefix: String = "canon_scan"): File {
        val scansDir = File(context.filesDir, "scans")
        if (!scansDir.exists()) scansDir.mkdirs()
        val file = File(scansDir, "${prefix}_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
        }
        return file
    }

    /**
     * Image processing helper: Rotate, Flip Horizontal/Vertical, Crop Normalized Rect, and Perspective/Border Trim.
     */
    fun transformScannedBitmap(
        source: Bitmap,
        rotationDegrees: Float,
        flipHorizontal: Boolean,
        flipVertical: Boolean,
        cropLeftRatio: Float,
        cropTopRatio: Float,
        cropRightRatio: Float,
        cropBottomRatio: Float,
        contrastBoost: Float = 1.0f
    ): Bitmap {
        // 1. Apply Crop first in normalized coordinates [0f..1f]
        val safeL = cropLeftRatio.coerceIn(0f, 0.9f)
        val safeT = cropTopRatio.coerceIn(0f, 0.9f)
        val safeR = cropRightRatio.coerceIn(safeL + 0.1f, 1f)
        val safeB = cropBottomRatio.coerceIn(safeT + 0.1f, 1f)

        val cropX = (safeL * source.width).toInt().coerceIn(0, source.width - 1)
        val cropY = (safeT * source.height).toInt().coerceIn(0, source.height - 1)
        val cropW = ((safeR - safeL) * source.width).toInt().coerceIn(1, source.width - cropX)
        val cropH = ((safeB - safeT) * source.height).toInt().coerceIn(1, source.height - cropY)

        val cropped = Bitmap.createBitmap(source, cropX, cropY, cropW, cropH)

        // 2. Apply Rotation and Flip Matrix
        val matrix = Matrix()
        val sx = if (flipHorizontal) -1f else 1f
        val sy = if (flipVertical) -1f else 1f
        if (flipHorizontal || flipVertical) {
            matrix.postScale(sx, sy, cropped.width / 2f, cropped.height / 2f)
        }
        if (rotationDegrees != 0f) {
            matrix.postRotate(rotationDegrees)
        }

        val transformed = Bitmap.createBitmap(
            cropped,
            0,
            0,
            cropped.width,
            cropped.height,
            matrix,
            true
        )

        if (contrastBoost == 1.0f) return transformed

        // 3. Optional Document Contrast Enhancement for crisp text/border reconstruction
        val output = Bitmap.createBitmap(transformed.width, transformed.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val scale = contrastBoost
        val translate = (-0.5f * scale + 0.5f) * 255f
        val cm = android.graphics.ColorMatrix(
            floatArrayOf(
                scale, 0f, 0f, 0f, translate,
                0f, scale, 0f, 0f, translate,
                0f, 0f, scale, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        paint.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
        canvas.drawBitmap(transformed, 0f, 0f, paint)
        return output
    }

    /**
     * Rebuilds a multi-page or single-page high-resolution PDF document from the edited scanned Bitmap(s)
     * using Android's native PdfDocument engine, and writes it to both app storage and project workspace.
     */
    fun generatePdfFromScannedBitmaps(
        pages: List<Bitmap>,
        outputPdfName: String,
        targetDirectory: File? = null
    ): File {
        val pdfDocument = PdfDocument()

        // Standard A4 @ 150 DPI PDF page points (or match bitmap aspect ratio at high resolution)
        pages.forEachIndexed { index, bmp ->
            val pageInfo = PdfDocument.PageInfo.Builder(bmp.width, bmp.height, index + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawColor(Color.WHITE)
            canvas.drawBitmap(bmp, 0f, 0f, null)
            pdfDocument.finishPage(page)
        }

        val outDir = targetDirectory ?: File(context.filesDir, "scans").apply { mkdirs() }
        if (!outDir.exists()) outDir.mkdirs()

        val cleanName = if (outputPdfName.endsWith(".pdf", ignoreCase = true)) {
            outputPdfName
        } else {
            "$outputPdfName.pdf"
        }

        val pdfFile = File(outDir, cleanName)
        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return pdfFile
    }
}
