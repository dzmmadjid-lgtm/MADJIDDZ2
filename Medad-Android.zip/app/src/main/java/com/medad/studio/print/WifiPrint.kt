package com.medad.studio.print

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class WifiPrinter(
    val name: String,
    val host: String,
    val port: Int,
    val type: String,
)

object WifiPrint {

    fun discover(context: Context): Flow<List<WifiPrinter>> = callbackFlow {
        val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
        val found = linkedMapOf<String, WifiPrinter>()

        fun emitNow() {
            trySend(found.values.toList())
        }

        val resolveListener = object : NsdManager.ResolveListener {
            override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
            override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                val host = serviceInfo.host?.hostAddress ?: return
                found[serviceInfo.serviceName] = WifiPrinter(
                    name = serviceInfo.serviceName,
                    host = host,
                    port = serviceInfo.port,
                    type = serviceInfo.serviceType ?: "_ipp._tcp",
                )
                emitNow()
            }
        }

        val discovery = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
            override fun onDiscoveryStarted(serviceType: String) = Unit
            override fun onDiscoveryStopped(serviceType: String) = Unit
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                try {
                    nsd.resolveService(serviceInfo, resolveListener)
                } catch (_: Exception) {
                }
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                found.remove(serviceInfo.serviceName)
                emitNow()
            }
        }

        try {
            nsd.discoverServices("_ipp._tcp.", NsdManager.PROTOCOL_DNS_SD, discovery)
        } catch (_: Exception) {
        }

        emitNow()
        awaitClose {
            try {
                nsd.stopServiceDiscovery(discovery)
            } catch (_: Exception) {
            }
        }
    }

    fun systemPrint(context: Context, jobName: String, uri: Uri) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val adapter = PdfPrintAdapter(context, uri)
        val attrs = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()
        printManager.print(jobName, adapter, attrs)
    }
}
