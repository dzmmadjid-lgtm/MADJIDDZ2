package com.crimsonpdf.reconstructor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.crimsonpdf.reconstructor.export.DocumentExporter
import com.crimsonpdf.reconstructor.export.ExportFormat
import com.crimsonpdf.reconstructor.export.ExportResult
import com.crimsonpdf.reconstructor.model.AppThemeMode
import com.crimsonpdf.reconstructor.model.BorderProperties
import com.crimsonpdf.reconstructor.model.BorderSide
import com.crimsonpdf.reconstructor.model.LayoutObjectType
import com.crimsonpdf.reconstructor.model.PageLayoutObject
import com.crimsonpdf.reconstructor.model.PreprocessingConfig
import com.crimsonpdf.reconstructor.model.ProcessingMode
import com.crimsonpdf.reconstructor.model.ReconstructedPage
import com.crimsonpdf.reconstructor.model.TableCellModel
import com.crimsonpdf.reconstructor.model.TableStructureModel
import com.crimsonpdf.reconstructor.model.TextAlignment
import com.crimsonpdf.reconstructor.model.TextDirection
import com.crimsonpdf.reconstructor.model.WorkflowTab
import com.crimsonpdf.reconstructor.ocr.OcrAndLayoutEngine
import com.crimsonpdf.reconstructor.preprocessing.ImagePreprocessor
import com.crimsonpdf.reconstructor.rendering.DocumentPageRenderer
import com.crimsonpdf.reconstructor.samples.AcceptanceTestSuite
import com.crimsonpdf.reconstructor.validation.IterativeVisualValidator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                CrimsonPdfApplication()
            }
        }
    }
}

private val DayScheme = lightColorScheme(
    primary = Color(0xFFDC2626),
    onPrimary = Color.White,
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF),
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A)
)

private val NightScheme = darkColorScheme(
    primary = Color(0xFFEF4444),
    onPrimary = Color.White,
    background = Color(0xFF0F172A),
    surface = Color(0xFF1E293B),
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF8FAFC)
)

private val OledScheme = darkColorScheme(
    primary = Color(0xFFDC2626),
    onPrimary = Color.White,
    background = Color(0xFF000000),
    surface = Color(0xFF0A0A0A),
    onBackground = Color(0xFFFFFFFF),
    onSurface = Color(0xFFFFFFFF)
)

@Composable
fun RedPdfBadgeIcon(modifier: Modifier = Modifier.size(36.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(
            color = Color(0xFFDC2626),
            cornerRadius = CornerRadius(w * 0.22f, h * 0.22f)
        )
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(w * 0.22f, h * 0.16f),
            size = Size(w * 0.56f, h * 0.68f),
            cornerRadius = CornerRadius(w * 0.06f, h * 0.06f)
        )
        drawRect(
            color = Color(0xFFDC2626),
            topLeft = Offset(w * 0.28f, h * 0.32f),
            size = Size(w * 0.44f, h * 0.08f)
        )
        drawRect(
            color = Color(0xFFEF4444),
            topLeft = Offset(w * 0.36f, h * 0.45f),
            size = Size(w * 0.36f, h * 0.06f)
        )
        drawRect(
            color = Color(0xFFDC2626),
            topLeft = Offset(w * 0.28f, h * 0.56f),
            size = Size(w * 0.44f, h * 0.20f)
        )
    }
}

@Composable
fun CrimsonPdfApplication() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var themeMode by remember { mutableStateOf(AppThemeMode.OLED) }
    var activeTab by remember { mutableStateOf(WorkflowTab.PREVIEW_COMPARE) }
    var processingMode by remember { mutableStateOf(ProcessingMode.MODE_A_CLEAN_RECONSTRUCTION) }
    var previewSubMode by remember { mutableIntStateOf(0) } // 0: SideBySide, 1: Mode A, 2: Mode B, 3: Heatmap

    var selectedTestId by remember { mutableStateOf("arabic_table") }
    var pages by remember { mutableStateOf<List<ReconstructedPage>>(emptyList()) }
    var activePageIdx by remember { mutableIntStateOf(0) }
    var selectedObjectId by remember { mutableStateOf<String?>(null) }
    var selectedCellIndex by remember { mutableIntStateOf(0) }
    var showBoundingBoxes by remember { mutableStateOf(false) }

    var isBusy by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("جاهز — اختر وثيقة أو التقط صورة لإعادة بنائها") }

    var exportFormat by remember { mutableStateOf(ExportFormat.PDF) }
    var exportDpi by remember { mutableIntStateOf(300) }
    var lastExportResult by remember { mutableStateOf<ExportResult?>(null) }

    val currentPage = pages.getOrNull(activePageIdx)

    fun loadTestSuiteDocument(testId: String) {
        scope.launch {
            isBusy = true
            selectedTestId = testId
            lastExportResult = null
            val built = withContext(Dispatchers.Default) {
                val spec = AcceptanceTestSuite.specs.find { it.id == testId } ?: AcceptanceTestSuite.specs[2]
                (0 until spec.pageCount).map { pIdx ->
                    val data = AcceptanceTestSuite.getPageData(testId, pIdx)
                    val srcBmp = DocumentPageRenderer.renderToBitmap(
                        objects = data.objects,
                        widthPx = 800,
                        heightPx = 1131,
                        simulateScanAngleDeg = data.simulateAngleDeg,
                        simulateNoiseLevel = data.simulateNoiseLevel,
                        simulateShadowStrength = data.simulateShadowStrength
                    )
                    val prepBmp = ImagePreprocessor.processBitmap(srcBmp, data.preprocessing, forModeB = false)
                    val cleanBmp = ImagePreprocessor.processBitmap(srcBmp, data.preprocessing, forModeB = true)
                    val valResult = IterativeVisualValidator.validateAndRefine(prepBmp, data.objects, refineGeometry = true)
                    val recBmp = DocumentPageRenderer.renderToBitmap(
                        objects = valResult.refinedObjects,
                        widthPx = 800,
                        heightPx = 1131,
                        selectedObjectId = valResult.refinedObjects.firstOrNull()?.id,
                        highlightLowConfidence = true,
                        showBoundingBoxes = showBoundingBoxes
                    )
                    ReconstructedPage(
                        pageNumber = pIdx + 1,
                        sourceBitmap = srcBmp,
                        preprocessedBitmap = prepBmp,
                        cleanedModeBBitmap = cleanBmp,
                        reconstructedBitmap = recBmp,
                        objects = valResult.refinedObjects,
                        preprocessing = data.preprocessing,
                        validationReport = valResult.report
                    )
                }
            }
            pages = built
            activePageIdx = 0
            selectedObjectId = built.firstOrNull()?.objects?.firstOrNull()?.id
            val specTitle = AcceptanceTestSuite.specs.find { it.id == testId }?.titleAr ?: testId
            statusMessage = "تمت إعادة بناء: $specTitle (${built.first().validationReport.overallSimilarityPercent}% مطابقة)"
            isBusy = false
        }
    }

    fun processCustomBitmap(rawBitmap: Bitmap, sourceLabel: String) {
        scope.launch {
            isBusy = true
            selectedTestId = "custom"
            statusMessage = "جاري تصحيح الإضاءة وتحليل التخطيط والجداول..."
            val builtPage = withContext(Dispatchers.Default) {
                val scaledSrc = Bitmap.createScaledBitmap(rawBitmap, 800, 1131, true)
                val prepConfig = PreprocessingConfig()
                val prepBmp = ImagePreprocessor.processBitmap(scaledSrc, prepConfig, forModeB = false)
                val cleanBmp = ImagePreprocessor.processBitmap(scaledSrc, prepConfig, forModeB = true)
                val detectedObjects = OcrAndLayoutEngine.analyzeDocumentBitmap(prepBmp)
                val valResult = IterativeVisualValidator.validateAndRefine(prepBmp, detectedObjects, refineGeometry = true)
                val recBmp = DocumentPageRenderer.renderToBitmap(
                    objects = valResult.refinedObjects,
                    widthPx = 800,
                    heightPx = 1131,
                    selectedObjectId = valResult.refinedObjects.firstOrNull()?.id,
                    highlightLowConfidence = true,
                    showBoundingBoxes = showBoundingBoxes
                )
                ReconstructedPage(
                    pageNumber = 1,
                    sourceBitmap = scaledSrc,
                    preprocessedBitmap = prepBmp,
                    cleanedModeBBitmap = cleanBmp,
                    reconstructedBitmap = recBmp,
                    objects = valResult.refinedObjects,
                    preprocessing = prepConfig,
                    validationReport = valResult.report
                )
            }
            pages = listOf(builtPage)
            activePageIdx = 0
            selectedObjectId = builtPage.objects.firstOrNull()?.id
            statusMessage = "تم استيراد وإعادة بناء ($sourceLabel) — تم اكتشاف ${builtPage.objects.size} عنصر تخطيطي"
            activeTab = WorkflowTab.PREVIEW_COMPARE
            isBusy = false
        }
    }

    fun refreshCurrentPageRender(updatedObjects: List<PageLayoutObject>, updatedPrep: PreprocessingConfig? = null) {
        val pg = currentPage ?: return
        scope.launch {
            val updatedPage = withContext(Dispatchers.Default) {
                val prepCfg = updatedPrep ?: pg.preprocessing
                val prepBmp = if (updatedPrep != null) {
                    ImagePreprocessor.processBitmap(pg.sourceBitmap, prepCfg, forModeB = false)
                } else pg.preprocessedBitmap
                val cleanBmp = if (updatedPrep != null) {
                    ImagePreprocessor.processBitmap(pg.sourceBitmap, prepCfg, forModeB = true)
                } else pg.cleanedModeBBitmap

                val recBmp = DocumentPageRenderer.renderToBitmap(
                    objects = updatedObjects,
                    widthPx = 800,
                    heightPx = 1131,
                    selectedObjectId = selectedObjectId,
                    highlightLowConfidence = true,
                    showBoundingBoxes = showBoundingBoxes
                )
                pg.copy(
                    preprocessedBitmap = prepBmp,
                    cleanedModeBBitmap = cleanBmp,
                    reconstructedBitmap = recBmp,
                    objects = updatedObjects,
                    preprocessing = prepCfg
                )
            }
            pages = pages.mapIndexed { idx, item -> if (idx == activePageIdx) updatedPage else item }
        }
    }

    // Gallery Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        processCustomBitmap(bmp, "صورة من المعرض")
                    }
                }
            } catch (_: Throwable) {
                statusMessage = "تعذر قراءة الصورة المختارة"
            }
        }
    }

    // Camera Capture Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bmp: Bitmap? ->
        if (bmp != null) {
            processCustomBitmap(bmp, "التقاط الكاميرا")
        }
    }

    LaunchedEffect(Unit) {
        loadTestSuiteDocument("arabic_table")
    }

    val colorScheme = when (themeMode) {
        AppThemeMode.DAY -> DayScheme
        AppThemeMode.NIGHT -> NightScheme
        AppThemeMode.OLED -> OledScheme
    }
    val cardBorderColor = when (themeMode) {
        AppThemeMode.DAY -> Color(0xFFE2E8F0)
        AppThemeMode.NIGHT -> Color(0xFF334155)
        AppThemeMode.OLED -> Color(0xFF222222)
    }

    MaterialTheme(colorScheme = colorScheme) {
        Scaffold(
            topBar = {
                Surface(
                    color = colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.8.dp, cardBorderColor)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                RedPdfBadgeIcon()
                                Column {
                                    Text(
                                        text = "CrimsonPDF Reconstruct",
                                        color = Color(0xFFDC2626),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "محرك إعادة بناء المستندات والجداول العربية",
                                        color = colorScheme.onSurface.copy(alpha = 0.75f),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            // Theme Switcher (Day / Night / OLED)
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, cardBorderColor, RoundedCornerShape(8.dp))
                                    .padding(2.dp),
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                listOf(
                                    AppThemeMode.DAY to "نهاري",
                                    AppThemeMode.NIGHT to "ليلي",
                                    AppThemeMode.OLED to "OLED"
                                ).forEach { (mode, label) ->
                                    val active = themeMode == mode
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (active) Color(0xFFDC2626) else Color.Transparent)
                                            .clickable { themeMode = mode }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (active) Color.White else colorScheme.onSurface,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Mode A vs Mode B Switcher Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val isModeA = processingMode == ProcessingMode.MODE_A_CLEAN_RECONSTRUCTION
                            Button(
                                onClick = {
                                    processingMode = ProcessingMode.MODE_A_CLEAN_RECONSTRUCTION
                                    previewSubMode = 0
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isModeA) Color(0xFFDC2626) else colorScheme.surface
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "الوضع (أ): إعادة بناء نظيف",
                                    color = if (isModeA) Color.White else colorScheme.onSurface,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Button(
                                onClick = {
                                    processingMode = ProcessingMode.MODE_B_IMAGE_CLEANING
                                    previewSubMode = 2
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (!isModeA) Color(0xFFDC2626) else colorScheme.surface
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "الوضع (ب): تنظيف الصورة",
                                    color = if (!isModeA) Color.White else colorScheme.onSurface,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            },
            bottomBar = {
                Surface(
                    color = colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.8.dp, cardBorderColor)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(
                            WorkflowTab.IMPORT to "١. الاستيراد",
                            WorkflowTab.PREPROCESS to "٢. المعالجة",
                            WorkflowTab.PREVIEW_COMPARE to "٣. المعاينة",
                            WorkflowTab.MANUAL_EDIT to "٤. الضبط",
                            WorkflowTab.EXPORT to "٥. التصدير"
                        ).forEach { (tab, label) ->
                            val selected = activeTab == tab
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selected) Color(0xFFDC2626) else Color.Transparent)
                                    .clickable { activeTab = tab }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    color = if (selected) Color.White else colorScheme.onSurface,
                                    fontSize = 11.5.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(colorScheme.background)
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Status Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(colorScheme.surface)
                        .border(1.dp, cardBorderColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusMessage,
                            color = colorScheme.onSurface,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        if (isBusy) {
                            Spacer(modifier = Modifier.width(8.dp))
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFFDC2626)
                            )
                        }
                    }
                }

                // TAB 1: IMPORT IMAGE & 10 ACCEPTANCE TEST DOCUMENTS
                if (activeTab == WorkflowTab.IMPORT) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(colorScheme.surface)
                            .border(1.dp, cardBorderColor, RoundedCornerShape(10.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "استيراد صورة وثيقة من الهاتف أو الكاميرا",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = colorScheme.onSurface
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { galleryLauncher.launch("image/*") },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                            ) {
                                Text("اختيار صورة من المعرض", color = Color.White, fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { cameraLauncher.launch(null) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("التقاط بالكاميرا", color = colorScheme.onSurface, fontSize = 12.sp)
                            }
                        }

                        Divider(color = cardBorderColor, modifier = Modifier.padding(vertical = 4.dp))

                        Text(
                            text = "حالات القبول المعيارية العشر (10 Acceptance Test Documents):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = colorScheme.onSurface
                        )

                        AcceptanceTestSuite.specs.forEach { spec ->
                            val isSelected = selectedTestId == spec.id
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isSelected) Color(0xFFDC2626).copy(alpha = 0.14f)
                                        else colorScheme.background
                                    )
                                    .border(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) Color(0xFFDC2626) else cardBorderColor,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        loadTestSuiteDocument(spec.id)
                                        activeTab = WorkflowTab.PREVIEW_COMPARE
                                    }
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = spec.titleAr,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${spec.categoryAr} · ${if (spec.pageCount > 1) "صفحتان" else "صفحة ١"}",
                                        fontSize = 11.sp,
                                        color = Color(0xFFDC2626)
                                    )
                                }
                                Text(
                                    text = spec.descriptionAr,
                                    fontSize = 11.5.sp,
                                    color = colorScheme.onSurface.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }

                // TAB 2: IMAGE PREPROCESSING
                if (activeTab == WorkflowTab.PREPROCESS && currentPage != null) {
                    val prep = currentPage.preprocessing
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(colorScheme.surface)
                            .border(1.dp, cardBorderColor, RoundedCornerShape(10.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "المعالجة المسبقة للصورة (Perspective, Deskew & Shadow Removal)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = colorScheme.onSurface
                        )

                        Text(
                            text = "زاوية تصحيح الميلان (Deskew): ${prep.deskewAngleDeg.roundToInt()}°",
                            fontSize = 12.sp,
                            color = colorScheme.onSurface
                        )
                        Slider(
                            value = prep.deskewAngleDeg,
                            onValueChange = { angle ->
                                refreshCurrentPageRender(
                                    currentPage.objects,
                                    prep.copy(deskewAngleDeg = angle)
                                )
                            },
                            valueRange = -12f..12f,
                            colors = SliderDefaults.colors(thumbColor = Color(0xFFDC2626), activeTrackColor = Color(0xFFDC2626))
                        )

                        // Rotation buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("تدوير الورقة:", fontSize = 12.sp, color = colorScheme.onSurface)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(0, 90, 180, 270).forEach { deg ->
                                    Button(
                                        onClick = {
                                            refreshCurrentPageRender(
                                                currentPage.objects,
                                                prep.copy(rotationDeg = deg)
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (prep.rotationDeg == deg) Color(0xFFDC2626) else Color(0xFF334155)
                                        )
                                    ) {
                                        Text("${deg}°", color = Color.White, fontSize = 11.sp)
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = prep.removeShadows,
                                    onCheckedChange = { chk ->
                                        refreshCurrentPageRender(
                                            currentPage.objects,
                                            prep.copy(removeShadows = chk)
                                        )
                                    }
                                )
                                Text("إزالة ظلال الكاميرا", fontSize = 12.sp, color = colorScheme.onSurface)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = prep.normalizeBackground,
                                    onCheckedChange = { chk ->
                                        refreshCurrentPageRender(
                                            currentPage.objects,
                                            prep.copy(normalizeBackground = chk)
                                        )
                                    }
                                )
                                Text("تبييض الورقة", fontSize = 12.sp, color = colorScheme.onSurface)
                            }
                        }

                        Text(
                            text = "قوة إزالة الظل: ${prep.shadowStrength.roundToInt()}%",
                            fontSize = 12.sp,
                            color = colorScheme.onSurface
                        )
                        Slider(
                            value = prep.shadowStrength,
                            onValueChange = { v ->
                                refreshCurrentPageRender(
                                    currentPage.objects,
                                    prep.copy(shadowStrength = v)
                                )
                            },
                            valueRange = 0f..100f,
                            colors = SliderDefaults.colors(thumbColor = Color(0xFFDC2626), activeTrackColor = Color(0xFFDC2626))
                        )

                        Text(
                            text = "تعزيز التباين وحدة الحبر: ${prep.contrastBoost.roundToInt()}%",
                            fontSize = 12.sp,
                            color = colorScheme.onSurface
                        )
                        Slider(
                            value = prep.contrastBoost,
                            onValueChange = { v ->
                                refreshCurrentPageRender(
                                    currentPage.objects,
                                    prep.copy(contrastBoost = v)
                                )
                            },
                            valueRange = 0f..100f,
                            colors = SliderDefaults.colors(thumbColor = Color(0xFFDC2626), activeTrackColor = Color(0xFFDC2626))
                        )

                        // Side-by-side preview of Source vs Cleaned Preprocessed
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("الصورة المصدرية", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Image(
                                    bitmap = currentPage.sourceBitmap.asImageBitmap(),
                                    contentDescription = "Source",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(800f / 1131f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .border(1.dp, cardBorderColor, RoundedCornerShape(6.dp)),
                                    contentScale = ContentScale.Fit
                                )
                            }
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("بعد إزالة الظل والميلان", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                                Image(
                                    bitmap = currentPage.cleanedModeBBitmap.asImageBitmap(),
                                    contentDescription = "Cleaned",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(800f / 1131f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .border(1.dp, cardBorderColor, RoundedCornerShape(6.dp)),
                                    contentScale = ContentScale.Fit
                                )
                            }
                        }
                    }
                }

                // TAB 3: PREVIEW RECONSTRUCTION & ITERATIVE VISUAL COMPARISON
                if (activeTab == WorkflowTab.PREVIEW_COMPARE && currentPage != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(colorScheme.surface)
                            .border(1.dp, cardBorderColor, RoundedCornerShape(10.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Sub-mode switcher
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                0 to "مقارنة جنباً إلى جنب",
                                1 to "المستند المعاد بناؤه (Mode A)",
                                2 to "تنظيف الوثيقة (Mode B)",
                                3 to "خريطة المطابقة البصرية"
                            ).forEach { (idx, label) ->
                                val active = previewSubMode == idx
                                Button(
                                    onClick = { previewSubMode = idx },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (active) Color(0xFFDC2626) else Color(0xFF334155)
                                    )
                                ) {
                                    Text(label, color = Color.White, fontSize = 11.sp)
                                }
                            }
                        }

                        // Multi-page selector & Bounding Box toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = showBoundingBoxes,
                                    onCheckedChange = { chk ->
                                        showBoundingBoxes = chk
                                        refreshCurrentPageRender(currentPage.objects)
                                    }
                                )
                                Text("إظهار حدود وإحداثيات العناصر", fontSize = 11.5.sp)
                            }

                            if (pages.size > 1) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    pages.forEachIndexed { idx, pg ->
                                        Button(
                                            onClick = { activePageIdx = idx },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (activePageIdx == idx) Color(0xFFDC2626) else Color(0xFF334155)
                                            )
                                        ) {
                                            Text("ص ${pg.pageNumber}", color = Color.White, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }

                        // Document Viewport
                        when (previewSubMode) {
                            0 -> {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "١. الورقة المصدرية",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Image(
                                            bitmap = currentPage.sourceBitmap.asImageBitmap(),
                                            contentDescription = "Source Page",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .aspectRatio(800f / 1131f)
                                                .clip(RoundedCornerShape(6.dp))
                                                .border(1.dp, cardBorderColor, RoundedCornerShape(6.dp)),
                                            contentScale = ContentScale.Fit
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "٢. إعادة البناء (${currentPage.validationReport.overallSimilarityPercent}%)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFDC2626)
                                        )
                                        Image(
                                            bitmap = currentPage.reconstructedBitmap.asImageBitmap(),
                                            contentDescription = "Reconstructed Page",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .aspectRatio(800f / 1131f)
                                                .clip(RoundedCornerShape(6.dp))
                                                .border(1.5.dp, Color(0xFFDC2626), RoundedCornerShape(6.dp))
                                                .clickable { activeTab = WorkflowTab.MANUAL_EDIT },
                                            contentScale = ContentScale.Fit
                                        )
                                    }
                                }
                            }
                            1 -> {
                                Image(
                                    bitmap = currentPage.reconstructedBitmap.asImageBitmap(),
                                    contentDescription = "Mode A Full",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(800f / 1131f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.5.dp, Color(0xFFDC2626), RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Fit
                                )
                            }
                            2 -> {
                                Image(
                                    bitmap = currentPage.cleanedModeBBitmap.asImageBitmap(),
                                    contentDescription = "Mode B Cleaned",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(800f / 1131f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, cardBorderColor, RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Fit
                                )
                            }
                            else -> {
                                currentPage.validationReport.diffHeatmapBitmap?.let { heatBmp ->
                                    Image(
                                        bitmap = heatBmp.asImageBitmap(),
                                        contentDescription = "Visual Diff Heatmap",
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .aspectRatio(450f / 636f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .border(1.dp, cardBorderColor, RoundedCornerShape(8.dp)),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                            }
                        }

                        // Iterative Validation Report Summary
                        Divider(color = cardBorderColor)
                        Text(
                            text = "تقرير المقارنة البصرية والتصحيح التكراري (Section 13):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        currentPage.validationReport.metrics.forEach { m ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(colorScheme.background)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(m.titleAr, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    Text(m.detailAr, fontSize = 11.sp, color = colorScheme.onSurface.copy(alpha = 0.75f))
                                }
                                Text(
                                    text = "${m.scorePercent}%",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (m.isWarning) Color(0xFFD97706) else Color(0xFF16A34A)
                                )
                            }
                        }
                    }
                }

                // TAB 4: MANUAL COORDINATE & STRUCTURED TABLE INSPECTOR
                if (activeTab == WorkflowTab.MANUAL_EDIT && currentPage != null) {
                    val selectedObj = currentPage.objects.find { it.id == selectedObjectId }
                        ?: currentPage.objects.firstOrNull()

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(colorScheme.surface)
                            .border(1.dp, cardBorderColor, RoundedCornerShape(10.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "الضبط اليدوي الدقيق للإحداثيات والنصوص والجداول",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )

                        // Horizontal chip selector for objects on page
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            currentPage.objects.forEach { obj ->
                                val isSel = obj.id == selectedObj?.id
                                Button(
                                    onClick = {
                                        selectedObjectId = obj.id
                                        selectedCellIndex = 0
                                        refreshCurrentPageRender(currentPage.objects)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSel) Color(0xFFDC2626) else Color(0xFF334155)
                                    )
                                ) {
                                    Text(
                                        text = "${obj.type} (${obj.id})",
                                        color = Color.White,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        if (selectedObj != null) {
                            // Low-confidence confirmation banner if applicable
                            if (selectedObj.confidence < 0.78f && !selectedObj.userCorrected) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFD97706).copy(alpha = 0.15f))
                                        .border(1.dp, Color(0xFFD97706), RoundedCornerShape(8.dp))
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "منطقة حبر باهت (${(selectedObj.confidence * 100).roundToInt()}%) — راجع النص ثم اعتمد",
                                        fontSize = 11.5.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(
                                        onClick = {
                                            val next = currentPage.objects.map {
                                                if (it.id == selectedObj.id) it.copy(userCorrected = true, confidence = 1f)
                                                else it
                                            }
                                            refreshCurrentPageRender(next)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                                    ) {
                                        Text("تأكيد", color = Color.White, fontSize = 11.sp)
                                    }
                                }
                            }

                            // Position X, Y and Size Width, Height sliders
                            Text(
                                text = "الموقع الأفقي X (${selectedObj.x.roundToInt()}) والعمودي Y (${selectedObj.y.roundToInt()}):",
                                fontSize = 12.sp
                            )
                            Slider(
                                value = selectedObj.x,
                                onValueChange = { nx ->
                                    val next = currentPage.objects.map {
                                        if (it.id == selectedObj.id) it.copy(x = nx) else it
                                    }
                                    refreshCurrentPageRender(next)
                                },
                                valueRange = 20f..900f,
                                colors = SliderDefaults.colors(thumbColor = Color(0xFFDC2626), activeTrackColor = Color(0xFFDC2626))
                            )
                            Slider(
                                value = selectedObj.y,
                                onValueChange = { ny ->
                                    val next = currentPage.objects.map {
                                        if (it.id == selectedObj.id) it.copy(y = ny) else it
                                    }
                                    refreshCurrentPageRender(next)
                                },
                                valueRange = 20f..920f,
                                colors = SliderDefaults.colors(thumbColor = Color(0xFFDC2626), activeTrackColor = Color(0xFFDC2626))
                            )

                            // Font size & Alignment controls
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("المحاذاة وحجم الخط (${selectedObj.fontSizePt.roundToInt()} pt):", fontSize = 12.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf(
                                        TextAlignment.RIGHT to "يمين",
                                        TextAlignment.CENTER to "وسط",
                                        TextAlignment.LEFT to "يسار"
                                    ).forEach { (align, lbl) ->
                                        Button(
                                            onClick = {
                                                val next = currentPage.objects.map {
                                                    if (it.id == selectedObj.id) it.copy(alignment = align) else it
                                                }
                                                refreshCurrentPageRender(next)
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (selectedObj.alignment == align) Color(0xFFDC2626) else Color(0xFF334155)
                                            )
                                        ) {
                                            Text(lbl, color = Color.White, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }

                            if (selectedObj.type != LayoutObjectType.TABLE && selectedObj.type != LayoutObjectType.LINE) {
                                OutlinedTextField(
                                    value = selectedObj.content,
                                    onValueChange = { newText ->
                                        val next = currentPage.objects.map {
                                            if (it.id == selectedObj.id) it.copy(content = newText, userCorrected = true)
                                            else it
                                        }
                                        refreshCurrentPageRender(next)
                                    },
                                    label = { Text("تحرير النص المستخرج") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            // Structured Table Editor if object is TABLE
                            if (selectedObj.type == LayoutObjectType.TABLE && selectedObj.tableStructure != null) {
                                val tbl = selectedObj.tableStructure
                                val visibleCells = tbl.cells.filter { !it.hiddenByMerge }
                                val activeCell = visibleCells.getOrNull(selectedCellIndex) ?: visibleCells.firstOrNull()

                                Divider(color = cardBorderColor)
                                Text(
                                    text = "محرر خلايا الجدول المهيكل (${tbl.rows} صفوف × ${tbl.cols} أعمدة):",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    visibleCells.forEachIndexed { idx, cellItem ->
                                        val active = idx == selectedCellIndex
                                        Button(
                                            onClick = { selectedCellIndex = idx },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (active) Color(0xFFDC2626) else Color(0xFF334155)
                                            )
                                        ) {
                                            Text(
                                                text = cellItem.content.take(14).ifEmpty { "(${cellItem.row + 1},${cellItem.col + 1})" },
                                                color = Color.White,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }

                                if (activeCell != null) {
                                    OutlinedTextField(
                                        value = activeCell.content,
                                        onValueChange = { newVal ->
                                            val nextCells = tbl.cells.map { c ->
                                                if (c.row == activeCell.row && c.col == activeCell.col) c.copy(content = newVal)
                                                else c
                                            }
                                            val nextObjs = currentPage.objects.map {
                                                if (it.id == selectedObj.id) it.copy(tableStructure = tbl.copy(cells = nextCells))
                                                else it
                                            }
                                            refreshCurrentPageRender(nextObjs)
                                        },
                                        label = {
                                            Text("نص الخلية (${activeCell.row + 1}، ${activeCell.col + 1}) · دمج ${activeCell.rowSpan}×${activeCell.colSpan}")
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                val nextCol = activeCell.col + activeCell.colSpan
                                                if (nextCol < tbl.cols) {
                                                    val nextCells = tbl.cells.map { c ->
                                                        if (c.row == activeCell.row && c.col == activeCell.col) {
                                                            c.copy(colSpan = c.colSpan + 1)
                                                        } else if (c.row >= activeCell.row && c.row < activeCell.row + activeCell.rowSpan && c.col == nextCol) {
                                                            c.copy(hiddenByMerge = true)
                                                        } else c
                                                    }
                                                    val nextObjs = currentPage.objects.map {
                                                        if (it.id == selectedObj.id) it.copy(tableStructure = tbl.copy(cells = nextCells))
                                                        else it
                                                    }
                                                    refreshCurrentPageRender(nextObjs)
                                                }
                                            },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                                        ) {
                                            Text("دمج أفقي", color = Color.White, fontSize = 11.sp)
                                        }

                                        Button(
                                            onClick = {
                                                val nextRow = activeCell.row + activeCell.rowSpan
                                                if (nextRow < tbl.rows) {
                                                    val nextCells = tbl.cells.map { c ->
                                                        if (c.row == activeCell.row && c.col == activeCell.col) {
                                                            c.copy(rowSpan = c.rowSpan + 1)
                                                        } else if (c.col >= activeCell.col && c.col < activeCell.col + activeCell.colSpan && c.row == nextRow) {
                                                            c.copy(hiddenByMerge = true)
                                                        } else c
                                                    }
                                                    val nextObjs = currentPage.objects.map {
                                                        if (it.id == selectedObj.id) it.copy(tableStructure = tbl.copy(cells = nextCells))
                                                        else it
                                                    }
                                                    refreshCurrentPageRender(nextObjs)
                                                }
                                            },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                                        ) {
                                            Text("دمج عمودي", color = Color.White, fontSize = 11.sp)
                                        }

                                        if (activeCell.colSpan > 1 || activeCell.rowSpan > 1) {
                                            Button(
                                                onClick = {
                                                    val nextCells = tbl.cells.map { c ->
                                                        if (c.row in activeCell.row until (activeCell.row + activeCell.rowSpan) &&
                                                            c.col in activeCell.col until (activeCell.col + activeCell.colSpan)
                                                        ) {
                                                            c.copy(rowSpan = 1, colSpan = 1, hiddenByMerge = false)
                                                        } else c
                                                    }
                                                    val nextObjs = currentPage.objects.map {
                                                        if (it.id == selectedObj.id) it.copy(tableStructure = tbl.copy(cells = nextCells))
                                                        else it
                                                    }
                                                    refreshCurrentPageRender(nextObjs)
                                                },
                                                modifier = Modifier.weight(1f),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                                            ) {
                                                Text("فك الدمج", color = Color.White, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Live Reconstructed Page Preview below controls
                        Image(
                            bitmap = currentPage.reconstructedBitmap.asImageBitmap(),
                            contentDescription = "Live Reconstructed Preview",
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(800f / 1131f)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.5.dp, Color(0xFFDC2626), RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Fit
                        )
                    }
                }

                // TAB 5: EXPORT PDF / PNG / JPG
                if (activeTab == WorkflowTab.EXPORT && currentPage != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(colorScheme.surface)
                            .border(1.dp, cardBorderColor, RoundedCornerShape(10.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "التصدير الطباعي النهائي (PDF / PNG / JPG)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "يحفظ الملف مباشرة في مجلد التنزيلات (Downloads/CrimsonPDF) مع إمكانية فتحه أو مشاركته فوراً.",
                            fontSize = 12.sp,
                            color = colorScheme.onSurface.copy(alpha = 0.8f)
                        )

                        // Format Selection
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                ExportFormat.PDF to "PDF (${pages.size} ص)",
                                ExportFormat.PNG to "PNG (بدون ضغط)",
                                ExportFormat.JPG to "JPG (قياسي)"
                            ).forEach { (fmt, label) ->
                                val selected = exportFormat == fmt
                                Button(
                                    onClick = { exportFormat = fmt },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) Color(0xFFDC2626) else Color(0xFF334155)
                                    )
                                ) {
                                    Text(label, color = Color.White, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }

                        // DPI Resolution Selection
                        Text("دقة الطباعة والتصدير (DPI):", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                150 to "150 DPI",
                                300 to "300 DPI (طباعة)",
                                400 to "400 DPI (فائق)"
                            ).forEach { (dpiVal, label) ->
                                val selected = exportDpi == dpiVal
                                Button(
                                    onClick = { exportDpi = dpiVal },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) Color(0xFFDC2626) else Color(0xFF334155)
                                    )
                                ) {
                                    Text(label, color = Color.White, fontSize = 11.sp)
                                }
                            }
                        }

                        Button(
                            onClick = {
                                scope.launch {
                                    isBusy = true
                                    statusMessage = "جاري بناء ملف ${exportFormat.name} بدقة $exportDpi DPI..."
                                    try {
                                        val res = withContext(Dispatchers.IO) {
                                            DocumentExporter.exportDocument(
                                                context = context,
                                                pages = pages,
                                                format = exportFormat,
                                                dpi = exportDpi,
                                                processingMode = processingMode,
                                                prefix = "CrimsonPDF_${selectedTestId}"
                                            )
                                        }
                                        lastExportResult = res
                                        statusMessage = "تم حفظ الملف في التنزيلات: ${res.filename} (${res.sizeKb} KB)"
                                    } catch (e: Throwable) {
                                        statusMessage = "خطأ أثناء التصدير: ${e.message}"
                                    } finally {
                                        isBusy = false
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                        ) {
                            Text(
                                text = "تصدير وحفظ ${exportFormat.name} ($exportDpi DPI) في الهاتف",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp
                            )
                        }

                        lastExportResult?.let { exp ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF16A34A).copy(alpha = 0.14f))
                                    .border(1.dp, Color(0xFF16A34A), RoundedCornerShape(8.dp))
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "تم التصدير والحفظ بنجاح في Downloads/CrimsonPDF:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp,
                                    color = Color(0xFF16A34A)
                                )
                                Text(
                                    text = "${exp.filename}\nالحجم: ${exp.sizeKb} KB · الأبعاد: ${exp.dimensionsLabel}",
                                    fontSize = 11.5.sp
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { DocumentExporter.shareOrOpenExportedFile(context, exp, share = false) },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                                    ) {
                                        Text("فتح المستند الآن", color = Color.White, fontSize = 12.sp)
                                    }
                                    OutlinedButton(
                                        onClick = { DocumentExporter.shareOrOpenExportedFile(context, exp, share = true) },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("مشاركة الملف", color = colorScheme.onSurface, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
