package com.example.core.reconstruct

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import com.example.data.model.RectNormalized
import com.example.data.model.TextRegion
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Computer vision table and grid detector.
 * Analyzes physical raster lines in the document to detect genuine table structures:
 * outer borders, rows, columns, and individual cells.
 */
object TableStructureDetector {

    data class TableCell(
        val row: Int,
        val col: Int,
        val bounds: RectF,
        val normalizedBounds: RectNormalized
    )

    data class ReconstructedTable(
        val bounds: RectF,
        val normalizedBounds: RectNormalized,
        val horizontalLines: List<Float>, // Y coordinates in pixels
        val verticalLines: List<Float>,   // X coordinates in pixels
        val cells: List<TableCell>
    )

    /**
     * Detects physical grid tables by scanning for continuous horizontal and vertical line runs.
     */
    fun detectTables(
        bitmap: Bitmap,
        regions: List<TextRegion>
    ): List<ReconstructedTable> {
        val width = bitmap.width
        val height = bitmap.height

        // Downsample slightly for fast and robust line projection
        val scale = if (width > 1200) 1200f / width else 1f
        val sw = (width * scale).toInt()
        val sh = (height * scale).toInt()

        val pixels = IntArray(sw * sh)
        val scaledBitmap = if (scale < 1f) {
            Bitmap.createScaledBitmap(bitmap, sw, sh, true)
        } else {
            bitmap
        }
        scaledBitmap.getPixels(pixels, 0, sw, 0, 0, sw, sh)

        // 1. Horizontal line detection: scan rows for long runs of dark pixels
        val minHLineLength = (sw * 0.20f).toInt() // At least 20% page width
        val horizontalLineY = mutableListOf<Float>()

        val darkThreshold = 180 // Below 180 is ink or line
        for (y in 5 until sh - 5) {
            var darkRun = 0
            var maxDarkRun = 0
            val rowOffset = y * sw
            for (x in 0 until sw) {
                val p = pixels[rowOffset + x]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val lum = (r * 299 + g * 587 + b * 114) / 1000

                if (lum < darkThreshold) {
                    darkRun++
                    if (darkRun > maxDarkRun) maxDarkRun = darkRun
                } else {
                    darkRun = 0
                }
            }

            if (maxDarkRun >= minHLineLength) {
                val origY = y / scale
                // Avoid duplicate adjacent lines
                if (horizontalLineY.isEmpty() || abs(horizontalLineY.last() - origY) > (height * 0.015f)) {
                    horizontalLineY.add(origY)
                }
            }
        }

        // 2. Vertical line detection: scan columns for vertical line segments between horizontal lines
        val verticalLineX = mutableListOf<Float>()
        if (horizontalLineY.size >= 2) {
            val tableTop = horizontalLineY.first()
            val tableBottom = horizontalLineY.last()
            val tableSpanY = tableBottom - tableTop

            if (tableSpanY > (height * 0.08f)) {
                val syStart = (tableTop * scale).toInt().coerceIn(0, sh - 1)
                val syEnd = (tableBottom * scale).toInt().coerceIn(syStart + 1, sh)
                val minVLineHeight = ((syEnd - syStart) * 0.50f).toInt()

                for (x in 5 until sw - 5) {
                    var darkCount = 0
                    for (y in syStart until syEnd) {
                        val p = pixels[y * sw + x]
                        val r = (p shr 16) and 0xFF
                        val g = (p shr 8) and 0xFF
                        val b = p and 0xFF
                        val lum = (r * 299 + g * 587 + b * 114) / 1000
                        if (lum < darkThreshold) darkCount++
                    }

                    if (darkCount >= minVLineHeight) {
                        val origX = x / scale
                        if (verticalLineX.isEmpty() || abs(verticalLineX.last() - origX) > (width * 0.03f)) {
                            verticalLineX.add(origX)
                        }
                    }
                }
            }
        }

        // Also check text alignment clusters if physical lines were faint or partially dashed
        if (horizontalLineY.size < 2 || verticalLineX.size < 2) {
            val fallbackTable = detectTableFromAlignedRegions(regions, width, height)
            if (fallbackTable != null) {
                return listOf(fallbackTable)
            }
        }

        if (horizontalLineY.size >= 2 && verticalLineX.size >= 2) {
            val minX = verticalLineX.first()
            val maxX = verticalLineX.last()
            val minY = horizontalLineY.first()
            val maxY = horizontalLineY.last()

            val tableBounds = RectF(minX, minY, maxX, maxY)
            val normBounds = RectNormalized(minX / width, minY / height, maxX / width, maxY / height)

            // Construct cells
            val cells = mutableListOf<TableCell>()
            for (r in 0 until horizontalLineY.size - 1) {
                val top = horizontalLineY[r]
                val bottom = horizontalLineY[r + 1]
                for (c in 0 until verticalLineX.size - 1) {
                    val left = verticalLineX[c]
                    val right = verticalLineX[c + 1]
                    val cellBounds = RectF(left, top, right, bottom)
                    val normCell = RectNormalized(left / width, top / height, right / width, bottom / height)
                    cells.add(TableCell(row = r, col = c, bounds = cellBounds, normalizedBounds = normCell))
                }
            }

            return listOf(
                ReconstructedTable(
                    bounds = tableBounds,
                    normalizedBounds = normBounds,
                    horizontalLines = horizontalLineY,
                    verticalLines = verticalLineX,
                    cells = cells
                )
            )
        }

        return emptyList()
    }

    /**
     * Fallback for tables where grid lines are faint or borderless by detecting 2D grid matrix of text cells
     */
    private fun detectTableFromAlignedRegions(
        regions: List<TextRegion>,
        width: Int,
        height: Int
    ): ReconstructedTable? {
        if (regions.size < 4) return null

        // Group regions with similar top coordinates into rows
        val toleranceY = 0.025f // 2.5% of height
        val rowGroups = mutableListOf<MutableList<TextRegion>>()

        val sorted = regions.sortedBy { it.boundingBox.top }
        for (r in sorted) {
            val group = rowGroups.find { g -> abs(g.first().boundingBox.top - r.boundingBox.top) < toleranceY }
            if (group != null) {
                group.add(r)
            } else {
                rowGroups.add(mutableListOf(r))
            }
        }

        // A table has at least 2 rows with multiple aligned columns (>= 2 cells each)
        val multiCellRows = rowGroups.filter { it.size >= 2 }
        if (multiCellRows.size >= 2) {
            val allTableRegions = multiCellRows.flatten()
            val minX = allTableRegions.minOf { it.boundingBox.left } * width - 10f
            val maxX = allTableRegions.maxOf { it.boundingBox.right } * width + 10f
            val minY = multiCellRows.first().minOf { it.boundingBox.top } * height - 8f
            val maxY = multiCellRows.last().maxOf { it.boundingBox.bottom } * height + 8f

            val hLines = mutableListOf<Float>()
            hLines.add(minY)
            for (row in multiCellRows) {
                val rowBottom = row.maxOf { it.boundingBox.bottom } * height + 6f
                hLines.add(rowBottom)
            }

            // Derive vertical column divisions
            val allX = mutableListOf<Float>()
            allX.add(minX)
            val firstRow = multiCellRows.first().sortedBy { it.boundingBox.left }
            for (i in 0 until firstRow.size - 1) {
                val midX = ((firstRow[i].boundingBox.right + firstRow[i + 1].boundingBox.left) / 2f) * width
                allX.add(midX)
            }
            allX.add(maxX)

            val cells = mutableListOf<TableCell>()
            for (r in 0 until hLines.size - 1) {
                for (c in 0 until allX.size - 1) {
                    val cb = RectF(allX[c], hLines[r], allX[c + 1], hLines[r + 1])
                    val ncb = RectNormalized(cb.left / width, cb.top / height, cb.right / width, cb.bottom / height)
                    cells.add(TableCell(row = r, col = c, bounds = cb, normalizedBounds = ncb))
                }
            }

            return ReconstructedTable(
                bounds = RectF(minX, minY, maxX, maxY),
                normalizedBounds = RectNormalized(minX / width, minY / height, maxX / width, maxY / height),
                horizontalLines = hLines,
                verticalLines = allX,
                cells = cells
            )
        }

        return null
    }
}
