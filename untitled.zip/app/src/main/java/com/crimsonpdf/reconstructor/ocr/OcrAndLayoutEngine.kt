package com.crimsonpdf.reconstructor.ocr

import android.graphics.Bitmap
import android.graphics.Color
import com.crimsonpdf.reconstructor.model.BorderProperties
import com.crimsonpdf.reconstructor.model.FontRole
import com.crimsonpdf.reconstructor.model.LayoutObjectType
import com.crimsonpdf.reconstructor.model.PageLayoutObject
import com.crimsonpdf.reconstructor.model.TableCellModel
import com.crimsonpdf.reconstructor.model.TableStructureModel
import com.crimsonpdf.reconstructor.model.TextAlignment
import com.crimsonpdf.reconstructor.model.TextDirection
import com.crimsonpdf.reconstructor.preprocessing.ImagePreprocessor
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.suspendCancellableCoroutine

object OcrAndLayoutEngine {

    /**
     * Converts any Eastern Arabic (٠-٩) or Persian (۰-۹) digits to Western Arabic digits (0-9).
     */
    fun normalizeToWesternDigits(input: String): String {
        if (input.isEmpty()) return input
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '\u0660'..'\u0669' -> sb.append((ch.code - 0x0660 + '0'.code).toChar())
                in '\u06F0'..'\u06F9' -> sb.append((ch.code - 0x06F0 + '0'.code).toChar())
                '٪' -> sb.append('%')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Analyzes a preprocessed document bitmap and reconstructs its page layout objects.
     * Never invents or hallucinates placeholder text: every detected region retains its
     * cleaned ink patch (sourcePatchBitmap) from the source image unless the user manually edits it.
     */
    suspend fun analyzeDocumentBitmap(bitmap: Bitmap): List<PageLayoutObject> {
        val mlKitHints = runMlKitRecognition(bitmap)
        val structuralObjects = analyzePixelStructure(bitmap, mlKitHints)
        if (structuralObjects.isNotEmpty()) {
            return structuralObjects
        }

        // Fallback: single full-page reconstructed block preserving source ink
        val fullPatch = ImagePreprocessor.extractCleanInkPatch(bitmap, 30f, 30f, 940f, 940f)
        return listOf(
            PageLayoutObject(
                id = "page_region_1",
                type = LayoutObjectType.PARAGRAPH,
                x = 30f,
                y = 30f,
                width = 940f,
                height = 940f,
                content = "",
                confidence = 0.96f,
                userCorrected = false,
                alignment = TextAlignment.RIGHT,
                direction = TextDirection.RTL,
                zOrder = 1,
                sourcePatchBitmap = fullPatch
            )
        )
    }

    private data class OcrBoxHint(
        val xNorm: Float,
        val yNorm: Float,
        val wNorm: Float,
        val hNorm: Float,
        val text: String
    )

    private suspend fun runMlKitRecognition(bitmap: Bitmap): List<OcrBoxHint> =
        suspendCancellableCoroutine { cont ->
            try {
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val image = InputImage.fromBitmap(bitmap, 0)
                val bw = bitmap.width.coerceAtLeast(1).toFloat()
                val bh = bitmap.height.coerceAtLeast(1).toFloat()

                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        val list = mutableListOf<OcrBoxHint>()
                        for (block in visionText.textBlocks) {
                            val rect = block.boundingBox ?: continue
                            val cleaned = normalizeToWesternDigits(block.text.trim())
                            if (cleaned.isNotEmpty()) {
                                list.add(
                                    OcrBoxHint(
                                        xNorm = ((rect.left / bw) * 1000f).coerceIn(10f, 980f),
                                        yNorm = ((rect.top / bh) * 1000f).coerceIn(10f, 980f),
                                        wNorm = ((rect.width() / bw) * 1000f).coerceIn(20f, 980f),
                                        hNorm = ((rect.height() / bh) * 1000f).coerceIn(12f, 960f),
                                        text = cleaned
                                    )
                                )
                            }
                        }
                        if (cont.isActive) cont.resume(list)
                    }
                    .addOnFailureListener {
                        if (cont.isActive) cont.resume(emptyList())
                    }
            } catch (_: Throwable) {
                if (cont.isActive) cont.resume(emptyList())
            }
        }

    private fun analyzePixelStructure(
        bitmap: Bitmap,
        mlKitHints: List<OcrBoxHint>
    ): List<PageLayoutObject> {
        val w = bitmap.width.coerceAtLeast(100)
        val h = bitmap.height.coerceAtLeast(100)
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val rowDarkCounts = IntArray(h)
        for (y in 0 until h) {
            var count = 0
            val offset = y * w
            for (x in (w * 0.03).toInt() until (w * 0.97).toInt()) {
                val c = pixels[offset + x]
                val luma = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
                if (luma < 195f) count++
            }
            rowDarkCounts[y] = count
        }

        val objects = mutableListOf<PageLayoutObject>()
        var inBand = false
        var bandStart = 0
        var bandIdx = 0

        val minActivePixels = (w * 0.012).toInt().coerceAtLeast(6)

        for (y in (h * 0.02).toInt() until (h * 0.98).toInt()) {
            val active = rowDarkCounts[y] >= minActivePixels
            if (active && !inBand) {
                inBand = true
                bandStart = y
            } else if (!active && inBand) {
                var lookahead = false
                for (k in 1..10) {
                    if (y + k < h && rowDarkCounts[y + k] >= minActivePixels) {
                        lookahead = true
                        break
                    }
                }
                if (!lookahead) {
                    inBand = false
                    val bandEnd = y
                    val bandH = bandEnd - bandStart
                    if (bandH >= 4 && bandIdx < 24) {
                        var minX = w
                        var maxX = 0
                        var maxDensity = 0
                        var horizontalRuleRows = 0

                        for (by in bandStart..bandEnd) {
                            if (rowDarkCounts[by] > maxDensity) maxDensity = rowDarkCounts[by]
                            if (rowDarkCounts[by] > (w * 0.38).toInt()) horizontalRuleRows++
                            val off = by * w
                            var bx = (w * 0.02).toInt()
                            while (bx < (w * 0.98).toInt()) {
                                val c = pixels[off + bx]
                                val luma = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
                                if (luma < 195f) {
                                    minX = min(minX, bx)
                                    maxX = max(maxX, bx)
                                }
                                bx += 2
                            }
                        }

                        if (maxX > minX + 16) {
                            bandIdx++
                            val padX = 4
                            val padY = 3
                            val safeMinX = (minX - padX).coerceAtLeast(4)
                            val safeMaxX = (maxX + padX).coerceAtMost(w - 4)
                            val safeMinY = (bandStart - padY).coerceAtLeast(4)
                            val safeMaxY = (bandEnd + padY).coerceAtMost(h - 4)

                            val nx = ((safeMinX.toFloat() / w) * 1000f).coerceIn(15f, 950f)
                            val ny = ((safeMinY.toFloat() / h) * 1000f).coerceIn(15f, 960f)
                            val nw = (((safeMaxX - safeMinX).toFloat() / w) * 1000f).coerceIn(30f, 970f - nx)
                            val nh = (((safeMaxY - safeMinY).toFloat() / h) * 1000f).coerceIn(6f, 970f - ny)

                            val matchedHint = mlKitHints.firstOrNull { hint ->
                                val overlapY = min(ny + nh, hint.yNorm + hint.hNorm) - max(ny, hint.yNorm)
                                overlapY > min(nh, hint.hNorm) * 0.35f
                            }?.text ?: ""

                            if (nh <= 14f && nw > 380f) {
                                objects.add(
                                    PageLayoutObject(
                                        id = "line_$bandIdx",
                                        type = LayoutObjectType.LINE,
                                        x = nx,
                                        y = ny,
                                        width = nw,
                                        height = 4f,
                                        content = "",
                                        confidence = 0.98f,
                                        borders = BorderProperties.uniform(1.8f),
                                        zOrder = bandIdx
                                    )
                                )
                            } else if (nh > 110f && horizontalRuleRows >= 2 && maxDensity > (safeMaxX - safeMinX) * 0.48f) {
                                // Reconstruct structured table with real cell ink patches from source
                                val patch = ImagePreprocessor.extractCleanInkPatch(bitmap, nx, ny, nw, nh)
                                val detectedRows = (nh / 55f).toInt().coerceIn(2, 8)
                                val detectedCols = 4
                                val rHeights = List(detectedRows) { 1f / detectedRows }
                                val cWidths = List(detectedCols) { 1f / detectedCols }

                                val cells = mutableListOf<TableCellModel>()
                                for (r in 0 until detectedRows) {
                                    for (c in 0 until detectedCols) {
                                        // RTL table: col 0 is rightmost
                                        val cellW = nw / detectedCols
                                        val cellH = nh / detectedRows
                                        val cellX = nx + nw - (c + 1) * cellW
                                        val cellY = ny + r * cellH
                                        val cellPatch = ImagePreprocessor.extractCleanInkPatch(
                                            bitmap,
                                            cellX + 2f,
                                            cellY + 2f,
                                            (cellW - 4f).coerceAtLeast(8f),
                                            (cellH - 4f).coerceAtLeast(8f)
                                        )
                                        cells.add(
                                            TableCellModel(
                                                id = "c_${bandIdx}_${r}_$c",
                                                row = r,
                                                col = c,
                                                content = "",
                                                confidence = 0.95f,
                                                alignment = TextAlignment.CENTER,
                                                isBold = r == 0,
                                                borders = BorderProperties.uniform(1.1f),
                                                backgroundColorArgb = if (r == 0) 0xFFF8FAFC.toInt() else 0,
                                                sourcePatchBitmap = cellPatch,
                                                userEditedText = false
                                            )
                                        )
                                    }
                                }

                                objects.add(
                                    PageLayoutObject(
                                        id = "table_$bandIdx",
                                        type = LayoutObjectType.TABLE,
                                        x = nx,
                                        y = ny,
                                        width = nw,
                                        height = nh,
                                        content = "",
                                        confidence = 0.95f,
                                        userCorrected = false,
                                        borders = BorderProperties.uniform(1.8f),
                                        zOrder = bandIdx,
                                        sourcePatchBitmap = patch,
                                        tableStructure = TableStructureModel(
                                            rows = detectedRows,
                                            cols = detectedCols,
                                            rowHeights = rHeights,
                                            colWidths = cWidths,
                                            direction = TextDirection.RTL,
                                            cells = cells
                                        )
                                    )
                                )
                            } else {
                                val patch = ImagePreprocessor.extractCleanInkPatch(bitmap, nx, ny, nw, nh)
                                val isHeading = bandIdx == 1 || (nh < 48f && nw < 720f)
                                objects.add(
                                    PageLayoutObject(
                                        id = "block_$bandIdx",
                                        type = if (isHeading) LayoutObjectType.TEXT else LayoutObjectType.PARAGRAPH,
                                        x = nx,
                                        y = ny,
                                        width = nw,
                                        height = nh.coerceAtLeast(24f),
                                        content = matchedHint,
                                        confidence = 0.96f,
                                        userCorrected = false,
                                        alignment = if (nx > 160f && nx + nw < 840f) TextAlignment.CENTER else TextAlignment.RIGHT,
                                        direction = TextDirection.RTL,
                                        fontSizePt = if (isHeading) 14.5f else 12f,
                                        isBold = isHeading,
                                        fontRole = if (isHeading) FontRole.HEADING else FontRole.NORMAL,
                                        zOrder = bandIdx,
                                        sourcePatchBitmap = patch
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
        return objects
    }
}
