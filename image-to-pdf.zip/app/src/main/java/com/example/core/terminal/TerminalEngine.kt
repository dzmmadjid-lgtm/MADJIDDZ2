package com.example.core.terminal

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

data class TerminalLine(
    val text: String,
    val isCommand: Boolean = false,
    val isError: Boolean = false
)

class TerminalEngine(
    private val scope: CoroutineScope,
    private val context: Context? = null
) {

    private val _output = MutableStateFlow<List<TerminalLine>>(
        listOf(
            TerminalLine("=== DroidIDE Terminal [Android Linux Shell] ==="),
            TerminalLine("جاهز لاستقبال الأوامر (الاستجابة والنتائج تظهر هنا)"),
            TerminalLine("اكتب الأمر في الخانة بالأسفل واضغط [إرسال] أو اختر أمرًا سريعًا")
        )
    )
    val output: StateFlow<List<TerminalLine>> = _output.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private var activeProcess: Process? = null
    private var executionJob: Job? = null

    init {
        if (context != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val jdkDir = File(context.filesDir, "jdk")
                    if (jdkDir.exists()) {
                        com.example.core.build.JdkProvisioner.configureJdkPermissionsAndWrappers(context, jdkDir)
                    }
                } catch (_: Exception) {}
            }
        }
    }

    fun appendLine(text: String, isCommand: Boolean = false, isError: Boolean = false) {
        _output.value = _output.value + TerminalLine(text, isCommand, isError)
    }

    fun appendOutput(text: String, isError: Boolean = false) {
        appendLine(text, isCommand = false, isError = isError)
    }

    fun appendCommand(command: String) {
        appendLine("$ $command", isCommand = true, isError = false)
    }

    fun clear() {
        _output.value = listOf(
            TerminalLine("=== Terminal Cleared ==="),
            TerminalLine("جاهز لاستقبال الأوامر الجديدة...")
        )
    }

    fun getAllText(): String {
        return _output.value.joinToString("\n") { it.text }
    }

    private fun isDirectAppBinPath(cmd: String): Boolean {
        val token = cmd.trim().split(" ").firstOrNull() ?: return false
        return (token.startsWith("/data/") || token.startsWith("./") || token.contains("/files/")) &&
                (token.endsWith("/java") || token.endsWith("/javac") || token.contains("/bin/"))
    }

    fun executeCommand(command: String, workingDir: File) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return

        appendLine("$ $trimmed", isCommand = true)

        if (trimmed == "clear" || trimmed == "cls") {
            clear()
            return
        }

        executionJob?.cancel()
        executionJob = scope.launch(Dispatchers.IO) {
            _isRunning.value = true
            try {
                val envMap = mutableMapOf<String, String>()

                // Inject internal/sandbox JDK if provisioned
                if (context != null) {
                    val jdkDir = File(context.filesDir, "jdk")
                    if (jdkDir.exists()) {
                        val directBin = File(jdkDir, "bin")
                        val binDir = if (directBin.exists()) directBin else {
                            jdkDir.listFiles()?.firstOrNull { File(it, "bin").exists() }?.let { File(it, "bin") }
                        }
                        if (binDir != null && binDir.exists()) {
                            val javaHome = binDir.parentFile?.absolutePath ?: jdkDir.absolutePath
                            envMap["JAVA_HOME"] = javaHome
                            val currentPath = System.getenv("PATH") ?: "/system/bin"
                            envMap["PATH"] = "${binDir.absolutePath}:$currentPath"
                            val curLd = System.getenv("LD_LIBRARY_PATH") ?: ""
                            envMap["LD_LIBRARY_PATH"] = "$javaHome/lib:$javaHome/lib/server:$javaHome/lib/jli:${binDir.absolutePath}:$curLd"

                            // Ensure wrappers and library links exist
                            try {
                                com.example.core.build.JdkProvisioner.configureJdkPermissionsAndWrappers(context, jdkDir)
                            } catch (_: Exception) {}
                        }
                    }

                    val sdkDir = File(context.filesDir, "android-sdk")
                    if (sdkDir.exists()) {
                        envMap["ANDROID_HOME"] = sdkDir.absolutePath
                        envMap["ANDROID_SDK_ROOT"] = sdkDir.absolutePath
                    }
                }

                val androidHome = envMap["ANDROID_HOME"] ?: System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT")
                if (androidHome != null) {
                    envMap["ANDROID_HOME"] = androidHome
                    envMap["ANDROID_SDK_ROOT"] = androidHome
                }

                val javaHomeVal = envMap["JAVA_HOME"] ?: ""
                val ldLibraryPathVal = envMap["LD_LIBRARY_PATH"] ?: ""
                val pathVal = envMap["PATH"] ?: (System.getenv("PATH") ?: "/system/bin")

                // Shell preamble with linker wrapper for Android W^X bypass
                val preamble = buildString {
                    append("export JAVA_HOME=\"$javaHomeVal\"\n")
                    append("export LD_LIBRARY_PATH=\"$ldLibraryPathVal\"\n")
                    append("export PATH=\"$pathVal\"\n")
                    append("""
                        _run_bin() {
                            local target="${'$'}1"
                            shift
                            local target_dir="${'$'}(dirname "${'$'}target")"
                            local jdk_root="${'$'}(dirname "${'$'}target_dir")"
                            local all_libs="${'$'}jdk_root/lib:${'$'}jdk_root/lib/server:${'$'}jdk_root/lib/jli:${'$'}target_dir:${'$'}LD_LIBRARY_PATH"
                            
                            if [ -x "/system/bin/linker64" ]; then
                                env LD_LIBRARY_PATH="${'$'}all_libs" /system/bin/linker64 "${'$'}target" "${'$'}@"
                            elif [ -x "/system/bin/linker" ]; then
                                env LD_LIBRARY_PATH="${'$'}all_libs" /system/bin/linker "${'$'}target" "${'$'}@"
                            else
                                env LD_LIBRARY_PATH="${'$'}all_libs" "${'$'}target" "${'$'}@"
                            fi
                        }
                        java() {
                            if [ -n "${'$'}JAVA_HOME" ] && [ -x "${'$'}JAVA_HOME/bin/run-java.sh" ]; then
                                /system/bin/sh "${'$'}JAVA_HOME/bin/run-java.sh" "${'$'}@"
                            elif [ -n "${'$'}JAVA_HOME" ] && [ -f "${'$'}JAVA_HOME/bin/java" ]; then
                                _run_bin "${'$'}JAVA_HOME/bin/java" "${'$'}@"
                            else
                                command java "${'$'}@" 2>/dev/null || _run_bin "${'$'}(which java 2>/dev/null)" "${'$'}@"
                            fi
                        }
                        javac() {
                            if [ -n "${'$'}JAVA_HOME" ] && [ -x "${'$'}JAVA_HOME/bin/run-javac.sh" ]; then
                                /system/bin/sh "${'$'}JAVA_HOME/bin/run-javac.sh" "${'$'}@"
                            elif [ -n "${'$'}JAVA_HOME" ] && [ -f "${'$'}JAVA_HOME/bin/javac" ]; then
                                _run_bin "${'$'}JAVA_HOME/bin/javac" "${'$'}@"
                            else
                                command javac "${'$'}@" 2>/dev/null || _run_bin "${'$'}(which javac 2>/dev/null)" "${'$'}@"
                            fi
                        }
                        jar() {
                            if [ -n "${'$'}JAVA_HOME" ] && [ -x "${'$'}JAVA_HOME/bin/run-jar.sh" ]; then
                                /system/bin/sh "${'$'}JAVA_HOME/bin/run-jar.sh" "${'$'}@"
                            elif [ -n "${'$'}JAVA_HOME" ] && [ -f "${'$'}JAVA_HOME/bin/jar" ]; then
                                _run_bin "${'$'}JAVA_HOME/bin/jar" "${'$'}@"
                            else
                                command jar "${'$'}@" 2>/dev/null || _run_bin "${'$'}(which jar 2>/dev/null)" "${'$'}@"
                            fi
                        }
                    """.trimIndent())
                    append("\n")
                }

                val commandScript = if (isDirectAppBinPath(trimmed)) {
                    val parts = trimmed.split(" ", limit = 2)
                    val binPath = parts[0]
                    val args = if (parts.size > 1) parts[1] else ""
                    """
                    $preamble
                    "$binPath" $args 2>/dev/null || _run_bin "$binPath" $args
                    """.trimIndent()
                } else {
                    """
                    $preamble
                    $trimmed
                    """.trimIndent()
                }

                val pb = ProcessBuilder("/system/bin/sh", "-c", commandScript)
                pb.directory(workingDir)
                pb.redirectErrorStream(false)

                val processEnv = pb.environment()
                processEnv.putAll(envMap)

                val process = pb.start()
                activeProcess = process

                // Coroutine to read stdout
                val outJob = launch {
                    val reader = BufferedReader(InputStreamReader(process.inputStream))
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        appendLine(line ?: "")
                    }
                }

                // Coroutine to read stderr
                val errJob = launch {
                    val errReader = BufferedReader(InputStreamReader(process.errorStream))
                    var errLine: String?
                    while (errReader.readLine().also { errLine = it } != null) {
                        appendLine(errLine ?: "", isError = true)
                    }
                }

                outJob.join()
                errJob.join()

                val exitCode = process.waitFor()
                appendLine("[Process completed with exit code $exitCode]")
            } catch (e: Exception) {
                appendLine("Terminal execution error: ${e.localizedMessage}", isError = true)
            } finally {
                activeProcess = null
                _isRunning.value = false
            }
        }
    }

    fun stop() {
        activeProcess?.destroy()
        executionJob?.cancel()
        activeProcess = null
        _isRunning.value = false
        appendLine("[Process stopped by user]", isError = true)
    }
}
