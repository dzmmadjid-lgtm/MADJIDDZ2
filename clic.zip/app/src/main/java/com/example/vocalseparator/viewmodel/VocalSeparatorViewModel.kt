package com.example.vocalseparator.viewmodel

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.vocalseparator.audio.AiModelManager
import com.example.vocalseparator.audio.AudioDecoder
import com.example.vocalseparator.audio.StudioMultiTrackPlayer
import com.example.vocalseparator.data.AppDatabase
import com.example.vocalseparator.data.AudioRepository
import com.example.vocalseparator.data.SeparationRecord
import com.example.vocalseparator.model.SeparationUiState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class VocalSeparatorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AudioRepository(
        application,
        AppDatabase.getInstance(application)
    )

    val player = StudioMultiTrackPlayer(application, viewModelScope)
    val modelManager = AiModelManager(application)

    private val _selectedAudioUri = MutableStateFlow<Uri?>(null)
    val selectedAudioUri: StateFlow<Uri?> = _selectedAudioUri.asStateFlow()

    private val _selectedMetadata = MutableStateFlow<AudioDecoder.AudioMetadata?>(null)
    val selectedMetadata: StateFlow<AudioDecoder.AudioMetadata?> = _selectedMetadata.asStateFlow()

    private val _separationState = MutableStateFlow<SeparationUiState>(SeparationUiState.Idle)
    val separationState: StateFlow<SeparationUiState> = _separationState.asStateFlow()

    private val _currentRecord = MutableStateFlow<SeparationRecord?>(null)
    val currentRecord: StateFlow<SeparationRecord?> = _currentRecord.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    val historyList: StateFlow<List<SeparationRecord>> = repository.getSeparations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val playerPlaybackState: StateFlow<StudioMultiTrackPlayer.PlayerPlaybackState> = player.playbackState

    private var separationJob: Job? = null

    fun selectAudio(uri: Uri) {
        _selectedAudioUri.value = uri
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val meta = repository.extractMetadata(uri)
                _selectedMetadata.value = meta
            } catch (e: Exception) {
                Log.e(TAG, "Error inspecting selected audio file", e)
                _toastMessage.value = "تعذر قراءة بيانات الملف: ${e.localizedMessage}"
            }
        }
    }

    fun startSeparation() {
        val uri = _selectedAudioUri.value ?: return
        separationJob?.cancel()

        separationJob = viewModelScope.launch {
            try {
                _separationState.value = SeparationUiState.Processing(
                    progress = com.example.vocalseparator.audio.SourceSeparationEngine.SeparationProgress(
                        stage = com.example.vocalseparator.audio.SourceSeparationEngine.Stage.INITIALIZING,
                        progressPercent = 0,
                        elapsedSeconds = 0,
                        estimatedRemainingSeconds = 0,
                        currentChunk = 0,
                        totalChunks = 0
                    )
                )

                val record = repository.separateAudio(uri) { progress ->
                    _separationState.value = SeparationUiState.Processing(progress)
                }

                _separationState.value = SeparationUiState.Success(record)
                loadRecordIntoStudio(record)
                _toastMessage.value = "تم فصل الصوت والموسيقى بنجاح!"
            } catch (e: CancellationException) {
                _separationState.value = SeparationUiState.Idle
                _toastMessage.value = "تم إلغاء عملية الفصل."
            } catch (e: Exception) {
                Log.e(TAG, "Separation failure", e)
                _separationState.value = SeparationUiState.Error(
                    e.localizedMessage ?: "حدث خطأ غير متوقع أثناء معالجة الصوت."
                )
            }
        }
    }

    fun cancelSeparation() {
        separationJob?.cancel()
        separationJob = null
        _separationState.value = SeparationUiState.Idle
    }

    fun loadRecordIntoStudio(record: SeparationRecord) {
        _currentRecord.value = record
        val origFile = File(record.originalFilePath)
        val vocFile = File(record.vocalsFilePath)
        val instFile = File(record.instrumentalFilePath)

        if (origFile.exists() && vocFile.exists() && instFile.exists()) {
            player.loadTracks(origFile, vocFile, instFile, record.durationMs)
        } else {
            _toastMessage.value = "ملفات الصوت المحفوظة لم تعد موجودة على الجهاز."
        }
    }

    fun exportTrack(isVocals: Boolean) {
        val record = _currentRecord.value ?: return
        viewModelScope.launch {
            try {
                val targetFile = if (isVocals) File(record.vocalsFilePath) else File(record.instrumentalFilePath)
                val suffix = if (isVocals) "Vocals_الصوت_البشري" else "Instrumental_الموسيقى"
                val cleanTitle = "${record.title}_$suffix"

                val uri = repository.exportTrackToMusicFolder(targetFile, cleanTitle)
                if (uri != null) {
                    _toastMessage.value = "تم حفظ المسار في مجلد Music/VocalRemoverAI بنجاح!"
                } else {
                    _toastMessage.value = "تعذر تصدير الملف إلى ذاكرة الهاتف."
                }
            } catch (e: Exception) {
                Log.e(TAG, "Export error", e)
                _toastMessage.value = "فشل التصدير: ${e.localizedMessage}"
            }
        }
    }

    fun deleteRecord(record: SeparationRecord) {
        viewModelScope.launch {
            try {
                if (_currentRecord.value?.id == record.id) {
                    player.release()
                    _currentRecord.value = null
                }
                repository.deleteSeparation(record)
                _toastMessage.value = "تم حذف المشروع بنجاح."
            } catch (e: Exception) {
                Log.e(TAG, "Delete error", e)
            }
        }
    }

    fun clearToastMessage() {
        _toastMessage.value = null
    }

    fun clearError() {
        _separationState.value = SeparationUiState.Idle
    }

    override fun onCleared() {
        super.onCleared()
        player.release()
    }

    companion object {
        private const val TAG = "VocalSeparatorVM"
    }
}
