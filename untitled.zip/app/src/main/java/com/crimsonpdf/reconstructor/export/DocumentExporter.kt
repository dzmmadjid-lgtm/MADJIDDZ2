package com.crimsonpdf.reconstructor.export

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.crimsonpdf.reconstructor.model.ProcessingMode
import com.crimsonpdf.reconstructor.model.ReconstructedPage
import com.crimsonpdf.reconstructor.rendering.DocumentPageRenderer
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import kotlin.math.roundToInt

enum class ExportFormat { PDF, PNG, JPG }

data class ExportResult(
    val filename: String,
    val sizeKb: Long,
    val dimensionsLabel: String,
    val cacheFile: File,
    val mimeType: String
)

object DocumentExporter {

    fun exportDocument(
        context: Context,
        pages: List<ReconstructedPage>,
        format: ExportFormat,
        dpi: Int = 300,
        jpgQuality: Int = 95,
        processingMode: ProcessingMode = ProcessingMode.MODE_A_CLEAN_RECONSTRUCTION,
        prefix: String = "CrimsonPDF_Doc"
    ): ExportResult {
        require(pages.isNotEmpty()) { "لا توجد صفحات جاهزة للتصدير" }

        val widthPx = (8.27f * dpi).roundToInt()
        val heightPx = (11.69f * dpi).roundToInt()
        val dimensionsLabel = "$widthPx × $heightPx px ($dpi DPI)"
        val modeTag = if (processingMode == ProcessingMode.MODE_A_CLEAN_RECONSTRUCTION) "reconstructed" else "cleaned"
        val timestamp = System.currentTimeMillis() % 100000

        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }

        return when (format) {
            ExportFormat.PDF -> {
                val filename = "${prefix}_${modeTag}_${dpi}dpi_$timestamp.pdf"
                val outFile = File(exportsDir, filename)

                val pdfDoc = PdfDocument()
                pages.forEachIndexed { index, page ->
                    val pageInfo = PdfDocument.PageInfo.Builder(widthPx, heightPx, index + 1).create()
                    val pdfPage = pdfDoc.startPage(pageInfo)

                    if (processingMode == ProcessingMode.MODE_B_IMAGE_CLEANING) {
                        val scaled = Bitmap.createScaledBitmap(page.cleanedModeBBitmap, widthPx, heightPx, true)
                        pdfPage.canvas.drawBitmap(scaled, 0f, 0f, null)
                    } else {
                        DocumentPageRenderer.renderToCanvas(
                            canvas = pdfPage.canvas,
                            widthPx = widthPx,
                            heightPx = heightPx,
                            objects = page.objects,
                            highlightLowConfidence = false,
                            showBoundingBoxes = false
                        )
                    }
                    pdfDoc.finishPage(pdfPage)
                }

                FileOutputStream(outFile).use { out ->
                    pdfDoc.writeTo(out)
                }
                pdfDoc.close()

                saveToPublicDownloads(context, outFile, filename, "application/pdf")

                ExportResult(
                    filename = filename,
                    sizeKb = (outFile.length() / 1024L).coerceAtLeast(1L),
                    dimensionsLabel = dimensionsLabel,
                    cacheFile = outFile,
                    mimeType = "application/pdf"
                )
            }

            ExportFormat.PNG, ExportFormat.JPG -> {
                val isPng = format == ExportFormat.PNG
                val ext = if (isPng) "png" else "jpg"
                val mime = if (isPng) "image/png" else "image/jpeg"
                val filename = "${prefix}_${modeTag}_${dpi}dpi_$timestamp.$ext"
                val outFile = File(exportsDir, filename)

                val firstPage = pages.first()
                val bitmap = if (processingMode == ProcessingMode.MODE_B_IMAGE_CLEANING) {
                    Bitmap.createScaledBitmap(firstPage.cleanedModeBBitmap, widthPx, heightPx, true)
                } else {
                    DocumentPageRenderer.renderToBitmap(
                        objects = firstPage.objects,
                        widthPx = widthPx,
                        heightPx = heightPx,
                        highlightLowConfidence = false,
                        showBoundingBoxes = false
                    )
                }

                FileOutputStream(outFile).use { out ->
                    bitmap.compress(
                        if (isPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,
                        if (isPng) 100 else jpgQuality,
                        out
                    )
                }

                saveToPublicDownloads(context, outFile, filename, mime)

                ExportResult(
                    filename = filename,
                    sizeKb = (outFile.length() / 1024L).coerceAtLeast(1L),
                    dimensionsLabel = dimensionsLabel,
                    cacheFile = outFile,
                    mimeType = mime
                )
            }
        }
    }

    private fun saveToPublicDownloads(
        context: Context,
        sourceFile: File,
        filename: String,
        mimeType: String
    ) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/CrimsonPDF")
                }
                val uri: Uri? = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { outStream: OutputStream ->
                        sourceFile.inputStream().use { inStream ->
                            inStream.copyTo(outStream)
                        }
                    }
                }
            }
        } catch (_: Throwable) {
            // Kept in cacheFile for FileProvider share/open
        }
    }

    fun shareOrOpenExportedFile(context: Context, result: ExportResult, share: Boolean = true) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                result.cacheFile
            )
            val intent = if (share) {
                Intent(Intent.ACTION_SEND).apply {
                    type = result.mimeType
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } else {
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, result.mimeType)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            context.startActivity(Intent.createChooser(intent, "فتح أو مشاركة المستند"))
        } catch (_: Throwable) {
        }
    }
}
