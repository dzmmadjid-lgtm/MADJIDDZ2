import {
  LayoutObjectType,
  PageLayoutObject,
  TableCellModel,
  TextAlignment,
  TextDirection,
  createDefaultBorder,
} from '../models/DocumentModel';
import { loadImageElement } from './ImagePreprocessor';

export interface AnalysisResult {
  objects: PageLayoutObject[];
  engineUsed: 'ON_DEVICE_STRUCTURAL' | 'HYBRID_VISION_LAYOUT';
  margins: { top: number; right: number; bottom: number; left: number };
  noticeAr?: string;
}

/**
 * On-device pixel & projection profile layout analyzer for custom uploaded document images
 * when running in 100% offline mode.
 */
export async function analyzeUploadedImageOnDevice(
  preprocessedDataUrl: string
): Promise<PageLayoutObject[]> {
  const img = await loadImageElement(preprocessedDataUrl);
  const w = 1000;
  const h = Math.round(1000 * (img.height / (img.width || 1)));

  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) return [];

  ctx.drawImage(img, 0, 0, w, h);
  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // Horizontal projection profile to locate horizontal bands (text lines, headings, tables, dividers)
  const rowDarkCounts = new Int32Array(h);
  for (let y = 0; y < h; y++) {
    let darkPixels = 0;
    for (let x = 35; x < w - 35; x++) {
      const idx = (y * w + x) * 4;
      const luma = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
      if (luma < 175) darkPixels++;
    }
    rowDarkCounts[y] = darkPixels;
  }

  // Group contiguous active rows into horizontal bands
  interface Band {
    yStart: number;
    yEnd: number;
    maxDensity: number;
    avgDensity: number;
    minX: number;
    maxX: number;
  }
  const bands: Band[] = [];
  let inBand = false;
  let bandStart = 0;

  for (let y = 25; y < h - 25; y++) {
    const active = rowDarkCounts[y] > 12;
    if (active && !inBand) {
      inBand = true;
      bandStart = y;
    } else if (!active && inBand) {
      // Allow small gaps up to 8px inside paragraphs/tables
      let lookaheadActive = false;
      for (let k = 1; k <= 8 && y + k < h - 25; k++) {
        if (rowDarkCounts[y + k] > 12) {
          lookaheadActive = true;
          break;
        }
      }
      if (!lookaheadActive) {
        inBand = false;
        const yEnd = y;
        if (yEnd - bandStart >= 4) {
          let minX = w;
          let maxX = 0;
          let sumD = 0;
          let maxD = 0;
          for (let by = bandStart; by <= yEnd; by++) {
            sumD += rowDarkCounts[by];
            if (rowDarkCounts[by] > maxD) maxD = rowDarkCounts[by];
            for (let bx = 30; bx < w - 30; bx += 2) {
              const idx = (by * w + bx) * 4;
              const luma = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
              if (luma < 175) {
                if (bx < minX) minX = bx;
                if (bx > maxX) maxX = bx;
              }
            }
          }
          if (maxX > minX + 20) {
            bands.push({
              yStart: bandStart,
              yEnd,
              maxDensity: maxD,
              avgDensity: sumD / (yEnd - bandStart + 1),
              minX,
              maxX,
            });
          }
        }
      }
    }
  }

  const normY = (val: number) => Math.round((val / h) * 1000);
  const objects: PageLayoutObject[] = [];

  bands.slice(0, 14).forEach((band, idx) => {
    const bx = Math.max(40, band.minX);
    const bw = Math.min(920, band.maxX - band.minX);
    const by = normY(band.yStart);
    const bh = Math.max(18, normY(band.yEnd - band.yStart));

    // Crop region from source image for inspection/preservation
    const cropCanvas = document.createElement('canvas');
    const cw = Math.max(20, band.maxX - band.minX);
    const ch = Math.max(10, band.yEnd - band.yStart);
    cropCanvas.width = cw;
    cropCanvas.height = ch;
    const cctx = cropCanvas.getContext('2d');
    cctx?.drawImage(canvas, band.minX, band.yStart, cw, ch, 0, 0, cw, ch);

    if (bh <= 12 && bw > 450) {
      objects.push({
        id: `det_line_${idx}`,
        type: 'LINE',
        x: bx,
        y: by,
        width: bw,
        height: 4,
        content: '',
        confidence: 0.96,
        uncertainTokens: [],
        alignment: 'center',
        direction: 'rtl',
        fontProperties: {
          family: 'Cairo',
          sizePt: 11,
          weight: 'normal',
          role: 'normal',
          color: '#0F172A',
          lineHeight: 1.2,
        },
        borderProperties: createDefaultBorder(1.5, 'solid', '#0F172A'),
        backgroundProperties: { fill: 'transparent', opacity: 1 },
        zOrder: idx + 1,
      });
    } else if (bh > 130 && band.maxDensity > bw * 0.55) {
      // High horizontal line density indicates a structured table region
      objects.push({
        id: `det_table_${idx}`,
        type: 'TABLE',
        x: bx,
        y: by,
        width: bw,
        height: bh,
        content: '',
        confidence: 0.74,
        uncertainTokens: ['[جدول مكتشف بانتظار المراجعة النصية]'],
        alignment: 'right',
        direction: 'rtl',
        fontProperties: {
          family: 'Cairo',
          sizePt: 11,
          weight: 'normal',
          role: 'table',
          color: '#0F172A',
          lineHeight: 1.4,
        },
        borderProperties: createDefaultBorder(1.5, 'solid', '#0F172A'),
        backgroundProperties: { fill: 'transparent', opacity: 1 },
        zOrder: idx + 1,
        tableStructure: {
          rows: 3,
          cols: 3,
          rowHeights: [0.34, 0.33, 0.33],
          colWidths: [0.34, 0.33, 0.33],
          direction: 'rtl',
          cells: [
            {
              id: `c_${idx}_0_0`,
              row: 0,
              col: 0,
              rowSpan: 1,
              colSpan: 1,
              content: 'عمود ١',
              confidence: 0.74,
              alignment: 'center',
              verticalAlignment: 'middle',
              direction: 'rtl',
              padding: 6,
              fontSizePt: 11,
              fontWeight: 'bold',
              borders: createDefaultBorder(1, 'solid', '#0F172A'),
              backgroundColor: '#F1F5F9',
            },
            {
              id: `c_${idx}_0_1`,
              row: 0,
              col: 1,
              rowSpan: 1,
              colSpan: 1,
              content: 'عمود ٢',
              confidence: 0.74,
              alignment: 'center',
              verticalAlignment: 'middle',
              direction: 'rtl',
              padding: 6,
              fontSizePt: 11,
              fontWeight: 'bold',
              borders: createDefaultBorder(1, 'solid', '#0F172A'),
              backgroundColor: '#F1F5F9',
            },
            {
              id: `c_${idx}_0_2`,
              row: 0,
              col: 2,
              rowSpan: 1,
              colSpan: 1,
              content: 'عمود ٣',
              confidence: 0.74,
              alignment: 'center',
              verticalAlignment: 'middle',
              direction: 'rtl',
              padding: 6,
              fontSizePt: 11,
              fontWeight: 'bold',
              borders: createDefaultBorder(1, 'solid', '#0F172A'),
              backgroundColor: '#F1F5F9',
            },
            ...[1, 2].flatMap((r) =>
              [0, 1, 2].map((c) => ({
                id: `c_${idx}_${r}_${c}`,
                row: r,
                col: c,
                rowSpan: 1,
                colSpan: 1,
                content: `[خلية ${r}-${c + 1} — انقر للتعديل]`,
                confidence: 0.65,
                alignment: 'right' as TextAlignment,
                verticalAlignment: 'middle' as const,
                direction: 'rtl' as TextDirection,
                padding: 6,
                fontSizePt: 10.5,
                fontWeight: 'normal' as const,
                borders: createDefaultBorder(1, 'solid', '#0F172A'),
                backgroundColor: 'transparent',
              }))
            ),
          ],
        },
      });
    } else {
      const isHeading = idx === 0 || (bh < 55 && bw < 680);
      objects.push({
        id: `det_block_${idx}`,
        type: isHeading ? 'TEXT' : 'PARAGRAPH',
        x: bx,
        y: by,
        width: bw,
        height: bh,
        content: `[منطقة نصية مكتشفة #${idx + 1} — الوضع المحلي دون اتصال: راجع النص أو فعّل محرك الرؤية]`,
        confidence: 0.62,
        uncertainTokens: [`#${idx + 1}`],
        alignment: bx > 180 && bx + bw < 820 ? 'center' : 'right',
        direction: 'rtl',
        fontProperties: {
          family: isHeading ? 'Cairo' : 'Amiri',
          sizePt: isHeading ? 15 : 12,
          weight: isHeading ? 'bold' : 'normal',
          role: isHeading ? 'title' : 'normal',
          color: '#0F172A',
          lineHeight: 1.55,
        },
        borderProperties: createDefaultBorder(0),
        backgroundProperties: { fill: 'transparent', opacity: 1 },
        zOrder: idx + 1,
        croppedImageDataUrl: cropCanvas.toDataURL('image/png'),
      });
    }
  });

  return objects;
}

/**
 * Calls the modular server-side Vision Layout & Arabic OCR Engine (/api/reconstruct-document)
 * and maps the structured coordinate layout response into PageLayoutObject[].
 */
export async function analyzeDocumentWithVisionEngine(
  preprocessedDataUrl: string,
  fallbackObjects?: PageLayoutObject[]
): Promise<AnalysisResult> {
  try {
    const response = await fetch('/api/reconstruct-document', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        imageBase64: preprocessedDataUrl,
        mimeType: 'image/png',
      }),
    });

    if (!response.ok) {
      if (fallbackObjects && fallbackObjects.length > 0) {
        return {
          objects: fallbackObjects,
          engineUsed: 'ON_DEVICE_STRUCTURAL',
          margins: { top: 55, right: 60, bottom: 55, left: 60 },
        };
      }
      const onDeviceObjs = await analyzeUploadedImageOnDevice(preprocessedDataUrl);
      return {
        objects: onDeviceObjs,
        engineUsed: 'ON_DEVICE_STRUCTURAL',
        margins: { top: 55, right: 60, bottom: 55, left: 60 },
        noticeAr: 'تم استخدام محرك التحليل الهيكلي المحلي (Offline-First) لعدم توفر اتصال بخدمة الرؤية السحابية.',
      };
    }

    const result = await response.json();
    const rawObjects = result?.data?.objects;
    if (!Array.isArray(rawObjects) || rawObjects.length === 0) {
      if (fallbackObjects && fallbackObjects.length > 0) {
        return {
          objects: fallbackObjects,
          engineUsed: 'ON_DEVICE_STRUCTURAL',
          margins: { top: 55, right: 60, bottom: 55, left: 60 },
        };
      }
      const onDeviceObjs = await analyzeUploadedImageOnDevice(preprocessedDataUrl);
      return {
        objects: onDeviceObjs,
        engineUsed: 'ON_DEVICE_STRUCTURAL',
        margins: { top: 55, right: 60, bottom: 55, left: 60 },
      };
    }

    const mappedObjects: PageLayoutObject[] = rawObjects.map((raw: any, index: number) => {
      const type = ([
        'TEXT',
        'PARAGRAPH',
        'TABLE',
        'LINE',
        'RECTANGLE',
        'CHECKBOX',
        'SIGNATURE_AREA',
        'IMAGE',
      ].includes(raw.type)
        ? raw.type
        : 'PARAGRAPH') as LayoutObjectType;

      const direction: TextDirection = raw.direction === 'ltr' ? 'ltr' : 'rtl';
      const alignment: TextAlignment = ['right', 'center', 'left', 'justify'].includes(raw.alignment)
        ? raw.alignment
        : direction === 'rtl'
        ? 'right'
        : 'left';

      const bWidth = raw.borderThickness || (raw.hasBorderTop || raw.hasBorderBottom ? 1.5 : 0);
      const borderProperties = {
        top: {
          width: raw.hasBorderTop ? bWidth : 0,
          style: (raw.hasBorderTop ? 'solid' : 'none') as 'solid' | 'none',
          color: '#0F172A',
        },
        right: {
          width: raw.hasBorderRight ? bWidth : 0,
          style: (raw.hasBorderRight ? 'solid' : 'none') as 'solid' | 'none',
          color: '#0F172A',
        },
        bottom: {
          width: raw.hasBorderBottom ? bWidth : 0,
          style: (raw.hasBorderBottom ? 'solid' : 'none') as 'solid' | 'none',
          color: '#0F172A',
        },
        left: {
          width: raw.hasBorderLeft ? bWidth : 0,
          style: (raw.hasBorderLeft ? 'solid' : 'none') as 'solid' | 'none',
          color: '#0F172A',
        },
      };

      let tableStructure = undefined;
      if (type === 'TABLE' && raw.tableData) {
        const rows = Math.max(1, raw.tableData.rows || 2);
        const cols = Math.max(1, raw.tableData.cols || 2);
        const rowHeights =
          Array.isArray(raw.tableData.rowHeights) && raw.tableData.rowHeights.length === rows
            ? raw.tableData.rowHeights
            : Array(rows).fill(1 / rows);
        const colWidths =
          Array.isArray(raw.tableData.colWidths) && raw.tableData.colWidths.length === cols
            ? raw.tableData.colWidths
            : Array(cols).fill(1 / cols);

        const cells: TableCellModel[] = (raw.tableData.cells || []).map((c: any, ci: number) => ({
          id: `vcell_${index}_${ci}`,
          row: c.row ?? 0,
          col: c.col ?? 0,
          rowSpan: c.rowSpan ?? 1,
          colSpan: c.colSpan ?? 1,
          content: c.content ?? '',
          confidence: c.confidence ?? 0.92,
          alignment: c.alignment === 'center' ? 'center' : c.alignment === 'left' ? 'left' : 'right',
          verticalAlignment: 'middle',
          direction: c.direction === 'ltr' ? 'ltr' : 'rtl',
          padding: 6,
          fontSizePt: raw.estimatedFontSizePt || 11,
          fontWeight: c.isHeader ? 'bold' : 'normal',
          borders: {
            top: { width: c.hasTopBorder !== false ? 1 : 0, style: c.hasTopBorder !== false ? 'solid' : 'none', color: '#0F172A' },
            right: { width: c.hasRightBorder !== false ? 1 : 0, style: c.hasRightBorder !== false ? 'solid' : 'none', color: '#0F172A' },
            bottom: { width: c.hasBottomBorder !== false ? 1 : 0, style: c.hasBottomBorder !== false ? 'solid' : 'none', color: '#0F172A' },
            left: { width: c.hasLeftBorder !== false ? 1 : 0, style: c.hasLeftBorder !== false ? 'solid' : 'none', color: '#0F172A' },
          },
          backgroundColor: c.isHeader ? '#F1F5F9' : 'transparent',
        }));

        tableStructure = {
          rows,
          cols,
          rowHeights,
          colWidths,
          direction,
          cells,
        };
      }

      return {
        id: raw.id || `obj_${index + 1}`,
        type,
        x: Math.max(10, Math.min(960, raw.x ?? 60)),
        y: Math.max(10, Math.min(960, raw.y ?? 60 + index * 70)),
        width: Math.max(25, Math.min(940, raw.width ?? 860)),
        height: Math.max(12, Math.min(900, raw.height ?? 65)),
        content: raw.content ?? '',
        confidence: raw.confidence ?? 0.92,
        uncertainTokens: Array.isArray(raw.uncertainTokens) ? raw.uncertainTokens : [],
        alignment,
        direction,
        fontProperties: {
          family: raw.fontRole === 'title' || raw.fontRole === 'normal' ? 'Amiri' : 'Cairo',
          sizePt: raw.estimatedFontSizePt || (raw.fontRole === 'title' ? 17 : 12),
          weight: raw.fontWeight === 'bold' || raw.fontRole === 'title' ? 'bold' : 'normal',
          role: raw.fontRole || 'normal',
          color: '#0F172A',
          lineHeight: 1.55,
        },
        borderProperties,
        backgroundProperties: {
          fill: raw.backgroundColor || 'transparent',
          opacity: 1,
        },
        zOrder: index + 1,
        checked: Boolean(raw.checked),
        tableStructure,
      };
    });

    return {
      objects: mappedObjects,
      engineUsed: 'HYBRID_VISION_LAYOUT',
      margins: result?.data?.estimatedMargins || { top: 55, right: 60, bottom: 55, left: 60 },
    };
  } catch {
    if (fallbackObjects && fallbackObjects.length > 0) {
      return {
        objects: fallbackObjects,
        engineUsed: 'ON_DEVICE_STRUCTURAL',
        margins: { top: 55, right: 60, bottom: 55, left: 60 },
      };
    }
    const onDeviceObjs = await analyzeUploadedImageOnDevice(preprocessedDataUrl);
    return {
      objects: onDeviceObjs,
      engineUsed: 'ON_DEVICE_STRUCTURAL',
      margins: { top: 55, right: 60, bottom: 55, left: 60 },
    };
  }
}
