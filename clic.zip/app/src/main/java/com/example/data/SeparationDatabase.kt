package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [SeparationEntity::class], version = 1, exportSchema = false)
abstract class SeparationDatabase : RoomDatabase() {
    abstract fun separationDao(): SeparationDao

    companion object {
        @Volatile
        private var INSTANCE: SeparationDatabase? = null

        fun getDatabase(context: Context): SeparationDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SeparationDatabase::class.java,
                    "separation_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
