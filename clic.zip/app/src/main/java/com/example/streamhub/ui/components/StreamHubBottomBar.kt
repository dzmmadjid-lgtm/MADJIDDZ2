package com.example.streamhub.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.streamhub.model.NavigationDestination
import com.example.streamhub.theme.StreamTheme

@Composable
fun StreamHubBottomBar(
    currentDestination: NavigationDestination,
    onSelectDestination: (NavigationDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StreamTheme.colors

    // حل مشكلة تداخل أزرار الهاتف السفلية بشكل جذري:
    // نطبق navigationBarsPadding() هنا بحيث ترتفع شريط الأزرار فوق أزرار نظام أندرويد تماماً دون أي تداخل!
    Surface(
        color = colors.navBarBackground,
        shadowElevation = if (colors.isOled) 0.dp else 16.dp,
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = colors.cardBorder.copy(alpha = 0.6f),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            )
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding() // ضمان عدم تداخل أزرار النظام (رجوع / رئيسية / تطبيقات)
                .padding(vertical = 6.dp, horizontal = 12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomNavItem(
                    label = "الرئيسية",
                    selectedIcon = Icons.Filled.Home,
                    unselectedIcon = Icons.Outlined.Home,
                    isSelected = currentDestination == NavigationDestination.HOME,
                    testTag = "nav_home",
                    onClick = { onSelectDestination(NavigationDestination.HOME) }
                )

                BottomNavItem(
                    label = "استكشف",
                    selectedIcon = Icons.Filled.Search,
                    unselectedIcon = Icons.Outlined.Search,
                    isSelected = currentDestination == NavigationDestination.SEARCH,
                    testTag = "nav_search",
                    onClick = { onSelectDestination(NavigationDestination.SEARCH) }
                )

                BottomNavItem(
                    label = "مكتبتي",
                    selectedIcon = Icons.Filled.VideoLibrary,
                    unselectedIcon = Icons.Outlined.VideoLibrary,
                    isSelected = currentDestination == NavigationDestination.LIBRARY,
                    testTag = "nav_library",
                    onClick = { onSelectDestination(NavigationDestination.LIBRARY) }
                )

                BottomNavItem(
                    label = "حسابي",
                    selectedIcon = Icons.Filled.Person,
                    unselectedIcon = Icons.Outlined.Person,
                    isSelected = currentDestination == NavigationDestination.PROFILE,
                    testTag = "nav_profile",
                    onClick = { onSelectDestination(NavigationDestination.PROFILE) }
                )
            }
        }
    }
}

@Composable
private fun BottomNavItem(
    label: String,
    selectedIcon: ImageVector,
    unselectedIcon: ImageVector,
    isSelected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    val colors = StreamTheme.colors
    val interactionSource = remember { MutableInteractionSource() }

    val iconColor by animateColorAsState(
        targetValue = if (isSelected) colors.primaryAccent else colors.textMuted,
        animationSpec = spring(),
        label = "iconColor"
    )

    val backgroundColor by animateColorAsState(
        targetValue = if (isSelected) {
            if (colors.isOled) colors.primaryAccent.copy(alpha = 0.18f) else colors.primaryAccent.copy(alpha = 0.12f)
        } else {
            Color.Transparent
        },
        animationSpec = spring(),
        label = "bgColor"
    )

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundColor)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (isSelected) selectedIcon else unselectedIcon,
                contentDescription = label,
                tint = iconColor,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = iconColor,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}
