package com.example.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * High-performance Radix-2 Cooley-Tukey Fast Fourier Transform (FFT) and Inverse FFT (IFFT).
 * Optimized for power-of-two frame sizes (e.g. 4096 for audio source separation).
 */
class FastFourierTransform(val n: Int) {
    init {
        require(n > 0 && (n and (n - 1)) == 0) { "FFT size must be a power of 2, got: $n" }
    }

    private val bitRev = IntArray(n)
    private val cosTable = FloatArray(n / 2)
    private val sinTable = FloatArray(n / 2)

    init {
        // Precompute bit reversal permutation
        var j = 0
        for (i in 0 until n) {
            bitRev[i] = j
            var bit = n shr 1
            while (bit > 0 && (j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j or bit
        }

        // Precompute twiddle factors: exp(-2 * pi * i * k / n)
        val angleStep = (-2.0 * PI / n).toFloat()
        for (k in 0 until n / 2) {
            val angle = angleStep * k
            cosTable[k] = cos(angle)
            sinTable[k] = sin(angle)
        }
    }

    /**
     * In-place forward FFT: transforms real and imaginary parts into frequency domain.
     */
    fun fft(real: FloatArray, imag: FloatArray) {
        require(real.size >= n && imag.size >= n) { "Array size must be at least $n" }

        // Bit-reversal permutation
        for (i in 0 until n) {
            val rev = bitRev[i]
            if (i < rev) {
                val tr = real[i]
                real[i] = real[rev]
                real[rev] = tr

                val ti = imag[i]
                imag[i] = imag[rev]
                imag[rev] = ti
            }
        }

        // Cooley-Tukey decimation-in-time
        var len = 2
        while (len <= n) {
            val halfLen = len shr 1
            val step = n / len

            var k = 0
            while (k < n) {
                var tableIdx = 0
                for (m in 0 until halfLen) {
                    val c = cosTable[tableIdx]
                    val s = sinTable[tableIdx]
                    tableIdx += step

                    val uIdx = k + m
                    val vIdx = k + m + halfLen

                    val vr = real[vIdx]
                    val vi = imag[vIdx]

                    // Twiddle factor multiplication: (c + i*s) * (vr + i*vi)
                    val tr = c * vr - s * vi
                    val ti = c * vi + s * vr

                    val ur = real[uIdx]
                    val ui = imag[uIdx]

                    real[uIdx] = ur + tr
                    imag[uIdx] = ui + ti
                    real[vIdx] = ur - tr
                    imag[vIdx] = ui - ti
                }
                k += len
            }
            len = len shl 1
        }
    }

    /**
     * In-place inverse FFT (IFFT): transforms frequency domain back to time domain.
     */
    fun ifft(real: FloatArray, imag: FloatArray) {
        require(real.size >= n && imag.size >= n) { "Array size must be at least $n" }

        // Conjugate imaginary part
        for (i in 0 until n) {
            imag[i] = -imag[i]
        }

        // Forward FFT
        fft(real, imag)

        // Conjugate imaginary part and scale by 1/n
        val invN = 1.0f / n
        for (i in 0 until n) {
            real[i] *= invN
            imag[i] = -imag[i] * invN
        }
    }
}
