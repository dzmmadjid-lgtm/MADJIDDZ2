package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// PDF Red Identity Colors
val PdfRedPrimary = Color(0xFFD32F2F)
val PdfRedDark = Color(0xFFB71C1C)
val PdfRedLight = Color(0xFFFFEBEE)
val PdfRedHover = Color(0xFFEF5350)
val PdfRedContainer = Color(0xFFFFDAD6)
val PdfOnRedContainer = Color(0xFF410002)

// Region Type Highlighting Colors
val RegionTitleColor = Color(0xFFE65100) // Deep Orange
val RegionParagraphColor = Color(0xFF1976D2) // Blue
val RegionListColor = Color(0xFF388E3C) // Green
val RegionNumberColor = Color(0xFF7B1FA2) // Purple
val RegionTableCellColor = Color(0xFF0097A7) // Cyan
val RegionGraphicColor = Color(0xFF757575) // Gray

// Light Palette
val LightBg = Color(0xFFF9F9FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceSubtle = Color(0xFFF0F1F5)
val LightBorder = Color(0xFFE2E4E9)
val LightTextPrimary = Color(0xFF1B1B1F)
val LightTextSecondary = Color(0xFF6A6D78)

// Dark Palette
val DarkBg = Color(0xFF121214)
val DarkSurface = Color(0xFF1A1A1E)
val DarkSurfaceSubtle = Color(0xFF24242A)
val DarkBorder = Color(0xFF2E2E36)
val DarkTextPrimary = Color(0xFFF1F1F5)
val DarkTextSecondary = Color(0xFFA1A3AE)
