package com.medad.studio.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material.icons.outlined.Tonality
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.medad.studio.pdf.PdfEngine
import com.medad.studio.print.WifiPrint
import com.medad.studio.ui.components.GhostButton
import com.medad.studio.ui.components.GoldButton
import com.medad.studio.ui.components.GoldChip
import com.medad.studio.ui.theme.LocalPalette

@Composable
fun ReaderScreen(
    onBack: () -> Unit,
    incomingUri: Uri? = null,
) {
    val p = LocalPalette.current
    val context = LocalContext.current

    var uri by remember { mutableStateOf(incomingUri) }
    var pageCount by remember { mutableIntStateOf(0) }
    var pageIndex by remember { mutableIntStateOf(0) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var invert by remember { mutableStateOf(p.oled) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    picked,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            } catch (_: Exception) {
            }
            uri = picked
            pageIndex = 0
            scale = 1f
            offsetX = 0f
            offsetY = 0f
        }
    }

    LaunchedEffect(uri, pageIndex, invert) {
        val current = uri ?: return@LaunchedEffect
        loading = true
        error = null
        try {
            pageCount = PdfEngine.pageCount(context, current)
            preview = PdfEngine.renderPage(context, current, pageIndex, nightInvert = invert).bitmap
        } catch (e: Exception) {
            error = e.message ?: "تعذر عرض المستند"
        } finally {
            loading = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(p.canvas),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, "رجوع", tint = p.ink)
            }
            Column(Modifier.weight(1f)) {
                Text("القارئ", color = p.ink, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Text(
                    if (uri == null) "لم يُفتح مستند بعد" else "صفحة ${pageIndex + 1} من $pageCount",
                    color = p.muted,
                    fontSize = 12.sp,
                )
            }
            IconButton(onClick = { invert = !invert }) {
                Icon(Icons.Outlined.Tonality, "قلب الألوان", tint = if (invert) p.gold else p.ink)
            }
            IconButton(
                onClick = { uri?.let { WifiPrint.systemPrint(context, "مداد", it) } },
                enabled = uri != null,
            ) {
                Icon(Icons.Outlined.Print, "طباعة", tint = p.ink)
            }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(if (p.oled) androidx.compose.ui.graphics.Color.Black else p.panel)
                .border(1.dp, p.line, RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center,
        ) {
            when {
                loading -> CircularProgressIndicator(color = p.gold)
                error != null -> Text(error ?: "", color = p.muted, modifier = Modifier.padding(24.dp))
                preview != null -> {
                    val bmp = preview!!
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "صفحة PDF",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offsetX,
                                translationY = offsetY,
                            )
                            .pointerInput(bmp) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    scale = (scale * zoom).coerceIn(1f, 4f)
                                    offsetX += pan.x
                                    offsetY += pan.y
                                }
                            },
                    )
                }
                else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    GoldChip("PDF")
                    Spacer(Modifier.height(16.dp))
                    Text("افتح مستنداً للبدء", color = p.ink, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("يدعم التكبير بالأصابع ووضع القراءة الليلي", color = p.muted, fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GhostButton("فتح", Icons.Outlined.FolderOpen) { picker.launch(arrayOf("application/pdf")) }
            IconButton(
                onClick = { if (pageIndex > 0) pageIndex -= 1 },
                enabled = pageIndex > 0,
            ) { Icon(Icons.Outlined.ChevronLeft, "السابق", tint = p.ink) }
            IconButton(
                onClick = { if (pageIndex < pageCount - 1) pageIndex += 1 },
                enabled = pageIndex < pageCount - 1,
            ) { Icon(Icons.Outlined.ChevronRight, "التالي", tint = p.ink) }
            IconButton(onClick = { scale = (scale - 0.25f).coerceAtLeast(1f) }) {
                Icon(Icons.Outlined.Remove, "تصغير", tint = p.ink)
            }
            IconButton(onClick = { scale = (scale + 0.25f).coerceAtMost(4f) }) {
                Icon(Icons.Outlined.Add, "تكبير", tint = p.ink)
            }
            GoldButton("طباعة", Icons.Outlined.Print, enabled = uri != null) {
                uri?.let { WifiPrint.systemPrint(context, "مداد", it) }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}
