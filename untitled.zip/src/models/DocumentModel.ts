export type ThemeMode = 'day' | 'night' | 'oled';

export type ProcessingMode = 'MODE_A_CLEAN_RECONSTRUCTION' | 'MODE_B_IMAGE_CLEANING';

export type PipelineStage =
  | 'IMPORT'
  | 'PREPROCESS'
  | 'ANALYZE_RECONSTRUCT'
  | 'VALIDATE_EDIT'
  | 'EXPORT';

export type LayoutObjectType =
  | 'TEXT'
  | 'PARAGRAPH'
  | 'TABLE'
  | 'TABLE_CELL'
  | 'IMAGE'
  | 'LINE'
  | 'RECTANGLE'
  | 'CHECKBOX'
  | 'SIGNATURE_AREA'
  | 'PAGE_BREAK';

export type TextAlignment = 'right' | 'center' | 'left' | 'justify';
export type TextDirection = 'rtl' | 'ltr';
export type VerticalAlignment = 'top' | 'middle' | 'bottom';

export type FontRole =
  | 'title'
  | 'heading'
  | 'subtitle'
  | 'normal'
  | 'small'
  | 'table'
  | 'label'
  | 'footnote';

export type ArabicFontFamily = 'Amiri' | 'Cairo' | 'Tajawal' | 'IBM Plex Sans Arabic';

export interface BorderSide {
  width: number; // 0 = missing border, 1 = thin, 2 = medium, 3 = thick
  style: 'solid' | 'dashed' | 'double' | 'none';
  color: string;
}

export interface BorderProperties {
  top: BorderSide;
  right: BorderSide;
  bottom: BorderSide;
  left: BorderSide;
}

export interface FontProperties {
  family: ArabicFontFamily;
  sizePt: number;
  weight: 'normal' | 'bold';
  role: FontRole;
  color: string;
  lineHeight: number;
}

export interface BackgroundProperties {
  fill: string; // 'transparent' or hex color
  opacity: number;
}

export interface TableCellModel {
  id: string;
  row: number;
  col: number;
  rowSpan: number;
  colSpan: number;
  content: string;
  confidence: number;
  uncertainTokens?: string[];
  alignment: TextAlignment;
  verticalAlignment: VerticalAlignment;
  direction: TextDirection;
  padding: number;
  fontSizePt: number;
  fontWeight: 'normal' | 'bold';
  borders: BorderProperties;
  backgroundColor: string;
  hiddenByMerge?: boolean;
}

export interface TableStructureModel {
  rows: number;
  cols: number;
  rowHeights: number[]; // Relative proportions summing to 1.0
  colWidths: number[]; // Relative proportions summing to 1.0 (ordered right-to-left for RTL tables or index 0..cols-1)
  direction: TextDirection;
  cells: TableCellModel[];
}

export interface PageLayoutObject {
  id: string;
  type: LayoutObjectType;
  /** Normalized coordinates (0 to 1000) relative to page width and height */
  x: number;
  y: number;
  width: number;
  height: number;
  content: string;
  confidence: number; // 0.0 to 1.0
  uncertainTokens: string[];
  userCorrected?: boolean;
  alignment: TextAlignment;
  direction: TextDirection;
  fontProperties: FontProperties;
  borderProperties: BorderProperties;
  backgroundProperties: BackgroundProperties;
  zOrder: number;
  checked?: boolean; // For CHECKBOX
  tableStructure?: TableStructureModel; // For TABLE
  croppedImageDataUrl?: string; // For IMAGE / STAMP / LOGO / SIGNATURE_AREA
  stampColor?: string;
}

export interface Point2D {
  x: number; // 0 to 1 normalized
  y: number; // 0 to 1 normalized
}

export interface PreprocessingConfig {
  perspectiveCorners: [Point2D, Point2D, Point2D, Point2D]; // TL, TR, BR, BL
  deskewAngleDeg: number; // -15 to +15
  rotationDeg: 0 | 90 | 180 | 270;
  removeShadows: boolean;
  shadowStrength: number; // 0 to 100
  normalizeBackground: boolean;
  contrastBoost: number; // 0 to 100
  denoiseLevel: number; // 0 to 100
  sharpenAmount: number; // 0 to 100
}

export interface ValidationMetric {
  labelAr: string;
  labelEn: string;
  score: number; // 0 to 100
  status: 'optimal' | 'adjusted' | 'warning';
  detailsAr: string;
}

export interface ReconstructionValidationReport {
  iterationsExecuted: number;
  overallVisualSimilarity: number; // 0 to 100
  pageGeometryFidelity: number;
  textPositionFidelity: number;
  tableGeometryFidelity: number;
  arabicTypographyFidelity: number;
  lowConfidenceRegionsCount: number;
  adjustmentsLog: string[];
  metrics: ValidationMetric[];
  diffHeatmapDataUrl?: string;
}

export interface ReconstructedPage {
  pageNumber: number;
  widthMm: number; // Default A4 210
  heightMm: number; // Default A4 297
  aspectRatio: number; // width / height
  sourceImageDataUrl: string;
  preprocessedImageDataUrl: string;
  cleanedModeBImageDataUrl: string;
  reconstructedPreviewDataUrl?: string;
  direction: TextDirection;
  margins: {
    top: number;
    right: number;
    bottom: number;
    left: number;
  };
  objects: PageLayoutObject[];
  preprocessing: PreprocessingConfig;
  validationReport: ReconstructionValidationReport;
}

export interface SampleTestSpec {
  id: string;
  index: number;
  titleAr: string;
  titleEn: string;
  categoryAr: string;
  descriptionAr: string;
  simulatedIssueAr: string;
  pageCount: number;
}

export function createDefaultBorder(
  width = 0,
  style: 'solid' | 'dashed' | 'double' | 'none' = 'none',
  color = '#1E293B'
): BorderProperties {
  const side: BorderSide = { width, style: width > 0 ? (style === 'none' ? 'solid' : style) : 'none', color };
  return {
    top: { ...side },
    right: { ...side },
    bottom: { ...side },
    left: { ...side },
  };
}

export function createDefaultPreprocessingConfig(): PreprocessingConfig {
  return {
    perspectiveCorners: [
      { x: 0.0, y: 0.0 },
      { x: 1.0, y: 0.0 },
      { x: 1.0, y: 1.0 },
      { x: 0.0, y: 1.0 },
    ],
    deskewAngleDeg: 0,
    rotationDeg: 0,
    removeShadows: true,
    shadowStrength: 75,
    normalizeBackground: true,
    contrastBoost: 45,
    denoiseLevel: 35,
    sharpenAmount: 50,
  };
}
