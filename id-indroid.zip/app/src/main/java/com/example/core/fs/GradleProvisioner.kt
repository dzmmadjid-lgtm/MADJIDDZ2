package com.example.core.fs

import android.content.Context
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

data class GradleInstallStatus(
    val isInstalled: Boolean = false,
    val version: String = "Gradle 8.7",
    val gradleHomePath: String = "",
    val zipSizeMb: Double = 0.0,
    val errorDetails: String? = null
)

class GradleProvisioner(private val context: Context) {

    val gradleHomeDir: File
        get() = File(context.filesDir, "gradle_home")

    val gradleDistsDir: File
        get() = File(context.filesDir, "gradle_dists")

    val localZipFile: File
        get() = File(gradleDistsDir, "gradle-8.7-bin.zip")

    val installedGradleDir: File
        get() = File(gradleHomeDir, "gradle-8.7")

    /**
     * Check whether Gradle 8.7 is already installed and ready.
     */
    fun checkGradleStatus(): GradleInstallStatus {
        val binDir = File(installedGradleDir, "bin")
        val libDir = File(installedGradleDir, "lib")
        val hasBinAndLib = binDir.exists() && libDir.exists()

        if (hasBinAndLib) {
            val zipSize = if (localZipFile.exists()) localZipFile.length() / (1024.0 * 1024.0) else 0.0
            return GradleInstallStatus(
                isInstalled = true,
                version = "Gradle 8.7 (Installed)",
                gradleHomePath = installedGradleDir.absolutePath,
                zipSizeMb = String.format("%.1f", zipSize).toDoubleOrNull() ?: zipSize
            )
        }

        if (localZipFile.exists() && localZipFile.length() > 10_000_000L) {
            val zipSize = localZipFile.length() / (1024.0 * 1024.0)
            return GradleInstallStatus(
                isInstalled = true,
                version = "Gradle 8.7 (.zip Cached)",
                gradleHomePath = localZipFile.absolutePath,
                zipSizeMb = String.format("%.1f", zipSize).toDoubleOrNull() ?: zipSize
            )
        }

        return GradleInstallStatus(
            isInstalled = false,
            version = "Not installed",
            errorDetails = "Gradle 8.7 distribution not found."
        )
    }

    /**
     * Look for gradle-8.7-bin.zip in common Android download paths.
     */
    fun findDetectedZipInDownloads(): File? {
        val candidateLocations = listOf(
            File("/storage/emulated/0/Download/gradle-8.7-bin.zip"),
            File("/storage/emulated/0/Downloads/gradle-8.7-bin.zip"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "gradle-8.7-bin.zip")
        )

        for (candidate in candidateLocations) {
            try {
                if (candidate.exists() && candidate.isFile && candidate.length() > 10_000_000L) {
                    return candidate
                }
            } catch (_: Exception) {}
        }
        return null
    }

    /**
     * Install Gradle from a user-selected Uri (.zip file).
     */
    suspend fun installGradleFromUri(
        uri: Uri,
        onProgress: (String) -> Unit
    ): GradleInstallStatus = withContext(Dispatchers.IO) {
        try {
            onProgress("Opening selected Gradle archive...")
            gradleDistsDir.mkdirs()
            gradleHomeDir.mkdirs()

            val tempFile = File(gradleDistsDir, "gradle-download.tmp")
            if (tempFile.exists()) tempFile.delete()

            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return@withContext GradleInstallStatus(isInstalled = false, errorDetails = "Could not open selected file")

            onProgress("Copying Gradle zip to application storage...")
            var totalBytesCopied = 0L
            FileOutputStream(tempFile).use { out ->
                val buffer = ByteArray(64 * 1024)
                var bytesRead: Int
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    out.write(buffer, 0, bytesRead)
                    totalBytesCopied += bytesRead
                    if (totalBytesCopied % (5 * 1024 * 1024) == 0L) {
                        val mb = totalBytesCopied / (1024 * 1024)
                        onProgress("Copying... ($mb MB transferred)")
                    }
                }
            }

            if (tempFile.length() < 10_000_000L) {
                tempFile.delete()
                return@withContext GradleInstallStatus(
                    isInstalled = false,
                    errorDetails = "File appears corrupted or incomplete (size: ${totalBytesCopied / 1024} KB, expected ~130 MB)"
                )
            }

            if (localZipFile.exists()) localZipFile.delete()
            tempFile.renameTo(localZipFile)

            // Extract Gradle archive into internal gradle_home directory
            onProgress("Extracting Gradle distribution (this takes a few moments)...")
            extractZipArchive(localZipFile, gradleHomeDir, onProgress)

            // Configure wrapper dist cache so Gradle Wrapper recognizes the distribution offline
            configureWrapperCache(localZipFile)

            onProgress("Gradle 8.7 installed and verified successfully!")
            checkGradleStatus()
        } catch (e: Exception) {
            e.printStackTrace()
            GradleInstallStatus(isInstalled = false, errorDetails = e.message ?: "Unknown extraction error")
        }
    }

    /**
     * Install directly from a local File (e.g. from Downloads folder).
     */
    suspend fun installGradleFromFile(
        sourceFile: File,
        onProgress: (String) -> Unit
    ): GradleInstallStatus = withContext(Dispatchers.IO) {
        try {
            onProgress("Reading file from: ${sourceFile.name} (${sourceFile.length() / (1024 * 1024)} MB)...")
            gradleDistsDir.mkdirs()
            gradleHomeDir.mkdirs()

            if (localZipFile.exists()) localZipFile.delete()
            sourceFile.copyTo(localZipFile, overwrite = true)

            onProgress("Extracting Gradle distribution...")
            extractZipArchive(localZipFile, gradleHomeDir, onProgress)

            configureWrapperCache(localZipFile)

            onProgress("Gradle 8.7 installed and verified successfully!")
            checkGradleStatus()
        } catch (e: Exception) {
            e.printStackTrace()
            GradleInstallStatus(isInstalled = false, errorDetails = e.message ?: "Extraction failed")
        }
    }

    private fun extractZipArchive(zipFile: File, targetDir: File, onProgress: (String) -> Unit) {
        var fileCount = 0
        ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
            var entry: ZipEntry?
            while (zis.nextEntry.also { entry = it } != null) {
                val e = entry ?: continue
                val outFile = File(targetDir, e.name)
                // Prevent Zip Slip vulnerability
                if (!outFile.canonicalPath.startsWith(targetDir.canonicalPath)) {
                    continue
                }
                if (e.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { fos ->
                        zis.copyTo(fos)
                    }
                    if (outFile.name == "gradle" || outFile.extension == "sh") {
                        outFile.setExecutable(true, false)
                    }
                }
                fileCount++
                if (fileCount % 300 == 0) {
                    onProgress("Extracting Gradle files... ($fileCount files)")
                }
            }
        }
    }

    /**
     * Creates wrapper cache markers so Gradle Wrapper sees the distribution as pre-downloaded.
     */
    private fun configureWrapperCache(zipFile: File) {
        try {
            // Set up common wrapper dist hashes
            val wrapperDists = File(gradleHomeDir, "wrapper/dists")
            wrapperDists.mkdirs()

            // Standard hash directory names used by Gradle for gradle-8.7-bin.zip
            val hashDirs = listOf("gradle-8.7-bin/local", "gradle-8.7-bin")
            for (dirName in hashDirs) {
                val target = File(wrapperDists, dirName)
                target.mkdirs()
                // Put copy of zip or link
                val destZip = File(target, "gradle-8.7-bin.zip")
                if (!destZip.exists()) {
                    try {
                        zipFile.copyTo(destZip, overwrite = true)
                    } catch (_: Exception) {}
                }
                // Write the ok lock marker files
                File(target, "gradle-8.7-bin.zip.ok").writeText("ok")
                File(target, "gradle-8.7-bin.zip.lck").writeText("")
            }
        } catch (_: Exception) {}
    }

    /**
     * Patch project's gradle-wrapper.properties to use local file URI for 100% offline builds.
     */
    fun applyLocalDistributionToProject(projectRootDir: File) {
        val propsFile = File(projectRootDir, "gradle/wrapper/gradle-wrapper.properties")
        if (localZipFile.exists() && propsFile.exists()) {
            try {
                val content = propsFile.readText()
                val updatedContent = content.lines().joinToString("\n") { line ->
                    if (line.startsWith("distributionUrl=")) {
                        "distributionUrl=file\\://${localZipFile.absolutePath}"
                    } else {
                        line
                    }
                }
                propsFile.writeText(updatedContent)
            } catch (_: Exception) {}
        }
    }
}
