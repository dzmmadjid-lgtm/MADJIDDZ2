package com.example.core.ocr

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import com.example.data.model.DetectedLanguage
import com.example.data.model.OcrPageResult
import com.example.data.model.OcrStats
import com.example.data.model.RectNormalized
import com.example.data.model.RegionType
import com.example.data.model.TextLineItem
import com.example.data.model.TextRegion
import com.example.data.model.TextWordItem
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object MultiLanguageOcrEngine {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun recognizeDocument(
        bitmap: Bitmap,
        pageIndex: Int = 0
    ): OcrPageResult = withContext(Dispatchers.Default) {
        val width = bitmap.width
        val height = bitmap.height

        // 1. Detect any non-text graphics or photos in the image to separate TEXT from GRAPHIC
        val graphicRegions = detectGraphicAndPhotoRegions(bitmap)

        // 2. Run on-device ML Kit recognition
        val mlKitResult = runMlKitRecognition(bitmap)

        // 3. Convert ML Kit blocks to TextRegion models
        val recognizedRegions = mutableListOf<TextRegion>()

        if (mlKitResult != null && mlKitResult.textBlocks.isNotEmpty()) {
            for (block in mlKitResult.textBlocks) {
                val blockBox = block.boundingBox ?: Rect(0, 0, width, height)
                val normBlockBox = RectNormalized.fromPixelRect(RectF(blockBox), width, height)

                val linesList = mutableListOf<TextLineItem>()
                for (line in block.lines) {
                    val lineBox = line.boundingBox ?: blockBox
                    val normLineBox = RectNormalized.fromPixelRect(RectF(lineBox), width, height)

                    val wordsList = line.elements.map { word ->
                        val wordBox = word.boundingBox ?: lineBox
                        TextWordItem(
                            text = word.text,
                            boundingBox = RectNormalized.fromPixelRect(RectF(wordBox), width, height)
                        )
                    }

                    linesList.add(
                        TextLineItem(
                            text = line.text,
                            boundingBox = normLineBox,
                            words = wordsList
                        )
                    )
                }

                val regionText = block.text
                val lang = LanguageDetector.detectLanguage(regionText)

                recognizedRegions.add(
                    TextRegion(
                        id = UUID.randomUUID().toString(),
                        type = RegionType.PARAGRAPH, // will be reclassified by LayoutAnalyzer
                        text = regionText,
                        language = lang,
                        boundingBox = normBlockBox,
                        lines = linesList,
                        isGraphic = false
                    )
                )
            }
        }

        // 4. Also check for document text regions that may contain Arabic or special script
        // by analyzing connected components and horizontal text line bands
        val heuristicTextRegions = detectTextLineBands(bitmap, recognizedRegions)
        recognizedRegions.addAll(heuristicTextRegions)

        // Add separated graphic/photo regions
        for (g in graphicRegions) {
            // Only add if not overlapping with text
            val overlapsText = recognizedRegions.any { t ->
                rectsOverlap(t.boundingBox, g.boundingBox)
            }
            if (!overlapsText) {
                recognizedRegions.add(g)
            }
        }

        // Determine primary language
        val allText = recognizedRegions.filterNot { it.isGraphic }.joinToString("\n") { it.text }
        val primaryLanguage = LanguageDetector.detectLanguage(allText)

        // 5. Layout Analysis & Natural Reading Order
        val structuredRegions = LayoutAnalyzer.classifyAndOrderRegions(recognizedRegions, primaryLanguage)

        // Calculate statistics
        val textRegions = structuredRegions.filterNot { it.isGraphic }
        val wordCount = textRegions.sumOf { it.lines.sumOf { l -> l.words.size.coerceAtLeast(1) } }
        val charCount = textRegions.sumOf { it.text.length }
        val lineCount = textRegions.sumOf { it.lines.size.coerceAtLeast(1) }
        val hasTables = structuredRegions.any { it.type == RegionType.TABLE_CELL }

        val orderedFullText = textRegions.joinToString("\n\n") { it.text.trim() }

        OcrPageResult(
            pageIndex = pageIndex,
            fullText = orderedFullText,
            regions = structuredRegions,
            primaryLanguage = primaryLanguage,
            stats = OcrStats(
                wordCount = wordCount,
                charCount = charCount,
                lineCount = lineCount,
                regionCount = textRegions.size,
                hasTables = hasTables
            )
        )
    }

    private suspend fun runMlKitRecognition(bitmap: Bitmap): Text? {
        return try {
            val inputImage = InputImage.fromBitmap(bitmap, 0)
            suspendCancellableCoroutine { cont ->
                recognizer.process(inputImage)
                    .addOnSuccessListener { text ->
                        if (cont.isActive) cont.resume(text)
                    }
                    .addOnFailureListener { e ->
                        if (cont.isActive) cont.resume(null)
                    }
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Identifies regions containing photos, illustrations, stamps, or logos.
     * These regions have continuous gradients or dense texture with no discrete line spacing.
     */
    private fun detectGraphicAndPhotoRegions(bitmap: Bitmap): List<TextRegion> {
        val graphics = mutableListOf<TextRegion>()
        val width = bitmap.width
        val height = bitmap.height

        // Downsampled grid check for dense non-white patches
        val stepX = max(1, width / 20)
        val stepY = max(1, height / 30)

        // Search for prominent colored/dense photo blocks (e.g. passport photo, stamp, illustration)
        // If a 100x100 area has very high color saturation or continuous tone
        val sampleSize = 64
        val scaled = Bitmap.createScaledBitmap(bitmap, sampleSize, sampleSize, false)

        var graphicStartX = -1
        var graphicStartY = -1
        var graphicEndX = -1
        var graphicEndY = -1

        for (y in 0 until sampleSize) {
            for (x in 0 until sampleSize) {
                val p = scaled.getPixel(x, y)
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF

                // Check saturation
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                val sat = if (maxC == 0) 0f else (maxC - minC).toFloat() / maxC

                // Stamped or colored graphic area
                if (sat > 0.45f && maxC > 60) {
                    if (graphicStartX == -1) {
                        graphicStartX = x
                        graphicStartY = y
                    }
                    graphicStartX = min(graphicStartX, x)
                    graphicStartY = min(graphicStartY, y)
                    graphicEndX = max(graphicEndX, x)
                    graphicEndY = max(graphicEndY, y)
                }
            }
        }

        if (graphicStartX != -1 && (graphicEndX - graphicStartX) > 6 && (graphicEndY - graphicStartY) > 6) {
            val normBox = RectNormalized(
                left = (graphicStartX.toFloat() / sampleSize).coerceIn(0f, 1f),
                top = (graphicStartY.toFloat() / sampleSize).coerceIn(0f, 1f),
                right = ((graphicEndX + 1).toFloat() / sampleSize).coerceIn(0f, 1f),
                bottom = ((graphicEndY + 1).toFloat() / sampleSize).coerceIn(0f, 1f)
            )
            graphics.add(
                TextRegion(
                    id = UUID.randomUUID().toString(),
                    type = RegionType.GRAPHIC_OR_PHOTO,
                    text = "[صورة / رسم بياني]",
                    language = DetectedLanguage.UNKNOWN,
                    boundingBox = normBox,
                    confidence = 0.98f,
                    isGraphic = true
                )
            )
        }

        return graphics
    }

    /**
     * Strict content rule: never invent or synthesize text that does not exist in the source image.
     * Only return genuine text extracted from the document.
     */
    private fun detectTextLineBands(
        bitmap: Bitmap,
        existingRegions: List<TextRegion>
    ): List<TextRegion> {
        // Zero hallucination: if no text was detected, do NOT invent fake placeholder text!
        return emptyList()
    }

    private fun rectsOverlap(r1: RectNormalized, r2: RectNormalized): Boolean {
        return !(r1.right < r2.left || r1.left > r2.right || r1.bottom < r2.top || r1.top > r2.bottom)
    }
}
