import { jsPDF } from 'jspdf';
import { ProcessingMode, ReconstructedPage } from '../models/DocumentModel';
import { renderPageToCanvas } from './DocumentRenderer';
import { loadImageElement } from './ImagePreprocessor';

export type ExportFormat = 'PDF' | 'PNG' | 'JPG';
export type ExportDpi = 150 | 300 | 400;

export interface ExportOptions {
  format: ExportFormat;
  dpi: ExportDpi;
  jpgQuality: number; // 0.80 to 1.00
  processingMode: ProcessingMode;
  filenamePrefix: string;
}

function getPixelDimensionsForDpi(dpi: ExportDpi, aspectRatio = 210 / 297) {
  const widthInches = 8.27; // A4 width
  const widthPx = Math.round(widthInches * dpi);
  const heightPx = Math.round(widthPx / aspectRatio);
  return { widthPx, heightPx };
}

async function renderPageForExport(
  page: ReconstructedPage,
  options: ExportOptions
): Promise<HTMLCanvasElement> {
  const { widthPx, heightPx } = getPixelDimensionsForDpi(
    options.dpi,
    page.aspectRatio || 210 / 297
  );
  const canvas = document.createElement('canvas');
  canvas.width = widthPx;
  canvas.height = heightPx;

  if (options.processingMode === 'MODE_B_IMAGE_CLEANING') {
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, widthPx, heightPx);
      const cleanedImg = await loadImageElement(
        page.cleanedModeBImageDataUrl || page.preprocessedImageDataUrl || page.sourceImageDataUrl
      );
      ctx.drawImage(cleanedImg, 0, 0, widthPx, heightPx);
    }
    return canvas;
  }

  // MODE_A_CLEAN_RECONSTRUCTION: Render full coordinate object model at print DPI
  renderPageToCanvas(canvas, page.objects, {
    widthPx,
    heightPx,
    highlightLowConfidence: false,
    showBoundingBoxes: false,
  });

  return canvas;
}

function triggerBlobDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

export async function exportReconstructedDocument(
  pages: ReconstructedPage[],
  options: ExportOptions
): Promise<{ filename: string; sizeKb: number; dimensionsLabel: string }> {
  if (!pages || pages.length === 0) {
    throw new Error('لا توجد صفحات جاهزة للتصدير.');
  }

  const firstDims = getPixelDimensionsForDpi(options.dpi, pages[0].aspectRatio || 210 / 297);
  const dimensionsLabel = `${firstDims.widthPx} × ${firstDims.heightPx} px (${options.dpi} DPI)`;
  const modeSuffix = options.processingMode === 'MODE_A_CLEAN_RECONSTRUCTION' ? 'reconstructed' : 'cleaned';
  const cleanPrefix = (options.filenamePrefix || 'crimson_doc').replace(/[^a-zA-Z0-9_\u0600-\u06FF-]/g, '_');

  if (options.format === 'PDF') {
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    for (let i = 0; i < pages.length; i++) {
      if (i > 0) {
        pdf.addPage('a4', 'portrait');
      }
      const canvas = await renderPageForExport(pages[i], options);
      const imgDataUrl = canvas.toDataURL('image/jpeg', 0.98);
      pdf.addImage(imgDataUrl, 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
    }

    const pdfBlob = pdf.output('blob');
    const filename = `${cleanPrefix}_${modeSuffix}_${options.dpi}dpi.pdf`;
    triggerBlobDownload(pdfBlob, filename);

    return {
      filename,
      sizeKb: Math.round(pdfBlob.size / 1024),
      dimensionsLabel,
    };
  }

  // PNG or JPG export (exports each page)
  let totalSize = 0;
  let lastFilename = '';
  const mimeType = options.format === 'PNG' ? 'image/png' : 'image/jpeg';
  const ext = options.format === 'PNG' ? 'png' : 'jpg';

  for (let i = 0; i < pages.length; i++) {
    const canvas = await renderPageForExport(pages[i], options);
    const blob: Blob = await new Promise((resolve, reject) => {
      canvas.toBlob(
        (b) => (b ? resolve(b) : reject(new Error('فشل توليد ملف الصورة'))),
        mimeType,
        options.jpgQuality
      );
    });
    const pageTag = pages.length > 1 ? `_p${i + 1}` : '';
    const filename = `${cleanPrefix}_${modeSuffix}${pageTag}_${options.dpi}dpi.${ext}`;
    triggerBlobDownload(blob, filename);
    totalSize += blob.size;
    lastFilename = filename;
  }

  return {
    filename: lastFilename,
    sizeKb: Math.round(totalSize / 1024),
    dimensionsLabel,
  };
}
