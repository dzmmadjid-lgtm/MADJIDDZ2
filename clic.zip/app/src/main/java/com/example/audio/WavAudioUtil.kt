package com.example.audio

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Audio container and WAV encoding/decoding utilities for 44.1 kHz stereo audio.
 */
data class StereoAudio(
    val left: FloatArray,
    val right: FloatArray,
    val sampleRate: Int = 44100
) {
    val durationSeconds: Float
        get() = left.size.toFloat() / sampleRate

    fun isStereo(): Boolean = left !== right
}

object WavAudioUtil {

    /**
     * Reads a 16-bit PCM WAV file and returns normalized stereo float audio [-1.0 .. 1.0].
     */
    fun readWavFile(file: File): StereoAudio {
        FileInputStream(file).use { input ->
            val header = ByteArray(44)
            val readHeader = input.read(header)
            require(readHeader >= 44) { "File is too short to be a valid WAV" }

            val riff = String(header, 0, 4)
            val wave = String(header, 8, 4)
            require(riff == "RIFF" && wave == "WAVE") { "Not a valid RIFF/WAVE file" }

            val bb = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            val channels = bb.getShort(22).toInt()
            val sampleRate = bb.getInt(24)
            val bitsPerSample = bb.getShort(34).toInt()

            var dataSize = bb.getInt(40)
            if (dataSize <= 0) {
                dataSize = (file.length() - 44).toInt()
            }

            val pcmBytes = ByteArray(dataSize)
            var totalRead = 0
            while (totalRead < dataSize) {
                val r = input.read(pcmBytes, totalRead, dataSize - totalRead)
                if (r <= 0) break
                totalRead += r
            }

            return decodePcm(pcmBytes, channels, sampleRate, bitsPerSample)
        }
    }

    /**
     * Decodes raw PCM bytes to StereoAudio.
     */
    fun decodePcm(
        bytes: ByteArray,
        channels: Int,
        sampleRate: Int,
        bitsPerSample: Int
    ): StereoAudio {
        val bytesPerSample = max(1, bitsPerSample / 8)
        val validChannels = max(1, channels)
        val frameBytes = validChannels * bytesPerSample
        val totalSamples = bytes.size / frameBytes
        val left = FloatArray(totalSamples)
        val right = FloatArray(totalSamples)

        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        for (i in 0 until totalSamples) {
            val sampleL = when (bitsPerSample) {
                16 -> bb.short.toFloat() / 32768.0f
                else -> (bb.get().toInt() - 128) / 128.0f
            }
            left[i] = sampleL

            if (validChannels > 1) {
                val sampleR = when (bitsPerSample) {
                    16 -> bb.short.toFloat() / 32768.0f
                    else -> (bb.get().toInt() - 128) / 128.0f
                }
                right[i] = sampleR

                // Skip any extra channels beyond stereo (e.g. 5.1 surround)
                for (c in 2 until validChannels) {
                    when (bitsPerSample) {
                        16 -> bb.short
                        else -> bb.get()
                    }
                }
            } else {
                right[i] = sampleL
            }
        }

        // Resample to 44100 Hz if needed for the model
        return if (sampleRate != 44100 && sampleRate > 0) {
            resampleTo44100(left, right, sampleRate)
        } else {
            StereoAudio(left, right, 44100)
        }
    }

    /**
     * Resamples audio to 44100 Hz using linear interpolation.
     */
    private fun resampleTo44100(left: FloatArray, right: FloatArray, origRate: Int): StereoAudio {
        val targetRate = 44100
        val targetLength = (left.size.toLong() * targetRate / origRate).toInt()
        val newLeft = FloatArray(targetLength)
        val newRight = FloatArray(targetLength)
        val ratio = origRate.toDouble() / targetRate.toDouble()

        for (i in 0 until targetLength) {
            val srcPos = i * ratio
            val srcIdx = srcPos.toInt()
            val frac = (srcPos - srcIdx).toFloat()

            if (srcIdx + 1 < left.size) {
                newLeft[i] = left[srcIdx] * (1f - frac) + left[srcIdx + 1] * frac
                newRight[i] = right[srcIdx] * (1f - frac) + right[srcIdx + 1] * frac
            } else if (srcIdx < left.size) {
                newLeft[i] = left[srcIdx]
                newRight[i] = right[srcIdx]
            }
        }

        return StereoAudio(newLeft, newRight, targetRate)
    }

    /**
     * Writes StereoAudio to a standard 16-bit 44.1 kHz PCM WAV file.
     */
    fun writeWavFile(audio: StereoAudio, destination: File) {
        val numSamples = audio.left.size
        val channels = 2
        val sampleRate = audio.sampleRate
        val byteRate = sampleRate * channels * 2
        val blockAlign = channels * 2
        val dataLength = numSamples * blockAlign
        val totalLength = 36 + dataLength

        FileOutputStream(destination).use { out ->
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt(totalLength)
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16) // Subchunk1Size (16 for PCM)
            header.putShort(1) // AudioFormat (1 for PCM)
            header.putShort(channels.toShort())
            header.putInt(sampleRate)
            header.putInt(byteRate)
            header.putShort(blockAlign.toShort())
            header.putShort(16) // BitsPerSample
            header.put("data".toByteArray())
            header.putInt(dataLength)

            out.write(header.array())

            // Write interleaved 16-bit samples
            val buffer = ByteArray(8192)
            val bb = ByteBuffer.wrap(buffer).order(ByteOrder.LITTLE_ENDIAN)

            for (i in 0 until numSamples) {
                val sL = (max(-1.0f, min(1.0f, audio.left[i])) * 32767.0f).toInt().toShort()
                val sR = (max(-1.0f, min(1.0f, audio.right[i])) * 32767.0f).toInt().toShort()

                bb.putShort(sL)
                bb.putShort(sR)

                if (bb.position() >= buffer.size) {
                    out.write(buffer)
                    bb.clear()
                }
            }

            if (bb.position() > 0) {
                out.write(buffer, 0, bb.position())
            }
        }
    }

    /**
     * Generates a realistic 12-second musical test audio containing both:
     * - Melody / singing voice (formant-rich harmonics, vibrato, center panned).
     * - Musical accompaniment (stereo acoustic guitar chords, bass line, wide drums).
     * Used for instant testing and demonstration without needing an external audio file.
     */
    fun createDemoSong(durationSeconds: Float = 12.0f): StereoAudio {
        val sampleRate = 44100
        val totalSamples = (durationSeconds * sampleRate).toInt()
        val left = FloatArray(totalSamples)
        val right = FloatArray(totalSamples)

        // Musical parameters
        val bpm = 110.0
        val beatDuration = (60.0 / bpm * sampleRate).toInt()

        // Chord progression: Am (220Hz), F (174Hz), C (261Hz), G (196Hz)
        val chords = listOf(
            listOf(220.0, 261.63, 329.63), // Am
            listOf(174.61, 220.0, 261.63), // F
            listOf(261.63, 329.63, 392.0), // C
            listOf(196.0, 246.94, 293.66)  // G
        )

        // Vocal melody notes (Hz): E4, D4, C4, D4, E4, E4, E4
        val melodyNotes = listOf(
            329.63, 293.66, 261.63, 293.66,
            329.63, 329.63, 329.63, 293.66,
            261.63, 293.66, 329.63, 261.63
        )

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val currentBeat = i / beatDuration
            val chordIdx = (currentBeat / 4) % chords.size
            val activeChord = chords[chordIdx]

            // 1. Instrumental: Acoustic chord strumming + Bass
            var instL = 0.0
            var instR = 0.0

            // Guitar plucking
            for ((noteIdx, freq) in activeChord.withIndex()) {
                val strumPhase = (i % beatDuration).toDouble() / beatDuration
                val decay = exp(-strumPhase * 3.5)
                val tone = sin(2.0 * PI * freq * t) + 0.3 * sin(4.0 * PI * freq * t)
                val panL = if (noteIdx % 2 == 0) 0.8 else 0.3
                val panR = if (noteIdx % 2 == 0) 0.3 else 0.8
                instL += tone * decay * panL * 0.25
                instR += tone * decay * panR * 0.25
            }

            // Bass note (sub-frequencies)
            val bassFreq = activeChord[0] / 2.0
            val bass = sin(2.0 * PI * bassFreq * t) * 0.35
            instL += bass * 0.5
            instR += bass * 0.5

            // Drum beat (Kick on beat 0, 2; Snare on beat 1, 3)
            val beatPhase = (i % beatDuration).toDouble() / beatDuration
            if (currentBeat % 2 == 0) { // Kick
                val kickDecay = exp(-beatPhase * 15.0)
                val kick = sin(2.0 * PI * 65.0 * beatPhase) * kickDecay * 0.4
                instL += kick
                instR += kick
            } else { // Snare
                val snareDecay = exp(-beatPhase * 8.0)
                val noise = ((i * 1103515245 + 12345) and 0x7FFFFFFF) / 2147483648.0 - 0.5
                val snare = noise * snareDecay * 0.25
                instL += snare
                instR += snare
            }

            // 2. Vocal Melody: Formant-rich voice with natural vibrato
            var vocal = 0.0
            if (t > 1.5 && t < durationSeconds - 0.5) {
                val noteIdx = ((t - 1.5) * 1.5).toInt() % melodyNotes.size
                val baseFreq = melodyNotes[noteIdx]
                // 5.5 Hz vibrato
                val vibrato = 1.0 + 0.015 * sin(2.0 * PI * 5.5 * t)
                val f = baseFreq * vibrato

                // Voice formants (F0, F1 ~ 700Hz, F2 ~ 1200Hz, F3 ~ 2800Hz)
                val h1 = sin(2.0 * PI * f * t) * 0.45
                val h2 = sin(2.0 * PI * 2 * f * t) * 0.35
                val h3 = sin(2.0 * PI * 3 * f * t) * 0.25
                val h4 = sin(2.0 * PI * 4 * f * t) * 0.15

                // Envelope attack/release
                val notePhase = ((t - 1.5) * 1.5) % 1.0
                val env = min(1.0, notePhase * 10.0) * min(1.0, (1.0 - notePhase) * 8.0)
                vocal = (h1 + h2 + h3 + h4) * env * 0.45
            }

            // Vocals are center panned, instruments spread stereo
            left[i] = (instL + vocal).toFloat()
            right[i] = (instR + vocal).toFloat()
        }

        return StereoAudio(left, right, sampleRate)
    }
}
