package com.medad.studio.print

import android.app.Service
import android.content.Intent
import android.os.IBinder

class WifiPrintDiscoveryService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
