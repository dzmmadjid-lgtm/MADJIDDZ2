package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.components.ExportPdfDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OcrResultScreen
import com.example.ui.screens.ScanEditScreen

@Composable
fun MainScreen(viewModel: DocScanViewModel) {
    val state by viewModel.uiState.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        when (state.currentScreen) {
            AppScreen.HOME -> {
                HomeScreen(
                    recentExports = state.recentExports,
                    onImportImages = { uris -> viewModel.importImages(uris) },
                    onLoadDemo = { demoId -> viewModel.loadDemoDocument(demoId) },
                    onOpenPdf = { doc -> viewModel.openExportedPdf(doc.file) },
                    onSharePdf = { doc -> viewModel.shareExportedPdf(doc.file) }
                )
            }
            AppScreen.SCAN_EDIT -> {
                ScanEditScreen(
                    pages = state.pages,
                    currentPageIndex = state.currentPageIndex,
                    cachedBitmaps = state.cachedBitmaps,
                    isProcessing = state.isProcessing,
                    pipelineStage = state.pipelineStage,
                    statusMessage = state.statusMessage,
                    onSelectPage = { idx -> viewModel.selectPage(idx) },
                    onRemovePage = { idx -> viewModel.removePage(idx) },
                    onRotatePage = { viewModel.rotateCurrentPage() },
                    onSetEnhancement = { mode -> viewModel.setEnhancementMode(mode) },
                    onAddMoreImages = { uris -> viewModel.importImages(uris) },
                    onStartOcr = { viewModel.runOcrPipeline() },
                    onBack = { viewModel.navigateTo(AppScreen.HOME) }
                )
            }
            AppScreen.OCR_RESULT, AppScreen.PDF_VIEWER -> {
                OcrResultScreen(
                    pages = state.pages,
                    currentPageIndex = state.currentPageIndex,
                    cachedBitmaps = state.cachedBitmaps,
                    reconstructedBitmaps = state.reconstructedBitmaps,
                    isReconstructedViewActive = state.isReconstructedViewActive,
                    activeViewTab = state.activeViewTab,
                    selectedRegionId = state.selectedRegionId,
                    selectionUnit = state.selectionUnit,
                    customSelectedText = state.customSelectedText,
                    searchQuery = state.searchQuery,
                    searchMatchCount = state.searchMatchCount,
                    onSelectPage = { idx -> viewModel.selectPage(idx) },
                    onSetActiveViewTab = { tab -> viewModel.setActiveViewTab(tab) },
                    onToggleReconstructedView = { active -> viewModel.toggleReconstructedView(active) },
                    onSelectRegion = { regId -> viewModel.selectRegion(regId) },
                    onSetSelectionUnit = { unit -> viewModel.setSelectionUnit(unit) },
                    onUpdateSearchQuery = { q -> viewModel.updateSearchQuery(q) },
                    onCopyText = { onDone -> viewModel.copySelectedText(onDone) },
                    onShareText = { viewModel.shareText() },
                    onShareCleanImage = { viewModel.shareCurrentDocumentImage() },
                    onOpenExportDialog = { viewModel.setShowExportDialog(true) },
                    onBack = { viewModel.navigateTo(AppScreen.SCAN_EDIT) }
                )
            }
        }

        // Export PDF Dialog
        if (state.showExportDialog) {
            ExportPdfDialog(
                isExporting = state.isExportingPdf,
                latestExport = state.latestExportedPdf,
                onDismiss = { viewModel.setShowExportDialog(false) },
                onExport = { mode, title -> viewModel.exportPdf(mode, title) },
                onOpenFile = { doc -> viewModel.openExportedPdf(doc.file) },
                onShareFile = { doc -> viewModel.shareExportedPdf(doc.file) }
            )
        }
    }
}
