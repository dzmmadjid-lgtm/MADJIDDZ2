package com.example.core.reconstruct

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import com.example.core.image.ImageUtils
import com.example.data.model.DetectedLanguage
import com.example.data.model.OcrPageResult
import com.example.data.model.RegionType
import com.example.data.model.TextLineItem
import com.example.data.model.TextRegion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object DocumentReconstructor {

    data class ReconstructionOptions(
        val removeShadows: Boolean = true,
        val deskewAndStraighten: Boolean = true,
        val reconstructTables: Boolean = true,
        val preserveGraphics: Boolean = true,
        val paperTone: PaperTone = PaperTone.CLEAN_WHITE
    )

    enum class PaperTone(val labelAr: String, val colorInt: Int) {
        CLEAN_WHITE("أبيض ناصع", Color.WHITE),
        NATURAL_PAPER("ورق طبيعي", Color.rgb(253, 252, 248)),
        CREAM("ورق عاجي", Color.rgb(255, 253, 245))
    }

    private data class TableRowGroup(
        val top: Float,
        val bottom: Float,
        val cells: MutableList<TextRegion> = mutableListOf()
    )

    /**
     * Reconstructs a clean digital twin of the original document.
     * Preserves exact 1:1 layout geometry:
     * - Exact line positions, heights, baseline alignment, and text widths.
     * - Real reconstructed table grids with outer borders, row dividers, and column dividers.
     * - Extracted and cleaned stamps, logos, and signatures.
     * - Pure white background with zero camera shadows, stains, or folds.
     * - NO bounding boxes or OCR debug rectangles in the output!
     */
    suspend fun reconstruct(
        sourceBitmap: Bitmap,
        ocrResult: OcrPageResult?,
        options: ReconstructionOptions = ReconstructionOptions()
    ): Bitmap = withContext(Dispatchers.Default) {
        // 1. Deskew & straighten
        val straightened = if (options.deskewAndStraighten) {
            autoDeskew(sourceBitmap, ocrResult)
        } else {
            sourceBitmap
        }

        // 2. High-fidelity shadow and stain removal
        val whitenedBase = if (options.removeShadows) {
            removeShadowsAndStains(straightened)
        } else {
            straightened
        }

        val outWidth = max(straightened.width, 1600)
        val outHeight = max(straightened.height, 2200)

        val reconstructed = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(reconstructed)

        // Fill pristine paper background
        canvas.drawColor(options.paperTone.colorInt)

        if (ocrResult == null || ocrResult.regions.isEmpty()) {
            val dstRect = RectF(0f, 0f, outWidth.toFloat(), outHeight.toFloat())
            val srcRect = Rect(0, 0, whitenedBase.width, whitenedBase.height)
            canvas.drawBitmap(whitenedBase, srcRect, dstRect, Paint(Paint.FILTER_BITMAP_FLAG))
            return@withContext reconstructed
        }

        // 3. Separate elements: Tables vs Freeform Text vs Graphics vs Rules
        val tableRegions = ocrResult.regions.filter { it.type == RegionType.TABLE_CELL }
        val graphicRegions = ocrResult.regions.filter { it.isGraphic }
        val regularTextRegions = ocrResult.regions.filter { it.type != RegionType.TABLE_CELL && !it.isGraphic }

        // 4. Reconstruct Table Grids (Real table borders and cell dividers)
        if (options.reconstructTables && tableRegions.isNotEmpty()) {
            renderReconstructedTables(canvas, tableRegions, ocrResult.primaryLanguage, outWidth, outHeight)
        } else {
            // Render as regular text if table reconstruction disabled
            for (region in tableRegions) {
                renderTextRegion(canvas, region, ocrResult.primaryLanguage, outWidth, outHeight)
            }
        }

        // 5. Render Regular Text Regions Line-by-Line with 1:1 Geometry
        for (region in regularTextRegions) {
            renderTextRegion(canvas, region, ocrResult.primaryLanguage, outWidth, outHeight)
        }

        // 6. Detect and draw horizontal separator rules
        drawDocumentRules(canvas, regularTextRegions, outWidth, outHeight)

        // 7. Render Clean Graphics, Logos, and Stamps
        if (options.preserveGraphics) {
            for (graphic in graphicRegions) {
                renderCleanGraphic(canvas, graphic, whitenedBase, outWidth, outHeight)
            }
        }

        reconstructed
    }

    /**
     * Renders a text region line-by-line using exact normalized coordinates from the physical image.
     * Calculates font size from actual line height and adjusts textScaleX to preserve exact text width.
     */
    private fun renderTextRegion(
        canvas: Canvas,
        region: TextRegion,
        primaryLang: DetectedLanguage,
        outWidth: Int,
        outHeight: Int
    ) {
        val lines = if (region.lines.isNotEmpty()) {
            region.lines
        } else {
            listOf(TextLineItem(text = region.text, boundingBox = region.boundingBox))
        }

        val isRtl = region.language == DetectedLanguage.ARABIC ||
                (region.language == DetectedLanguage.MIXED && primaryLang == DetectedLanguage.ARABIC)

        val isTitle = region.type == RegionType.TITLE
        val isBold = isTitle || region.type == RegionType.TABLE_CELL

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isTitle) Color.rgb(20, 20, 25) else Color.rgb(30, 30, 35)
            typeface = if (isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            textAlign = if (isRtl) Paint.Align.RIGHT else Paint.Align.LEFT
        }

        for (line in lines) {
            val text = line.text.trim()
            if (text.isEmpty()) continue

            val box = line.boundingBox
            val lx = box.left * outWidth
            val ly = box.top * outHeight
            val lw = (box.width * outWidth).coerceAtLeast(10f)
            val lh = (box.height * outHeight).coerceAtLeast(12f)

            // Font size proportionally matched to physical line height in original photo
            val targetFontSize = (lh * 0.80f).coerceIn(14f, 90f)
            textPaint.textSize = targetFontSize

            // Measure width and adapt textScaleX slightly if needed to match word boundaries
            val measuredW = textPaint.measureText(text)
            if (measuredW > 0f && lw > 0f) {
                val scaleRatio = lw / measuredW
                textPaint.textScaleX = scaleRatio.coerceIn(0.88f, 1.15f)
            } else {
                textPaint.textScaleX = 1.0f
            }

            // Accurate baseline calculation using FontMetrics
            val fontMetrics = textPaint.fontMetrics
            val baselineOffset = (fontMetrics.descent - fontMetrics.ascent) / 2f - fontMetrics.descent
            val baselineY = ly + (lh / 2f) + baselineOffset

            if (isRtl) {
                canvas.drawText(text, lx + lw, baselineY, textPaint)
            } else {
                canvas.drawText(text, lx, baselineY, textPaint)
            }
        }
    }

    /**
     * Identifies table structure and draws real vector grid lines (outer borders, rows, columns)
     * and neatly places cell contents inside their bounded cell areas.
     */
    private fun renderReconstructedTables(
        canvas: Canvas,
        tableCells: List<TextRegion>,
        primaryLang: DetectedLanguage,
        outWidth: Int,
        outHeight: Int
    ) {
        if (tableCells.isEmpty()) return

        // 1. Group cells into horizontal rows
        val rowThreshold = 0.022f // 2.2% page height tolerance
        val rows = mutableListOf<TableRowGroup>()

        val sortedCells = tableCells.sortedBy { it.boundingBox.top }

        for (cell in sortedCells) {
            val cellTop = cell.boundingBox.top
            val existingRow = rows.find { abs(it.top - cellTop) < rowThreshold }
            if (existingRow != null) {
                existingRow.cells.add(cell)
            } else {
                rows.add(TableRowGroup(top = cellTop, bottom = cell.boundingBox.bottom, cells = mutableListOf(cell)))
            }
        }

        if (rows.isEmpty()) return

        // Global table boundary
        val minLeft = (tableCells.minOf { it.boundingBox.left } * outWidth) - 12f
        val maxRight = (tableCells.maxOf { it.boundingBox.right } * outWidth) + 12f
        val minTop = (rows.first().cells.minOf { it.boundingBox.top } * outHeight) - 8f
        val maxBottom = (rows.last().cells.maxOf { it.boundingBox.bottom } * outHeight) + 8f

        // Table Border and Grid Paints
        val outerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(60, 64, 72)
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }

        val rowDividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(180, 185, 195)
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }

        val colDividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(200, 205, 215)
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
        }

        val headerBgPaint = Paint().apply {
            color = Color.rgb(242, 244, 248)
            style = Paint.Style.FILL
        }

        // Draw Header Row background fill (first row)
        val firstRowBottom = (rows.first().cells.maxOf { it.boundingBox.bottom } * outHeight) + 6f
        canvas.drawRect(minLeft, minTop, maxRight, firstRowBottom, headerBgPaint)

        // Draw Outer Table Border
        canvas.drawRect(minLeft, minTop, maxRight, maxBottom, outerBorderPaint)

        // Draw Horizontal Row Dividers
        for (i in 0 until rows.size - 1) {
            val rowY = (rows[i].cells.maxOf { it.boundingBox.bottom } * outHeight) + 6f
            val isHeaderDivider = (i == 0)
            val paint = if (isHeaderDivider) outerBorderPaint else rowDividerPaint
            canvas.drawLine(minLeft, rowY, maxRight, rowY, paint)
        }

        // Collect all unique column divider coordinates across all rows
        val colDividers = mutableListOf<Float>()
        for (row in rows) {
            val sortedRowCells = row.cells.sortedBy { it.boundingBox.left }
            for (j in 0 until sortedRowCells.size - 1) {
                val midX = ((sortedRowCells[j].boundingBox.right + sortedRowCells[j + 1].boundingBox.left) / 2f) * outWidth
                if (colDividers.none { abs(it - midX) < 40f }) {
                    colDividers.add(midX)
                }
            }
        }

        // Draw Vertical Column Dividers
        for (colX in colDividers) {
            canvas.drawLine(colX, minTop, colX, maxBottom, colDividerPaint)
        }

        // Render each cell's text aligned inside its row and cell boundaries
        for (row in rows) {
            for (cell in row.cells) {
                renderTextRegion(canvas, cell, primaryLang, outWidth, outHeight)
            }
        }
    }

    /**
     * Renders crisp horizontal divider rules under titles or totals
     */
    private fun drawDocumentRules(
        canvas: Canvas,
        textRegions: List<TextRegion>,
        outWidth: Int,
        outHeight: Int
    ) {
        val rulePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(180, 185, 195)
            strokeWidth = 2f
        }

        // Draw subtle divider under prominent top title
        val titleRegion = textRegions.find { it.type == RegionType.TITLE && it.boundingBox.top < 0.22f }
        if (titleRegion != null) {
            val y = (titleRegion.boundingBox.bottom * outHeight) + 14f
            val margin = 60f
            canvas.drawLine(margin, y, outWidth - margin, y, rulePaint)
        }
    }

    /**
     * Extracts, whitens, and cleanly draws a seal, stamp, logo, or signature
     */
    private fun renderCleanGraphic(
        canvas: Canvas,
        region: TextRegion,
        whitenedBase: Bitmap,
        outWidth: Int,
        outHeight: Int
    ) {
        val box = region.boundingBox
        val srcLeft = (box.left * whitenedBase.width).toInt().coerceIn(0, whitenedBase.width - 1)
        val srcTop = (box.top * whitenedBase.height).toInt().coerceIn(0, whitenedBase.height - 1)
        val srcRight = (box.right * whitenedBase.width).toInt().coerceIn(srcLeft + 1, whitenedBase.width)
        val srcBottom = (box.bottom * whitenedBase.height).toInt().coerceIn(srcTop + 1, whitenedBase.height)

        val cropW = srcRight - srcLeft
        val cropH = srcBottom - srcTop
        if (cropW > 8 && cropH > 8) {
            val cropped = Bitmap.createBitmap(whitenedBase, srcLeft, srcTop, cropW, cropH)
            val dstRect = RectF(
                box.left * outWidth,
                box.top * outHeight,
                box.right * outWidth,
                box.bottom * outHeight
            )
            canvas.drawBitmap(cropped, null, dstRect, Paint(Paint.FILTER_BITMAP_FLAG))
        }
    }

    /**
     * Advanced Paper Whitening:
     * Removes shadows, stains, yellowing, and fingerprints, turning background to pure white
     * while preserving ink colors (black, blue, red stamps).
     */
    fun removeShadowsAndStains(source: Bitmap): Bitmap {
        val width = source.width
        val height = source.height
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        val blockSize = 32
        val blocksX = (width + blockSize - 1) / blockSize
        val blocksY = (height + blockSize - 1) / blockSize
        val maxLum = IntArray(blocksX * blocksY)

        for (by in 0 until blocksY) {
            for (bx in 0 until blocksX) {
                var maxL = 0
                val startY = by * blockSize
                val endY = min(height, startY + blockSize)
                val startX = bx * blockSize
                val endX = min(width, startX + blockSize)

                for (y in startY until endY) {
                    val rowOffset = y * width
                    for (x in startX until endX) {
                        val p = pixels[rowOffset + x]
                        val r = (p shr 16) and 0xFF
                        val g = (p shr 8) and 0xFF
                        val b = p and 0xFF
                        val lum = (r * 299 + g * 587 + b * 114) / 1000
                        if (lum > maxL) maxL = lum
                    }
                }
                maxLum[by * blocksX + bx] = max(maxL, 110)
            }
        }

        val outPixels = IntArray(width * height)
        for (y in 0 until height) {
            val by = (y / blockSize).coerceIn(0, blocksY - 1)
            val rowOffset = y * width
            for (x in 0 until width) {
                val bx = (x / blockSize).coerceIn(0, blocksX - 1)
                val bgLum = maxLum[by * blocksX + bx].toFloat()

                val p = pixels[rowOffset + x]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val lum = (r * 299 + g * 587 + b * 114) / 1000

                val ratio = lum.toFloat() / bgLum
                if (ratio > 0.86f) {
                    outPixels[rowOffset + x] = Color.WHITE
                } else {
                    val darkFactor = (ratio / 0.86f).coerceIn(0f, 1f)
                    val nr = (r * darkFactor).toInt().coerceIn(0, 255)
                    val ng = (g * darkFactor).toInt().coerceIn(0, 255)
                    val nb = (b * darkFactor).toInt().coerceIn(0, 255)
                    outPixels[rowOffset + x] = Color.rgb(nr, ng, nb)
                }
            }
        }

        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        result.setPixels(outPixels, 0, width, 0, 0, width, height)
        return result
    }

    private fun autoDeskew(bitmap: Bitmap, ocrResult: OcrPageResult?): Bitmap {
        if (ocrResult == null || ocrResult.regions.size < 3) return bitmap

        var totalAngle = 0f
        var count = 0

        for (region in ocrResult.regions) {
            for (line in region.lines) {
                val box = line.boundingBox
                if (box.width > 0.25f) {
                    val dx = box.width
                    val dy = box.bottom - box.top
                    val angle = (dy / dx) * (180f / Math.PI.toFloat())
                    if (abs(angle) < 15f) {
                        totalAngle += angle
                        count++
                    }
                }
            }
        }

        val avgAngle = if (count > 0) totalAngle / count else 0f
        return if (abs(avgAngle) > 0.75f) {
            ImageUtils.rotateBitmap(bitmap, -avgAngle)
        } else {
            bitmap
        }
    }
}
