package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.streamhub.data.SampleCatalog
import com.example.streamhub.model.NavigationDestination
import com.example.streamhub.theme.AppThemeMode
import com.example.streamhub.viewmodel.StreamHubViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun testAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("StreamHub", appName)
    }

    @Test
    fun testCatalogHasMediaAndGenres() {
        assertTrue(SampleCatalog.allMedia.isNotEmpty())
        assertTrue(SampleCatalog.genres.isNotEmpty())
        val featured = SampleCatalog.allMedia.firstOrNull { it.isFeatured }
        assertNotNull(featured)
    }

    @Test
    fun testThemeSwitchingAndBackHandling() {
        val viewModel = StreamHubViewModel()
        assertEquals(AppThemeMode.OLED, viewModel.themeMode.value)

        // تبديل السمة إلى النهاري
        viewModel.toggleThemeMode()
        assertEquals(AppThemeMode.LIGHT, viewModel.themeMode.value)

        // تبديل السمة إلى OLED مجدداً
        viewModel.toggleThemeMode()
        assertEquals(AppThemeMode.OLED, viewModel.themeMode.value)

        // اختبار الرجوع بنظام أندرويد
        viewModel.navigateTo(NavigationDestination.SEARCH)
        assertEquals(NavigationDestination.SEARCH, viewModel.activeDestination.value)

        val handled = viewModel.handleSystemBackPress()
        assertTrue(handled)
        assertEquals(NavigationDestination.HOME, viewModel.activeDestination.value)

        // في الرئيسية بدون نوافذ مفتوحة، لا يستهلك الحدث ليسمح بالخروج
        val exitHandled = viewModel.handleSystemBackPress()
        assertFalse(exitHandled)
    }

    @Test
    fun testWatchlistToggle() {
        val viewModel = StreamHubViewModel()
        val testId = "test_movie_123"
        assertFalse(viewModel.watchlist.value.contains(testId))

        viewModel.toggleWatchlist(testId)
        assertTrue(viewModel.watchlist.value.contains(testId))

        viewModel.toggleWatchlist(testId)
        assertFalse(viewModel.watchlist.value.contains(testId))
    }
}
