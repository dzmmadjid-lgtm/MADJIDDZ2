package com.medad.studio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat
import com.medad.studio.ui.screens.ConvertMode
import com.medad.studio.ui.screens.ConvertScreen
import com.medad.studio.ui.screens.HomeScreen
import com.medad.studio.ui.screens.PrintScreen
import com.medad.studio.ui.screens.ReaderScreen
import com.medad.studio.ui.theme.MedadTheme

sealed interface Dest {
    data object Home : Dest
    data class Reader(val uri: Uri? = null) : Dest
    data class Convert(val mode: ConvertMode) : Dest
    data object Print : Dest
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val incoming = intent.takeIf {
            it.action == Intent.ACTION_VIEW && it.data != null
        }?.data

        setContent {
            val prefs = remember { getSharedPreferences("medad", MODE_PRIVATE) }
            var oledNight by remember { mutableStateOf(prefs.getBoolean("oled", true)) }
            var dest by remember {
                mutableStateOf<Dest>(if (incoming != null) Dest.Reader(incoming) else Dest.Home)
            }

            MedadTheme(oledNight = oledNight) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MedadRoot(
                    dest = dest,
                    oledNight = oledNight,
                    onToggleTheme = {
                        oledNight = !oledNight
                        prefs.edit().putBoolean("oled", oledNight).apply()
                    },
                    onNavigate = { dest = it },
                )
                }
            }
        }
    }
}

@Composable
private fun MedadRoot(
    dest: Dest,
    oledNight: Boolean,
    onToggleTheme: () -> Unit,
    onNavigate: (Dest) -> Unit,
) {
    AnimatedContent(
        targetState = dest,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "nav",
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) { screen ->
        when (screen) {
            Dest.Home -> HomeScreen(
                oledNight = oledNight,
                onToggleTheme = onToggleTheme,
                onOpenReader = { onNavigate(Dest.Reader()) },
                onOpenImagesToPdf = { onNavigate(Dest.Convert(ConvertMode.ImagesToPdf)) },
                onOpenPdfToImages = { onNavigate(Dest.Convert(ConvertMode.PdfToImages)) },
                onOpenPrint = { onNavigate(Dest.Print) },
            )
            is Dest.Reader -> ReaderScreen(
                incomingUri = screen.uri,
                onBack = { onNavigate(Dest.Home) },
            )
            is Dest.Convert -> ConvertScreen(
                mode = screen.mode,
                onBack = { onNavigate(Dest.Home) },
            )
            Dest.Print -> PrintScreen(onBack = { onNavigate(Dest.Home) })
        }
    }
}
