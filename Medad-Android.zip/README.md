# مداد · Medad

تطبيق أندرويد لقراءة PDF، تحويل الصور إلى PDF والعكس، والطباعة العادية أو المباشرة عبر الواي فاي.

الوضع الليلي OLED أسود مطلق. الوضع النهاري ورق دافئ.

## المتطلبات

- Android Studio Ladybug أو أحدث
- JDK 17
- Android SDK 35

## البناء محلياً

```bash
git clone https://github.com/YOUR_USER/medad.git
cd medad
```

افتح المجلد في Android Studio ثم:

1. Sync Project with Gradle Files
2. Run على جهاز أو محاكي
3. أو من الطرفية:

```bash
chmod +x gradlew
./gradlew assembleDebug
```

ملف APK يظهر في:

```
app/build/outputs/apk/debug/app-debug.apk
```

إذا لم يوجد `gradlew` بعد الاستنساخ، افتح المشروع في Android Studio وسيولّد Gradle Wrapper تلقائياً.

## الرفع إلى GitHub

```bash
git init
git add .
git commit -m "feat: Medad PDF studio for Android"
git branch -M main
git remote add origin https://github.com/YOUR_USER/medad.git
git push -u origin main
```

بعد الدفع، تبويب Actions يبني APK تلقائياً ويمكن تنزيله من Artifacts.

## الميزات

- قارئ PDF: فتح، صفحات، تكبير بالأصابع، قلب ألوان للقراءة الليلية، طباعة
- صور إلى PDF: تجميع صور داخل صفحات A4
- PDF إلى صور: استخراج كل صفحة كـ JPEG
- طباعة عادية عبر نظام أندرويد
- اكتشاف طابعات IPP / AirPrint على نفس الشبكة وإرسال مباشر

## ملاحظة عن الطباعة عبر الواي فاي

الطباعة المباشرة تحتاج طابعة على نفس شبكة الهاتف تدعم IPP أو AirPrint. إن فشل الإرسال المباشر استخدم زر الطباعة العادية.

## الرخصة

استخدمه كما تشاء.
