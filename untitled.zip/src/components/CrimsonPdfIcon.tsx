import React from 'react';

export const CrimsonPdfIcon: React.FC<{ className?: string }> = ({ className = 'w-8 h-8' }) => (
  <svg
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <rect width="64" height="64" rx="14" fill="#DC2626" />
    <path
      d="M17 14h20l11 11v27a4 4 0 0 1-4 4H17a4 4 0 0 1-4-4V18a4 4 0 0 1 4-4z"
      fill="#7F1D1D"
      opacity="0.4"
    />
    <path
      d="M19 11h19l11 11v27a4 4 0 0 1-4 4H19a4 4 0 0 1-4-4V15a4 4 0 0 1 4-4z"
      fill="#FFFFFF"
    />
    <path d="M38 11v11h11L38 11z" fill="#FCA5A5" />
    <rect x="21" y="25" width="22" height="3.5" rx="1.2" fill="#DC2626" />
    <rect x="27" y="31" width="16" height="2.8" rx="1.2" fill="#EF4444" />
    <rect
      x="21"
      y="37"
      width="22"
      height="10"
      rx="1.5"
      stroke="#DC2626"
      strokeWidth="2"
    />
    <line x1="21" y1="42" x2="43" y2="42" stroke="#DC2626" strokeWidth="1.5" />
    <line x1="32" y1="37" x2="32" y2="47" stroke="#DC2626" strokeWidth="1.5" />
  </svg>
);
