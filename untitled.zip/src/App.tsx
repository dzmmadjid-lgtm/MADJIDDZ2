import React, { useEffect, useRef, useState } from 'react';
import {
  PageLayoutObject,
  PipelineStage,
  ProcessingMode,
  PreprocessingConfig,
  ReconstructedPage,
  ThemeMode,
  createDefaultPreprocessingConfig,
} from './models/DocumentModel';
import {
  ACCEPTANCE_TEST_SPECS,
  getSampleDocumentObjects,
} from './engines/SampleDocumentsGenerator';
import { renderObjectsToDataUrl, renderPageToCanvas } from './engines/DocumentRenderer';
import { processDocumentImage } from './engines/ImagePreprocessor';
import { analyzeDocumentWithVisionEngine } from './engines/OcrAndLayoutEngine';
import { runIterativeVisualValidation } from './engines/IterativeValidator';
import {
  ExportDpi,
  ExportFormat,
  exportReconstructedDocument,
} from './engines/ExportEngine';
import { CrimsonPdfIcon } from './components/CrimsonPdfIcon';
import { ManualInspectorPanel } from './components/ManualInspectorPanel';
import { AndroidArchitectureModal } from './components/AndroidArchitectureModal';
import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  Code2,
  Download,
  Eye,
  FileCheck2,
  FileSpreadsheet,
  FileText,
  Layers,
  Moon,
  RefreshCw,
  RotateCw,
  ScanLine,
  Sliders,
  Smartphone,
  Sparkles,
  SplitSquareHorizontal,
  Sun,
  Upload,
} from 'lucide-react';

type ViewportComparisonMode =
  | 'RECONSTRUCTED_MODE_A'
  | 'CLEANED_MODE_B'
  | 'SIDE_BY_SIDE'
  | 'DIFF_HEATMAP'
  | 'SOURCE_ORIGINAL';

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>('oled');
  const [activeStage, setActiveStage] = useState<PipelineStage>('IMPORT');
  const [processingMode, setProcessingMode] = useState<ProcessingMode>(
    'MODE_A_CLEAN_RECONSTRUCTION'
  );
  const [comparisonMode, setComparisonMode] =
    useState<ViewportComparisonMode>('SIDE_BY_SIDE');

  const [selectedTestId, setSelectedTestId] = useState<string>('arabic_table');
  const [pages, setPages] = useState<ReconstructedPage[]>([]);
  const [activePageIdx, setActivePageIdx] = useState<number>(0);
  const [selectedObjectId, setSelectedObjectId] = useState<string | null>(null);

  const [showBoundingBoxes, setShowBoundingBoxes] = useState<boolean>(false);
  const [highlightLowConfidence, setHighlightLowConfidence] = useState<boolean>(true);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [statusBanner, setStatusBanner] = useState<{
    type: 'info' | 'success' | 'warning';
    text: string;
  } | null>(null);

  // Export state
  const [exportFormat, setExportFormat] = useState<ExportFormat>('PDF');
  const [exportDpi, setExportDpi] = useState<ExportDpi>(300);
  const [jpgQuality, setJpgQuality] = useState<number>(0.95);
  const [lastExportResult, setLastExportResult] = useState<{
    filename: string;
    sizeKb: number;
    dimensionsLabel: string;
  } | null>(null);

  // Modals
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState<boolean>(false);
  const [isCameraOpen, setIsCameraOpen] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const interactiveCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Dragging object on canvas
  const [dragState, setDragState] = useState<{
    objId: string;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);

  const currentPage: ReconstructedPage | undefined = pages[activePageIdx];

  // Build and initialize a sample test document (including multi-page support)
  const loadAcceptanceTestDocument = async (testId: string) => {
    setIsProcessing(true);
    setSelectedTestId(testId);
    setSelectedObjectId(null);
    setLastExportResult(null);

    try {
      const spec =
        ACCEPTANCE_TEST_SPECS.find((s) => s.id === testId) || ACCEPTANCE_TEST_SPECS[0];
      const builtPages: ReconstructedPage[] = [];

      for (let p = 0; p < spec.pageCount; p++) {
        const sample = getSampleDocumentObjects(testId, p);

        // 1. Render realistic photographed/scanned source image
        const sourceDataUrl = renderObjectsToDataUrl(sample.objects, {
          widthPx: 900,
          heightPx: 1273,
          simulateScannedPhoto: {
            angleDeg: sample.simulateAngleDeg,
            noiseLevel: sample.simulateNoiseLevel,
            shadowStrength: sample.simulateShadowStrength,
          },
        });

        // 2. Preprocess image (Mode A input & Mode B cleaned output)
        const preprocessedDataUrl = await processDocumentImage(
          sourceDataUrl,
          sample.preprocessing,
          false
        );
        const cleanedModeBDataUrl = await processDocumentImage(
          sourceDataUrl,
          sample.preprocessing,
          true
        );

        // 3. Run Iterative Visual Comparison & Refinement
        const validation = await runIterativeVisualValidation(
          preprocessedDataUrl,
          sample.objects,
          true
        );

        builtPages.push({
          pageNumber: p + 1,
          widthMm: 210,
          heightMm: 297,
          aspectRatio: 210 / 297,
          sourceImageDataUrl: sourceDataUrl,
          preprocessedImageDataUrl: preprocessedDataUrl,
          cleanedModeBImageDataUrl: cleanedModeBDataUrl,
          direction: 'rtl',
          margins: { top: 55, right: 60, bottom: 55, left: 60 },
          objects: validation.refinedObjects,
          preprocessing: sample.preprocessing,
          validationReport: validation.report,
        });
      }

      setPages(builtPages);
      setActivePageIdx(0);
      if (builtPages[0]?.objects.length > 0) {
        setSelectedObjectId(builtPages[0].objects[0].id);
      }

      const lowConfTotal = builtPages.reduce(
        (acc, pg) => acc + pg.validationReport.lowConfidenceRegionsCount,
        0
      );

      if (lowConfTotal > 0) {
        setStatusBanner({
          type: 'warning',
          text: `تمت إعادة بناء "${spec.titleAr}" مع اكتشاف (${lowConfTotal}) منطقة حبر باهت تم إبرازها للمراجعة البشرية دون تخمين.`,
        });
      } else {
        setStatusBanner({
          type: 'success',
          text: `تم تحميل وإعادة بناء "${spec.titleAr}" (${spec.pageCount} صفحة) بمطابقة بصرية ${builtPages[0].validationReport.overallVisualSimilarity}%.`,
        });
      }
    } finally {
      setIsProcessing(false);
    }
  };

  useEffect(() => {
    loadAcceptanceTestDocument('arabic_table');
  }, []);

  // Re-render interactive canvas whenever currentPage or overlays change
  useEffect(() => {
    if (!currentPage || !interactiveCanvasRef.current) return;
    renderPageToCanvas(interactiveCanvasRef.current, currentPage.objects, {
      widthPx: 900,
      heightPx: 1273,
      highlightSelectedId: selectedObjectId,
      highlightLowConfidence,
      showBoundingBoxes,
    });
  }, [
    currentPage,
    selectedObjectId,
    highlightLowConfidence,
    showBoundingBoxes,
    comparisonMode,
    processingMode,
  ]);

  // Handle custom uploaded photo/scan file
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setSelectedTestId('custom_upload');
    setStatusBanner({
      type: 'info',
      text: 'جاري معالجة الصورة المرفوعة وتصحيح الإضاءة وتحليل التخطيط البصري...',
    });

    try {
      const reader = new FileReader();
      const sourceDataUrl: string = await new Promise((resolve, reject) => {
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      await processCustomSourceImage(sourceDataUrl, file.name);
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const processCustomSourceImage = async (sourceDataUrl: string, labelName: string) => {
    const defaultPrep = createDefaultPreprocessingConfig();
    const preprocessedDataUrl = await processDocumentImage(
      sourceDataUrl,
      defaultPrep,
      false
    );
    const cleanedModeBDataUrl = await processDocumentImage(
      sourceDataUrl,
      defaultPrep,
      true
    );

    const analysis = await analyzeDocumentWithVisionEngine(preprocessedDataUrl);
    const validation = await runIterativeVisualValidation(
      preprocessedDataUrl,
      analysis.objects,
      true
    );

    const newPage: ReconstructedPage = {
      pageNumber: 1,
      widthMm: 210,
      heightMm: 297,
      aspectRatio: 210 / 297,
      sourceImageDataUrl: sourceDataUrl,
      preprocessedImageDataUrl: preprocessedDataUrl,
      cleanedModeBImageDataUrl: cleanedModeBDataUrl,
      direction: 'rtl',
      margins: analysis.margins,
      objects: validation.refinedObjects,
      preprocessing: defaultPrep,
      validationReport: validation.report,
    };

    setPages([newPage]);
    setActivePageIdx(0);
    setSelectedObjectId(newPage.objects[0]?.id || null);

    setStatusBanner({
      type: analysis.noticeAr ? 'warning' : 'success',
      text:
        analysis.noticeAr ||
        `تمت إعادة بناء الوثيقة "${labelName}" واستخراج (${newPage.objects.length}) عنصر تخطيطي.`,
    });
  };

  // Update preprocessing settings for current page
  const handleUpdatePreprocessing = async (partial: Partial<PreprocessingConfig>) => {
    if (!currentPage) return;
    const updatedPrep: PreprocessingConfig = {
      ...currentPage.preprocessing,
      ...partial,
    };

    setIsProcessing(true);
    try {
      const preprocessedDataUrl = await processDocumentImage(
        currentPage.sourceImageDataUrl,
        updatedPrep,
        false
      );
      const cleanedModeBDataUrl = await processDocumentImage(
        currentPage.sourceImageDataUrl,
        updatedPrep,
        true
      );
      const validation = await runIterativeVisualValidation(
        preprocessedDataUrl,
        currentPage.objects,
        false
      );

      const nextPages = pages.map((pg, idx) =>
        idx === activePageIdx
          ? {
              ...pg,
              preprocessing: updatedPrep,
              preprocessedImageDataUrl: preprocessedDataUrl,
              cleanedModeBImageDataUrl: cleanedModeBDataUrl,
              validationReport: validation.report,
            }
          : pg
      );
      setPages(nextPages);
    } finally {
      setIsProcessing(false);
    }
  };

  // Trigger Iterative Visual Refinement Pass manually
  const handleRunIterativeRefinement = async () => {
    if (!currentPage) return;
    setIsProcessing(true);
    try {
      const validation = await runIterativeVisualValidation(
        currentPage.preprocessedImageDataUrl,
        currentPage.objects,
        true
      );
      const nextPages = pages.map((pg, idx) =>
        idx === activePageIdx
          ? {
              ...pg,
              objects: validation.refinedObjects,
              validationReport: validation.report,
            }
          : pg
      );
      setPages(nextPages);
      setStatusBanner({
        type: 'success',
        text: `اكتملت دورة التصحيح البصري التكراري — نسبة المطابقة الهندسية الحالية: ${validation.report.overallVisualSimilarity}%.`,
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Update a single layout object on the active page without touching unrelated elements
  const handleUpdateObject = (updatedObj: PageLayoutObject) => {
    if (!currentPage) return;
    const nextObjects = currentPage.objects.map((o) =>
      o.id === updatedObj.id ? updatedObj : o
    );
    setPages(
      pages.map((pg, idx) =>
        idx === activePageIdx ? { ...pg, objects: nextObjects } : pg
      )
    );
  };

  const handleAddObject = (newObj: PageLayoutObject) => {
    if (!currentPage) return;
    setPages(
      pages.map((pg, idx) =>
        idx === activePageIdx ? { ...pg, objects: [...pg.objects, newObj] } : pg
      )
    );
  };

  const handleDeleteObject = (id: string) => {
    if (!currentPage) return;
    const nextObjects = currentPage.objects.filter((o) => o.id !== id);
    setPages(
      pages.map((pg, idx) =>
        idx === activePageIdx ? { ...pg, objects: nextObjects } : pg
      )
    );
    setSelectedObjectId(nextObjects[0]?.id || null);
  };

  // Interactive canvas click & drag to select/move objects directly on the reconstructed page
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!currentPage || !interactiveCanvasRef.current) return;
    const rect = interactiveCanvasRef.current.getBoundingClientRect();
    const normX = ((e.clientX - rect.left) / rect.width) * 1000;
    const normY = ((e.clientY - rect.top) / rect.height) * 1000;

    // Find topmost object containing (normX, normY)
    const clicked = [...currentPage.objects]
      .reverse()
      .find(
        (obj) =>
          normX >= obj.x &&
          normX <= obj.x + obj.width &&
          normY >= obj.y &&
          normY <= obj.y + obj.height
      );

    if (clicked) {
      setSelectedObjectId(clicked.id);
      setDragState({
        objId: clicked.id,
        startX: normX,
        startY: normY,
        origX: clicked.x,
        origY: clicked.y,
      });
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!dragState || !currentPage || !interactiveCanvasRef.current) return;
    const rect = interactiveCanvasRef.current.getBoundingClientRect();
    const normX = ((e.clientX - rect.left) / rect.width) * 1000;
    const normY = ((e.clientY - rect.top) / rect.height) * 1000;

    const dx = Math.round(normX - dragState.startX);
    const dy = Math.round(normY - dragState.startY);

    const targetObj = currentPage.objects.find((o) => o.id === dragState.objId);
    if (!targetObj) return;

    handleUpdateObject({
      ...targetObj,
      x: Math.max(10, Math.min(980 - targetObj.width, dragState.origX + dx)),
      y: Math.max(10, Math.min(980 - targetObj.height, dragState.origY + dy)),
    });
  };

  const handleCanvasMouseUp = () => {
    setDragState(null);
  };

  // Camera capture handlers
  const openCameraModal = async () => {
    setIsCameraOpen(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch {
      setStatusBanner({
        type: 'warning',
        text: 'تعذر الوصول إلى الكاميرا المباشرة في هذا المتصفح — يمكنك رفع صورة أو اختيار أحد اختبارات القبول العشرة.',
      });
      setIsCameraOpen(false);
    }
  };

  const closeCameraModal = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((t) => t.stop());
    }
    setIsCameraOpen(false);
  };

  const captureCameraFrame = async () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 1000;
    canvas.height = videoRef.current.videoHeight || 1414;
    const ctx = canvas.getContext('2d');
    ctx?.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/png');
    closeCameraModal();
    setIsProcessing(true);
    try {
      await processCustomSourceImage(dataUrl, 'camera_capture');
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle PDF / PNG / JPG Export
  const handleExportDocument = async (formatOverride?: ExportFormat) => {
    if (!pages.length) return;
    const fmt = formatOverride || exportFormat;
    setIsProcessing(true);
    try {
      const res = await exportReconstructedDocument(pages, {
        format: fmt,
        dpi: exportDpi,
        jpgQuality,
        processingMode,
        filenamePrefix: `CrimsonPDF_${selectedTestId}`,
      });
      setLastExportResult(res);
      setStatusBanner({
        type: 'success',
        text: `تم تصدير المستند بنجاح: ${res.filename} (${res.sizeKb} KB · ${res.dimensionsLabel}).`,
      });
    } catch (err: any) {
      setStatusBanner({
        type: 'warning',
        text: err?.message || 'حدث خطأ أثناء تصدير المستند.',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Theme classes (Day / Night / Pure OLED)
  const rootThemeClass =
    theme === 'oled'
      ? 'bg-black text-white'
      : theme === 'night'
      ? 'bg-slate-950 text-slate-100'
      : 'bg-slate-50 text-slate-900';

  const headerThemeClass =
    theme === 'oled'
      ? 'bg-[#050505] border-[#1F1F1F]'
      : theme === 'night'
      ? 'bg-slate-900 border-slate-800'
      : 'bg-white border-slate-200';

  const panelThemeClass =
    theme === 'oled'
      ? 'bg-[#0A0A0A] border-[#1F1F1F]'
      : theme === 'night'
      ? 'bg-slate-900 border-slate-800'
      : 'bg-white border-slate-200';

  const mutedTextClass =
    theme === 'oled'
      ? 'text-neutral-400'
      : theme === 'night'
      ? 'text-slate-400'
      : 'text-slate-500';

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-150 ${rootThemeClass}`}>
      {/* STRICT 3-ZONE TOP BAR CONTRACT */}
      <header
        className={`flex items-center justify-between px-6 py-3.5 border-b sticky top-0 z-30 ${headerThemeClass}`}
      >
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveStage('IMPORT');
          }}
          className="text-lg font-bold tracking-tight text-red-600 whitespace-nowrap"
        >
          CrimsonPDF Reconstruct
        </a>

        {/* Zone 2: 5 clean stage navigation links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium">
          {(
            [
              { id: 'IMPORT', label: 'استيراد وفحص' },
              { id: 'PREPROCESS', label: 'المعالجة والمنظور' },
              { id: 'ANALYZE_RECONSTRUCT', label: 'إعادة البناء الهيكلي' },
              { id: 'VALIDATE_EDIT', label: 'المقارنة والضبط اليدوي' },
              { id: 'EXPORT', label: 'التصدير الطباعي' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveStage(item.id)}
              className={`py-1 border-b-2 transition-colors whitespace-nowrap ${
                activeStage === item.id
                  ? 'border-red-600 text-red-600 font-semibold'
                  : 'border-transparent opacity-75 hover:opacity-100'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Primary Actions (Theme Segmented Control + Export PDF) */}
        <div className="flex items-center gap-2.5">
          <div
            className={`flex items-center p-1 rounded-lg border ${
              theme === 'oled'
                ? 'bg-black border-[#242424]'
                : theme === 'night'
                ? 'bg-slate-950 border-slate-800'
                : 'bg-slate-100 border-slate-200'
            }`}
          >
            <button
              type="button"
              onClick={() => setTheme('day')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md flex items-center gap-1 transition-colors whitespace-nowrap ${
                theme === 'day'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              <Sun className="w-3.5 h-3.5" />
              <span>نهاري</span>
            </button>
            <button
              type="button"
              onClick={() => setTheme('night')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md flex items-center gap-1 transition-colors whitespace-nowrap ${
                theme === 'night'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              <Moon className="w-3.5 h-3.5" />
              <span>ليلي</span>
            </button>
            <button
              type="button"
              onClick={() => setTheme('oled')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md flex items-center gap-1 transition-colors whitespace-nowrap ${
                theme === 'oled'
                  ? 'bg-red-600 text-white shadow-sm'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>OLED</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => handleExportDocument('PDF')}
            disabled={isProcessing}
            className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير PDF</span>
          </button>
        </div>
      </header>

      {/* Sub-header Identity & Processing Mode Strip */}
      <div className={`border-b px-6 py-3 ${panelThemeClass}`}>
        <div className="max-w-[1440px] mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <CrimsonPdfIcon className="w-10 h-10 shrink-0" />
            <div>
              <div className="flex items-center gap-2 text-xs font-mono opacity-75">
                <span>com.crimsonpdf.reconstructor</span>
                <span aria-hidden="true">·</span>
                <span>محرك إعادة بناء الصفحة والجداول العربية</span>
                <span aria-hidden="true">·</span>
                <span>سلطة المصدر ١٠٠٪ بدون هلوسة</span>
              </div>
              <h1 className="text-base font-bold mt-0.5">
                إعادة بناء المستندات الورقية الممسوحة ضوئياً (PDF / PNG / JPG)
              </h1>
            </div>
          </div>

          {/* Processing Mode Switcher (Section 11: Mode A vs Mode B) + Android Code Button */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div
              className={`flex items-center p-1 rounded-lg border ${
                theme === 'oled'
                  ? 'bg-black border-[#242424]'
                  : theme === 'night'
                  ? 'bg-slate-950 border-slate-800'
                  : 'bg-slate-100 border-slate-200'
              }`}
            >
              <button
                type="button"
                onClick={() => {
                  setProcessingMode('MODE_A_CLEAN_RECONSTRUCTION');
                  setComparisonMode('SIDE_BY_SIDE');
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  processingMode === 'MODE_A_CLEAN_RECONSTRUCTION'
                    ? 'bg-red-600 text-white'
                    : 'opacity-75 hover:opacity-100'
                }`}
              >
                الوضع (أ): إعادة بناء هيكلي نظيف (Mode A)
              </button>
              <button
                type="button"
                onClick={() => {
                  setProcessingMode('MODE_B_IMAGE_CLEANING');
                  setComparisonMode('CLEANED_MODE_B');
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  processingMode === 'MODE_B_IMAGE_CLEANING'
                    ? 'bg-red-600 text-white'
                    : 'opacity-75 hover:opacity-100'
                }`}
              >
                الوضع (ب): تنظيف الصورة الأصلية (Mode B)
              </button>
            </div>

            <button
              type="button"
              onClick={() => setIsAndroidModalOpen(true)}
              className="px-3 py-2 text-xs font-medium rounded-lg border border-current/20 hover:bg-current/5 transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <Code2 className="w-4 h-4 text-red-500" />
              <span>كود مشروع Android (Kotlin)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Status Notification Bar */}
      {statusBanner && (
        <div
          className={`px-6 py-2.5 text-xs border-b flex items-center justify-between ${
            statusBanner.type === 'warning'
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
              : statusBanner.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-blue-500/10 border-blue-500/30 text-blue-400'
          }`}
        >
          <div className="max-w-[1440px] mx-auto w-full flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              {statusBanner.type === 'warning' ? (
                <AlertTriangle className="w-4 h-4 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              )}
              <span>{statusBanner.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setStatusBanner(null)}
              className="text-xs underline opacity-80 hover:opacity-100 whitespace-nowrap"
            >
              إخفاء
            </button>
          </div>
        </div>
      )}

      {/* MAIN WORKSPACE CONTAINER (1440px Baseline) */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* RIGHT COLUMN (Controls, Pipeline Stages, 10 Test Cases, Preprocessing, Inspector) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Pipeline Stage Tabs for Quick Access */}
          <div className={`p-1.5 rounded-lg border grid grid-cols-5 gap-1 ${panelThemeClass}`}>
            {(
              [
                { id: 'IMPORT', label: '١. الاستيراد', icon: Upload },
                { id: 'PREPROCESS', label: '٢. المعالجة', icon: Sliders },
                { id: 'ANALYZE_RECONSTRUCT', label: '٣. التحليل', icon: ScanLine },
                { id: 'VALIDATE_EDIT', label: '٤. الضبط', icon: Layers },
                { id: 'EXPORT', label: '٥. التصدير', icon: FileCheck2 },
              ] as const
            ).map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                type="button"
                onClick={() => setActiveStage(id)}
                className={`py-2 px-1.5 rounded-md text-xs font-medium flex flex-col items-center gap-1 transition-colors whitespace-nowrap ${
                  activeStage === id
                    ? 'bg-red-600 text-white'
                    : 'opacity-75 hover:opacity-100 hover:bg-current/5'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{label}</span>
              </button>
            ))}
          </div>

          {/* STAGE 1: IMPORT IMAGE & 10 ACCEPTANCE TEST DOCUMENTS */}
          {activeStage === 'IMPORT' && (
            <div className={`border rounded-lg p-4 space-y-4 ${panelThemeClass}`}>
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold">
                    ٠١. استيراد صورة وثيقة أو اختبار حالات القبول العشر
                  </h2>
                  <p className={`text-xs mt-0.5 ${mutedTextClass}`}>
                    ارفع صورة لمستند مطبوع أو التقط بالكاميرا أو اختبر النماذج المعيارية العشرة
                  </p>
                </div>
              </div>

              {/* Upload & Camera Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="py-3 px-4 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
                >
                  <Upload className="w-4 h-4" />
                  <span>رفع صورة مستند / مسح ضوئي</span>
                </button>
                <button
                  type="button"
                  onClick={openCameraModal}
                  className="py-3 px-4 rounded-lg border border-current/20 hover:bg-current/5 text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
                >
                  <Camera className="w-4 h-4 text-red-500" />
                  <span>التقاط وثيقة بالكاميرا</span>
                </button>
              </div>

              {/* 10 Real Acceptance Test Documents (Section 20) */}
              <div className="space-y-2 pt-2 border-t border-current/10">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold">
                    حالات الاختبار المعيارية العشر (Final Acceptance Test Suite)
                  </span>
                  <span className={`text-xs font-mono tabular-nums ${mutedTextClass}`}>
                    10 / 10 جاهزة
                  </span>
                </div>

                <div className="space-y-1.5 max-h-[380px] overflow-y-auto pr-1">
                  {ACCEPTANCE_TEST_SPECS.map((spec) => {
                    const isSelected = selectedTestId === spec.id;
                    return (
                      <button
                        key={spec.id}
                        type="button"
                        onClick={() => loadAcceptanceTestDocument(spec.id)}
                        className={`w-full text-right p-3 rounded-lg border transition-colors flex flex-col gap-1 ${
                          isSelected
                            ? 'border-red-600 bg-red-600/10'
                            : 'border-current/10 hover:border-current/30 hover:bg-current/[0.03]'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-bold">{spec.titleAr}</span>
                          <span className={`text-[11px] font-mono ${mutedTextClass}`}>
                            {spec.categoryAr} · {spec.pageCount === 2 ? 'صفحتان' : 'صفحة ١'}
                          </span>
                        </div>
                        <p className={`text-xs leading-relaxed ${mutedTextClass}`}>
                          {spec.descriptionAr}
                        </p>
                        <div className="text-[11px] text-red-500/90 font-medium">
                          التحدي الهندسي المحاكى: {spec.simulatedIssueAr}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* STAGE 2: IMAGE PREPROCESSING (Perspective, Deskew, Shadow Removal, Contrast) */}
          {activeStage === 'PREPROCESS' && currentPage && (
            <div className={`border rounded-lg p-4 space-y-4 ${panelThemeClass}`}>
              <div className="flex items-center justify-between border-b pb-3 border-current/10">
                <div>
                  <h2 className="text-sm font-bold">
                    ٠٢. المعالجة المسبقة للصورة وتصحيح المنظور والظلال
                  </h2>
                  <p className={`text-xs mt-0.5 ${mutedTextClass}`}>
                    تُنفذ قبل التعرف الضوئي وإعادة البناء دون المساس بمحتوى الوثيقة الأصلي
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    handleUpdatePreprocessing(createDefaultPreprocessingConfig())
                  }
                  className="px-2.5 py-1 text-xs rounded border border-current/20 hover:bg-current/5 whitespace-nowrap"
                >
                  إعادة الضبط
                </button>
              </div>

              {/* Deskew Angle Slider */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium">تصحيح زاوية الميلان (Deskew Angle)</span>
                  <span className="font-mono tabular-nums">
                    {currentPage.preprocessing.deskewAngleDeg.toFixed(1)}°
                  </span>
                </div>
                <input
                  type="range"
                  min={-12}
                  max={12}
                  step={0.2}
                  value={currentPage.preprocessing.deskewAngleDeg}
                  onChange={(e) =>
                    handleUpdatePreprocessing({
                      deskewAngleDeg: Number(e.target.value),
                    })
                  }
                  className="w-full accent-red-600"
                />
              </div>

              {/* 90-degree Rotation Buttons */}
              <div className="flex items-center justify-between text-xs pt-1">
                <span className="font-medium">تدوير الصفحة (Rotation)</span>
                <div className="flex items-center gap-1.5">
                  {([0, 90, 180, 270] as const).map((deg) => (
                    <button
                      key={deg}
                      type="button"
                      onClick={() => handleUpdatePreprocessing({ rotationDeg: deg })}
                      className={`px-2.5 py-1 rounded border font-mono tabular-nums flex items-center gap-1 ${
                        currentPage.preprocessing.rotationDeg === deg
                          ? 'bg-red-600 text-white border-red-600'
                          : 'border-current/20 hover:bg-current/5'
                      }`}
                    >
                      <RotateCw className="w-3 h-3" />
                      <span>{deg}°</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Shadow Removal & Background Normalization */}
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-current/10">
                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={currentPage.preprocessing.removeShadows}
                    onChange={(e) =>
                      handleUpdatePreprocessing({ removeShadows: e.target.checked })
                    }
                    className="accent-red-600 w-4 h-4"
                  />
                  <span>إزالة ظلال الإضاءة (Shadow Removal)</span>
                </label>

                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={currentPage.preprocessing.normalizeBackground}
                    onChange={(e) =>
                      handleUpdatePreprocessing({
                        normalizeBackground: e.target.checked,
                      })
                    }
                    className="accent-red-600 w-4 h-4"
                  />
                  <span>توحيد بياض الورقة (Background Norm)</span>
                </label>
              </div>

              {/* Shadow Strength Slider */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span>قوة إزالة الظل وتوحيد الإضاءة المحلية</span>
                  <span className="font-mono tabular-nums">
                    {currentPage.preprocessing.shadowStrength}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={currentPage.preprocessing.shadowStrength}
                  onChange={(e) =>
                    handleUpdatePreprocessing({
                      shadowStrength: Number(e.target.value),
                    })
                  }
                  className="w-full accent-red-600"
                />
              </div>

              {/* Contrast Normalization Slider */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span>تعزيز التباين وحدة الحبر (Contrast & Ink Boost)</span>
                  <span className="font-mono tabular-nums">
                    {currentPage.preprocessing.contrastBoost}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={currentPage.preprocessing.contrastBoost}
                  onChange={(e) =>
                    handleUpdatePreprocessing({
                      contrastBoost: Number(e.target.value),
                    })
                  }
                  className="w-full accent-red-600"
                />
              </div>

              {/* Denoise Slider */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span>تقليل الضوضاء النقطية (Noise Reduction)</span>
                  <span className="font-mono tabular-nums">
                    {currentPage.preprocessing.denoiseLevel}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={currentPage.preprocessing.denoiseLevel}
                  onChange={(e) =>
                    handleUpdatePreprocessing({
                      denoiseLevel: Number(e.target.value),
                    })
                  }
                  className="w-full accent-red-600"
                />
              </div>
            </div>
          )}

          {/* STAGE 3: ANALYZE DOCUMENT & LAYOUT RECONSTRUCTION MODEL */}
          {activeStage === 'ANALYZE_RECONSTRUCT' && currentPage && (
            <div className={`border rounded-lg p-4 space-y-4 ${panelThemeClass}`}>
              <div>
                <h2 className="text-sm font-bold">
                  ٠٣. تحليل بنية الصفحة وإعادة البناء بالإحداثيات
                </h2>
                <p className={`text-xs mt-0.5 ${mutedTextClass}`}>
                  فصل تام بين طبقة التعرف الضوئي (OCR) وطبقة إعادة بناء التخطيط والجداول
                </p>
              </div>

              {/* Hierarchy of Authority Notice (Section 19) */}
              <div className="p-3 rounded-lg border border-current/15 bg-current/[0.02] space-y-1.5">
                <div className="text-xs font-semibold text-red-500">
                  التسلسل الهرمي الصارم لمنع الهلوسة (Section 19 Hierarchy):
                </div>
                <div className="text-[11px] font-mono leading-relaxed">
                  ١. الصورة المصدرية (SOURCE IMAGE) ← ٢. البنية المكتشفة (DETECTED STRUCTURE) ← ٣. نتيجة OCR ← ٤. تصحيح المستخدم ← ٥. الافتراضات الافتراضية
                </div>
              </div>

              {/* Object Type Breakdown Summary */}
              <div className="grid grid-cols-3 gap-2.5">
                {[
                  {
                    label: 'إجمالي الكائنات',
                    count: currentPage.objects.length,
                  },
                  {
                    label: 'الجداول المهيكلة',
                    count: currentPage.objects.filter((o) => o.type === 'TABLE').length,
                  },
                  {
                    label: 'مناطق المراجعة',
                    count: currentPage.validationReport.lowConfidenceRegionsCount,
                  },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="p-3 rounded-lg border border-current/10 flex flex-col gap-1"
                  >
                    <span className={`text-xs ${mutedTextClass}`}>{stat.label}</span>
                    <span className="text-lg font-bold font-mono tabular-nums">
                      {stat.count}
                    </span>
                  </div>
                ))}
              </div>

              {/* Re-run On-Device or Vision Cloud Reconstruction */}
              <div className="space-y-2 pt-2 border-t border-current/10">
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={async () => {
                    setIsProcessing(true);
                    try {
                      const res = await analyzeDocumentWithVisionEngine(
                        currentPage.preprocessedImageDataUrl,
                        currentPage.objects
                      );
                      const val = await runIterativeVisualValidation(
                        currentPage.preprocessedImageDataUrl,
                        res.objects,
                        true
                      );
                      setPages(
                        pages.map((pg, idx) =>
                          idx === activePageIdx
                            ? {
                                ...pg,
                                objects: val.refinedObjects,
                                validationReport: val.report,
                              }
                            : pg
                        )
                      );
                      setStatusBanner({
                        type: 'success',
                        text: `تم تحديث نموذج التخطيط الهندسي (${val.refinedObjects.length} عنصر).`,
                      });
                    } finally {
                      setIsProcessing(false);
                    }
                  }}
                  className="w-full py-2.5 px-4 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>إعادة تحليل الصفحة وبناء نموذج الإحداثيات والجداول</span>
                </button>
              </div>
            </div>
          )}

          {/* STAGE 4: VISUAL COMPARISON / ITERATIVE CORRECTION & MANUAL INSPECTOR */}
          {activeStage === 'VALIDATE_EDIT' && currentPage && (
            <div className="space-y-4">
              {/* Visual Comparison & Iterative Correction Card (Section 13) */}
              <div className={`border rounded-lg p-4 space-y-3 ${panelThemeClass}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-sm font-bold">
                      المقارنة البصرية والتصحيح التكراري (Iterative Validation)
                    </h2>
                    <p className={`text-xs ${mutedTextClass}`}>
                      مقارنة الصفحة المعاد بناؤها بالصورة المصدرية لضبط المواقع والأبعاد
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleRunIterativeRefinement}
                    disabled={isProcessing}
                    className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-medium flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${isProcessing ? 'animate-spin' : ''}`}
                    />
                    <span>تشغيل دورة مطابقة</span>
                  </button>
                </div>

                {/* Metrics Table */}
                <div className="space-y-2 pt-1">
                  {currentPage.validationReport.metrics.map((m) => (
                    <div
                      key={m.labelEn}
                      className="p-2.5 rounded border border-current/10 flex items-center justify-between gap-3 text-xs"
                    >
                      <div>
                        <div className="font-semibold">{m.labelAr}</div>
                        <div className={`text-[11px] ${mutedTextClass}`}>{m.detailsAr}</div>
                      </div>
                      <span
                        className={`font-mono tabular-nums font-bold text-sm shrink-0 ${
                          m.status === 'warning' ? 'text-amber-500' : 'text-emerald-500'
                        }`}
                      >
                        {m.score}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Manual Coordinate & Table Inspector (Section 14) */}
              <ManualInspectorPanel
                theme={theme}
                objects={currentPage.objects}
                selectedObjectId={selectedObjectId}
                onSelectObject={setSelectedObjectId}
                onUpdateObject={handleUpdateObject}
                onAddObject={handleAddObject}
                onDeleteObject={handleDeleteObject}
              />
            </div>
          )}

          {/* STAGE 5: EXPORT PDF / PNG / JPG (Section 12) */}
          {activeStage === 'EXPORT' && currentPage && (
            <div className={`border rounded-lg p-4 space-y-4 ${panelThemeClass}`}>
              <div>
                <h2 className="text-sm font-bold">
                  ٠٥. التصدير بجودة طباعية (PDF / PNG / JPG)
                </h2>
                <p className={`text-xs mt-0.5 ${mutedTextClass}`}>
                  إخراج نهائي حاد للنصوص العربية والجداول بدون الحاجة إلى Microsoft Word
                </p>
              </div>

              {/* Format Selection */}
              <div className="grid grid-cols-3 gap-2.5">
                {(['PDF', 'PNG', 'JPG'] as const).map((fmt) => (
                  <button
                    key={fmt}
                    type="button"
                    onClick={() => setExportFormat(fmt)}
                    className={`p-3 rounded-lg border text-center transition-colors ${
                      exportFormat === fmt
                        ? 'border-red-600 bg-red-600/15 font-bold'
                        : 'border-current/15 hover:bg-current/5'
                    }`}
                  >
                    <div className="text-sm font-mono">{fmt}</div>
                    <div className={`text-[11px] mt-0.5 ${mutedTextClass}`}>
                      {fmt === 'PDF'
                        ? `مستند (${pages.length} ص)`
                        : fmt === 'PNG'
                        ? 'صورة غير مضغوطة'
                        : 'صورة قياسية'}
                    </div>
                  </button>
                ))}
              </div>

              {/* Resolution / DPI Selector */}
              <div className="space-y-1.5">
                <label className="block text-xs font-medium">
                  دقة التصدير والطباعة (Print Resolution DPI)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { dpi: 150, desc: '150 DPI · سريعة' },
                      { dpi: 300, desc: '300 DPI · طباعة قياسية' },
                      { dpi: 400, desc: '400 DPI · أرشفة فائقة' },
                    ] as const
                  ).map((item) => (
                    <button
                      key={item.dpi}
                      type="button"
                      onClick={() => setExportDpi(item.dpi)}
                      className={`py-2 px-2.5 rounded border text-xs font-mono tabular-nums transition-colors ${
                        exportDpi === item.dpi
                          ? 'bg-red-600 text-white border-red-600'
                          : 'border-current/20 hover:bg-current/5'
                      }`}
                    >
                      {item.desc}
                    </button>
                  ))}
                </div>
              </div>

              {/* JPG Quality slider if JPG */}
              {exportFormat === 'JPG' && (
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span>جودة ضغط الصورة (JPG Quality)</span>
                    <span className="font-mono tabular-nums">
                      {Math.round(jpgQuality * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.8}
                    max={1}
                    step={0.05}
                    value={jpgQuality}
                    onChange={(e) => setJpgQuality(Number(e.target.value))}
                    className="w-full accent-red-600"
                  />
                </div>
              )}

              {/* Primary Export Action Button */}
              <button
                type="button"
                onClick={() => handleExportDocument()}
                disabled={isProcessing}
                className="w-full py-3 px-4 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>
                  تصدير وتنزيل المستند بصيغة {exportFormat} ({exportDpi} DPI)
                </span>
              </button>

              {lastExportResult && (
                <div className="p-3 rounded-lg border border-emerald-500/40 bg-emerald-500/10 text-xs space-y-1">
                  <div className="font-semibold text-emerald-400">
                    تم تجهيز وتنزيل الملف بنجاح:
                  </div>
                  <div className="font-mono tabular-nums" dir="ltr">
                    {lastExportResult.filename} — {lastExportResult.sizeKb} KB —{' '}
                    {lastExportResult.dimensionsLabel}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Always show Manual Inspector below if inIMPORT or ANALYZE for rapid editing */}
          {activeStage !== 'VALIDATE_EDIT' && currentPage && (
            <ManualInspectorPanel
              theme={theme}
              objects={currentPage.objects}
              selectedObjectId={selectedObjectId}
              onSelectObject={setSelectedObjectId}
              onUpdateObject={handleUpdateObject}
              onAddObject={handleAddObject}
              onDeleteObject={handleDeleteObject}
            />
          )}
        </div>

        {/* LEFT COLUMN (Interactive Document Canvas Viewport & Side-by-Side Comparison) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          {/* Viewport Toolbar */}
          <div
            className={`border rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 ${panelThemeClass}`}
          >
            {/* View Mode Selector */}
            <div className="flex flex-wrap items-center gap-1.5">
              {(
                [
                  {
                    id: 'SIDE_BY_SIDE',
                    label: 'مقارنة جنباً إلى جنب',
                    icon: SplitSquareHorizontal,
                  },
                  {
                    id: 'RECONSTRUCTED_MODE_A',
                    label: 'الورقة المعاد بناؤها (Mode A)',
                    icon: FileText,
                  },
                  {
                    id: 'CLEANED_MODE_B',
                    label: 'تنظيف الصورة (Mode B)',
                    icon: Eye,
                  },
                  {
                    id: 'DIFF_HEATMAP',
                    label: 'خريطة المطابقة البصرية',
                    icon: FileSpreadsheet,
                  },
                ] as const
              ).map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setComparisonMode(id)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                    comparisonMode === id
                      ? 'bg-red-600 text-white'
                      : 'border border-current/15 hover:bg-current/5'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{label}</span>
                </button>
              ))}
            </div>

            {/* Canvas Overlay Toggles & Multi-page Selector */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowBoundingBoxes((v) => !v)}
                className={`px-2.5 py-1.5 rounded text-xs border transition-colors whitespace-nowrap ${
                  showBoundingBoxes
                    ? 'border-red-600 bg-red-600/15 font-semibold'
                    : 'border-current/20 opacity-75'
                }`}
              >
                إظهار الإحداثيات
              </button>

              {pages.length > 1 && (
                <div className="flex items-center gap-1 border-r pr-2 border-current/15">
                  {pages.map((pg, idx) => (
                    <button
                      key={pg.pageNumber}
                      type="button"
                      onClick={() => {
                        setActivePageIdx(idx);
                        setSelectedObjectId(pages[idx].objects[0]?.id || null);
                      }}
                      className={`px-2.5 py-1 rounded text-xs font-mono tabular-nums ${
                        activePageIdx === idx
                          ? 'bg-red-600 text-white font-bold'
                          : 'border border-current/20'
                      }`}
                    >
                      ص {pg.pageNumber}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Document Canvas Stage */}
          {currentPage && (
            <div
              className={`border rounded-lg p-4 flex-1 flex flex-col justify-center ${panelThemeClass}`}
            >
              {comparisonMode === 'SIDE_BY_SIDE' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                  {/* Source Photograph */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs px-1">
                      <span className="font-semibold">
                        ١. الصورة المصدرية الملتقطة (Source Image)
                      </span>
                      <span className={`font-mono ${mutedTextClass}`}>
                        المرجع الأصلي ١٠٠٪
                      </span>
                    </div>
                    <div className="rounded-lg overflow-hidden border border-current/20 bg-neutral-900 shadow-md">
                      <img
                        src={currentPage.sourceImageDataUrl}
                        alt="الصورة المصدرية للمستند"
                        referrerPolicy="no-referrer"
                        className="w-full h-auto block"
                      />
                    </div>
                  </div>

                  {/* Digitally Reconstructed Render (Interactive Canvas) */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs px-1">
                      <span className="font-semibold text-red-500">
                        ٢. المستند المعاد بناؤه رقمياً (انقر على أي عنصر لتحريره)
                      </span>
                      <span className="font-mono tabular-nums text-emerald-500 font-semibold">
                        مطابقة {currentPage.validationReport.overallVisualSimilarity}%
                      </span>
                    </div>
                    <div className="rounded-lg overflow-hidden border-2 border-red-600/60 bg-white shadow-md">
                      <canvas
                        ref={interactiveCanvasRef}
                        onMouseDown={handleCanvasMouseDown}
                        onMouseMove={handleCanvasMouseMove}
                        onMouseUp={handleCanvasMouseUp}
                        onMouseLeave={handleCanvasMouseUp}
                        className="w-full h-auto block cursor-pointer"
                      />
                    </div>
                  </div>
                </div>
              ) : comparisonMode === 'RECONSTRUCTED_MODE_A' ? (
                <div className="max-w-2xl mx-auto w-full space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold">
                      المعاينة الكاملة للورقة المعاد بناؤها (Mode A — Clean Reconstruction) — انقر أو اسحب أي عنصر
                    </span>
                    <span className="font-mono tabular-nums">A4 · 210 × 297 mm</span>
                  </div>
                  <div className="rounded-lg overflow-hidden border border-current/20 bg-white shadow-lg">
                    <canvas
                      ref={interactiveCanvasRef}
                      onMouseDown={handleCanvasMouseDown}
                      onMouseMove={handleCanvasMouseMove}
                      onMouseUp={handleCanvasMouseUp}
                      onMouseLeave={handleCanvasMouseUp}
                      className="w-full h-auto block cursor-pointer"
                    />
                  </div>
                </div>
              ) : comparisonMode === 'CLEANED_MODE_B' ? (
                <div className="max-w-2xl mx-auto w-full space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold">
                      الوضع (ب): تنظيف الوثيقة المصورة مع إبقاء المظهر الفوتوغرافي الأصلي (Mode B — Image Cleaning)
                    </span>
                    <span className="font-mono tabular-nums">إزالة الظلال والميلان</span>
                  </div>
                  <div className="rounded-lg overflow-hidden border border-current/20 bg-white shadow-lg">
                    <img
                      src={currentPage.cleanedModeBImageDataUrl}
                      alt="الوثيقة المنظفة بالوضع ب"
                      referrerPolicy="no-referrer"
                      className="w-full h-auto block"
                    />
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                  <div className="space-y-2">
                    <div className="text-xs font-semibold">
                      الصورة بعد المعالجة الهندسية (Preprocessed Source)
                    </div>
                    <div className="rounded-lg overflow-hidden border border-current/20 bg-white">
                      <img
                        src={currentPage.preprocessedImageDataUrl}
                        alt="الصورة بعد المعالجة"
                        referrerPolicy="no-referrer"
                        className="w-full h-auto block"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-xs font-semibold">
                      خريطة المطابقة البصرية (الأخضر: تطابق الحبر والجدول)
                    </div>
                    <div className="rounded-lg overflow-hidden border border-current/20 bg-white">
                      {currentPage.validationReport.diffHeatmapDataUrl && (
                        <img
                          src={currentPage.validationReport.diffHeatmapDataUrl}
                          alt="خريطة الفروقات البصرية"
                          referrerPolicy="no-referrer"
                          className="w-full h-auto block"
                        />
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      {/* Camera Capture Modal */}
      {isCameraOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className={`w-full max-w-lg rounded-xl border p-4 space-y-4 ${panelThemeClass}`}>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold">التقاط صورة وثيقة لإعادة بنائها</h3>
              <button
                type="button"
                onClick={closeCameraModal}
                className="text-xs underline opacity-80"
              >
                إلغاء
              </button>
            </div>
            <div className="rounded-lg overflow-hidden bg-black aspect-[3/4] flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
            </div>
            <button
              type="button"
              onClick={captureCameraFrame}
              className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-bold"
            >
              التقاط وبدء إعادة البناء
            </button>
          </div>
        </div>
      )}

      {/* Native Android Project Source & SDK Modal */}
      <AndroidArchitectureModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
        theme={theme}
      />
    </div>
  );
}
