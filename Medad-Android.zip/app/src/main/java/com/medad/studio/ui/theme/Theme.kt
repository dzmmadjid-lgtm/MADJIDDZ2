package com.medad.studio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class MedadPalette(
    val oled: Boolean,
    val canvas: Color,
    val panel: Color,
    val elevated: Color,
    val line: Color,
    val ink: Color,
    val muted: Color,
    val gold: Color,
    val goldSoft: Color,
    val cream: Color,
)

val LocalPalette = staticCompositionLocalOf {
    MedadPalette(
        oled = true,
        canvas = InkBlack,
        panel = InkPanel,
        elevated = Color(0xFF1A1A1D),
        line = InkLine,
        ink = NightText,
        muted = NightMuted,
        gold = Gold,
        goldSoft = GoldSoft,
        cream = Cream,
    )
}

private val OledScheme = darkColorScheme(
    primary = Gold,
    onPrimary = InkBlack,
    secondary = Cream,
    onSecondary = InkBlack,
    background = InkBlack,
    onBackground = NightText,
    surface = InkPanel,
    onSurface = NightText,
    surfaceVariant = Color(0xFF1A1A1D),
    outline = InkLine,
    error = Danger,
)

private val DayScheme = lightColorScheme(
    primary = DayGold,
    onPrimary = Color.White,
    secondary = DayInk,
    onSecondary = Color.White,
    background = DayBg,
    onBackground = DayInk,
    surface = DayPanel,
    onSurface = DayInk,
    surfaceVariant = Color(0xFFF0E6D8),
    outline = DayLine,
    error = Danger,
)

@Composable
fun MedadTheme(
    oledNight: Boolean,
    content: @Composable () -> Unit,
) {
    val palette = if (oledNight) {
        MedadPalette(
            oled = true,
            canvas = InkBlack,
            panel = InkPanel,
            elevated = Color(0xFF1A1A1D),
            line = InkLine,
            ink = NightText,
            muted = NightMuted,
            gold = Gold,
            goldSoft = GoldSoft,
            cream = Cream,
        )
    } else {
        MedadPalette(
            oled = false,
            canvas = DayBg,
            panel = DayPanel,
            elevated = Color(0xFFFFF8EE),
            line = DayLine,
            ink = DayInk,
            muted = DayMuted,
            gold = DayGold,
            goldSoft = Color(0xFFC9A227),
            cream = Color(0xFF3A2E18),
        )
    }

    CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(
            colorScheme = if (oledNight) OledScheme else DayScheme,
            typography = MedadTypography,
            content = content,
        )
    }
}
