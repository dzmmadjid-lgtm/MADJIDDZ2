package com.example.streamhub.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.streamhub.theme.StreamTheme

@Composable
fun HelpDialog(onDismiss: () -> Unit) {
    val colors = StreamTheme.colors

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.cardBackground,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.HelpOutline,
                    contentDescription = null,
                    tint = colors.primaryAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "مركز المساعدة والأسئلة الشائعة",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FaqItem(
                    q = "كيف أقوم بتفعيل وضع OLED أو الوضع النهاري؟",
                    a = "يمكنك الضغط على زر التبديل السريع في الشريط العلوي (أعلى اليمين) أو من خلال القائمة الجانبية أو صفحة الإعدادات."
                )
                FaqItem(
                    q = "هل التنزيلات تعمل بدون اتصال بالإنترنت؟",
                    a = "نعم! عند تنزيل أي فيلم أو حلقة، يتم حفظها على جهازك ويمكنك مشاهدتها في أي وقت وأي مكان في قسم 'مكتبتي'."
                )
                FaqItem(
                    q = "ما هي مميزات اشتراك VIP 4K؟",
                    a = "دقة عرض 4K فائقة بمعدل 60 إطاراً، صوت Dolby Atmos المحيطي، بدون إعلانات، وبث حي 24/7."
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = colors.primaryAccent,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(text = "حسناً، فهمت", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    val colors = StreamTheme.colors

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.cardBackground,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = colors.primaryAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "حول تطبيق StreamHub",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "StreamHub Cinema Edition",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Text(
                    text = "تطبيق ترفيهي وسينمائي متطور مصمم خصيصاً ليقدم تجربة بصرية مذهلة تلائم شاشات OLED بألوان سوداء مطلقة وموفرة للطاقة، ووضع نهاري ناصع وفائق الأناقة مع دعم كامل للغة العربية ودقة 4K HDR.",
                    fontSize = 13.sp,
                    color = colors.textSecondary,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "• الإصدار: 2.6.0 (بنية OLED السحرية)",
                    fontSize = 11.sp,
                    color = colors.textMuted
                )
                Text(
                    text = "• دعم أزرار النظام والرجوع السلس التلقائي",
                    fontSize = 11.sp,
                    color = colors.textMuted
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = colors.primaryAccent,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(text = "إغلاق", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun FaqItem(q: String, a: String) {
    val colors = StreamTheme.colors

    Surface(
        color = colors.surfaceVariant,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, colors.cardBorder, RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(
                text = q,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = a,
                fontSize = 11.sp,
                color = colors.textSecondary,
                lineHeight = 15.sp
            )
        }
    }
}
