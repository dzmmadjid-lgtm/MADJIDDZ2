package com.example.ui.tools

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.theme.AccentEmerald
import com.example.utils.PdfEngine
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextToPdfScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var documentTitle by remember { mutableStateOf("مستند_نصي_${System.currentTimeMillis() % 10000}") }
    var textContent by remember {
        mutableStateOf(
            "بسم الله الرحمن الرحيم\n\nهذا المستند تم إنشاؤه عبر منصة Click School الاحترافية.\nتتميز المنصة بدعمها الكامل لتشكيل الحروف العربية واتجاه الكتابة من اليمين إلى اليسار (RTL) ومعالجة المستندات محلياً على الجهاز بسرعة وأمان تام."
        )
    }

    var pageSize by remember { mutableStateOf("A4") }
    var isPortrait by remember { mutableStateOf(true) }
    var fontSizeSp by remember { mutableFloatStateOf(16f) }
    var alignRight by remember { mutableStateOf(true) }

    var isExporting by remember { mutableStateOf(false) }
    var generatedFile by remember { mutableStateOf<File?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تحويل النصوص إلى PDF", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Document Title
            OutlinedTextField(
                value = documentTitle,
                onValueChange = { documentTitle = it },
                label = { Text("عنوان المستند") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Formatting Controls
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تنسيق الصفحة والخط", fontWeight = FontWeight.Bold)

                    // Size and Orientation
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = pageSize == "A4",
                            onClick = { pageSize = "A4" },
                            label = { Text("A4") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = pageSize == "LETTER",
                            onClick = { pageSize = "LETTER" },
                            label = { Text("Letter") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = isPortrait,
                            onClick = { isPortrait = !isPortrait },
                            label = { Text(if (isPortrait) "عمودي" else "أفقي") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Font Size Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("حجم الخط: ${fontSizeSp.toInt()} sp", fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(
                                selected = alignRight,
                                onClick = { alignRight = true },
                                label = { Text("يمين (عربي)") }
                            )
                            FilterChip(
                                selected = !alignRight,
                                onClick = { alignRight = false },
                                label = { Text("يسار") }
                            )
                        }
                    }

                    Slider(
                        value = fontSizeSp,
                        onValueChange = { fontSizeSp = it },
                        valueRange = 12f..28f,
                        steps = 8
                    )
                }
            }

            // Rich Text Editor Area
            OutlinedTextField(
                value = textContent,
                onValueChange = { textContent = it },
                label = { Text("محتوى النص") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .testTag("text_to_pdf_input"),
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = fontSizeSp.sp,
                    textAlign = if (alignRight) TextAlign.Right else TextAlign.Left
                )
            )

            // Export to PDF Button
            Button(
                onClick = {
                    if (textContent.isBlank()) {
                        Toast.makeText(context, "الرجاء كتابة نص لإنشاء المستند", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    isExporting = true
                    coroutineScope.launch {
                        val outFile = File(context.cacheDir, "${documentTitle.replace(" ", "_")}.pdf")
                        val success = PdfEngine.convertTextToPdf(
                            title = documentTitle,
                            content = textContent,
                            outputFile = outFile,
                            pageSize = pageSize,
                            isPortrait = isPortrait,
                            fontSizeSp = fontSizeSp,
                            alignRight = alignRight
                        )
                        isExporting = false
                        if (success && outFile.exists() && outFile.length() > 0) {
                            generatedFile = outFile
                            Toast.makeText(context, "تم تصدير ملف PDF بنجاح!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "فشل تصدير ملف PDF.", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                enabled = !isExporting && textContent.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("export_text_to_pdf_button")
            ) {
                if (isExporting) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("جاري تشكيل النص وتصدير PDF...")
                } else {
                    Icon(Icons.AutoMirrored.Filled.Article, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تصدير ملف PDF عالي الجودة", fontWeight = FontWeight.Bold)
                }
            }

            // Generated file actions
            if (generatedFile != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("تم إنشاء المستند بنجاح:", fontWeight = FontWeight.Bold)
                        Text(generatedFile!!.name, style = MaterialTheme.typography.bodySmall)

                        Button(
                            onClick = {
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    generatedFile!!
                                )
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "مشاركة PDF"))
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("مشاركة المستند")
                        }
                    }
                }
            }
        }
    }
}
