package com.example.streamhub.model

import androidx.annotation.DrawableRes
import com.example.R

enum class MediaType {
    MOVIE,
    SERIES,
    LIVE_TV,
    ANIME
}

enum class NavigationDestination {
    HOME,
    SEARCH,
    LIBRARY,
    PROFILE,
    SETTINGS,
    HELP,
    ABOUT
}

data class Episode(
    val episodeNumber: Int,
    val title: String,
    val duration: String,
    val description: String,
    val thumbnail: String? = null,
    val youtubeVideoId: String? = null
)

data class MediaItem(
    val id: String,
    val title: String,
    val titleAr: String,
    val type: MediaType,
    val year: Int,
    val durationOrSeasons: String,
    val rating: Double,
    val genres: List<String>,
    val description: String,
    val director: String,
    val cast: List<String>,
    val youtubeVideoId: String = "8zgx5K58mfg",
    val youtubeChannel: String = "StreamHub Cinema",
    val viewCount: String = "12M views",
    val subscriberCount: String = "4.2M subscribers",
    val videoQuality: String = "4K UHD",
    val audioFormat: String = "Dolby Atmos",
    @param:DrawableRes val backdropRes: Int? = null,
    val posterPlaceholderColor: Long = 0xFF1E293B,
    val isFeatured: Boolean = false,
    val trendingRank: Int? = null,
    val watchProgress: Float? = null, // e.g. 0.65f for 65%
    val downloadSizeMb: Int = 2450,
    val episodes: List<Episode> = emptyList(),
    val channelNumber: Int? = null // For Live TV
) {
    val youtubeThumbnailUrl: String
        get() = "https://img.youtube.com/vi/$youtubeVideoId/hqdefault.jpg"

    val youtubeMaxResThumbnailUrl: String
        get() = "https://img.youtube.com/vi/$youtubeVideoId/maxresdefault.jpg"

    val youtubeWatchUrl: String
        get() = "https://www.youtube.com/watch?v=$youtubeVideoId"
}
