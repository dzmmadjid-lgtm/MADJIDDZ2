package com.example.theme

import androidx.compose.ui.graphics.Color

// Brand Colors
val RedBrand = Color(0xFFDC2626)
val RedBrandDark = Color(0xFFB91C1C)
val RedBrandContainer = Color(0xFFFEE2E2)

// Tool Accents
val AccentBlue = Color(0xFF2563EB)
val AccentCyan = Color(0xFF0284C7)
val AccentTeal = Color(0xFF0D9488)
val AccentPurple = Color(0xFF7C3AED)
val AccentIndigo = Color(0xFF4F46E5)
val AccentOrange = Color(0xFFEA580C)
val AccentEmerald = Color(0xFF059669)
val AccentSky = Color(0xFF0EA5E9)
val AccentViolet = Color(0xFF6366F1)
val AccentYellow = Color(0xFFEAB308)
val AccentYellowContainer = Color(0xFFFEF9C3)
val AccentRed = Color(0xFFDC2626)
val AccentRedContainer = Color(0xFFFEE2E2)
val AccentSlate = Color(0xFF475569)
val AccentGreen = Color(0xFF16A34A)

// Light Palette (matches the reference screenshot)
val LightBg = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceContainer = Color(0xFFF1F5F9)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightOutline = Color(0xFFE2E8F0)

// Welcome Banner Light Gradient
val BannerPink = Color(0xFFFCE7F3)
val BannerLavender = Color(0xFFEDE9FE)
val BannerBadgeBg = Color(0xFFFFE4E6)
val BannerBadgeText = Color(0xFFE11D48)

// Dark Palette
val DarkBg = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceContainer = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)

// OLED Palette (Pure Black #000000)
val OledBg = Color(0xFF000000)
val OledSurface = Color(0xFF0A0A0A)
val OledSurfaceContainer = Color(0xFF141414)
val OledTextPrimary = Color(0xFFFFFFFF)
val OledTextSecondary = Color(0xFFA1A1AA)
val OledOutline = Color(0xFF27272A)
