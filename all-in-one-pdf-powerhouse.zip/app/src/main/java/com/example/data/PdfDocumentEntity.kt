package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pdf_documents")
data class PdfDocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val filePath: String,
    val pageCount: Int,
    val fileSize: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val category: String, // "Scan", "Image", "Text", "Merged"
    val isSynced: Boolean = false
)
