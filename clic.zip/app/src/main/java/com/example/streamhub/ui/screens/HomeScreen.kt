package com.example.streamhub.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.streamhub.model.MediaItem
import com.example.streamhub.model.MediaType
import com.example.streamhub.theme.StreamTheme
import com.example.streamhub.ui.components.ContinueWatchingCard
import com.example.streamhub.ui.components.HeroBanner
import com.example.streamhub.ui.components.LiveChannelCard
import com.example.streamhub.ui.components.MediaPosterCard
import com.example.streamhub.ui.components.TrendingNumberedCard

@Composable
fun HomeScreen(
    featuredMedia: MediaItem,
    trendingMedia: List<MediaItem>,
    continueWatching: List<MediaItem>,
    liveChannels: List<MediaItem>,
    allMedia: List<MediaItem>,
    selectedCategory: String,
    watchlist: Set<String>,
    onSelectCategory: (String) -> Unit,
    onPlayMedia: (MediaItem) -> Unit,
    onOpenMediaDetails: (MediaItem) -> Unit,
    onToggleWatchlist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StreamTheme.colors

    val categories = listOf("All", "Movies", "TV Shows", "Anime", "Live TV")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_content"),
        contentPadding = PaddingValues(bottom = 90.dp) // ضمان مساحة كافية للشريط السفلي المرفوع
    ) {
        // شريط التصنيفات السريعة (Category Chips)
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                if (isSelected) colors.primaryAccent else colors.surfaceVariant
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) colors.primaryAccent else colors.cardBorder,
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable { onSelectCategory(cat) }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = when (cat) {
                                "All" -> "الكل"
                                "Movies" -> "أفلام"
                                "TV Shows" -> "مسلسلات"
                                "Anime" -> "أنمي"
                                "Live TV" -> "بث حي"
                                else -> cat
                            },
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else colors.textPrimary
                        )
                    }
                }
            }
        }

        // البانر السينمائي الفائق (Hero Banner)
        item {
            HeroBanner(
                media = featuredMedia,
                isInWatchlist = watchlist.contains(featuredMedia.id),
                onPlay = { onPlayMedia(featuredMedia) },
                onToggleWatchlist = { onToggleWatchlist(featuredMedia.id) },
                onOpenDetails = { onOpenMediaDetails(featuredMedia) }
            )
        }

        // متابعة المشاهدة (Continue Watching)
        if (continueWatching.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "متابعة المشاهدة",
                    subtitle = "استكمل عروضك المفضلة من حيث توقفت",
                    icon = Icons.Default.PlayCircle
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(continueWatching) { item ->
                        ContinueWatchingCard(
                            media = item,
                            onClick = { onPlayMedia(item) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(18.dp))
            }
        }

        // أفضل 10 أعمال رائجة عالمياً (Top 10 Trending with big numbers)
        item {
            SectionHeader(
                title = "الأكثر رواجاً في العالم",
                subtitle = "الأعمال السينمائية الأعلى مشاهدة هذا الأسبوع",
                icon = Icons.Default.LocalFireDepartment
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(trendingMedia) { index, item ->
                    TrendingNumberedCard(
                        media = item,
                        rank = index + 1,
                        onClick = { onOpenMediaDetails(item) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // قنوات البث المباشر (Live TV)
        item {
            SectionHeader(
                title = "قنوات البث المباشر 24/7",
                subtitle = "بثوث سينمائية ورياضية حية بدون توقف بدقة 4K",
                icon = Icons.Default.Tv
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(liveChannels) { channel ->
                    LiveChannelCard(
                        media = channel,
                        onClick = { onPlayMedia(channel) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // مختارات سينمائية فائقة الدقة (Curated Blockbusters)
        item {
            SectionHeader(
                title = "أفلام روائية عالمية 4K",
                subtitle = "أعمال فائزة بجوائز أوسكار وصوت Dolby Atmos المحيطي"
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(allMedia.filter { it.type == MediaType.MOVIE }) { movie ->
                    MediaPosterCard(
                        media = movie,
                        onClick = { onOpenMediaDetails(movie) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // مسلسلات وأنيمي مميزة
        item {
            SectionHeader(
                title = "مسلسلات وأنيمي حصري",
                subtitle = "مواسم كاملة جاهزة للمشاهدة بدون انقطاع"
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(allMedia.filter { it.type == MediaType.SERIES || it.type == MediaType.ANIME }) { series ->
                    MediaPosterCard(
                        media = series,
                        onClick = { onOpenMediaDetails(series) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SectionHeader(
    title: String,
    subtitle: String? = null,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    val colors = StreamTheme.colors

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = colors.primaryAccent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = title,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
        }

        if (subtitle != null) {
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = colors.textSecondary,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}
