package com.example.neural

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import android.util.Log
import com.example.audio.AudioDsp
import com.example.audio.FastFourierTransform
import com.example.audio.StereoAudio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Result of the neural source separation operation.
 */
data class SeparationResult(
    val vocals: StereoAudio,
    val instrumental: StereoAudio,
    val durationSeconds: Float,
    val inferenceTimeMs: Long,
    val modelName: String,
    val isNeuralInference: Boolean = true
)

/**
 * Executes Deep Neural Source Separation pipeline on stereo audio using
 * low-memory streaming chunk-by-chunk processing.
 *
 * Rather than holding full-song 2D STFT matrices in memory (which causes
 * OutOfMemory crashes on Android devices), this engine processes 512-frame
 * segments on-the-fly and directly overlap-adds reconstructed time-domain
 * waveforms into the output buffers.
 */
class NeuralSourceSeparator(
    private val modelManager: AiModelManager
) {
    private val tag = "NeuralSourceSeparator"
    private val audioDsp = AudioDsp(nFft = 4096, hopLength = 1024)

    suspend fun separate(
        audio: StereoAudio,
        onProgress: (step: String, progress: Float) -> Unit = { _, _ -> }
    ): SeparationResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()

        onProgress("التحقق من نموذج الذكاء الاصطناعي العصبي...", 0.05f)
        val initialized = modelManager.initializeModels()
        val vocalsSession = modelManager.vocalsSession
        val accompSession = modelManager.accompanimentSession

        require(initialized && vocalsSession != null && accompSession != null) {
            "لم يتم تحميل نموذج الذكاء الاصطناعي بنجاح: ${modelManager.modelInfo.value.lastError ?: "نموذج ONNX غير متوفر"}"
        }

        val totalSamples = audio.left.size
        require(totalSamples > 0) { "الملف الصوتي فارغ" }

        val nFft = 4096
        val hopLength = 1024
        val bins = 1024 // Spleeter operates on first 1024 frequency bins (0..11025 Hz)
        val fftBins = nFft / 2 + 1 // 2049

        // If audio is shorter than nFft, pad it
        val leftAudio = if (totalSamples < nFft) padSamples(audio.left, nFft) else audio.left
        val rightAudio = if (totalSamples < nFft) padSamples(audio.right, nFft) else audio.right
        val workingSamples = leftAudio.size

        val numFrames = (workingSamples - nFft) / hopLength + 1
        require(numFrames > 0) { "الملف الصوتي قصير جداً لإجراء عملية الفصل" }

        val numSplits = (numFrames + 511) / 512
        val outputLength = (numFrames - 1) * hopLength + nFft

        Log.i(tag, "Audio samples: $totalSamples, frames: $numFrames, splits: $numSplits (512 frames each)")
        onProgress("بدء المعالجة والاستدلال العصبي ($numSplits مقطع)...", 0.15f)

        // Waveform synthesis output buffers
        val vocalsL = FloatArray(outputLength)
        val vocalsR = FloatArray(outputLength)
        val accompL = FloatArray(outputLength)
        val accompR = FloatArray(outputLength)
        val windowSum = FloatArray(outputLength)

        val window = audioDsp.window
        val fft = FastFourierTransform(nFft)

        // Allocate reusable split STFT buffers (512 frames each, only ~16 MB total)
        val splitRealL = Array(512) { FloatArray(fftBins) }
        val splitImagL = Array(512) { FloatArray(fftBins) }
        val splitRealR = Array(512) { FloatArray(fftBins) }
        val splitImagR = Array(512) { FloatArray(fftBins) }

        // Reusable single-split tensor direct buffer [2, 1, 512, 1024]
        val splitElements = 2 * 1 * 512 * bins
        val splitBuffer = ByteBuffer.allocateDirect(splitElements * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        val env = OrtEnvironment.getEnvironment()
        val splitTensorShape = longArrayOf(2L, 1L, 512L, bins.toLong())

        // Reusable frame buffers for FFT and iSTFT
        val vFrameReal = FloatArray(nFft)
        val vFrameImag = FloatArray(nFft)
        val aFrameReal = FloatArray(nFft)
        val aFrameImag = FloatArray(nFft)
        val tempFftReal = FloatArray(nFft)
        val tempFftImag = FloatArray(nFft)

        for (split in 0 until numSplits) {
            val progressFraction = 0.15f + 0.78f * (split.toFloat() / numSplits)
            onProgress("استدلال النموذج العصبي: مقطع ${split + 1} من $numSplits...", progressFraction)

            val startFrame = split * 512

            // 1. Compute STFT on-the-fly for only this 512-frame chunk
            for (k in 0 until 512) {
                val frameIdx = startFrame + k
                if (frameIdx < numFrames) {
                    val sampleOffset = frameIdx * hopLength

                    // Left channel
                    for (i in 0 until nFft) {
                        tempFftReal[i] = leftAudio[sampleOffset + i] * window[i]
                        tempFftImag[i] = 0f
                    }
                    fft.fft(tempFftReal, tempFftImag)
                    System.arraycopy(tempFftReal, 0, splitRealL[k], 0, fftBins)
                    System.arraycopy(tempFftImag, 0, splitImagL[k], 0, fftBins)

                    // Right channel
                    for (i in 0 until nFft) {
                        tempFftReal[i] = rightAudio[sampleOffset + i] * window[i]
                        tempFftImag[i] = 0f
                    }
                    fft.fft(tempFftReal, tempFftImag)
                    System.arraycopy(tempFftReal, 0, splitRealR[k], 0, fftBins)
                    System.arraycopy(tempFftImag, 0, splitImagR[k], 0, fftBins)
                }
            }

            // 2. Populate input magnitude tensor buffer
            splitBuffer.clear()

            // Channel 0 (Left)
            for (k in 0 until 512) {
                val frameIdx = startFrame + k
                if (frameIdx < numFrames) {
                    val r = splitRealL[k]
                    val im = splitImagL[k]
                    for (b in 0 until bins) {
                        splitBuffer.put(sqrt(r[b] * r[b] + im[b] * im[b]))
                    }
                } else {
                    for (b in 0 until bins) splitBuffer.put(0f)
                }
            }

            // Channel 1 (Right)
            for (k in 0 until 512) {
                val frameIdx = startFrame + k
                if (frameIdx < numFrames) {
                    val r = splitRealR[k]
                    val im = splitImagR[k]
                    for (b in 0 until bins) {
                        splitBuffer.put(sqrt(r[b] * r[b] + im[b] * im[b]))
                    }
                } else {
                    for (b in 0 until bins) splitBuffer.put(0f)
                }
            }
            splitBuffer.flip()

            val splitInputTensor = OnnxTensor.createTensor(env, splitBuffer, splitTensorShape)

            // 3. Deep Neural Inference
            val vocalsResult = vocalsSession.run(mapOf("x" to splitInputTensor))
            val vocalsTensor = vocalsResult[0] as OnnxTensor
            val vocalsBuf = vocalsTensor.floatBuffer

            val accompResult = accompSession.run(mapOf("x" to splitInputTensor))
            val accompTensor = accompResult[0] as OnnxTensor
            val accompBuf = accompTensor.floatBuffer

            val chStride = 512 * bins

            // 4. On-the-fly soft-masking and iSTFT directly into output waveforms
            for (ch in 0..1) {
                val targetVocals = if (ch == 0) vocalsL else vocalsR
                val targetAccomp = if (ch == 0) accompL else accompR
                val origRealArray = if (ch == 0) splitRealL else splitRealR
                val origImagArray = if (ch == 0) splitImagL else splitImagR
                val chOffset = ch * chStride

                for (k in 0 until 512) {
                    val frameIdx = startFrame + k
                    if (frameIdx >= numFrames) break

                    val origReal = origRealArray[k]
                    val origImag = origImagArray[k]
                    val fOffset = chOffset + k * bins

                    // Soft mask for bins 0..1023
                    for (b in 0 until bins) {
                        val v = vocalsBuf.get(fOffset + b)
                        val a = accompBuf.get(fOffset + b)

                        val v2 = v * v + 1e-10f / 2f
                        val a2 = a * a + 1e-10f / 2f
                        val sum = v * v + a * a + 1e-10f

                        val maskV = v2 / sum
                        val maskA = a2 / sum

                        vFrameReal[b] = origReal[b] * maskV
                        vFrameImag[b] = origImag[b] * maskV

                        aFrameReal[b] = origReal[b] * maskA
                        aFrameImag[b] = origImag[b] * maskA
                    }

                    // Preserve instrumental brilliance for bins 1024..2048
                    for (b in bins until fftBins) {
                        vFrameReal[b] = 0f
                        vFrameImag[b] = 0f

                        aFrameReal[b] = origReal[b]
                        aFrameImag[b] = origImag[b]
                    }

                    // Conjugate symmetry for negative frequencies: X[nFft - m] = conj(X[m])
                    for (m in 1 until nFft - fftBins + 1) {
                        val symIdx = nFft - m
                        if (m < fftBins && symIdx < nFft) {
                            vFrameReal[symIdx] = vFrameReal[m]
                            vFrameImag[symIdx] = -vFrameImag[m]

                            aFrameReal[symIdx] = aFrameReal[m]
                            aFrameImag[symIdx] = -aFrameImag[m]
                        }
                    }

                    // Inverse FFT
                    fft.ifft(vFrameReal, vFrameImag)
                    fft.ifft(aFrameReal, aFrameImag)

                    // Overlap-add
                    val sampleOffset = frameIdx * hopLength
                    for (i in 0 until nFft) {
                        val outIdx = sampleOffset + i
                        if (outIdx < outputLength) {
                            val w = window[i]
                            targetVocals[outIdx] += vFrameReal[i] * w
                            targetAccomp[outIdx] += aFrameReal[i] * w
                            if (ch == 0) {
                                windowSum[outIdx] += w * w
                            }
                        }
                    }
                }
            }

            splitInputTensor.close()
            vocalsResult.close()
            accompResult.close()
        }

        // 5. Final normalization by window overlap sum
        onProgress("تنسيق الصوت وإنهاء المسارات الصوتية...", 0.95f)
        for (i in 0 until outputLength) {
            val wSum = windowSum[i]
            if (wSum > 1e-4f) {
                val inv = 1.0f / wSum
                vocalsL[i] *= inv
                vocalsR[i] *= inv
                accompL[i] *= inv
                accompR[i] *= inv
            }
        }

        // 6. Trim to exact original length
        val finalVocalsL = trimToLength(vocalsL, totalSamples)
        val finalVocalsR = trimToLength(vocalsR, totalSamples)
        val finalAccompL = trimToLength(accompL, totalSamples)
        val finalAccompR = trimToLength(accompR, totalSamples)

        val vocalsAudio = StereoAudio(finalVocalsL, finalVocalsR, audio.sampleRate)
        val instrumentalAudio = StereoAudio(finalAccompL, finalAccompR, audio.sampleRate)

        val inferenceTimeMs = System.currentTimeMillis() - startTime
        onProgress("اكتمل الفصل العصبي بنجاح!", 1.0f)

        Log.i(tag, "Neural separation finished in ${inferenceTimeMs}ms for ${audio.durationSeconds}s audio.")

        SeparationResult(
            vocals = vocalsAudio,
            instrumental = instrumentalAudio,
            durationSeconds = audio.durationSeconds,
            inferenceTimeMs = inferenceTimeMs,
            modelName = "Spleeter 2-Stems Deep U-Net (ONNX)",
            isNeuralInference = true
        )
    }

    private fun padSamples(samples: FloatArray, targetLength: Int): FloatArray {
        val padded = FloatArray(targetLength)
        System.arraycopy(samples, 0, padded, 0, samples.size)
        return padded
    }

    private fun trimToLength(samples: FloatArray, targetLength: Int): FloatArray {
        return if (samples.size == targetLength) {
            samples
        } else if (samples.size > targetLength) {
            samples.copyOf(targetLength)
        } else {
            val padded = FloatArray(targetLength)
            System.arraycopy(samples, 0, padded, 0, samples.size)
            padded
        }
    }
}
