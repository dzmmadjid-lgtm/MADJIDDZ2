package com.example.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max

/**
 * Short-Time Fourier Transform (STFT) and Inverse STFT (iSTFT) designed
 * specifically for Deep Learning Source Separation models (Spleeter / MDX-Net).
 *
 * Parameters matching model training:
 * - sampleRate: 44,100 Hz
 * - nFft: 4096
 * - hopLength: 1024
 * - windowLength: 4096
 * - windowType: Hann
 * - modelBins: 1024 (bins 0..1023 covering 0 to 11025 Hz)
 */
class AudioDsp(
    val nFft: Int = 4096,
    val hopLength: Int = 1024
) {
    val fftBins = nFft / 2 + 1 // 2049 bins
    private val fft = FastFourierTransform(nFft)
    val window: FloatArray = FloatArray(nFft) { i ->
        // Periodic Hann window: 0.5 * (1 - cos(2 * pi * i / nFft))
        (0.5 * (1.0 - cos(2.0 * PI * i / nFft))).toFloat()
    }

    class StftChannelResult(
        val numFrames: Int,
        val real: Array<FloatArray>, // [numFrames][fftBins]
        val imag: Array<FloatArray>  // [numFrames][fftBins]
    )

    /**
     * Computes the STFT of a 1D audio channel.
     */
    fun computeStft(samples: FloatArray): StftChannelResult {
        val totalSamples = samples.size
        if (totalSamples < nFft) {
            val padded = FloatArray(nFft) { if (it < totalSamples) samples[it] else 0f }
            return computeStft(padded)
        }

        val numFrames = (totalSamples - nFft) / hopLength + 1
        val realMatrix = Array(numFrames) { FloatArray(fftBins) }
        val imagMatrix = Array(numFrames) { FloatArray(fftBins) }

        val frameReal = FloatArray(nFft)
        val frameImag = FloatArray(nFft)

        for (f in 0 until numFrames) {
            val offset = f * hopLength
            for (i in 0 until nFft) {
                frameReal[i] = samples[offset + i] * window[i]
                frameImag[i] = 0f
            }

            fft.fft(frameReal, frameImag)

            // Copy positive frequency bins (0..nFft/2)
            System.arraycopy(frameReal, 0, realMatrix[f], 0, fftBins)
            System.arraycopy(frameImag, 0, imagMatrix[f], 0, fftBins)
        }

        return StftChannelResult(numFrames, realMatrix, imagMatrix)
    }

    /**
     * Reconstructs audio in time-domain from modified STFT using overlap-add iSTFT.
     */
    fun inverseStft(stft: StftChannelResult): FloatArray {
        val numFrames = stft.numFrames
        if (numFrames == 0) return FloatArray(0)

        val outputLength = (numFrames - 1) * hopLength + nFft
        val output = FloatArray(outputLength)
        val windowSum = FloatArray(outputLength)

        val frameReal = FloatArray(nFft)
        val frameImag = FloatArray(nFft)

        for (f in 0 until numFrames) {
            val fReal = stft.real[f]
            val fImag = stft.imag[f]

            // Fill positive frequencies
            System.arraycopy(fReal, 0, frameReal, 0, fftBins)
            System.arraycopy(fImag, 0, frameImag, 0, fftBins)

            // Reconstruct negative frequencies via conjugate symmetry:
            // X[nFft - k] = conj(X[k])
            for (k in 1 until nFft - fftBins + 1) {
                val symIdx = nFft - k
                if (k < fftBins && symIdx < nFft) {
                    frameReal[symIdx] = fReal[k]
                    frameImag[symIdx] = -fImag[k]
                }
            }

            fft.ifft(frameReal, frameImag)

            val offset = f * hopLength
            for (i in 0 until nFft) {
                val outIdx = offset + i
                if (outIdx < outputLength) {
                    val w = window[i]
                    output[outIdx] += frameReal[i] * w
                    windowSum[outIdx] += w * w
                }
            }
        }

        // Normalize by window overlap sum to ensure perfect signal reconstruction
        for (i in 0 until outputLength) {
            val wSum = windowSum[i]
            if (wSum > 1e-4f) {
                output[i] /= wSum
            }
        }

        return output
    }
}
