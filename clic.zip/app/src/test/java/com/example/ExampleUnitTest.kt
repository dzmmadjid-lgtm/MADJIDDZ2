package com.example

import com.example.streamhub.data.SampleCatalog
import com.example.streamhub.model.MediaType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testCatalogMediaTypes() {
        val all = SampleCatalog.allMedia
        assertTrue(all.isNotEmpty())

        val movies = all.filter { it.type == MediaType.MOVIE }
        val series = all.filter { it.type == MediaType.SERIES }
        val anime = all.filter { it.type == MediaType.ANIME }
        val live = all.filter { it.type == MediaType.LIVE_TV }

        assertTrue(movies.isNotEmpty())
        assertTrue(series.isNotEmpty())
        assertTrue(anime.isNotEmpty())
        assertTrue(live.isNotEmpty())
    }

    @Test
    fun testMediaAttributes() {
        val sample = SampleCatalog.allMedia.first { it.id == "movie_cyberpunk" }
        assertEquals("Cyberpunk: Neon Frontier", sample.title)
        assertEquals(2026, sample.year)
        assertEquals("4K HDR Dolby Vision", sample.videoQuality)
        assertTrue(sample.genres.contains("Sci-Fi"))
        assertNotNull(sample.backdropRes)
    }

    @Test
    fun testSeriesHasEpisodes() {
        val series = SampleCatalog.allMedia.first { it.type == MediaType.SERIES }
        assertTrue(series.episodes.isNotEmpty())
        val ep1 = series.episodes.first()
        assertEquals(1, ep1.episodeNumber)
        assertFalse(ep1.title.isBlank())
    }
}
