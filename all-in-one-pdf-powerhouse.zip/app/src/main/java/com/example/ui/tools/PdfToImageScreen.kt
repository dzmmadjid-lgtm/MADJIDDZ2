package com.example.ui.tools

import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.rememberAsyncImagePainter
import com.example.theme.AccentTeal
import com.example.utils.PdfEngine
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfToImageScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var documentName by remember { mutableStateOf("مستند PDF") }
    var totalPages by remember { mutableIntStateOf(0) }
    var selectedExportMode by remember { mutableStateOf("ALL") } // "ALL" or "CUSTOM"
    var customRangeText by remember { mutableStateOf("1") }
    var format by remember { mutableStateOf("JPG") } // "JPG" or "PNG"
    var quality by remember { mutableFloatStateOf(90f) }
    var isExporting by remember { mutableStateOf(false) }
    var exportedImages by remember { mutableStateOf<List<File>>(emptyList()) }

    val pdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            pdfUri = uri
            coroutineScope.launch {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && idx != -1) {
                        documentName = cursor.getString(idx)
                    }
                }
                totalPages = PdfEngine.getPageCount(context, uri)
                customRangeText = if (totalPages > 1) "1-$totalPages" else "1"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تحويل PDF إلى صور", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Document Selection Box
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (pdfUri != null) documentName else "لم يتم اختيار ملف PDF",
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            if (totalPages > 0) {
                                Text(
                                    text = "إجمالي الصفحات: $totalPages صفحة",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Button(
                            onClick = { pdfPicker.launch(arrayOf("application/pdf")) },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentTeal),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("select_pdf_button")
                        ) {
                            Text("اختيار ملف")
                        }
                    }
                }
            }

            if (pdfUri != null && totalPages > 0) {
                // Page Range Configuration
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("نطاق الصفحات للتصدير", fontWeight = FontWeight.Bold)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = selectedExportMode == "ALL",
                                onClick = { selectedExportMode = "ALL" },
                                label = { Text("جميع الصفحات ($totalPages)") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = selectedExportMode == "CUSTOM",
                                onClick = { selectedExportMode = "CUSTOM" },
                                label = { Text("نطاق محدد") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (selectedExportMode == "CUSTOM") {
                            OutlinedTextField(
                                value = customRangeText,
                                onValueChange = { customRangeText = it },
                                label = { Text("أدخل النطاق (مثال: 1-3)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // Format & Quality Configuration
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("صيغة وجودة الصور", fontWeight = FontWeight.Bold)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("JPG", "PNG").forEach { f ->
                                FilterChip(
                                    selected = format == f,
                                    onClick = { format = f },
                                    label = { Text(f) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        if (format == "JPG") {
                            Text("جودة الضغط: ${quality.toInt()}%", fontSize = 12.sp)
                            Slider(
                                value = quality,
                                onValueChange = { quality = it },
                                valueRange = 50f..100f
                            )
                        }
                    }
                }

                // Export Button
                Button(
                    onClick = {
                        isExporting = true
                        coroutineScope.launch {
                            val pageIndices = if (selectedExportMode == "ALL") {
                                (0 until totalPages).toList()
                            } else {
                                val parts = customRangeText.split("-")
                                val start = (parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 1) - 1
                                val end = (parts.getOrNull(1)?.trim()?.toIntOrNull() ?: (start + 1)) - 1
                                (start.coerceIn(0, totalPages - 1)..end.coerceIn(0, totalPages - 1)).toList()
                            }

                            val outputDir = File(context.cacheDir, "pdf_images_${System.currentTimeMillis()}").apply { mkdirs() }
                            val files = PdfEngine.exportPagesToImages(
                                context = context,
                                inputUri = pdfUri!!,
                                pageIndices = pageIndices,
                                outputDir = outputDir,
                                format = format,
                                quality = quality.toInt()
                            )

                            isExporting = false
                            if (files.isNotEmpty()) {
                                exportedImages = files
                                Toast.makeText(context, "تم تصدير ${files.size} صورة بنجاح!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "فشل تصدير الصور.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    enabled = !isExporting,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentTeal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("export_pdf_to_images_button")
                ) {
                    if (isExporting) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جاري استخراج الصور...")
                    } else {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("بدء استخراج الصور", fontWeight = FontWeight.Bold)
                    }
                }

                // Preview Grid of Exported Images
                if (exportedImages.isNotEmpty()) {
                    Text(
                        text = "الصور الناتجة (${exportedImages.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    exportedImages.forEachIndexed { index, file ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                Image(
                                    painter = rememberAsyncImagePainter(file),
                                    contentDescription = file.name,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize()
                                )

                                // Share button on image
                                IconButton(
                                    onClick = {
                                        val uri = FileProvider.getUriForFile(
                                            context,
                                            "${context.packageName}.fileprovider",
                                            file
                                        )
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = if (file.name.endsWith("png")) "image/png" else "image/jpeg"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة الصورة"))
                                    },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(8.dp)
                                        .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "مشاركة", tint = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
