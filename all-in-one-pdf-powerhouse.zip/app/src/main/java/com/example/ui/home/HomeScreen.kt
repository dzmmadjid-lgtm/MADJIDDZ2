package com.example.ui.home

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.theme.*
import com.example.ui.components.ToolCard
import com.example.ui.components.TopHeader
import com.example.ui.components.WelcomeBanner

data class ToolItem(
    val id: String,
    val title: String,
    val description: String,
    val tag: String,
    val icon: ImageVector,
    val color: Color
)

@Composable
fun HomeScreen(
    onNavigateToReader: (Uri?) -> Unit,
    onNavigateToImagesToPdf: () -> Unit,
    onNavigateToPdfToImages: () -> Unit,
    onNavigateToMerge: () -> Unit,
    onNavigateToSplit: () -> Unit,
    onNavigateToPageManager: () -> Unit,
    onNavigateToCrop: () -> Unit,
    onNavigateToTextToPdf: () -> Unit,
    onNavigateToScanner: () -> Unit,
    onNavigateToWifiScanner: () -> Unit,
    onNavigateToOrdinaryPrint: () -> Unit,
    onNavigateToDirectPrint: () -> Unit,
    onNavigateToViewer: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showInfoDialog by remember { mutableStateOf(false) }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            onNavigateToReader(uri)
        }
    }

    val tools = remember {
        listOf(
            ToolItem(
                id = "reader",
                title = "قراءة وعرض PDF",
                description = "استعرض صفحات المستندات مع تكبير ومصغرات وتنقل سلس وطباعة مباشرة.",
                tag = "قارئ متطور",
                icon = Icons.Outlined.Visibility,
                color = AccentBlue
            ),
            ToolItem(
                id = "images_to_pdf",
                title = "تحويل الصور إلى PDF",
                description = "اجمع الصور وحولها لمستند PDF عالي الدقة مع تخصيص الهوامش.",
                tag = "معالجة سريعة",
                icon = Icons.Outlined.PhotoLibrary,
                color = AccentCyan
            ),
            ToolItem(
                id = "pdf_to_images",
                title = "تحويل PDF إلى صور",
                description = "استخرج صفحات PDF كصور JPG أو PNG بجودة كاملة وسهولة مشاركتها.",
                tag = "تصدير عالي الدقة",
                icon = Icons.Outlined.Image,
                color = AccentTeal
            ),
            ToolItem(
                id = "merge",
                title = "دمج ملفات PDF",
                description = "اجمع عدة ملفات PDF في مستند واحد مرتب بسلاسة وبنقرة واحدة.",
                tag = "ترتيب وسحب",
                icon = Icons.Outlined.Layers,
                color = AccentPurple
            ),
            ToolItem(
                id = "split",
                title = "تقسيم واستخراج PDF",
                description = "قسّم المستندات الكبيرة أو استخرج نطاق صفحات محدد بدقة.",
                tag = "تخصيص النطاق",
                icon = Icons.Outlined.CallSplit,
                color = AccentIndigo
            ),
            ToolItem(
                id = "page_manager",
                title = "إدارة وتنظيم الصفحات",
                description = "حذف صفحات، إعادة ترتيبها، تدويرها أو استخراجها مع الحفاظ على الأصل.",
                tag = "تحكم كامل",
                icon = Icons.Outlined.GridView,
                color = AccentPurple
            ),
            ToolItem(
                id = "crop",
                title = "قص وتعديل الهوامش",
                description = "اضبط حدود وهوامش صفحات PDF وركز على المحتوى الأساسي.",
                tag = "قص رقمي",
                icon = Icons.Outlined.Crop,
                color = AccentOrange
            ),
            ToolItem(
                id = "text_to_pdf",
                title = "تحويل النصوص إلى PDF",
                description = "أنشئ مستندات PDF منسقة مع دعم كامل للغة العربية والاتجاه.",
                tag = "محرر ذكي",
                icon = Icons.AutoMirrored.Filled.Article,
                color = AccentEmerald
            ),
            ToolItem(
                id = "scanner",
                title = "ماسح المستندات بالكاميرا",
                description = "التقط المستندات وطبق فلاتر إزالة الظلال والتباين للتصدير.",
                tag = "معالجة فورية",
                icon = Icons.Outlined.CameraAlt,
                color = AccentSky
            ),
            ToolItem(
                id = "wifi_scanner",
                title = "ماسح الشبكة اللاسلكي",
                description = "اتصل بالماسحات الضوئية عبر الشبكة (eSCL/AirScan) واستلم الصفحات.",
                tag = "eSCL / AirScan",
                icon = Icons.Outlined.Print,
                color = AccentViolet
            ),
            ToolItem(
                id = "ordinary_print",
                title = "الطباعة العادية",
                description = "اطبع أي مستند عبر خدمة الطباعة القياسية ونظام أندرويد.",
                tag = "الزر الأصفر",
                icon = Icons.Outlined.LocalPrintshop,
                color = AccentYellow
            ),
            ToolItem(
                id = "direct_print",
                title = "الطباعة المباشرة",
                description = "إرسال مباشر عبر الشبكة (Socket 9100) للطابعات المتوافقة.",
                tag = "الزر الأحمر",
                icon = Icons.Outlined.SendToMobile,
                color = AccentRed
            ),
            ToolItem(
                id = "viewer",
                title = "مستعرض المستندات الشامل",
                description = "عرض سريع لملفات PDF، النصوص، الصور والمستندات المكتبية.",
                tag = "متعدد الصيغ",
                icon = Icons.AutoMirrored.Filled.MenuBook,
                color = AccentSlate
            ),
            ToolItem(
                id = "settings",
                title = "الإعدادات والتخصيص",
                description = "التحكم في الثيم ووضع OLED الأسود وجودة التصدير ومسح السجل.",
                tag = "تخصيص كامل",
                icon = Icons.Outlined.Settings,
                color = AccentSlate
            )
        )
    }

    Scaffold(
        topBar = {
            TopHeader(
                onInfoClick = { showInfoDialog = true },
                onSettingsClick = onNavigateToSettings
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Welcome Banner spans full width (2 columns)
            item(span = { GridItemSpan(2) }) {
                WelcomeBanner()
            }

            // Section Heading
            item(span = { GridItemSpan(2) }) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "أدوات المستندات",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${tools.size} أدوات متاحة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Compact 2-column tools
            items(tools, key = { it.id }) { tool ->
                ToolCard(
                    title = tool.title,
                    description = tool.description,
                    tag = tool.tag,
                    icon = tool.icon,
                    accentColor = tool.color,
                    testTag = "tool_${tool.id}",
                    onClick = {
                        when (tool.id) {
                            "reader" -> pdfPickerLauncher.launch(arrayOf("application/pdf"))
                            "images_to_pdf" -> onNavigateToImagesToPdf()
                            "pdf_to_images" -> onNavigateToPdfToImages()
                            "merge" -> onNavigateToMerge()
                            "split" -> onNavigateToSplit()
                            "page_manager" -> onNavigateToPageManager()
                            "crop" -> onNavigateToCrop()
                            "text_to_pdf" -> onNavigateToTextToPdf()
                            "scanner" -> onNavigateToScanner()
                            "wifi_scanner" -> onNavigateToWifiScanner()
                            "ordinary_print" -> onNavigateToOrdinaryPrint()
                            "direct_print" -> onNavigateToDirectPrint()
                            "viewer" -> onNavigateToViewer()
                            "settings" -> onNavigateToSettings()
                        }
                    }
                )
            }
        }
    }

    if (showInfoDialog) {
        AlertDialog(
            onDismissRequest = { showInfoDialog = false },
            title = {
                Text(
                    text = "عن Click School",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Click School — منصة أدوات PDF الاحترافية",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "تطبيق متكامل لمعالجة مستندات PDF محلياً بالكامل (Offline 100%) بأعلى معايير الأمان والخصوصية.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "• معالجة آمنة دون رفع الملفات لأي خادم.\n• طباعة عادية عبر النظام وطباعة مباشرة عبر الشبكة (Socket 9100).\n• دعم مسح ضوئي لاسلكي حقيقي (eSCL / AirScan).\n• إدارة وحذف الصفحات مع الحفاظ التام على أصول المستندات.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showInfoDialog = false }) {
                    Text("حسناً")
                }
            }
        )
    }
}
