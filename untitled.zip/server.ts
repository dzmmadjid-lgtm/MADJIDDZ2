import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '35mb' }));

function collectFilesRecursively(
  dirPath: string,
  rootDir: string,
  acc: { path: string; content: string }[] = []
) {
  if (!fs.existsSync(dirPath)) return acc;
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      collectFilesRecursively(fullPath, rootDir, acc);
    } else if (entry.isFile()) {
      const relPath = path.relative(rootDir, fullPath).replace(/\\/g, '/');
      const content = fs.readFileSync(fullPath, 'utf-8');
      acc.push({ path: relPath, content });
    }
  }
  return acc;
}

app.get('/api/android-project-files', (_req, res) => {
  try {
    const rootDir = process.cwd();
    const files: { path: string; content: string }[] = [];
    const topFiles = [
      'settings.gradle.kts',
      'build.gradle.kts',
      'gradle.properties',
      '.github/workflows/build.yml',
    ];
    for (const tf of topFiles) {
      const p = path.join(rootDir, tf);
      if (fs.existsSync(p)) {
        files.push({ path: tf, content: fs.readFileSync(p, 'utf-8') });
      }
    }
    collectFilesRecursively(path.join(rootDir, 'app'), rootDir, files);
    res.json({ files });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to read Android project files' });
  }
});

const getAiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

const EXTRACT_SYSTEM_INSTRUCTION = `You are Step 3 (EXTRACT) of a strict Measured Document Reconstruction Pipeline.
You receive:
1. A cleaned, deskewed, bleed-through-removed document page image.
2. The morphologically measured bounding boxes (normalized 0 to 1000 on each axis: [x, y, width, height]) for lines, dotted_lines, tables, boxes, checkboxes, drawings, handwriting, and text blocks.

STRICT PIPELINE RULES:
1. Return structured JSON elements ONLY:
   {
     "elements": [
       {
         "id": "string",
         "type": "text" | "line" | "table" | "box" | "dotted_line" | "drawing" | "handwriting",
         "bbox": [x, y, width, height],
         "text": "string",
         "lang": "ar" | "fr" | "en" | "mixed",
         "dir": "rtl" | "ltr",
         "font_weight": "normal" | "bold",
         "font_style": "normal" | "italic",
         "align": "right" | "center" | "left" | "justify",
         "checked": boolean,
         "svgPath": "optional clean SVG path for simple drawings",
         "tableData": { ... }
       }
     ]
   }
2. Transcribe text EXACTLY as printed in the source image. Preserve Arabic and French/English direction (rtl or ltr per element).
3. Fix scan noise or broken character ligatures inside words (for example: "suivar tes" MUST become "suivantes", broken Arabic letter connections must be joined properly).
4. Do NOT invent content, summarize, translate, or add headings.
5. NEVER use typed dot characters ("....." or "……") to represent dotted fill lines. Any dotted rule or fill line must be a separate element of type "dotted_line" with its exact measured [x, y, width, height] bbox.
6. Classify handwritten ink/pen annotations separately as type "handwriting" with their exact bbox.
7. Always use Western Arabic / European numerals (0123456789).
8. Do NOT output any self-assigned confidence scores.`;

app.post('/api/extract-elements', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/png', measuredBoxes = [] } = req.body;
    if (!imageBase64) {
      res.status(400).json({ error: 'Missing imageBase64 payload' });
      return;
    }

    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: 'GEMINI_API_KEY not configured on server; using deterministic morphological extractor.',
        offlineFallback: true,
      });
      return;
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType,
              data: cleanBase64,
            },
          },
          {
            text: `Extract all page elements using the measured morphological bounding boxes below (normalized 0-1000 coordinates [x, y, width, height]):
${JSON.stringify(measuredBoxes.slice(0, 80))}

Anchor your element bboxes to the measured boxes. Transcribe Arabic (dir="rtl") and French/English (dir="ltr") text accurately, fixing scan noise in words (e.g. "suivar tes" -> "suivantes"). Classify dotted lines as "dotted_line" (never typed dots), tables with their exact measured rowHeights and colWidths, and handwriting as "handwriting".`,
          },
        ],
      },
      config: {
        systemInstruction: EXTRACT_SYSTEM_INSTRUCTION,
        temperature: 0.05,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            elements: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  type: {
                    type: Type.STRING,
                    description: 'text, line, table, box, dotted_line, drawing, or handwriting',
                  },
                  bbox: {
                    type: Type.ARRAY,
                    items: { type: Type.NUMBER },
                    description: '[x, y, width, height] in 0..1000 coordinates',
                  },
                  text: { type: Type.STRING },
                  lang: { type: Type.STRING, description: 'ar, fr, en, or mixed' },
                  dir: { type: Type.STRING, description: 'rtl or ltr' },
                  font_weight: { type: Type.STRING, description: 'normal or bold' },
                  font_style: { type: Type.STRING, description: 'normal or italic' },
                  align: { type: Type.STRING, description: 'right, center, left, or justify' },
                  checked: { type: Type.BOOLEAN },
                  svgPath: { type: Type.STRING },
                  tableData: {
                    type: Type.OBJECT,
                    properties: {
                      rows: { type: Type.INTEGER },
                      cols: { type: Type.INTEGER },
                      rowHeights: {
                        type: Type.ARRAY,
                        items: { type: Type.NUMBER },
                      },
                      colWidths: {
                        type: Type.ARRAY,
                        items: { type: Type.NUMBER },
                      },
                      cells: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            row: { type: Type.INTEGER },
                            col: { type: Type.INTEGER },
                            rowSpan: { type: Type.INTEGER },
                            colSpan: { type: Type.INTEGER },
                            text: { type: Type.STRING },
                            dir: { type: Type.STRING },
                            align: { type: Type.STRING },
                            font_weight: { type: Type.STRING },
                            hasTopBorder: { type: Type.BOOLEAN },
                            hasRightBorder: { type: Type.BOOLEAN },
                            hasBottomBorder: { type: Type.BOOLEAN },
                            hasLeftBorder: { type: Type.BOOLEAN },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    });

    const rawText = response.text || '{}';
    const parsed = JSON.parse(rawText);
    res.json({ success: true, data: parsed });
  } catch (error: any) {
    console.error('Extract elements API error:', error?.message || error);
    res.status(500).json({
      error: error?.message || 'Failed to extract elements via Vision API',
      offlineFallback: true,
    });
  }
});

/**
 * Step 6c: VERIFY LOOP — Vision JSON Patch Correction Endpoint
 * Receives source image, rebuilt canvas image, difference overlay image, and current elements,
 * and returns a JSON patch of coordinate/size/text corrections.
 */
app.post('/api/verify-patch', async (req, res) => {
  try {
    const {
      sourceImageBase64,
      rebuiltImageBase64,
      diffOverlayBase64,
      elements = [],
      measuredBlockErrors = [],
    } = req.body;

    const ai = getAiClient();
    if (!ai || !sourceImageBase64 || !rebuiltImageBase64 || !diffOverlayBase64) {
      res.status(503).json({
        error: 'Vision patch service unavailable; using deterministic centroid & IoU patcher.',
        offlineFallback: true,
      });
      return;
    }

    const cleanSource = sourceImageBase64.replace(/^data:image\/\w+;base64,/, '');
    const cleanRebuilt = rebuiltImageBase64.replace(/^data:image\/\w+;base64,/, '');
    const cleanOverlay = diffOverlayBase64.replace(/^data:image\/\w+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/png', data: cleanSource } },
          { inlineData: { mimeType: 'image/png', data: cleanRebuilt } },
          { inlineData: { mimeType: 'image/png', data: cleanOverlay } },
          {
            text: `You are Step 6c of the VERIFY LOOP.
Image 1 is the cleaned SOURCE page.
Image 2 is our REBUILT page.
Image 3 is the DIFFERENCE OVERLAY (red = misaligned rebuilt ink, blue = uncovered source ink, green = exact overlap).
Current elements and their measured geometry errors:
${JSON.stringify({ elements: elements.slice(0, 60), measuredBlockErrors })}

Return a JSON patch list of corrections (id + corrected bbox [x, y, width, height] in 0..1000 + corrected fontSizePt or text if needed) to align the rebuilt elements accurately with the source image. Do NOT report any similarity score.`,
          },
        ],
      },
      config: {
        temperature: 0.05,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            patches: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  bbox: {
                    type: Type.ARRAY,
                    items: { type: Type.NUMBER },
                    description: '[x, y, width, height] in 0..1000',
                  },
                  fontSizePt: { type: Type.NUMBER },
                  text: { type: Type.STRING },
                  align: { type: Type.STRING },
                  dir: { type: Type.STRING },
                },
              },
            },
          },
        },
      },
    });

    const parsed = JSON.parse(response.text || '{"patches":[]}');
    res.json({ success: true, patches: parsed.patches || [] });
  } catch (error: any) {
    res.status(500).json({
      error: error?.message || 'Verify patch API error',
      offlineFallback: true,
    });
  }
});

// Keep legacy endpoint forwarding to same structured schema for backward compatibility
app.post('/api/reconstruct-document', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/png', measuredBoxes = [] } = req.body;
    if (!imageBase64) {
      res.status(400).json({ error: 'Missing imageBase64 payload' });
      return;
    }
    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({ offlineFallback: true });
      return;
    }
    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          { inlineData: { mimeType, data: cleanBase64 } },
          {
            text: `Extract all document layout elements in 0..1000 coordinates. Measured boxes: ${JSON.stringify(
              measuredBoxes.slice(0, 60)
            )}`,
          },
        ],
      },
      config: {
        systemInstruction: EXTRACT_SYSTEM_INSTRUCTION,
        temperature: 0.05,
        responseMimeType: 'application/json',
      },
    });
    const parsed = JSON.parse(response.text || '{}');
    res.json({ success: true, data: parsed });
  } catch (err: any) {
    res.status(500).json({ error: err?.message, offlineFallback: true });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CrimsonPDF Reconstruct Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
