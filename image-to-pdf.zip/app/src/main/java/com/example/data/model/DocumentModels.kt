package com.example.data.model

import android.graphics.RectF

enum class EnhancementMode(val labelAr: String, val labelEn: String) {
    ORIGINAL("أصلي", "Original"),
    B_AND_W("وثيقة واضحة", "Clean Doc B&W"),
    HIGH_CONTRAST("تباين فائق", "High Contrast"),
    GRAYSCALE("تدرج رمادي", "Grayscale"),
    MAGIC_COLOR("ألوان ذكية", "Magic Color")
}

enum class RegionType(val labelAr: String, val labelEn: String) {
    TITLE("عنوان", "Title"),
    PARAGRAPH("فقرة", "Paragraph"),
    SHORT_TEXT("نص قصير", "Short Text"),
    LIST_ITEM("عنصر قائمة", "List Item"),
    NUMBER("أرقام / كود", "Number / Code"),
    TABLE_CELL("جدول / صف", "Table Cell"),
    GRAPHIC_OR_PHOTO("صورة / رسم", "Graphic / Photo")
}

enum class DetectedLanguage(val labelAr: String, val labelEn: String, val code: String) {
    ARABIC("العربية", "Arabic", "ar"),
    ENGLISH("الإنجليزية", "English", "en"),
    FRENCH("الفرنسية", "French", "fr"),
    MIXED("مختلط", "Mixed", "multi"),
    NUMERIC("أرقام", "Numeric", "num"),
    UNKNOWN("غير محدد", "Unknown", "und")
}

data class RectNormalized(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val width: Float get() = (right - left).coerceAtLeast(0f)
    val height: Float get() = (bottom - top).coerceAtLeast(0f)

    fun toPixelRect(bitmapWidth: Int, bitmapHeight: Int): RectF {
        return RectF(
            left * bitmapWidth,
            top * bitmapHeight,
            right * bitmapWidth,
            bottom * bitmapHeight
        )
    }

    companion object {
        fun fromPixelRect(rect: RectF, bitmapWidth: Int, bitmapHeight: Int): RectNormalized {
            val bw = bitmapWidth.coerceAtLeast(1).toFloat()
            val bh = bitmapHeight.coerceAtLeast(1).toFloat()
            return RectNormalized(
                left = (rect.left / bw).coerceIn(0f, 1f),
                top = (rect.top / bh).coerceIn(0f, 1f),
                right = (rect.right / bw).coerceIn(0f, 1f),
                bottom = (rect.bottom / bh).coerceIn(0f, 1f)
            )
        }
    }
}

data class TextWordItem(
    val text: String,
    val boundingBox: RectNormalized
)

data class TextLineItem(
    val text: String,
    val boundingBox: RectNormalized,
    val words: List<TextWordItem> = emptyList()
)

data class TextRegion(
    val id: String,
    val type: RegionType,
    val text: String,
    val language: DetectedLanguage,
    val boundingBox: RectNormalized,
    val confidence: Float = 0.95f,
    val lines: List<TextLineItem> = emptyList(),
    val isGraphic: Boolean = false
)

data class OcrStats(
    val wordCount: Int,
    val charCount: Int,
    val lineCount: Int,
    val regionCount: Int,
    val hasTables: Boolean
)

data class OcrPageResult(
    val pageIndex: Int,
    val fullText: String,
    val regions: List<TextRegion>,
    val primaryLanguage: DetectedLanguage,
    val stats: OcrStats
)

data class ScanPage(
    val id: String,
    val uriString: String,
    val originalWidth: Int = 0,
    val originalHeight: Int = 0,
    val rotationDegrees: Int = 0,
    val enhancementMode: EnhancementMode = EnhancementMode.B_AND_W,
    val ocrResult: OcrPageResult? = null,
    val isProcessing: Boolean = false,
    val error: String? = null
)

enum class PdfExportMode(val titleAr: String, val subtitleAr: String) {
    RECONSTRUCTED_VECTOR(
        "PDF معاد إنشاؤه نظيف ومستقيم (موصى به)",
        "نسخة رقمية جديدة تبدو كالوثيقة الأصلية: إزالة الظلال والبقع، نصوص مستقيمة، جداول دقيقة، وبحث وتحديد كامل"
    ),
    SEARCHABLE_ORIGINAL(
        "PDF أصلي ممسوح ضوئياً",
        "يحافظ على شكل الصورة الأصلية مع إضافة طبقة نص OCR كاملة قابلة للتحديد والنسخ والبحث"
    ),
    PURE_TEXT(
        "PDF نصي خالص",
        "يعيد بناء الصفحة كنص حقيقي متجه ومنسق (بدون خلفية الصورة)، خفيف الحجم وقابل للبحث والتعديل"
    )
}

enum class SelectionUnit(val labelAr: String) {
    WORD("كلمة"),
    SENTENCE("جملة"),
    PARAGRAPH("فقرة"),
    ALL("كل النص")
}
