package com.example.vocalseparator.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * High-performance, memory-efficient Complex Fast Fourier Transform (FFT) & Inverse FFT (IFFT)
 * using the Radix-2 Cooley-Tukey algorithm.
 *
 * Designed specifically for real-time mobile audio source separation and spectral masking.
 */
class FastFourierTransform(val n: Int) {
    init {
        require(n > 0 && (n and (n - 1)) == 0) { "FFT size must be a power of 2, received $n" }
    }

    private val bitRev: IntArray = IntArray(n)
    private val cosTable: FloatArray = FloatArray(n / 2)
    private val sinTable: FloatArray = FloatArray(n / 2)

    init {
        // Precompute bit reversal permutation table
        val shift = 1 + Integer.numberOfLeadingZeros(n)
        for (i in 0 until n) {
            bitRev[i] = Integer.reverse(i) ushr shift
        }

        // Precompute twiddle factor trigonometric tables
        val angleStep = -2.0 * PI / n
        for (i in 0 until n / 2) {
            val angle = i * angleStep
            cosTable[i] = cos(angle).toFloat()
            sinTable[i] = sin(angle).toFloat()
        }
    }

    /**
     * In-place Forward Fast Fourier Transform.
     * @param real Real components array of size n
     * @param imag Imaginary components array of size n
     */
    fun forward(real: FloatArray, imag: FloatArray) {
        transform(real, imag, isInverse = false)
    }

    /**
     * In-place Inverse Fast Fourier Transform.
     * Output is scaled by 1/n.
     */
    fun inverse(real: FloatArray, imag: FloatArray) {
        transform(real, imag, isInverse = true)
        val scale = 1.0f / n
        for (i in 0 until n) {
            real[i] *= scale
            imag[i] *= scale
        }
    }

    private fun transform(real: FloatArray, imag: FloatArray, isInverse: Boolean) {
        // Bit-reversal permutation
        for (i in 0 until n) {
            val j = bitRev[i]
            if (i < j) {
                val tempR = real[i]
                real[i] = real[j]
                real[j] = tempR

                val tempI = imag[i]
                imag[i] = imag[j]
                imag[j] = tempI
            }
        }

        // Cooley-Tukey Radix-2 Butterfly iterations
        var len = 2
        while (len <= n) {
            val halfLen = len / 2
            val step = n / len
            var k = 0
            while (k < n) {
                var j = 0
                while (j < halfLen) {
                    val tableIdx = j * step
                    val c = cosTable[tableIdx]
                    val s = if (isInverse) -sinTable[tableIdx] else sinTable[tableIdx]

                    val uIdx = k + j
                    val vIdx = k + j + halfLen

                    val vReal = real[vIdx]
                    val vImag = imag[vIdx]

                    val tReal = vReal * c - vImag * s
                    val tImag = vReal * s + vImag * c

                    real[vIdx] = real[uIdx] - tReal
                    imag[vIdx] = imag[uIdx] - tImag

                    real[uIdx] += tReal
                    imag[uIdx] += tImag
                    j++
                }
                k += len
            }
            len = len shl 1
        }
    }

    companion object {
        /**
         * Generates a periodic Hann (Hanning) window of size [n].
         * Essential for smooth STFT analysis and artifact-free Overlap-Add reconstruction.
         */
        fun createHannWindow(n: Int): FloatArray {
            val window = FloatArray(n)
            val factor = 2.0 * PI / n
            for (i in 0 until n) {
                window[i] = (0.5 * (1.0 - cos(factor * i))).toFloat()
            }
            return window
        }

        /**
         * Calculates the magnitude spectrum from real and imaginary parts.
         */
        fun magnitude(real: Float, imag: Float): Float {
            return sqrt(real * real + imag * imag)
        }
    }
}
