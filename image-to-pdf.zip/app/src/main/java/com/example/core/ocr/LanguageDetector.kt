package com.example.core.ocr

import com.example.data.model.DetectedLanguage

object LanguageDetector {

    private val ARABIC_RANGE = Regex("[\\u0600-\\u06FF\\u0750-\\u077F\\u08A0-\\u08FF\\uFB50-\\uFDFF\\uFE70-\\uFEFF]")
    private val LATIN_RANGE = Regex("[a-zA-Z]")
    private val DIGIT_RANGE = Regex("[0-9\\u0660-\\u0669]")

    // Specific French marker words and accents
    private val FRENCH_ACCENTS = Regex("[éèêëàâäçîïôöùûüÿœæÉÈÊËÀÂÄÇÎÏÔÖÙÛÜŸŒÆ]")
    private val FRENCH_WORDS = setOf(
        "le", "la", "les", "un", "une", "des", "du", "de", "et", "en", "est", "dans",
        "pour", "avec", "sur", "qui", "ce", "cette", "ces", "au", "aux", "par", "pas",
        "plus", "nous", "vous", "ils", "elles", "facture", "total", "bonjour", "date"
    )

    // Common English marker words
    private val ENGLISH_WORDS = setOf(
        "the", "and", "is", "in", "to", "of", "it", "you", "that", "he", "was", "for",
        "on", "are", "as", "with", "his", "they", "at", "be", "this", "from", "invoice",
        "date", "total", "name", "subject", "page", "report", "company", "description"
    )

    fun detectLanguage(text: String): DetectedLanguage {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return DetectedLanguage.UNKNOWN

        val totalChars = trimmed.count { !it.isWhitespace() }
        val digitChars = trimmed.count { DIGIT_RANGE.containsMatchIn(it.toString()) }
        val arabicCount = trimmed.count { ARABIC_RANGE.containsMatchIn(it.toString()) }
        val latinCount = trimmed.count { LATIN_RANGE.containsMatchIn(it.toString()) }

        if (digitChars > 0 && (digitChars.toFloat() / totalChars >= 0.5f || (digitChars >= 4 && latinCount <= 4 && arabicCount == 0))) {
            return DetectedLanguage.NUMERIC
        }

        val hasArabic = arabicCount > 2
        val hasLatin = latinCount > 2

        if (hasArabic && hasLatin) {
            return DetectedLanguage.MIXED
        }

        if (hasArabic) {
            return DetectedLanguage.ARABIC
        }

        if (hasLatin) {
            // Distinguish French vs English
            if (FRENCH_ACCENTS.containsMatchIn(trimmed)) {
                return DetectedLanguage.FRENCH
            }

            val words = trimmed.lowercase().split(Regex("[\\s,.;:!?()\\[\\]{}\"']+"))
            var frenchScore = 0
            var englishScore = 0
            for (w in words) {
                if (FRENCH_WORDS.contains(w)) frenchScore++
                if (ENGLISH_WORDS.contains(w)) englishScore++
            }

            return when {
                frenchScore > englishScore -> DetectedLanguage.FRENCH
                englishScore > 0 -> DetectedLanguage.ENGLISH
                else -> DetectedLanguage.ENGLISH // default for Latin script
            }
        }

        return DetectedLanguage.UNKNOWN
    }
}
