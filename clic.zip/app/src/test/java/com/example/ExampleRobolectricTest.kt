package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.vocalseparator.audio.AiModelManager
import com.example.vocalseparator.audio.FastFourierTransform
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.abs

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun testAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("فصل الصوت AI", appName)
    }

    @Test
    fun testFastFourierTransformRoundtrip() {
        val size = 512
        val fft = FastFourierTransform(size)

        val original = FloatArray(size) { i ->
            kotlin.math.sin(2.0 * Math.PI * 440.0 * i / 44100.0).toFloat()
        }

        val real = original.clone()
        val imag = FloatArray(size)

        // Forward FFT
        fft.forward(real, imag)

        // Inverse FFT
        fft.inverse(real, imag)

        // Verify time domain waveform is reconstructed accurately
        for (i in 0 until size) {
            val diff = abs(original[i] - real[i])
            assertTrue("Reconstruction error at index $i is $diff", diff < 1e-3f)
        }
    }

    @Test
    fun testHannWindowGeneration() {
        val size = 1024
        val window = FastFourierTransform.createHannWindow(size)
        assertEquals(size, window.size)
        assertEquals(0f, window[0], 0.001f)
        assertTrue(window[size / 2] > 0.99f)
    }

    @Test
    fun testAiModelManagerCapabilities() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AiModelManager(context)
        val info = manager.getActiveModelInfo()
        assertNotNull(info)
        assertTrue(info.name.isNotEmpty())

        val capabilities = manager.getDeviceCapabilities()
        assertTrue(capabilities.isNotEmpty())
    }
}
