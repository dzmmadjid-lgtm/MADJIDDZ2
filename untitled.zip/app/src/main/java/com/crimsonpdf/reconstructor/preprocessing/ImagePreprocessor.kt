package com.crimsonpdf.reconstructor.preprocessing

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import com.crimsonpdf.reconstructor.model.PreprocessingConfig
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

object ImagePreprocessor {

    fun processBitmap(
        source: Bitmap,
        config: PreprocessingConfig,
        forModeB: Boolean = false
    ): Bitmap {
        val w = source.width.coerceAtLeast(100)
        val h = source.height.coerceAtLeast(100)

        val outBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)
        canvas.drawColor(Color.WHITE)

        val totalAngle = config.rotationDeg.toFloat() + config.deskewAngleDeg
        val matrix = Matrix().apply {
            postRotate(totalAngle, w / 2f, h / 2f)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(source, matrix, paint)

        val pixels = IntArray(w * h)
        outBitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val blockSize = 32
        val gridCols = ceil(w.toDouble() / blockSize).toInt().coerceAtLeast(1)
        val gridRows = ceil(h.toDouble() / blockSize).toInt().coerceAtLeast(1)
        val bgLumaGrid = FloatArray(gridCols * gridRows) { 225f }

        if (config.removeShadows || config.normalizeBackground) {
            for (gy in 0 until gridRows) {
                for (gx in 0 until gridCols) {
                    var maxLuma = 175f
                    val startY = gy * blockSize
                    val endY = min(h, startY + blockSize)
                    val startX = gx * blockSize
                    val endX = min(w, startX + blockSize)

                    var y = startY
                    while (y < endY) {
                        var x = startX
                        while (x < endX) {
                            val c = pixels[y * w + x]
                            val luma = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
                            if (luma > maxLuma) maxLuma = luma
                            x += 4
                        }
                        y += 4
                    }
                    bgLumaGrid[gy * gridCols + gx] = max(125f, maxLuma)
                }
            }
        }

        val shadowFactor = if (config.removeShadows) (config.shadowStrength / 100f) else 0f
        val contrastGain = 1f + (config.contrastBoost / 100f) * (if (forModeB) 1.15f else 0.85f)
        val whiteClip = if (config.normalizeBackground) (if (forModeB) 222f else 228f) else 250f

        for (y in 0 until h) {
            val gy = min(gridRows - 1, y / blockSize)
            val rowOffset = y * w
            for (x in 0 until w) {
                val gx = min(gridCols - 1, x / blockSize)
                val idx = rowOffset + x
                val c = pixels[idx]

                var r = Color.red(c).toFloat()
                var g = Color.green(c).toFloat()
                var b = Color.blue(c).toFloat()

                if (shadowFactor > 0f) {
                    val localBg = bgLumaGrid[gy * gridCols + gx]
                    val scale = 1f + shadowFactor * (250f / localBg - 1f)
                    r = min(255f, r * scale)
                    g = min(255f, g * scale)
                    b = min(255f, b * scale)
                }

                val luma = 0.299f * r + 0.587f * g + 0.114f * b
                val isColoredInk = abs(r - b) > 38f || abs(r - g) > 38f

                if (luma >= whiteClip && !isColoredInk) {
                    r = 255f
                    g = 255f
                    b = 255f
                } else {
                    r = min(255f, max(0f, (r - 165f) * contrastGain + 165f))
                    g = min(255f, max(0f, (g - 165f) * contrastGain + 165f))
                    b = min(255f, max(0f, (b - 165f) * contrastGain + 165f))
                }

                pixels[idx] = Color.argb(255, r.toInt(), g.toInt(), b.toInt())
            }
        }

        outBitmap.setPixels(pixels, 0, w, 0, 0, w, h)
        return outBitmap
    }
}
