package com.example.vocalseparator.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.vocalseparator.model.SeparationUiState
import com.example.vocalseparator.ui.components.FilePickerCard
import com.example.vocalseparator.ui.components.ProcessingProgressCard
import com.example.vocalseparator.ui.components.StudioPlayerCard
import com.example.vocalseparator.ui.theme.CyanAccent
import com.example.vocalseparator.ui.theme.InstrumentalGold
import com.example.vocalseparator.ui.theme.StudioBorder
import com.example.vocalseparator.ui.theme.StudioCardBg
import com.example.vocalseparator.ui.theme.StudioDarkBg
import com.example.vocalseparator.ui.theme.StudioSurfaceVariant
import com.example.vocalseparator.ui.theme.TextMuted
import com.example.vocalseparator.ui.theme.TextPrimary
import com.example.vocalseparator.ui.theme.TextSecondary
import com.example.vocalseparator.ui.theme.VocalPink
import com.example.vocalseparator.viewmodel.VocalSeparatorViewModel

/**
 * Main Studio Workstation Screen.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(
    viewModel: VocalSeparatorViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Studio, 1: History
    var showModelDialog by remember { mutableStateOf(false) }

    val selectedMetadata by viewModel.selectedMetadata.collectAsState()
    val separationState by viewModel.separationState.collectAsState()
    val currentRecord by viewModel.currentRecord.collectAsState()
    val historyList by viewModel.historyList.collectAsState()
    val playbackState by viewModel.playerPlaybackState.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.selectAudio(uri)
        }
    }

    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearToastMessage()
        }
    }

    if (showModelDialog) {
        ModelInfoDialog(
            modelManager = viewModel.modelManager,
            onDismiss = { showModelDialog = false }
        )
    }

    // Error Dialog
    if (separationState is SeparationUiState.Error) {
        val errorMsg = (separationState as SeparationUiState.Error).message
        AlertDialog(
            onDismissRequest = { viewModel.clearError() },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Error,
                        contentDescription = "خطأ",
                        tint = Color(0xFFEF4444)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تعذر إكمال فصل الصوت", color = TextPrimary)
                }
            },
            text = {
                Text(
                    text = errorMsg,
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.clearError() },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = StudioDarkBg)
                ) {
                    Text("حسناً")
                }
            },
            containerColor = StudioCardBg,
            shape = RoundedCornerShape(16.dp)
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = StudioDarkBg,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(CyanAccent.copy(alpha = 0.15f))
                                .border(1.dp, CyanAccent.copy(alpha = 0.4f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Logo",
                                tint = CyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = "فصل الصوت AI",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "Vocal & Music Stem Separator",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextMuted
                                )
                            )
                        }
                    }
                },
                actions = {
                    // AI Model status pill button
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = StudioSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .clickable { showModelDialog = true }
                            .padding(end = 8.dp)
                            .testTag("model_info_pill")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = "AI Model",
                                tint = CyanAccent,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "محرك AI",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CyanAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = StudioDarkBg
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = StudioCardBg,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "الاستوديو"
                        )
                    },
                    label = { Text("الاستوديو") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = StudioDarkBg,
                        selectedTextColor = CyanAccent,
                        indicatorColor = CyanAccent,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    ),
                    modifier = Modifier.testTag("nav_tab_studio")
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "السجل"
                        )
                    },
                    label = { Text("المشاريع (${historyList.size})") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = StudioDarkBg,
                        selectedTextColor = CyanAccent,
                        indicatorColor = CyanAccent,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    ),
                    modifier = Modifier.testTag("nav_tab_history")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (selectedTab == 0) {
                // Studio Screen Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Hero Studio Banner
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            Image(
                                painter = painterResource(id = R.drawable.studio_banner_1790507474474),
                                contentDescription = "Studio Banner",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Gradient overlay
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(
                                                StudioDarkBg.copy(alpha = 0.92f),
                                                StudioDarkBg.copy(alpha = 0.65f),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )

                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "عزل الصوت والموسيقى بالذكاء الاصطناعي",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "معالجة محلية 100% على هاتفك بدون إنترنت وبجودة استوديو احترافية",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextSecondary
                                    )
                                )
                            }
                        }
                    }

                    // 1. File Picker Card
                    val isSeparating = separationState is SeparationUiState.Processing
                    FilePickerCard(
                        selectedMetadata = selectedMetadata,
                        onPickFile = { filePickerLauncher.launch("audio/*") },
                        onStartSeparation = { viewModel.startSeparation() },
                        isProcessing = isSeparating
                    )

                    // 2. Active Separation Progress Card
                    if (separationState is SeparationUiState.Processing) {
                        val progress = (separationState as SeparationUiState.Processing).progress
                        ProcessingProgressCard(
                            progress = progress,
                            onCancel = { viewModel.cancelSeparation() }
                        )
                    }

                    // 3. Multi-Track Studio Player Deck
                    currentRecord?.let { record ->
                        StudioPlayerCard(
                            record = record,
                            playbackState = playbackState,
                            onTogglePlayPause = { viewModel.player.togglePlayPause() },
                            onSeekTo = { pos -> viewModel.player.seekTo(pos) },
                            onSeekRelative = { offset -> viewModel.player.seekRelative(offset) },
                            onSetVocalsVolume = { vol -> viewModel.player.setVocalsVolume(vol) },
                            onSetInstrumentalVolume = { vol -> viewModel.player.setInstrumentalVolume(vol) },
                            onToggleVocalsMute = { viewModel.player.toggleVocalsMute() },
                            onToggleInstrumentalMute = { viewModel.player.toggleInstrumentalMute() },
                            onSetSoloMode = { mode -> viewModel.player.setSoloMode(mode) },
                            onExportVocals = { viewModel.exportTrack(isVocals = true) },
                            onExportInstrumental = { viewModel.exportTrack(isVocals = false) }
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            } else {
                // History Screen Content
                HistoryScreen(
                    records = historyList,
                    onSelectRecord = { record ->
                        viewModel.loadRecordIntoStudio(record)
                        selectedTab = 0 // Switch back to Studio
                    },
                    onDeleteRecord = { record ->
                        viewModel.deleteRecord(record)
                    }
                )
            }
        }
    }
}
