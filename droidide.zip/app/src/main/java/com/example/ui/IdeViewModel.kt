package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.fs.JdkInstallStatus
import com.example.core.fs.JdkProvisioner
import com.example.core.fs.ProjectManager
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

import com.example.core.fs.GradleProvisioner
import com.example.core.fs.GradleInstallStatus
import com.example.core.diagnostics.EnvironmentDiagnostics
import com.example.core.scanner.DiscoveredScannerDevice
import com.example.core.scanner.ScanJobOptions
import com.example.core.scanner.ScannerManager
import com.example.core.scanner.TransportType
import android.graphics.Bitmap

data class GradleInfo(
    val isAvailable: Boolean = false,
    val version: String = "Gradle 8.7",
    val path: String = "",
    val zipSizeMb: Double = 0.0,
    val detectedDownloadFile: File? = null,
    val errorDetails: String? = null
)

data class JdkInfo(
    val isAvailable: Boolean = true,
    val javaVersion: String = "OpenJDK 17.0.20.1",
    val architecture: String = "arm64-v8a",
    val targetPlatform: String = "Android 16 / arm64-v8a",
    val javaHome: String? = null,
    val javaBin: String? = null,
    val usesLinker: Boolean = false,
    val installError: String? = null
)

class IdeViewModel(application: Application) : AndroidViewModel(application) {

    private val projectManager = ProjectManager(application)
    private val jdkProvisioner = JdkProvisioner(application)
    private val gradleProvisioner = GradleProvisioner(application)
    private val scannerManager = ScannerManager(application)
    @Volatile
    private var activeBuildProcess: Process? = null
    @Volatile
    private var isBuildCancelled = false

    // Canon MF440 Hardware Scanner State
    private val _discoveredScanners = MutableStateFlow<List<DiscoveredScannerDevice>>(emptyList())
    val discoveredScanners: StateFlow<List<DiscoveredScannerDevice>> = _discoveredScanners.asStateFlow()

    private val _selectedScanner = MutableStateFlow<DiscoveredScannerDevice?>(null)
    val selectedScanner: StateFlow<DiscoveredScannerDevice?> = _selectedScanner.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _scanStatusLogs = MutableStateFlow<List<String>>(emptyList())
    val scanStatusLogs: StateFlow<List<String>> = _scanStatusLogs.asStateFlow()

    private val _scanError = MutableStateFlow<String?>(null)
    val scanError: StateFlow<String?> = _scanError.asStateFlow()

    private val _scannedBitmap = MutableStateFlow<Bitmap?>(null)
    val scannedBitmap: StateFlow<Bitmap?> = _scannedBitmap.asStateFlow()

    private val _editedBitmap = MutableStateFlow<Bitmap?>(null)
    val editedBitmap: StateFlow<Bitmap?> = _editedBitmap.asStateFlow()

    private val _savedScanPages = MutableStateFlow<List<Bitmap>>(emptyList())
    val savedScanPages: StateFlow<List<Bitmap>> = _savedScanPages.asStateFlow()

    private val _lastSavedImageFile = MutableStateFlow<File?>(null)
    val lastSavedImageFile: StateFlow<File?> = _lastSavedImageFile.asStateFlow()

    private val _lastGeneratedPdfFile = MutableStateFlow<File?>(null)
    val lastGeneratedPdfFile: StateFlow<File?> = _lastGeneratedPdfFile.asStateFlow()

    // Theme Mode
    private val _themeMode = MutableStateFlow(ThemeMode.DARK)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    // Projects & File Tree
    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    // Gradle Provisioning UI State
    private val _showGradleDialog = MutableStateFlow(false)
    val showGradleDialog: StateFlow<Boolean> = _showGradleDialog.asStateFlow()

    private val _isGradleInstalling = MutableStateFlow(false)
    val isGradleInstalling: StateFlow<Boolean> = _isGradleInstalling.asStateFlow()

    private val _gradleInstallProgress = MutableStateFlow("")
    val gradleInstallProgress: StateFlow<String> = _gradleInstallProgress.asStateFlow()

    private val _gradleInstallError = MutableStateFlow<String?>(null)
    val gradleInstallError: StateFlow<String?> = _gradleInstallError.asStateFlow()

    private val _gradleInfo = MutableStateFlow<GradleInfo?>(null)
    val gradleInfo: StateFlow<GradleInfo?> = _gradleInfo.asStateFlow()

    private val _currentProject = MutableStateFlow<Project?>(null)
    val currentProject: StateFlow<Project?> = _currentProject.asStateFlow()

    private val _fileTree = MutableStateFlow<FileNode?>(null)
    val fileTree: StateFlow<FileNode?> = _fileTree.asStateFlow()

    // Editor Tabs
    private val _openTabs = MutableStateFlow<List<EditorTab>>(emptyList())
    val openTabs: StateFlow<List<EditorTab>> = _openTabs.asStateFlow()

    private val _activeTabIndex = MutableStateFlow(-1)
    val activeTabIndex: StateFlow<Int> = _activeTabIndex.asStateFlow()

    // Target line to jump to in editor
    private val _targetEditorLine = MutableStateFlow<Int?>(null)
    val targetEditorLine: StateFlow<Int?> = _targetEditorLine.asStateFlow()

    // Bottom Tool Window
    private val _activeToolWindow = MutableStateFlow(BottomToolWindow.BUILD_OUTPUT)
    val activeToolWindow: StateFlow<BottomToolWindow> = _activeToolWindow.asStateFlow()

    // JDK Provisioning UI State
    private val _showJdkDialog = MutableStateFlow(false)
    val showJdkDialog: StateFlow<Boolean> = _showJdkDialog.asStateFlow()

    private val _isJdkInstalling = MutableStateFlow(false)
    val isJdkInstalling: StateFlow<Boolean> = _isJdkInstalling.asStateFlow()

    private val _jdkInstallProgress = MutableStateFlow("")
    val jdkInstallProgress: StateFlow<String> = _jdkInstallProgress.asStateFlow()

    private val _jdkInstallError = MutableStateFlow<String?>(null)
    val jdkInstallError: StateFlow<String?> = _jdkInstallError.asStateFlow()

    private val _isToolWindowExpanded = MutableStateFlow(true)
    val isToolWindowExpanded: StateFlow<Boolean> = _isToolWindowExpanded.asStateFlow()

    private val _isFileExplorerVisible = MutableStateFlow(true)
    val isFileExplorerVisible: StateFlow<Boolean> = _isFileExplorerVisible.asStateFlow()

    // Build & Terminal State
    private val _buildStatus = MutableStateFlow(BuildStatus.IDLE)
    val buildStatus: StateFlow<BuildStatus> = _buildStatus.asStateFlow()

    private val _buildLogs = MutableStateFlow<List<BuildLogEntry>>(emptyList())
    val buildLogs: StateFlow<List<BuildLogEntry>> = _buildLogs.asStateFlow()

    private val _problems = MutableStateFlow<List<ProblemItem>>(emptyList())
    val problems: StateFlow<List<ProblemItem>> = _problems.asStateFlow()

    private val _buildResult = MutableStateFlow<BuildResult?>(null)
    val buildResult: StateFlow<BuildResult?> = _buildResult.asStateFlow()

    // JDK Info
    private val _jdkInfo = MutableStateFlow<JdkInfo?>(JdkInfo())
    val jdkInfo: StateFlow<JdkInfo?> = _jdkInfo.asStateFlow()

    init {
        loadProjects()
        refreshJdkStatus()
        refreshGradleStatus()
    }

    fun setShowGradleDialog(show: Boolean) {
        _showGradleDialog.value = show
        if (show) {
            _gradleInstallError.value = null
            refreshGradleStatus()
        }
    }

    fun refreshGradleStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            val status = gradleProvisioner.checkGradleStatus()
            val detected = gradleProvisioner.findDetectedZipInDownloads()
            _gradleInfo.value = GradleInfo(
                isAvailable = status.isInstalled,
                version = status.version,
                path = status.gradleHomePath,
                zipSizeMb = status.zipSizeMb,
                detectedDownloadFile = detected,
                errorDetails = status.errorDetails
            )
        }
    }

    fun installGradleFromUri(uri: Uri, fileName: String) {
        _isGradleInstalling.value = true
        _gradleInstallProgress.value = "Starting import from $fileName..."
        _gradleInstallError.value = null

        viewModelScope.launch(Dispatchers.IO) {
            val result = gradleProvisioner.installGradleFromUri(uri) { progress ->
                _gradleInstallProgress.value = progress
            }
            _isGradleInstalling.value = false
            if (result.isInstalled) {
                _gradleInstallProgress.value = "Gradle 8.7 successfully installed and verified!"
                _gradleInstallError.value = null
                currentProject.value?.rootDir?.let { gradleProvisioner.applyLocalDistributionToProject(it) }
                refreshGradleStatus()
            } else {
                _gradleInstallProgress.value = ""
                _gradleInstallError.value = result.errorDetails ?: "Gradle installation failed"
            }
        }
    }

    fun installGradleFromDetectedFile(file: File) {
        _isGradleInstalling.value = true
        _gradleInstallProgress.value = "Importing from ${file.name}..."
        _gradleInstallError.value = null

        viewModelScope.launch(Dispatchers.IO) {
            val result = gradleProvisioner.installGradleFromFile(file) { progress ->
                _gradleInstallProgress.value = progress
            }
            _isGradleInstalling.value = false
            if (result.isInstalled) {
                _gradleInstallProgress.value = "Gradle 8.7 successfully installed and verified!"
                _gradleInstallError.value = null
                currentProject.value?.rootDir?.let { gradleProvisioner.applyLocalDistributionToProject(it) }
                refreshGradleStatus()
            } else {
                _gradleInstallProgress.value = ""
                _gradleInstallError.value = result.errorDetails ?: "Gradle installation failed"
            }
        }
    }

    fun setShowJdkDialog(show: Boolean) {
        _showJdkDialog.value = show
        if (show) {
            _jdkInstallError.value = null
        }
    }

    fun refreshJdkStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            val status = jdkProvisioner.checkJdkStatus()
            _jdkInfo.value = JdkInfo(
                isAvailable = status.isInstalled,
                javaVersion = status.javaVersion,
                architecture = "arm64-v8a",
                targetPlatform = "Android 16 / arm64-v8a",
                javaHome = status.javaHomePath,
                javaBin = status.javaBinPath,
                usesLinker = status.usesLinker,
                installError = status.errorDetails
            )
        }
    }

    fun installJdkFromUri(uri: Uri, fileName: String) {
        _isJdkInstalling.value = true
        _jdkInstallProgress.value = "Starting installation from file..."
        _jdkInstallError.value = null

        viewModelScope.launch(Dispatchers.IO) {
            val result = jdkProvisioner.installJdkFromUri(uri, fileName) { progress ->
                _jdkInstallProgress.value = progress
            }
            _isJdkInstalling.value = false
            if (result.isInstalled) {
                _jdkInstallProgress.value = "JDK successfully installed and verified!"
                _jdkInstallError.value = null
                _jdkInfo.value = JdkInfo(
                    isAvailable = true,
                    javaVersion = result.javaVersion,
                    architecture = "arm64-v8a",
                    targetPlatform = "Android 16 / arm64-v8a",
                    javaHome = result.javaHomePath,
                    javaBin = result.javaBinPath,
                    usesLinker = result.usesLinker
                )
            } else {
                _jdkInstallProgress.value = ""
                _jdkInstallError.value = result.errorDetails ?: "Installation verification failed"
                _jdkInfo.value = _jdkInfo.value?.copy(
                    isAvailable = false,
                    usesLinker = result.usesLinker,
                    installError = result.errorDetails
                )
            }
        }
    }

    fun downloadAndInstallJdk(url: String) {
        if (url.isBlank()) return
        _isJdkInstalling.value = true
        _jdkInstallProgress.value = "Connecting to download server..."
        _jdkInstallError.value = null

        viewModelScope.launch(Dispatchers.IO) {
            val result = jdkProvisioner.downloadAndInstallJdk(url.trim()) { progress ->
                _jdkInstallProgress.value = progress
            }
            _isJdkInstalling.value = false
            if (result.isInstalled) {
                _jdkInstallProgress.value = "JDK successfully installed and verified!"
                _jdkInstallError.value = null
                _jdkInfo.value = JdkInfo(
                    isAvailable = true,
                    javaVersion = result.javaVersion,
                    architecture = "arm64-v8a",
                    targetPlatform = "Android 16 / arm64-v8a",
                    javaHome = result.javaHomePath,
                    javaBin = result.javaBinPath,
                    usesLinker = result.usesLinker
                )
            } else {
                _jdkInstallProgress.value = ""
                _jdkInstallError.value = result.errorDetails ?: "Download or extraction failed"
                _jdkInfo.value = _jdkInfo.value?.copy(
                    isAvailable = false,
                    usesLinker = result.usesLinker,
                    installError = result.errorDetails
                )
            }
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    fun toggleTheme() {
        _themeMode.value = when (_themeMode.value) {
            ThemeMode.DARK -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.OLED
            ThemeMode.OLED -> ThemeMode.DARK
        }
    }

    // Project Management Dialog
    private val _showProjectsDialog = MutableStateFlow(false)
    val showProjectsDialog: StateFlow<Boolean> = _showProjectsDialog.asStateFlow()

    // Top Drawer state for mobile navigation
    private val _isDrawerOpen = MutableStateFlow(false)
    val isDrawerOpen: StateFlow<Boolean> = _isDrawerOpen.asStateFlow()

    fun setDrawerOpen(isOpen: Boolean) {
        _isDrawerOpen.value = isOpen
    }

    fun setShowProjectsDialog(show: Boolean) {
        _showProjectsDialog.value = show
    }

    // Diagnostics State
    private val _isDiagnosticsRunning = MutableStateFlow(false)
    val isDiagnosticsRunning: StateFlow<Boolean> = _isDiagnosticsRunning.asStateFlow()

    private val _diagnosticsReport = MutableStateFlow<String?>(null)
    val diagnosticsReport: StateFlow<String?> = _diagnosticsReport.asStateFlow()

    private val _showDiagnosticsDialog = MutableStateFlow(false)
    val showDiagnosticsDialog: StateFlow<Boolean> = _showDiagnosticsDialog.asStateFlow()

    fun setShowDiagnosticsDialog(show: Boolean) {
        _showDiagnosticsDialog.value = show
    }

    fun runDiagnostics() {
        if (_isDiagnosticsRunning.value) return
        _isDiagnosticsRunning.value = true
        _showDiagnosticsDialog.value = true
        _diagnosticsReport.value = "🔍 Starting DroidIDE Environment & JDK Diagnostics...\nRunning comprehensive checks (OS, CPU, memory, linkers, java executable tests, pointer tagging check)..."

        _activeToolWindow.value = BottomToolWindow.BUILD_OUTPUT
        _isToolWindowExpanded.value = true
        _buildLogs.value = listOf(
            BuildLogEntry("==================================================", false, System.currentTimeMillis()),
            BuildLogEntry("🔍 Starting DroidIDE Environment & JDK Diagnostics...", false, System.currentTimeMillis())
        )

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val report = EnvironmentDiagnostics.runFullDiagnostic(
                    context = getApplication(),
                    jdkProvisioner = jdkProvisioner,
                    gradleProvisioner = gradleProvisioner,
                    onLog = { msg ->
                        val isErr = msg.contains("❌") || msg.contains("error", ignoreCase = true) || msg.contains("failed", ignoreCase = true) || msg.contains("Exit Code: 134") || msg.contains("Pointer tag for", ignoreCase = true)
                        _buildLogs.value = _buildLogs.value + BuildLogEntry(msg, isErr, System.currentTimeMillis())
                    }
                )
                _diagnosticsReport.value = report
            } catch (e: Exception) {
                val err = "Diagnostics execution failed: ${e.message}"
                _diagnosticsReport.value = err
                _buildLogs.value = _buildLogs.value + BuildLogEntry(err, true, System.currentTimeMillis())
            } finally {
                _isDiagnosticsRunning.value = false
            }
        }
    }

    fun loadProjects() {
        viewModelScope.launch(Dispatchers.IO) {
            var list = projectManager.listProjects()
            if (list.isEmpty()) {
                val candidate = File("/app/applet")
                if (candidate.exists() && File(candidate, "build.gradle.kts").exists()) {
                    val workspaceProj = Project(
                        name = "DroidIDE",
                        rootDir = candidate,
                        packageName = "com.example.droidide"
                    )
                    list = listOf(workspaceProj)
                } else {
                    // Automatically create sample project on user device if empty
                    val sample = projectManager.ensureDefaultProject()
                    list = listOf(sample)
                }
            }
            _projects.value = list

            if (_currentProject.value == null && list.isNotEmpty()) {
                openProject(list.first())
            }
        }
    }

    fun createNewProject(name: String, packageName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val proj = projectManager.createProject(name, packageName)
            _projects.value = projectManager.listProjects()
            openProject(proj)
            _showProjectsDialog.value = false
        }
    }

    fun importProjectFromZip(inputStream: java.io.InputStream, name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val proj = projectManager.importProjectFromZip(inputStream, name)
            if (proj != null) {
                _projects.value = projectManager.listProjects()
                openProject(proj)
                _showProjectsDialog.value = false
            }
        }
    }

    fun deleteProject(project: Project) {
        viewModelScope.launch(Dispatchers.IO) {
            projectManager.deleteProject(project)
            val remaining = projectManager.listProjects()
            _projects.value = remaining
            if (_currentProject.value?.rootDir?.absolutePath == project.rootDir.absolutePath) {
                _openTabs.value = emptyList()
                _activeTabIndex.value = -1
                if (remaining.isNotEmpty()) {
                    openProject(remaining.first())
                } else {
                    val def = projectManager.ensureDefaultProject()
                    _projects.value = listOf(def)
                    openProject(def)
                }
            }
        }
    }

    fun openProject(project: Project) {
        _currentProject.value = project
        _openTabs.value = emptyList()
        _activeTabIndex.value = -1
        refreshFileTree()
    }

    fun refreshFileTree() {
        val proj = _currentProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val tree = projectManager.buildFileTree(proj.rootDir)
            _fileTree.value = tree

            // If tabs empty, open MainActivity or first kotlin file
            if (_openTabs.value.isEmpty()) {
                val srcDir = File(proj.rootDir, "app/src/main/java")
                val firstKt = if (srcDir.exists()) {
                    srcDir.walkTopDown().firstOrNull { it.isFile && it.extension == "kt" }
                } else null
                val targetFile = firstKt ?: File(proj.rootDir, "app/build.gradle.kts").takeIf { it.exists() }
                if (targetFile != null) {
                    openFile(targetFile)
                }
            }
        }
    }

    fun openFile(file: File, jumpToLine: Int? = null) {
        if (!file.exists() || file.isDirectory) return

        viewModelScope.launch(Dispatchers.IO) {
            val currentTabs = _openTabs.value.toMutableList()
            val existingIndex = currentTabs.indexOfFirst { it.file.absolutePath == file.absolutePath }

            if (existingIndex >= 0) {
                _activeTabIndex.value = existingIndex
                _targetEditorLine.value = jumpToLine
            } else {
                val content = projectManager.readFileContent(file)
                val newTab = EditorTab(
                    file = file,
                    title = file.name,
                    content = content,
                    isDirty = false
                )
                currentTabs.add(newTab)
                _openTabs.value = currentTabs
                _activeTabIndex.value = currentTabs.size - 1
                _targetEditorLine.value = jumpToLine
            }
        }
    }

    fun closeTab(index: Int) {
        val currentTabs = _openTabs.value.toMutableList()
        if (index in currentTabs.indices) {
            currentTabs.removeAt(index)
            _openTabs.value = currentTabs
            val newActive = when {
                currentTabs.isEmpty() -> -1
                _activeTabIndex.value >= currentTabs.size -> currentTabs.size - 1
                _activeTabIndex.value == index -> index.coerceAtMost(currentTabs.size - 1)
                _activeTabIndex.value > index -> _activeTabIndex.value - 1
                else -> _activeTabIndex.value
            }
            _activeTabIndex.value = newActive
        }
    }

    fun selectTab(index: Int) {
        if (index in _openTabs.value.indices) {
            _activeTabIndex.value = index
        }
    }

    fun updateActiveTabContent(newContent: String) {
        val index = _activeTabIndex.value
        val tabs = _openTabs.value.toMutableList()
        if (index in tabs.indices) {
            val tab = tabs[index]
            tabs[index] = tab.copy(
                content = newContent,
                isDirty = true
            )
            _openTabs.value = tabs
        }
    }

    fun saveCurrentFile() {
        val index = _activeTabIndex.value
        val tabs = _openTabs.value.toMutableList()
        if (index in tabs.indices) {
            val tab = tabs[index]
            viewModelScope.launch(Dispatchers.IO) {
                projectManager.saveFileContent(tab.file, tab.content)
                tabs[index] = tab.copy(isDirty = false)
                _openTabs.value = tabs
            }
        }
    }

    fun saveAllFiles() {
        viewModelScope.launch(Dispatchers.IO) {
            val tabs = _openTabs.value.toMutableList()
            for (i in tabs.indices) {
                val tab = tabs[i]
                if (tab.isDirty) {
                    projectManager.saveFileContent(tab.file, tab.content)
                    tabs[i] = tab.copy(isDirty = false)
                }
            }
            _openTabs.value = tabs
        }
    }

    fun createFile(parentDir: File, fileName: String, initialContent: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            val created = projectManager.createFile(parentDir, fileName, initialContent)
            refreshFileTree()
            openFile(created)
        }
    }

    fun createFolder(parentDir: File, folderName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            projectManager.createDirectory(parentDir, folderName)
            refreshFileTree()
        }
    }

    fun deleteItem(file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            val currentTabs = _openTabs.value.filterNot { it.file.absolutePath == file.absolutePath }
            _openTabs.value = currentTabs
            _activeTabIndex.value = if (currentTabs.isNotEmpty()) 0 else -1

            projectManager.deleteFileOrDirectory(file)
            refreshFileTree()
        }
    }

    fun renameItem(file: File, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val renamed = projectManager.renameFileOrDirectory(file, newName)
            if (renamed != null) {
                val currentTabs = _openTabs.value.map { tab ->
                    if (tab.file.absolutePath == file.absolutePath) {
                        tab.copy(file = renamed, title = renamed.name)
                    } else tab
                }
                _openTabs.value = currentTabs
            }
            refreshFileTree()
        }
    }

    fun startBuild(tasks: List<String> = listOf("assembleDebug")) {
        val proj = _currentProject.value ?: return
        if (_buildStatus.value == BuildStatus.RUNNING) return

        saveAllFiles()

        _buildStatus.value = BuildStatus.RUNNING
        _buildLogs.value = emptyList()
        _problems.value = emptyList()
        _activeToolWindow.value = BottomToolWindow.BUILD_OUTPUT
        _isToolWindowExpanded.value = true
        isBuildCancelled = false

        viewModelScope.launch(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            val logs = mutableListOf<BuildLogEntry>()
            val rawLines = mutableListOf<String>()

            fun emit(msg: String, isErr: Boolean = false) {
                val entry = BuildLogEntry(msg, isErr, System.currentTimeMillis())
                logs.add(entry)
                rawLines.add(msg)
                _buildLogs.value = _buildLogs.value + entry
            }

            emit("> Starting build with tasks: ${tasks.joinToString(" ")}")

            // Check if local Gradle distribution is configured and apply to project
            val gradleUserHome = File(getApplication<Application>().filesDir, "gradle_home")
            if (!gradleUserHome.exists()) {
                gradleUserHome.mkdirs()
            }

            val jvmSafeArgs = "org.gradle.jvmargs=-Xmx768m -XX:+UseSerialGC -XX:-UseCompressedOops -XX:-UseCompressedClassPointers -Dfile.encoding=UTF-8"
            val safeGradlePropsContent = """
                org.gradle.daemon=false
                org.gradle.parallel=false
                org.gradle.vfs.watch=false
                $jvmSafeArgs
                android.useAndroidX=true
                android.nonTransitiveRClass=true
                kotlin.code.style=official
            """.trimIndent()

            try {
                gradleProvisioner.applyLocalDistributionToProject(proj.rootDir)
                if (gradleProvisioner.checkGradleStatus().isInstalled) {
                    emit("> Using local Gradle 8.7 distribution (Offline mode)")
                }

                // Ensure global gradleUserHome/gradle.properties exists with safe ARM64 memory settings
                File(gradleUserHome, "gradle.properties").writeText(safeGradlePropsContent)

                // Sanitize project's gradle.properties to ensure matching settings
                val gradleProps = File(proj.rootDir, "gradle.properties")
                if (gradleProps.exists()) {
                    val currentText = gradleProps.readText()
                    val updatedLines = currentText.lines().map { line ->
                        when {
                            line.startsWith("org.gradle.jvmargs=") -> jvmSafeArgs
                            line.startsWith("org.gradle.daemon=") -> "org.gradle.daemon=false"
                            line.startsWith("org.gradle.parallel=") -> "org.gradle.parallel=false"
                            line.startsWith("org.gradle.vfs.watch=") -> "org.gradle.vfs.watch=false"
                            else -> line
                        }
                    }
                    val updatedText = updatedLines.joinToString("\n")
                    val finalText = if (!updatedText.contains("org.gradle.daemon=")) {
                        "org.gradle.daemon=false\norg.gradle.parallel=false\norg.gradle.vfs.watch=false\n$updatedText"
                    } else updatedText
                    gradleProps.writeText(finalText)
                } else {
                    gradleProps.writeText(safeGradlePropsContent)
                }
            } catch (e: Exception) {}

            // Check if user has installed custom JDK
            val customJdkHome = jdkProvisioner.internalJdkDir
            val customJavaBin = jdkProvisioner.javaExecutable
            val hasCustomJdk = customJavaBin.exists()

            val gradlewScript = File(proj.rootDir, "gradlew")
            val command = mutableListOf<String>()

            val javaBin = when {
                hasCustomJdk -> customJavaBin.absolutePath
                System.getenv("JAVA_HOME") != null -> "${System.getenv("JAVA_HOME")}/bin/java"
                else -> "java"
            }

            if (hasCustomJdk) {
                emit("> Using Android Custom JDK at: ${customJdkHome.absolutePath}")
            }

            // Ensure Gradle Wrapper (gradle-wrapper.jar) exists or auto-download it
            val wrapperJar = ensureGradleWrapper(proj, ::emit)

            // Find gradle-launcher jar directly to bypass secondary JVM fork by wrapper
            val directLauncherJar: File? = run {
                val installedLib = File(gradleProvisioner.installedGradleDir, "lib")
                if (installedLib.exists()) {
                    val f = installedLib.listFiles { file -> file.name.startsWith("gradle-launcher-") && file.name.endsWith(".jar") }?.firstOrNull()
                    if (f != null) return@run f
                }
                val distsDir = File(gradleUserHome, "wrapper/dists")
                if (distsDir.exists()) {
                    val f = distsDir.walkTopDown().maxDepth(5).firstOrNull { it.isFile && it.name.startsWith("gradle-launcher-") && it.name.endsWith(".jar") }
                    if (f != null) return@run f
                }
                null
            }

            if (directLauncherJar != null && directLauncherJar.exists()) {
                emit("> Executing Gradle directly via ${directLauncherJar.name} (Direct Engine)")
                val javaTokens = if (hasCustomJdk) {
                    jdkProvisioner.getJavaInvocation(customJavaBin)
                } else {
                    listOf(javaBin)
                }
                command.addAll(javaTokens)
                command.addAll(listOf(
                    "-Xmx768m",
                    "-XX:+UseSerialGC",
                    "-XX:-UseCompressedOops",
                    "-XX:-UseCompressedClassPointers",
                    "-Dfile.encoding=UTF-8",
                    "-Dorg.gradle.appname=gradle",
                    "-Dorg.gradle.daemon=false",
                    "-Dorg.gradle.parallel=false",
                    "-Dorg.gradle.vfs.watch=false",
                    "-Dgradle.user.home=${gradleUserHome.absolutePath}",
                    "-Dorg.gradle.jvmargs=-Xmx768m -XX:+UseSerialGC -XX:-UseCompressedOops -XX:-UseCompressedClassPointers -Dfile.encoding=UTF-8",
                    "-classpath", directLauncherJar.absolutePath,
                    "org.gradle.launcher.GradleMain",
                    "-p", proj.rootDir.absolutePath,
                    "--no-daemon",
                    "--no-parallel",
                    "-Dorg.gradle.vfs.watch=false",
                    "--console=plain"
                ))
                command.addAll(tasks)
            } else if (wrapperJar != null && wrapperJar.exists()) {
                val javaTokens = if (hasCustomJdk) {
                    jdkProvisioner.getJavaInvocation(customJavaBin)
                } else {
                    listOf(javaBin)
                }
                command.addAll(javaTokens)
                command.addAll(listOf(
                    "-Xmx768m",
                    "-XX:+UseSerialGC",
                    "-XX:-UseCompressedOops",
                    "-XX:-UseCompressedClassPointers",
                    "-Dorg.gradle.appname=gradlew",
                    "-Dorg.gradle.daemon=false",
                    "-Dgradle.user.home=${gradleUserHome.absolutePath}",
                    "-Dorg.gradle.jvmargs=-Xmx768m -XX:+UseSerialGC -XX:-UseCompressedOops -XX:-UseCompressedClassPointers -Dfile.encoding=UTF-8",
                    "-classpath", wrapperJar.absolutePath,
                    "org.gradle.wrapper.GradleWrapperMain",
                    "-p", proj.rootDir.absolutePath,
                    "--no-daemon",
                    "--no-parallel",
                    "-Dorg.gradle.vfs.watch=false",
                    "--console=plain"
                ))
                command.addAll(tasks)
            } else if (gradlewScript.exists()) {
                try {
                    gradlewScript.setReadable(true, false)
                    gradlewScript.setExecutable(true, false)
                    Runtime.getRuntime().exec(arrayOf("chmod", "755", gradlewScript.absolutePath)).waitFor()
                } catch (e: Exception) {}
                command.addAll(listOf("sh", gradlewScript.absolutePath, "-p", proj.rootDir.absolutePath))
                command.addAll(tasks)
            } else {
                emit("> Build Error: Gradle Wrapper (gradle-wrapper.jar) is missing and could not be downloaded.", true)
                emit("> Please connect to the internet to download Gradle Wrapper or add it to gradle/wrapper/ directory.", true)
                _buildResult.value = BuildResult(
                    status = BuildStatus.FAILED,
                    exitCode = -1,
                    durationMs = System.currentTimeMillis() - startTime,
                    logs = logs
                )
                return@launch
            }

            var exitCode = -1
            try {
                val pb = ProcessBuilder(command).directory(proj.rootDir)
                val env = pb.environment()

                // Set GRADLE_USER_HOME so Gradle has full read/write permission in app private storage
                env["GRADLE_USER_HOME"] = gradleUserHome.absolutePath
                env["MALLOC_CHECK_"] = "0"
                env["SCUDO_OPTIONS"] = "Tagging=0:ZeroContents=0:DeallocTypeMismatch=0:DeleteSizeMismatch=0"
                env["BIONIC_TAGGED_POINTERS"] = "0"
                env["ANDROID_TAGGED_POINTERS"] = "0"
                env["MALLOC_TAGGING_LEVEL"] = "0"

                val safeJvmFlagsStr = "-Xmx768m -XX:+UseSerialGC -XX:-UseCompressedOops -XX:-UseCompressedClassPointers -Dfile.encoding=UTF-8"
                env["JAVA_OPTS"] = safeJvmFlagsStr
                env["GRADLE_OPTS"] = "$safeJvmFlagsStr -Dorg.gradle.daemon=false -Dorg.gradle.parallel=false -Dorg.gradle.vfs.watch=false"

                // Inject Custom JDK into environment if present
                if (hasCustomJdk) {
                    env["JAVA_HOME"] = customJdkHome.absolutePath
                    val binDir = File(customJdkHome, "bin").absolutePath
                    val libDir = File(customJdkHome, "lib").absolutePath
                    val jliDir = File(customJdkHome, "lib/jli").absolutePath
                    val serverDir = File(customJdkHome, "lib/server").absolutePath
                    val existingPath = env["PATH"] ?: ""
                    env["PATH"] = "$binDir:$existingPath"
                    val existingLd = env["LD_LIBRARY_PATH"] ?: ""
                    env["LD_LIBRARY_PATH"] = "$libDir:$jliDir:$serverDir:$existingLd"
                }

                val process = pb.start()
                activeBuildProcess = process

                val reader = BufferedReader(InputStreamReader(process.inputStream))
                val errReader = BufferedReader(InputStreamReader(process.errorStream))

                val t1 = Thread {
                    var l: String?
                    while (reader.readLine().also { l = it } != null) {
                        l?.let { emit(it, false) }
                    }
                }
                val t2 = Thread {
                    var l: String?
                    while (errReader.readLine().also { l = it } != null) {
                        l?.let { emit(it, true) }
                    }
                }
                t1.start()
                t2.start()

                exitCode = process.waitFor()
                t1.join(1000)
                t2.join(1000)
            } catch (e: Exception) {
                if (isBuildCancelled) {
                    emit("> Build cancelled.", true)
                } else {
                    emit("> Build error: ${e.message}", true)
                }
            } finally {
                activeBuildProcess = null
            }

            val duration = System.currentTimeMillis() - startTime
            val status = if (isBuildCancelled) BuildStatus.CANCELLED else if (exitCode == 0) BuildStatus.SUCCESS else BuildStatus.FAILED
            emit("> Process finished with exit code: $exitCode (${duration / 1000}s)")
            if (exitCode == 0) {
                emit("> BUILD SUCCESSFUL", false)
            } else if (isBuildCancelled) {
                emit("> BUILD CANCELLED", true)
            } else {
                emit("> BUILD FAILED (exit code: $exitCode)", true)
            }
            val apkCandidate = File(proj.rootDir, "app/build/outputs/apk/debug")
                .listFiles { _, name -> name.endsWith(".apk") }?.firstOrNull()

            val result = BuildResult(
                status = status,
                durationMs = duration,
                exitCode = exitCode,
                apkFile = apkCandidate,
                apkSize = apkCandidate?.length() ?: 0,
                logs = logs,
                problems = emptyList()
            )
            _buildResult.value = result
            _buildStatus.value = status
        }
    }

    fun cleanBuild() {
        startBuild(listOf("clean", "assembleDebug"))
    }

    fun cancelBuild() {
        isBuildCancelled = true
        activeBuildProcess?.destroy()
        _buildStatus.value = BuildStatus.CANCELLED
    }

    fun setActiveToolWindow(window: BottomToolWindow) {
        _activeToolWindow.value = window
        _isToolWindowExpanded.value = true
    }

    fun toggleToolWindow() {
        _isToolWindowExpanded.value = !_isToolWindowExpanded.value
    }

    fun toggleFileExplorer() {
        _isFileExplorerVisible.value = !_isFileExplorerVisible.value
    }

    fun jumpToProblem(problem: ProblemItem) {
        val file = problem.file ?: return
        openFile(file, problem.line)
    }

    fun clearTargetEditorLine() {
        _targetEditorLine.value = null
    }

    /**
     * Ensures gradle-wrapper.jar and gradle-wrapper.properties exist in the project,
     * downloading gradle-wrapper.jar from official repositories if missing.
     */
    private fun ensureGradleWrapper(proj: Project, emit: (String, Boolean) -> Unit): File? {
        val wrapperDir = File(proj.rootDir, "gradle/wrapper")
        if (!wrapperDir.exists()) {
            wrapperDir.mkdirs()
        }
        val wrapperJar = File(wrapperDir, "gradle-wrapper.jar")

        // Ensure gradle-wrapper.properties exists
        val propsFile = File(wrapperDir, "gradle-wrapper.properties")
        if (!propsFile.exists()) {
            try {
                propsFile.writeText(
                    """
                    distributionBase=GRADLE_USER_HOME
                    distributionPath=wrapper/dists
                    distributionUrl=https\://services.gradle.org/distributions/gradle-8.7-bin.zip
                    networkTimeout=10000
                    validateDistributionUrl=true
                    zipStoreBase=GRADLE_USER_HOME
                    zipStorePath=wrapper/dists
                    """.trimIndent()
                )
            } catch (e: Exception) {}
        }

        // If wrapper jar already exists and has valid size (> 10 KB)
        if (wrapperJar.exists() && wrapperJar.length() > 10_000L) {
            return wrapperJar
        }

        // 1. Try extracting directly from built-in app assets (100% offline & instant)
        try {
            val app = getApplication<Application>()
            app.assets.open("gradle-wrapper.jar").use { input ->
                FileOutputStream(wrapperJar).use { output ->
                    input.copyTo(output)
                }
            }
            if (wrapperJar.exists() && wrapperJar.length() > 10_000L) {
                emit("> Extracted gradle-wrapper.jar from built-in IDE assets (offline).", false)
                // Ensure gradlew script is also in place
                val gradlewDest = File(proj.rootDir, "gradlew")
                if (!gradlewDest.exists()) {
                    try {
                        app.assets.open("gradlew").use { input ->
                            FileOutputStream(gradlewDest).use { output ->
                                input.copyTo(output)
                            }
                        }
                        gradlewDest.setExecutable(true, false)
                    } catch (e: Exception) {}
                }
                return wrapperJar
            }
        } catch (e: Exception) {}

        // 2. Check internal app filesDir cache: files/gradle/gradle-wrapper.jar
        val cachedJar = File(getApplication<Application>().filesDir, "gradle/gradle-wrapper.jar")
        if (cachedJar.exists() && cachedJar.length() > 10_000L) {
            try {
                cachedJar.copyTo(wrapperJar, overwrite = true)
                emit("> Restored gradle-wrapper.jar from local app cache.", false)
                return wrapperJar
            } catch (e: Exception) {}
        }

        // 3. Fallback: Download from official repositories / CDNs
        emit("> Gradle Wrapper is missing in project. Provisioning gradle-wrapper.jar (~60 KB)...", false)
        val downloadSources = listOf(
            "https://cdn.jsdelivr.net/gh/gradle/gradle@v8.7.0/gradle/wrapper/gradle-wrapper.jar",
            "https://raw.githubusercontent.com/gradle/gradle/v8.7.0/gradle/wrapper/gradle-wrapper.jar",
            "https://repo1.maven.org/maven2/org/gradle/gradle-wrapper/8.7/gradle-wrapper-8.7.jar"
        )

        for (urlStr in downloadSources) {
            try {
                emit("> Connecting to $urlStr ...", false)
                val url = URL(urlStr)
                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 15000
                connection.readTimeout = 25000
                connection.instanceFollowRedirects = true
                if (connection.responseCode in 200..299) {
                    val tempFile = File(wrapperDir, "gradle-wrapper.jar.tmp")
                    connection.inputStream.use { input ->
                        FileOutputStream(tempFile).use { out ->
                            input.copyTo(out)
                        }
                    }
                    if (tempFile.exists() && tempFile.length() > 10_000L) {
                        tempFile.renameTo(wrapperJar)
                        // Also cache in application filesDir for instant access across all projects
                        try {
                            cachedJar.parentFile?.mkdirs()
                            wrapperJar.copyTo(cachedJar, overwrite = true)
                        } catch (e: Exception) {}
                        emit("> gradle-wrapper.jar downloaded successfully (${wrapperJar.length() / 1024} KB).", false)
                        return wrapperJar
                    }
                }
            } catch (e: Exception) {
                emit("> Download attempt failed: ${e.message}", false)
            }
        }

        emit("> Error: Could not download gradle-wrapper.jar automatically. Please check your internet connection.", true)
        return null
    }

    // =========================================================================
    // CANON MF440 HARDWARE SCANNER OPERATIONS (USB + eSCL Wi-Fi + PDF Pipeline)
    // =========================================================================

    private fun appendScanLog(msg: String) {
        val current = _scanStatusLogs.value.toMutableList()
        current.add(msg)
        _scanStatusLogs.value = current
    }

    fun refreshUsbScanners() {
        viewModelScope.launch(Dispatchers.IO) {
            val usbDevices: List<DiscoveredScannerDevice> = scannerManager.discoverUsbScanners()
            val existingWifi: List<DiscoveredScannerDevice> = _discoveredScanners.value.filter {
                it.transportType == TransportType.WIFI_ESCL || it.transportType == TransportType.WIFI_MFNP
            }
            val combined: List<DiscoveredScannerDevice> = usbDevices + existingWifi
            _discoveredScanners.value = combined

            if (_selectedScanner.value == null && combined.isNotEmpty()) {
                _selectedScanner.value = combined.firstOrNull {
                    it.vendorId == ScannerManager.CANON_VENDOR_ID
                } ?: combined.first()
            } else if (_selectedScanner.value != null) {
                val updated = combined.find { it.id == _selectedScanner.value?.id }
                if (updated != null) {
                    _selectedScanner.value = updated
                }
            }

            if (usbDevices.isEmpty()) {
                appendScanLog("[USB] لم يتم العثور على أجهزة USB متصلة حالياً. تأكد من توصيل كابل USB OTG بجهاز Canon MF440.")
            } else {
                usbDevices.forEach { dev ->
                    val vidPid = String.format("0x%04X:0x%04X", dev.vendorId, dev.productId)
                    appendScanLog("[USB] تم اكتشاف: ${dev.name} ($vidPid) | النقل: ${dev.transportType.name}")
                }
            }
        }
    }

    fun selectScannerDevice(device: DiscoveredScannerDevice) {
        _selectedScanner.value = device
        _scanError.value = null
        appendScanLog("[Device] تم اختيار الماسح: ${device.name} (${device.transportType.name})")
    }

    fun requestScannerUsbPermission(device: DiscoveredScannerDevice) {
        val usbDevice = device.usbDevice ?: return
        appendScanLog("[USB] جاري طلب صلاحية الوصول إلى USB لجهاز ${device.name}...")
        scannerManager.requestUsbPermission(usbDevice) { granted ->
            refreshUsbScanners()
            if (granted) {
                val intfSummary = device.interfaces.joinToString { "Intf #${it.id}: ${it.classDescription}" }
                appendScanLog("[USB] تم منح صلاحية USB بنجاح! الواجهات المكتشفة: $intfSummary")
            } else {
                _scanError.value = "تم رفض صلاحية الوصول إلى USB من نظام Android."
                appendScanLog("[USB] خطأ: تم رفض صلاحية USB.")
            }
        }
    }

    fun probeNetworkScanner(ipOrHost: String) {
        viewModelScope.launch(Dispatchers.IO) {
            appendScanLog("[Wi-Fi eSCL/MFNP] جاري فحص الماسح الشبكي على العنوان: $ipOrHost ...")
            val netDevice = scannerManager.probeNetworkScanner(ipOrHost)
            if (netDevice != null) {
                val filtered = _discoveredScanners.value.filterNot { it.id == netDevice.id }
                val updated: List<DiscoveredScannerDevice> = filtered + netDevice
                _discoveredScanners.value = updated
                _selectedScanner.value = netDevice
                _scanError.value = null
                appendScanLog("[Wi-Fi] تم الاتصال بماسح Canon بنجاح: ${netDevice.name} (${netDevice.serialOrAddress})")
            } else {
                _scanError.value = "تعذر العثور على خدمة مسح eSCL/AirScan أو MFNP على العنوان $ipOrHost. تأكد من أن الهاتف والماسح على نفس الشبكة."
                appendScanLog("[Wi-Fi] فشل الاتصال بالعنوان $ipOrHost.")
            }
        }
    }

    fun executeHardwareScan(options: ScanJobOptions) {
        val device = _selectedScanner.value
        if (device == null) {
            _scanError.value = "يرجى اختيار جهاز Canon Scanner أولاً (عبر USB أو Wi-Fi)."
            return
        }
        if (_isScanning.value) return

        _isScanning.value = true
        _scanError.value = null
        appendScanLog(">>> بدء جلسة مسح حقيقية على ${device.name} (${options.resolutionDpi} DPI, ${options.colorMode}, ${options.source})...")

        viewModelScope.launch(Dispatchers.IO) {
            val result = scannerManager.executeScan(
                scanner = device,
                options = options,
                onProgress = { statusMsg ->
                    appendScanLog(statusMsg)
                }
            )
            _isScanning.value = false
            if (result.success && result.bitmap != null) {
                val bmp: Bitmap = result.bitmap
                _scannedBitmap.value = bmp
                _editedBitmap.value = bmp
                _lastSavedImageFile.value = result.rawFile
                appendScanLog("<<< اكتملت عملية المسح بنجاح عبر ${result.protocolUsed}! أبعاد الصورة المستلمة: ${bmp.width}x${bmp.height} بكسل.")
            } else {
                val err = result.errorReason ?: "حدث خطأ غير معروف أثناء المسح."
                _scanError.value = err
                appendScanLog("<<< فشل المسح: $err")
            }
        }
    }

    fun applyScanImageTransform(
        rotationDeg: Float,
        flipH: Boolean,
        flipV: Boolean,
        cropL: Float,
        cropT: Float,
        cropR: Float,
        cropB: Float,
        contrast: Float
    ) {
        val sourceBmp = _scannedBitmap.value ?: return
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val transformed = scannerManager.transformScannedBitmap(
                    source = sourceBmp,
                    rotationDegrees = rotationDeg,
                    flipHorizontal = flipH,
                    flipVertical = flipV,
                    cropLeftRatio = cropL,
                    cropTopRatio = cropT,
                    cropRightRatio = cropR,
                    cropBottomRatio = cropB,
                    contrastBoost = contrast
                )
                _editedBitmap.value = transformed
                appendScanLog("[Editor] تم تطبيق التعديلات على الصورة الممسوحة (${transformed.width}x${transformed.height} px).")
            } catch (e: Exception) {
                _scanError.value = "فشل تعديل الصورة: ${e.message}"
            }
        }
    }

    fun resetEditedScanBitmap() {
        _editedBitmap.value = _scannedBitmap.value
        appendScanLog("[Editor] تمت استعادة الصورة الأصلية الممسوحة.")
    }

    fun saveEditedScanImage() {
        val bmp = _editedBitmap.value ?: _scannedBitmap.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val savedFile = scannerManager.saveRawScanToDisk(bmp, "canon_mf440_edited")
                _lastSavedImageFile.value = savedFile
                // Also copy into current project workspace if a project is open
                _currentProject.value?.rootDir?.let { projDir ->
                    val projScansDir = File(projDir, "scans").apply { mkdirs() }
                    val projCopy = File(projScansDir, savedFile.name)
                    savedFile.copyTo(projCopy, overwrite = true)
                }
                appendScanLog("[Storage] تم حفظ الصورة المعدلة في الهاتف: ${savedFile.absolutePath}")
                refreshFileTree()
            } catch (e: Exception) {
                _scanError.value = "فشل حفظ الصورة: ${e.message}"
            }
        }
    }

    fun addCurrentScanPageToPdfQueue() {
        val bmp = _editedBitmap.value ?: _scannedBitmap.value ?: return
        val pages = _savedScanPages.value.toMutableList()
        pages.add(bmp)
        _savedScanPages.value = pages
        appendScanLog("[PDF Queue] تمت إضافة الصفحة إلى قائمة بناء الـ PDF (إجمالي الصفحات: ${pages.size}).")
    }

    fun buildPdfFromScannedPages(outputFileName: String = "Canon_MF440_Scan.pdf") {
        val currentBmp = _editedBitmap.value ?: _scannedBitmap.value
        val pagesToBuild: List<Bitmap> = if (_savedScanPages.value.isNotEmpty()) {
            _savedScanPages.value
        } else if (currentBmp != null) {
            listOf(currentBmp)
        } else {
            _scanError.value = "لا توجد صور ممسوحة لإنشاء ملف PDF."
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            try {
                appendScanLog("[PDF Builder] جاري إعادة بناء ملف PDF ($outputFileName) من ${pagesToBuild.size} صفحة ممسوحة...")
                val targetDir = _currentProject.value?.rootDir?.let { File(it, "scans").apply { mkdirs() } }
                val pdfFile = scannerManager.generatePdfFromScannedBitmaps(
                    pages = pagesToBuild,
                    outputPdfName = outputFileName,
                    targetDirectory = targetDir
                )
                _lastGeneratedPdfFile.value = pdfFile
                _scanError.value = null
                appendScanLog("[PDF Builder] تم إنشاء ملف PDF بنجاح: ${pdfFile.absolutePath} (${pdfFile.length() / 1024} KB)")
                refreshFileTree()
            } catch (e: Exception) {
                _scanError.value = "فشل إنشاء ملف PDF: ${e.message}"
                appendScanLog("[PDF Builder] خطأ: ${e.message}")
            }
        }
    }

    fun clearSavedPdfPages() {
        _savedScanPages.value = emptyList()
        appendScanLog("[PDF Builder] تم تفريغ قائمة صفحات PDF المؤقتة.")
    }
}
