package com.example.ui.tools

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.theme.AccentPurple
import com.example.utils.PdfEngine
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PageManagerScreen(
    initialUri: Uri? = null,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentUri by remember { mutableStateOf(initialUri) }
    var documentName by remember { mutableStateOf("مستند PDF") }
    var activePageOrder by remember { mutableStateOf<List<Int>>(emptyList()) } // List of original 0-indexed page numbers in current order
    val pageThumbnails = remember { mutableStateMapOf<Int, Bitmap>() }
    val selectedPageIndices = remember { mutableStateListOf<Int>() } // Indices in activePageOrder that are selected

    var isLoading by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var savedResultFile by remember { mutableStateOf<File?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    val pdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            currentUri = uri
        }
    }

    // Load PDF page count and thumbnails
    LaunchedEffect(currentUri) {
        val uri = currentUri ?: return@LaunchedEffect
        isLoading = true
        selectedPageIndices.clear()
        pageThumbnails.clear()

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && idx != -1) {
                    documentName = cursor.getString(idx)
                }
            }
            val count = PdfEngine.getPageCount(context, uri)
            activePageOrder = (0 until count).toList()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            isLoading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("إدارة صفحات PDF", fontWeight = FontWeight.Bold)
                        if (activePageOrder.isNotEmpty()) {
                            Text(
                                text = "${activePageOrder.size} صفحات (المحدد: ${selectedPageIndices.size})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    if (currentUri != null && activePageOrder.isNotEmpty()) {
                        // Select All / Clear
                        IconButton(onClick = {
                            if (selectedPageIndices.size == activePageOrder.size) {
                                selectedPageIndices.clear()
                            } else {
                                selectedPageIndices.clear()
                                selectedPageIndices.addAll(activePageOrder.indices)
                            }
                        }) {
                            Icon(
                                imageVector = if (selectedPageIndices.size == activePageOrder.size) Icons.Default.SelectAll else Icons.Outlined.SelectAll,
                                contentDescription = "تحديد الكل"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            if (activePageOrder.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Rotate button
                        FilledTonalButton(
                            onClick = {
                                if (selectedPageIndices.isEmpty()) {
                                    Toast.makeText(context, "حدد صفحة واحدة أو أكثر للتدوير", Toast.LENGTH_SHORT).show()
                                    return@FilledTonalButton
                                }
                                coroutineScope.launch {
                                    // Rotate thumbnails in UI
                                    for (selIdx in selectedPageIndices) {
                                        val origPage = activePageOrder[selIdx]
                                        val oldBm = pageThumbnails[origPage]
                                        if (oldBm != null) {
                                            pageThumbnails[origPage] = com.example.utils.ImageProcessing.rotateBitmap(oldBm, 90f)
                                        }
                                    }
                                }
                            },
                            enabled = selectedPageIndices.isNotEmpty()
                        ) {
                            Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تدوير (90°)", fontSize = 12.sp)
                        }

                        // Delete button
                        Button(
                            onClick = { showDeleteConfirmDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            enabled = selectedPageIndices.isNotEmpty(),
                            modifier = Modifier.testTag("delete_selected_pages_button")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حذف (${selectedPageIndices.size})", fontSize = 12.sp)
                        }

                        // Save as new PDF
                        Button(
                            onClick = {
                                isSaving = true
                                coroutineScope.launch {
                                    val outFile = File(context.cacheDir, "نسخة_معدلة_${System.currentTimeMillis() % 10000}.pdf")
                                    val success = PdfEngine.reorderPages(
                                        context = context,
                                        inputUri = currentUri!!,
                                        newOrderIndices = activePageOrder,
                                        outputFile = outFile
                                    )
                                    isSaving = false
                                    if (success) {
                                        savedResultFile = outFile
                                        Toast.makeText(context, "تم حفظ المستند الجديد بنجاح مع الحفاظ على الأصل!", Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(context, "فشل حفظ التعديلات.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            enabled = !isSaving && activePageOrder.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                            modifier = Modifier.testTag("save_reordered_pdf_button")
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("حفظ كملف جديد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                currentUri == null -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Outlined.GridView, contentDescription = null, modifier = Modifier.size(54.dp), tint = AccentPurple)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("اختر ملف PDF لتنظيم وحذف صفحاته", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "يمكنك حذف صفحات محددة (مثل حذف الصفحة 2 من 6 مع الحفاظ على باقي الصفحات) أو إعادة ترتيبها بسهولة وبأمان دون المساس بالملف الأصلي.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { pdfPicker.launch(arrayOf("application/pdf")) },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("استيراد PDF")
                        }
                    }
                }

                isLoading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }

                else -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        itemsIndexed(activePageOrder) { displayIndex, originalPageIndex ->
                            val isSelected = selectedPageIndices.contains(displayIndex)
                            val bitmap = pageThumbnails[originalPageIndex]

                            LaunchedEffect(originalPageIndex, currentUri) {
                                if (bitmap == null && currentUri != null) {
                                    val rendered = PdfEngine.renderPageToBitmap(context, currentUri!!, originalPageIndex, 300)
                                    if (rendered != null) {
                                        pageThumbnails[originalPageIndex] = rendered
                                    }
                                }
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(170.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(
                                        width = if (isSelected) 2.5.dp else 1.dp,
                                        color = if (isSelected) AccentPurple else MaterialTheme.colorScheme.outlineVariant,
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable {
                                        if (isSelected) {
                                            selectedPageIndices.remove(displayIndex)
                                        } else {
                                            selectedPageIndices.add(displayIndex)
                                        }
                                    },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    if (bitmap != null) {
                                        Image(
                                            bitmap = bitmap.asImageBitmap(),
                                            contentDescription = "صفحة ${displayIndex + 1}",
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color(0xFFF1F5F9)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                                        }
                                    }

                                    // Display page number badge
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .padding(6.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color.Black.copy(alpha = 0.7f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "${displayIndex + 1}",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    // Checkbox indicator
                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = {
                                            if (it) selectedPageIndices.add(displayIndex) else selectedPageIndices.remove(displayIndex)
                                        },
                                        modifier = Modifier.align(Alignment.TopEnd)
                                    )

                                    // Move left/right arrows for reordering
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color.Black.copy(alpha = 0.5f))
                                            .align(Alignment.BottomCenter),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        if (displayIndex > 0) {
                                            IconButton(
                                                onClick = {
                                                    val list = activePageOrder.toMutableList()
                                                    val tmp = list[displayIndex]
                                                    list[displayIndex] = list[displayIndex - 1]
                                                    list[displayIndex - 1] = tmp
                                                    activePageOrder = list
                                                    selectedPageIndices.clear()
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.ArrowBack, contentDescription = "تقديم", tint = Color.White, modifier = Modifier.size(14.dp))
                                            }
                                        } else {
                                            Spacer(modifier = Modifier.size(24.dp))
                                        }

                                        if (displayIndex < activePageOrder.size - 1) {
                                            IconButton(
                                                onClick = {
                                                    val list = activePageOrder.toMutableList()
                                                    val tmp = list[displayIndex]
                                                    list[displayIndex] = list[displayIndex + 1]
                                                    list[displayIndex + 1] = tmp
                                                    activePageOrder = list
                                                    selectedPageIndices.clear()
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.ArrowForward, contentDescription = "تأخير", tint = Color.White, modifier = Modifier.size(14.dp))
                                            }
                                        } else {
                                            Spacer(modifier = Modifier.size(24.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation dialog before deleting pages
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("تأكيد حذف الصفحات") },
            text = {
                Text("هل أنت متأكد من رغبتك في حذف ${selectedPageIndices.size} صفحة؟ سيتم الاحتفاظ بالملف الأصلي دون أي تعديل وحفظ نسخة جديدة.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val setOfIndicesToDelete = selectedPageIndices.toSet()
                        activePageOrder = activePageOrder.filterIndexed { index, _ -> !setOfIndicesToDelete.contains(index) }
                        selectedPageIndices.clear()
                        showDeleteConfirmDialog = false
                        Toast.makeText(context, "تم حذف الصفحات من العرض. اضغط \"حفظ كملف جديد\" لتصديرها.", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text("حذف", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Exported Result Dialog
    if (savedResultFile != null) {
        AlertDialog(
            onDismissRequest = { savedResultFile = null },
            title = { Text("تم إنشاء المستند الجديد بنجاح!") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("اسم الملف: ${savedResultFile!!.name}", fontWeight = FontWeight.SemiBold)
                    Text("عدد الصفحات النهائي: ${activePageOrder.size} صفحة.")
                    Text("تم حفظ الملف دون المساس بالمستند الأصلي.", color = Color.Gray, fontSize = 12.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val uri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            savedResultFile!!
                        )
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة PDF المعدل"))
                        savedResultFile = null
                    }
                ) {
                    Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة المستند")
                }
            },
            dismissButton = {
                TextButton(onClick = { savedResultFile = null }) {
                    Text("إغلاق")
                }
            }
        )
    }
}
