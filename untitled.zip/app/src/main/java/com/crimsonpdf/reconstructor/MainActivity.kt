package com.crimsonpdf.reconstructor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var themeMode by remember { mutableStateOf("OLED") }
            val bgColor = when (themeMode) {
                "DAY" -> Color(0xFFF8FAFC)
                "NIGHT" -> Color(0xFF0F172A)
                else -> Color(0xFF000000)
            }
            val textColor = if (themeMode == "DAY") Color(0xFF0F172A) else Color.White

            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = bgColor) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "CrimsonPDF Reconstruct — محرك إعادة بناء المستندات",
                            color = Color(0xFFDC2626),
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "إعادة بناء التخطيط والجداول العربية وتصدير PDF / PNG / JPG بدقة 300 DPI",
                            color = textColor,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("DAY", "NIGHT", "OLED").forEach { mode ->
                                Button(
                                    onClick = { themeMode = mode },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (themeMode == mode) Color(0xFFDC2626) else Color(0xFF334155)
                                    )
                                ) {
                                    Text(text = mode, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
