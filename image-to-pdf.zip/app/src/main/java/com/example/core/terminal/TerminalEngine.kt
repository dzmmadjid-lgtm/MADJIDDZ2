package com.example.core.terminal

import android.content.Context
import com.example.core.termux.TermuxManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

data class TerminalLine(
    val text: String,
    val isCommand: Boolean = false,
    val isError: Boolean = false
)

class TerminalEngine(
    private val scope: CoroutineScope,
    private val context: Context? = null
) {

    private val _output = MutableStateFlow<List<TerminalLine>>(
        listOf(
            TerminalLine("=== DroidIDE Terminal [Termux Engine & Android Shell] ==="),
            TerminalLine("البيئة تدعم تشغيل أوامر Java و Gradle مباشرة عبر Termux (RUN_COMMAND)"),
            TerminalLine("جاهز لاستقبال الأوامر (الاستجابة والنتائج تظهر هنا بالكامل)")
        )
    )
    val output: StateFlow<List<TerminalLine>> = _output.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private var activeProcess: Process? = null
    private var executionJob: Job? = null

    init {
        // Initial setup
    }

    fun appendLine(text: String, isCommand: Boolean = false, isError: Boolean = false) {
        _output.value = _output.value + TerminalLine(text, isCommand, isError)
    }

    fun appendOutput(text: String, isError: Boolean = false) {
        appendLine(text, isCommand = false, isError = isError)
    }

    fun appendCommand(command: String) {
        appendLine("$ $command", isCommand = true, isError = false)
    }

    fun clear() {
        _output.value = listOf(
            TerminalLine("=== Terminal Cleared ==="),
            TerminalLine("جاهز لاستقبال الأوامر الجديدة...")
        )
    }

    fun getAllText(): String {
        return _output.value.joinToString("\n") { it.text }
    }

    private fun isDirectAppBinPath(cmd: String): Boolean {
        val token = cmd.trim().split(" ").firstOrNull() ?: return false
        return (token.startsWith("/data/") || token.startsWith("./") || token.contains("/files/")) &&
                (token.endsWith("/java") || token.endsWith("/javac") || token.contains("/bin/"))
    }

    fun executeCommand(command: String, workingDir: File) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return

        appendLine("$ $trimmed", isCommand = true)

        if (trimmed == "clear" || trimmed == "cls") {
            clear()
            return
        }

        // Prioritize Termux execution if Termux is installed on device
        if (context != null && TermuxManager.isTermuxInstalled(context) && TermuxManager.hasRunCommandPermission(context)) {
            executionJob?.cancel()
            executionJob = scope.launch(Dispatchers.IO) {
                _isRunning.value = true
                try {
                    val workPath = workingDir?.absolutePath
                    val termuxResult = TermuxManager.executeCommand(
                        context = context,
                        command = trimmed,
                        workDir = workPath,
                        inBackground = true
                    )
                    if (termuxResult.stdout.isNotBlank()) {
                        termuxResult.stdout.lines().forEach { line ->
                            appendLine(line)
                        }
                    }
                    if (termuxResult.stderr.isNotBlank()) {
                        termuxResult.stderr.lines().forEach { line ->
                            appendLine(line, isError = true)
                        }
                    }
                    if (termuxResult.errMsg != null) {
                        appendLine("[Termux Error]: ${termuxResult.errMsg}", isError = true)
                    }
                    appendLine("[Process completed with exit code ${termuxResult.exitCode}]")
                } catch (e: Exception) {
                    appendLine("Termux execution error: ${e.localizedMessage}", isError = true)
                } finally {
                    _isRunning.value = false
                }
            }
            return
        }

        executionJob?.cancel()
        executionJob = scope.launch(Dispatchers.IO) {
            _isRunning.value = true
            try {
                val envMap = mutableMapOf<String, String>()

                if (context != null) {
                    val sdkDir = File(context.filesDir, "android-sdk")
                    if (sdkDir.exists()) {
                        envMap["ANDROID_HOME"] = sdkDir.absolutePath
                        envMap["ANDROID_SDK_ROOT"] = sdkDir.absolutePath
                    }
                }

                val androidHome = envMap["ANDROID_HOME"] ?: System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT")
                if (androidHome != null) {
                    envMap["ANDROID_HOME"] = androidHome
                    envMap["ANDROID_SDK_ROOT"] = androidHome
                }

                val pathVal = envMap["PATH"] ?: (System.getenv("PATH") ?: "/system/bin")
                val pb = ProcessBuilder("/system/bin/sh", "-c", trimmed)
                pb.directory(workingDir)
                pb.redirectErrorStream(false)

                val processEnv = pb.environment()
                processEnv.putAll(envMap)

                val process = pb.start()
                activeProcess = process

                // Coroutine to read stdout
                val outJob = launch {
                    val reader = BufferedReader(InputStreamReader(process.inputStream))
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        appendLine(line ?: "")
                    }
                }

                // Coroutine to read stderr
                val errJob = launch {
                    val errReader = BufferedReader(InputStreamReader(process.errorStream))
                    var errLine: String?
                    while (errReader.readLine().also { errLine = it } != null) {
                        appendLine(errLine ?: "", isError = true)
                    }
                }

                outJob.join()
                errJob.join()

                val exitCode = process.waitFor()
                appendLine("[Process completed with exit code $exitCode]")
            } catch (e: Exception) {
                appendLine("Terminal execution error: ${e.localizedMessage}", isError = true)
            } finally {
                activeProcess = null
                _isRunning.value = false
            }
        }
    }

    fun stop() {
        activeProcess?.destroy()
        executionJob?.cancel()
        activeProcess = null
        _isRunning.value = false
        appendLine("[Process stopped by user]", isError = true)
    }
}
