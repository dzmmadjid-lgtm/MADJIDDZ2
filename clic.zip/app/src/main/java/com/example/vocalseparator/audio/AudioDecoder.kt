package com.example.vocalseparator.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * High-performance audio decoder utilizing Android's hardware-accelerated MediaExtractor and MediaCodec.
 * Decodes MP3, AAC, M4A, WAV, FLAC, and OGG files to raw 16-bit stereo PCM streams.
 */
class AudioDecoder(private val context: Context) {

    data class AudioMetadata(
        val title: String,
        val artist: String,
        val durationMs: Long,
        val sampleRate: Int,
        val channelCount: Int,
        val fileSizeBytes: Long,
        val mimeType: String
    )

    data class DecodedAudioData(
        val pcmFile: File,
        val sampleRate: Int,
        val channelCount: Int,
        val durationMs: Long,
        val totalSampleCount: Long // Number of frames (each frame = 2 samples if stereo)
    )

    /**
     * Extracts track metadata such as title, artist, and duration from the provided audio Uri.
     */
    fun extractMetadata(uri: Uri): AudioMetadata {
        val retriever = MediaMetadataRetriever()
        var title = "مقطع صوتي"
        var artist = "غير معروف"
        var durationMs = 0L
        var mimeType = "audio/*"
        var sampleRate = 44100
        var channelCount = 2
        var fileSizeBytes = 0L

        try {
            retriever.setDataSource(context, uri)
            title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?: uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.')
                ?: "مقطع صوتي"
            artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "فنان غير معروف"
            val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durStr?.toLongOrNull() ?: 0L
            mimeType = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "audio/*"
        } catch (e: Exception) {
            Log.w(TAG, "Failed to extract complete metadata via MediaMetadataRetriever", e)
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }

        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                fileSizeBytes = pfd.statSize
            }
        } catch (_: Exception) {}

        // Fallback for sample rate and channels via MediaExtractor
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    if (durationMs <= 0 && format.containsKey(MediaFormat.KEY_DURATION)) {
                        durationMs = format.getLong(MediaFormat.KEY_DURATION) / 1000
                    }
                    break
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "MediaExtractor inspection fallback error", e)
        } finally {
            extractor.release()
        }

        return AudioMetadata(
            title = title.ifBlank { "مقطع صوتي" },
            artist = artist.ifBlank { "غير معروف" },
            durationMs = durationMs,
            sampleRate = sampleRate,
            channelCount = channelCount,
            fileSizeBytes = fileSizeBytes,
            mimeType = mimeType
        )
    }

    /**
     * Decodes an input audio file directly to a temporary raw stereo 16-bit PCM file on disk.
     * Writing in streaming chunks to disk keeps the active RAM footprint under ~20MB even for 1-hour recordings.
     *
     * @param uri Input audio file Uri
     * @param onProgress Callback invoked with decode progress fraction (0.0 to 1.0)
     */
    suspend fun decodeToPcmFile(
        uri: Uri,
        onProgress: suspend (progress: Float) -> Unit
    ): DecodedAudioData = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)

        var audioTrackIndex = -1
        var format: MediaFormat? = null

        for (i in 0 until extractor.trackCount) {
            val trackFormat = extractor.getTrackFormat(i)
            val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                audioTrackIndex = i
                format = trackFormat
                break
            }
        }

        if (audioTrackIndex < 0 || format == null) {
            extractor.release()
            throw IllegalArgumentException("لا يحتوي الملف على مسار صوتي صالح أو صيغة الصوت غير مدعومة.")
        }

        extractor.selectTrack(audioTrackIndex)

        val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
        var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
            format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        } else 44100

        var channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
            format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        } else 2

        val totalDurationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) {
            format.getLong(MediaFormat.KEY_DURATION)
        } else 0L

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val tempPcmFile = File(context.cacheDir, "temp_mix_${System.currentTimeMillis()}.raw")
        val outputStream = FileOutputStream(tempPcmFile)

        val bufferInfo = MediaCodec.BufferInfo()
        var isExtractorEOS = false
        var isCodecEOS = false
        val timeoutUs = 5000L
        var totalFramesDecoded: Long = 0

        try {
            while (!isCodecEOS) {
                if (!isExtractorEOS) {
                    val inputBufferIndex = codec.dequeueInputBuffer(timeoutUs)
                    if (inputBufferIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputBufferIndex)
                        if (inputBuffer != null) {
                            val sampleSize = extractor.readSampleData(inputBuffer, 0)
                            if (sampleSize < 0) {
                                codec.queueInputBuffer(
                                    inputBufferIndex,
                                    0,
                                    0,
                                    0L,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                isExtractorEOS = true
                            } else {
                                val presentationTimeUs = extractor.sampleTime
                                codec.queueInputBuffer(
                                    inputBufferIndex,
                                    0,
                                    sampleSize,
                                    presentationTimeUs,
                                    0
                                )
                                extractor.advance()

                                if (totalDurationUs > 0) {
                                    val prog = (presentationTimeUs.toFloat() / totalDurationUs).coerceIn(0f, 1f)
                                    onProgress(prog)
                                }
                            }
                        }
                    }
                }

                val outputBufferIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outputBufferIndex >= 0) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isCodecEOS = true
                    }

                    val outputBuffer = codec.getOutputBuffer(outputBufferIndex)
                    if (outputBuffer != null && bufferInfo.size > 0) {
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        outputBuffer.order(ByteOrder.LITTLE_ENDIAN)

                        // If the source audio is mono, duplicate to stereo
                        if (channelCount == 1) {
                            val shortBuf = outputBuffer.asShortBuffer()
                            val shortArray = ShortArray(shortBuf.remaining())
                            shortBuf.get(shortArray)

                            val stereoBytes = ByteArray(shortArray.size * 4)
                            val stereoBuffer = ByteBuffer.wrap(stereoBytes).order(ByteOrder.LITTLE_ENDIAN)
                            for (s in shortArray) {
                                stereoBuffer.putShort(s) // Left
                                stereoBuffer.putShort(s) // Right
                            }
                            outputStream.write(stereoBytes)
                            totalFramesDecoded += shortArray.size
                        } else {
                            val chunk = ByteArray(bufferInfo.size)
                            outputBuffer.get(chunk)
                            outputStream.write(chunk)
                            // 2 channels * 2 bytes per sample = 4 bytes per stereo frame
                            totalFramesDecoded += (bufferInfo.size / (channelCount * 2))
                        }
                    }
                    codec.releaseOutputBuffer(outputBufferIndex, false)
                } else if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFormat = codec.outputFormat
                    if (newFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = newFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (newFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channelCount = newFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    Log.d(TAG, "Audio format updated from decoder: $sampleRate Hz, $channelCount channels")
                }
            }
        } finally {
            try { outputStream.flush(); outputStream.close() } catch (_: Exception) {}
            try { codec.stop(); codec.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }

        val finalDurationMs = if (sampleRate > 0) {
            (totalFramesDecoded * 1000L) / sampleRate
        } else totalDurationUs / 1000

        DecodedAudioData(
            pcmFile = tempPcmFile,
            sampleRate = sampleRate,
            channelCount = 2, // Always normalized to stereo for source separation
            durationMs = finalDurationMs,
            totalSampleCount = totalFramesDecoded
        )
    }

    companion object {
        private const val TAG = "AudioDecoder"
    }
}
