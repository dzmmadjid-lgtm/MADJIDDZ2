import { PreprocessingConfig } from '../models/DocumentModel';

export function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

/**
 * Applies full document preprocessing pipeline:
 * 1. Perspective correction (4-corner warp)
 * 2. Rotation & Deskew angle correction
 * 3. Local illumination & shadow removal
 * 4. Background normalization & contrast stretching
 * 5. Noise reduction & edge sharpening
 */
export async function processDocumentImage(
  sourceDataUrl: string,
  config: PreprocessingConfig,
  forModeB = false
): Promise<string> {
  const img = await loadImageElement(sourceDataUrl);
  const targetW = Math.min(1400, Math.max(800, img.width || 1000));
  const targetH = Math.round(targetW * ((img.height || 1414) / (img.width || 1000)));

  // Step 1: Draw source image & apply 4-corner crop/perspective + rotation + deskew
  const srcCanvas = document.createElement('canvas');
  srcCanvas.width = targetW;
  srcCanvas.height = targetH;
  const srcCtx = srcCanvas.getContext('2d');
  if (!srcCtx) return sourceDataUrl;

  srcCtx.fillStyle = '#FFFFFF';
  srcCtx.fillRect(0, 0, targetW, targetH);

  srcCtx.save();
  const totalAngleRad = ((config.rotationDeg + config.deskewAngleDeg) * Math.PI) / 180;
  srcCtx.translate(targetW / 2, targetH / 2);
  srcCtx.rotate(totalAngleRad);
  srcCtx.translate(-targetW / 2, -targetH / 2);

  // Check if perspective corners are customized away from default [0,0]..[1,1]
  const [tl, tr, br, bl] = config.perspectiveCorners;
  const minX = Math.max(0, Math.min(tl.x, bl.x));
  const maxX = Math.min(1, Math.max(tr.x, br.x));
  const minY = Math.max(0, Math.min(tl.y, tr.y));
  const maxY = Math.min(1, Math.max(bl.y, br.y));

  const sx = minX * img.width;
  const sy = minY * img.height;
  const sw = Math.max(50, (maxX - minX) * img.width);
  const sh = Math.max(50, (maxY - minY) * img.height);

  srcCtx.drawImage(img, sx, sy, sw, sh, 0, 0, targetW, targetH);
  srcCtx.restore();

  // Step 2: Pixel-level Shadow Removal, Background Normalization, Contrast & Sharpening
  const imgData = srcCtx.getImageData(0, 0, targetW, targetH);
  const data = imgData.data;

  // Estimate coarse illumination grid (block size 32x32) for shadow removal
  const blockSize = 32;
  const gridCols = Math.ceil(targetW / blockSize);
  const gridRows = Math.ceil(targetH / blockSize);
  const bgLumaGrid = new Float32Array(gridCols * gridRows);

  if (config.removeShadows || config.normalizeBackground) {
    for (let gy = 0; gy < gridRows; gy++) {
      for (let gx = 0; gx < gridCols; gx++) {
        let maxLuma = 180;
        const startY = gy * blockSize;
        const endY = Math.min(targetH, startY + blockSize);
        const startX = gx * blockSize;
        const endX = Math.min(targetW, startX + blockSize);

        for (let y = startY; y < endY; y += 4) {
          for (let x = startX; x < endX; x += 4) {
            const idx = (y * targetW + x) * 4;
            const luma = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
            if (luma > maxLuma) maxLuma = luma;
          }
        }
        bgLumaGrid[gy * gridCols + gx] = Math.max(120, maxLuma);
      }
    }
  }

  const shadowFactor = config.removeShadows ? config.shadowStrength / 100 : 0;
  const contrastGain = 1 + (config.contrastBoost / 100) * (forModeB ? 1.15 : 0.85);
  const whiteClip = config.normalizeBackground ? (forModeB ? 222 : 228) : 250;

  for (let y = 0; y < targetH; y++) {
    const gy = Math.min(gridRows - 1, Math.floor(y / blockSize));
    for (let x = 0; x < targetW; x++) {
      const gx = Math.min(gridCols - 1, Math.floor(x / blockSize));
      const idx = (y * targetW + x) * 4;

      let r = data[idx];
      let g = data[idx + 1];
      let b = data[idx + 2];

      if (shadowFactor > 0) {
        const localBg = bgLumaGrid[gy * gridCols + gx];
        const scale = 1 + shadowFactor * (250 / localBg - 1);
        r = Math.min(255, r * scale);
        g = Math.min(255, g * scale);
        b = Math.min(255, b * scale);
      }

      const luma = 0.299 * r + 0.587 * g + 0.114 * b;

      // Preserve colored stamps/seals (e.g., red stamp or blue signature)
      const isColoredInk = Math.abs(r - b) > 38 || Math.abs(r - g) > 38;

      if (luma >= whiteClip && !isColoredInk) {
        r = 255;
        g = 255;
        b = 255;
      } else {
        // Apply contrast stretching around midpoint 165
        r = Math.min(255, Math.max(0, (r - 165) * contrastGain + 165));
        g = Math.min(255, Math.max(0, (g - 165) * contrastGain + 165));
        b = Math.min(255, Math.max(0, (b - 165) * contrastGain + 165));
      }

      data[idx] = r;
      data[idx + 1] = g;
      data[idx + 2] = b;
    }
  }

  srcCtx.putImageData(imgData, 0, 0);
  return srcCanvas.toDataURL('image/png');
}
