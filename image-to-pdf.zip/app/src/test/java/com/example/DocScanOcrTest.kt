package com.example

import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import com.example.core.image.ImageUtils
import com.example.core.ocr.LanguageDetector
import com.example.core.ocr.LayoutAnalyzer
import com.example.core.pdf.PdfDocumentGenerator
import com.example.data.model.DetectedLanguage
import com.example.data.model.EnhancementMode
import com.example.data.model.OcrPageResult
import com.example.data.model.OcrStats
import com.example.data.model.PdfExportMode
import com.example.data.model.RectNormalized
import com.example.data.model.RegionType
import com.example.data.model.ScanPage
import com.example.data.model.TextLineItem
import com.example.data.model.TextRegion
import com.example.data.model.TextWordItem
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DocScanOcrTest {

    @Test
    fun `test app name resource`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("DocScan OCR", appName)
    }

    @Test
    fun `test language detector accurately identifies Arabic, English, French, and Mixed`() {
        // Arabic
        val arabicText = "هذا مستند رسمي باللغة العربية مع نصوص واضحة"
        assertEquals(DetectedLanguage.ARABIC, LanguageDetector.detectLanguage(arabicText))

        // English
        val englishText = "This is an official invoice and report document"
        assertEquals(DetectedLanguage.ENGLISH, LanguageDetector.detectLanguage(englishText))

        // French
        val frenchText = "Facture officielle de conformité numérique avec les données"
        assertEquals(DetectedLanguage.FRENCH, LanguageDetector.detectLanguage(frenchText))

        // Mixed (Arabic with English word inside)
        val mixedText = "تعتبر تقنيات Document Analysis حجر الأساس في التحول الرقمي الحديث"
        assertEquals(DetectedLanguage.MIXED, LanguageDetector.detectLanguage(mixedText))

        // Numeric
        val numberText = "REF: 2026-984210 / 1,450.00"
        assertEquals(DetectedLanguage.NUMERIC, LanguageDetector.detectLanguage(numberText))
    }

    @Test
    fun `test layout analyzer classifies regions into titles, lists, numbers and separates graphics`() {
        val titleRegion = TextRegion(
            id = "1",
            type = RegionType.PARAGRAPH,
            text = "التقرير الأكاديمي الدولي",
            language = DetectedLanguage.ARABIC,
            boundingBox = RectNormalized(0.1f, 0.05f, 0.9f, 0.12f),
            lines = listOf(TextLineItem("التقرير الأكاديمي الدولي", RectNormalized(0.1f, 0.05f, 0.9f, 0.12f)))
        )

        val listRegion = TextRegion(
            id = "2",
            type = RegionType.PARAGRAPH,
            text = "• الميزة الأولى للمسح الضوئي",
            language = DetectedLanguage.ARABIC,
            boundingBox = RectNormalized(0.1f, 0.30f, 0.9f, 0.35f),
            lines = listOf(TextLineItem("• الميزة الأولى للمسح الضوئي", RectNormalized(0.1f, 0.30f, 0.9f, 0.35f)))
        )

        val numberRegion = TextRegion(
            id = "3",
            type = RegionType.PARAGRAPH,
            text = "1,450.00 EUR",
            language = DetectedLanguage.NUMERIC,
            boundingBox = RectNormalized(0.1f, 0.85f, 0.4f, 0.90f),
            lines = listOf(TextLineItem("1,450.00 EUR", RectNormalized(0.1f, 0.85f, 0.4f, 0.90f)))
        )

        val graphicRegion = TextRegion(
            id = "4",
            type = RegionType.GRAPHIC_OR_PHOTO,
            text = "[شعار رسمي]",
            language = DetectedLanguage.UNKNOWN,
            boundingBox = RectNormalized(0.1f, 0.50f, 0.3f, 0.65f),
            isGraphic = true
        )

        val classified = LayoutAnalyzer.classifyAndOrderRegions(
            listOf(numberRegion, titleRegion, listRegion, graphicRegion),
            primaryLanguage = DetectedLanguage.ARABIC
        )

        // Reading order check: title (top) should come first!
        assertEquals("1", classified[0].id)
        assertEquals(RegionType.TITLE, classified[0].type)

        // List item correctly classified
        val foundList = classified.find { it.id == "2" }
        assertNotNull(foundList)
        assertEquals(RegionType.LIST_ITEM, foundList!!.type)

        // Number item correctly classified
        val foundNum = classified.find { it.id == "3" }
        assertNotNull(foundNum)
        assertEquals(RegionType.NUMBER, foundNum!!.type)

        // Graphic remains separated
        val foundGraphic = classified.find { it.id == "4" }
        assertNotNull(foundGraphic)
        assertTrue(foundGraphic!!.isGraphic)
        assertEquals(RegionType.GRAPHIC_OR_PHOTO, foundGraphic.type)
    }

    @Test
    fun `test image rotation and enhancement`() {
        val bitmap = Bitmap.createBitmap(100, 200, Bitmap.Config.ARGB_8888)
        assertEquals(100, bitmap.width)
        assertEquals(200, bitmap.height)

        val rotated = ImageUtils.rotateBitmap(bitmap, 90f)
        assertEquals(200, rotated.width)
        assertEquals(100, rotated.height)

        val enhanced = ImageUtils.applyEnhancement(bitmap, EnhancementMode.B_AND_W)
        assertNotNull(enhanced)
        assertEquals(100, enhanced.width)
        assertEquals(200, enhanced.height)
    }

    @Test
    fun `test searchable PDF and pure text PDF generation`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val bitmap = Bitmap.createBitmap(400, 600, Bitmap.Config.ARGB_8888)

        val page = ScanPage(
            id = UUID.randomUUID().toString(),
            uriString = "content://dummy",
            originalWidth = 400,
            originalHeight = 600,
            ocrResult = OcrPageResult(
                pageIndex = 0,
                fullText = "عنوان المستند التجريبي\nفقرة توثيقية باللغة العربية والإنجليزية OCR\n123456",
                regions = listOf(
                    TextRegion(
                        id = "r1",
                        type = RegionType.TITLE,
                        text = "عنوان المستند التجريبي",
                        language = DetectedLanguage.ARABIC,
                        boundingBox = RectNormalized(0.1f, 0.1f, 0.9f, 0.18f),
                        lines = listOf(
                            TextLineItem(
                                "عنوان المستند التجريبي",
                                RectNormalized(0.1f, 0.1f, 0.9f, 0.18f),
                                listOf(
                                    TextWordItem("عنوان", RectNormalized(0.7f, 0.1f, 0.9f, 0.18f)),
                                    TextWordItem("المستند", RectNormalized(0.4f, 0.1f, 0.68f, 0.18f)),
                                    TextWordItem("التجريبي", RectNormalized(0.1f, 0.1f, 0.38f, 0.18f))
                                )
                            )
                        )
                    )
                ),
                primaryLanguage = DetectedLanguage.ARABIC,
                stats = OcrStats(3, 22, 1, 1, false)
            )
        )

        // 1. Generate Searchable Original PDF
        val searchablePdf = PdfDocumentGenerator.generatePdf(
            context = context,
            pages = listOf(Pair(page, bitmap)),
            mode = PdfExportMode.SEARCHABLE_ORIGINAL,
            documentTitle = "Test_Searchable_Doc"
        )
        assertTrue(searchablePdf.exists())
        assertTrue(searchablePdf.length() > 0)

        // 2. Generate Pure Text PDF
        val textPdf = PdfDocumentGenerator.generatePdf(
            context = context,
            pages = listOf(Pair(page, bitmap)),
            mode = PdfExportMode.PURE_TEXT,
            documentTitle = "Test_Clean_Text_Doc"
        )
        assertTrue(textPdf.exists())
        assertTrue(textPdf.length() > 0)
    }
}
