package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SeparationDao {
    @Query("SELECT * FROM separations ORDER BY timestamp DESC")
    fun getAllSeparations(): Flow<List<SeparationEntity>>

    @Query("SELECT * FROM separations WHERE id = :id LIMIT 1")
    suspend fun getSeparationById(id: Long): SeparationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSeparation(entity: SeparationEntity): Long

    @Delete
    suspend fun deleteSeparation(entity: SeparationEntity)

    @Query("DELETE FROM separations")
    suspend fun clearAll()
}
