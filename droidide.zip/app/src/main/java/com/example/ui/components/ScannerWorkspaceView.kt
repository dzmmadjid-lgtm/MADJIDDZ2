package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.scanner.DiscoveredScannerDevice
import com.example.core.scanner.ScanJobOptions
import com.example.core.scanner.TransportType
import java.io.File

@Composable
fun ScannerWorkspaceView(
    discoveredScanners: List<DiscoveredScannerDevice>,
    selectedScanner: DiscoveredScannerDevice?,
    isScanning: Boolean,
    scanStatusLogs: List<String>,
    scanError: String?,
    scannedBitmap: Bitmap?,
    editedBitmap: Bitmap?,
    savedPages: List<Bitmap>,
    lastSavedImageFile: File?,
    lastGeneratedPdfFile: File?,
    onRefreshUsbScanners: () -> Unit,
    onProbeWifiScanner: (String) -> Unit,
    onSelectScanner: (DiscoveredScannerDevice) -> Unit,
    onRequestUsbPermission: (DiscoveredScannerDevice) -> Unit,
    onStartScan: (ScanJobOptions) -> Unit,
    onApplyImageTransform: (
        rotationDeg: Float,
        flipH: Boolean,
        flipV: Boolean,
        cropL: Float,
        cropT: Float,
        cropR: Float,
        cropB: Float,
        contrast: Float
    ) -> Unit,
    onResetImageTransform: () -> Unit,
    onSaveEditedImage: () -> Unit,
    onAddPageToPdfQueue: () -> Unit,
    onClearPdfQueue: () -> Unit,
    onGeneratePdfDocument: (String) -> Unit
) {
    var wifiIpInput by remember { mutableStateOf("192.168.1.") }
    var selectedDpi by remember { mutableStateOf(300) }
    var selectedColorMode by remember { mutableStateOf("RGB24") }
    var selectedSource by remember { mutableStateOf("Platen") }
    var pdfFileName by remember { mutableStateOf("Canon_MF440_Scan.pdf") }

    // Image Editor Transform States
    var rotationDegrees by remember(scannedBitmap) { mutableStateOf(0f) }
    var flipHorizontal by remember(scannedBitmap) { mutableStateOf(false) }
    var flipVertical by remember(scannedBitmap) { mutableStateOf(false) }
    var cropLeft by remember(scannedBitmap) { mutableStateOf(0f) }
    var cropTop by remember(scannedBitmap) { mutableStateOf(0f) }
    var cropRight by remember(scannedBitmap) { mutableStateOf(1f) }
    var cropBottom by remember(scannedBitmap) { mutableStateOf(1f) }
    var contrastBoost by remember(scannedBitmap) { mutableStateOf(1.0f) }

    // Interactive Pinch/Pan Zoom state on preview
    var zoomScale by remember(scannedBitmap) { mutableStateOf(1f) }
    var panOffset by remember(scannedBitmap) { mutableStateOf(Offset.Zero) }
    var showCropControls by remember { mutableStateOf(false) }

    val activePreviewBitmap = editedBitmap ?: scannedBitmap

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Header Banner: Canon MF440 Series Hardware Scanner Interface
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            )
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Scanner,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Canon MF440 Series Hardware Scanner (USB / eSCL)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Direct Hardware Scan → Preview → Rotate/Crop/Border → PDF Rebuild (No Camera / No OCR)",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    FilledTonalButton(
                        onClick = onRefreshUsbScanners,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Usb, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Scan USB Bus", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Technical Note: 'Canon Generic Plus UFR II V250' is the Windows Printer driver (USB Class 7). " +
                        "This module bypasses the printer endpoint and communicates with the actual Scanner interface (USB Class 0xFF ScanGear/MFNP, IPP-USB 7/1/4, or eSCL).",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 2. USB Device Discovery & Wi-Fi Probe Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "1. Connected Scanners (USB Host & Network eSCL/MFNP)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                // Wi-Fi / LAN IP Probe Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = wifiIpInput,
                        onValueChange = { wifiIpInput = it },
                        label = { Text("Canon MF440 IP (Optional Wi-Fi eSCL / MFNP)", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                    )
                    OutlinedButton(
                        onClick = { onProbeWifiScanner(wifiIpInput) },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.WifiFind, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Probe IP", fontSize = 12.sp)
                    }
                }

                if (discoveredScanners.isEmpty()) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "No Canon USB scanner detected yet. Connect Canon MF440 via USB OTG cable and tap 'Scan USB Bus', or enter its IP for Wi-Fi eSCL.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    discoveredScanners.forEach { device ->
                        val isSelected = selectedScanner?.id == device.id
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    width = if (isSelected) 1.5.dp else 0.5.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { onSelectScanner(device) },
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                            else MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = device.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "VID: 0x${device.vendorId.toString(16).uppercase()} • PID: 0x${device.productId.toString(16).uppercase()} • ${device.transportType}",
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    if (device.usbDevice != null && !device.hasUsbPermission) {
                                        Button(
                                            onClick = { onRequestUsbPermission(device) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MaterialTheme.colorScheme.tertiary
                                            ),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Grant USB Permission", fontSize = 11.sp)
                                        }
                                    } else {
                                        AssistChip(
                                            onClick = { onSelectScanner(device) },
                                            label = {
                                                Text(
                                                    if (isSelected) "Selected" else "Ready",
                                                    fontSize = 10.sp
                                                )
                                            },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = Color(0xFF4CAF50),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        )
                                    }
                                }

                                if (device.technicalStatusNote.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = device.technicalStatusNote,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                // USB Descriptor Table
                                if (device.interfaces.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    device.interfaces.forEach { intf ->
                                        Text(
                                            text = "• Intf #${intf.id}: ${intf.classDescription} " +
                                                (if (intf.bulkInEndpointAddress != null) "[IN:0x${intf.bulkInEndpointAddress.toString(16)} OUT:0x${intf.bulkOutEndpointAddress?.toString(16)}]" else ""),
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = if (intf.isScannerCandidate) Color(0xFF4CAF50)
                                            else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Scan Parameters & Execute Scan Command
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "2. Hardware Scan Parameters & Command",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Resolution DPI selector
                    listOf(150, 300, 600).forEach { dpi ->
                        FilterChip(
                            selected = selectedDpi == dpi,
                            onClick = { selectedDpi = dpi },
                            label = { Text("$dpi DPI", fontSize = 11.sp) }
                        )
                    }

                    // Color Mode selector
                    listOf(
                        "RGB24" to "Color (24-bit)",
                        "Grayscale8" to "Grayscale",
                        "BlackAndWhite1" to "B&W Text"
                    ).forEach { (mode, label) ->
                        FilterChip(
                            selected = selectedColorMode == mode,
                            onClick = { selectedColorMode = mode },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }

                    // Source (Flatbed Platen vs ADF Feeder)
                    listOf(
                        "Platen" to "Flatbed Glass",
                        "Feeder" to "ADF Feeder"
                    ).forEach { (src, label) ->
                        FilterChip(
                            selected = selectedSource == src,
                            onClick = { selectedSource = src },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }

                Button(
                    onClick = {
                        onStartScan(
                            ScanJobOptions(
                                resolutionDpi = selectedDpi,
                                colorMode = selectedColorMode,
                                source = selectedSource,
                                pageSize = "A4"
                            )
                        )
                    },
                    enabled = !isScanning && selectedScanner != null,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                ) {
                    if (isScanning) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Scanning from Canon MF440...", color = Color.White, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.Scanner, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (selectedScanner != null) "Send Scan Command to ${selectedScanner.name}"
                            else "Select a USB / Wi-Fi Scanner Above First",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (scanError != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = scanError,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                if (scanStatusLogs.isNotEmpty()) {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            scanStatusLogs.takeLast(6).forEach { line ->
                                Text(
                                    text = "> $line",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Scanned Image Preview & Interactive Editor (Rotate, Flip, Crop, Zoom, Border/Contrast, PDF)
        if (activePreviewBitmap != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "3. Scanned Page Preview & Editor (${activePreviewBitmap.width}×${activePreviewBitmap.height} px)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Zoom: ${(zoomScale * 100).toInt()}%",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Interactive Image Viewport with Pinch-to-Zoom, Pan, and Crop Boundary Overlay
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(320.dp)
                            .background(Color(0xFF0D0D0D), RoundedCornerShape(8.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                            .clipToBounds()
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    zoomScale = (zoomScale * zoom).coerceIn(0.5f, 5f)
                                    panOffset = Offset(
                                        x = (panOffset.x + pan.x).coerceIn(-600f, 600f),
                                        y = (panOffset.y + pan.y).coerceIn(-600f, 600f)
                                    )
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = activePreviewBitmap.asImageBitmap(),
                            contentDescription = "Scanned Page Preview",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp)
                                .graphicsLayer(
                                    scaleX = zoomScale,
                                    scaleY = zoomScale,
                                    translationX = panOffset.x,
                                    translationY = panOffset.y
                                )
                        )

                        // Visual Crop / Border Frame Overlay when adjusting boundaries
                        if (showCropControls) {
                            Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                                val leftPx = cropLeft * size.width
                                val topPx = cropTop * size.height
                                val rightPx = cropRight * size.width
                                val bottomPx = cropBottom * size.height
                                drawRect(
                                    color = Color(0xFF00E5FF),
                                    topLeft = Offset(leftPx, topPx),
                                    size = Size(
                                        width = (rightPx - leftPx).coerceAtLeast(10f),
                                        height = (bottomPx - topPx).coerceAtLeast(10f)
                                    ),
                                    style = Stroke(width = 3f)
                                )
                            }
                        }
                    }

                    // Manipulation Toolbar: Rotate Left/Right, Flip H/V, Zoom +/-, Crop/Border Toggle, Reset
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                rotationDegrees = (rotationDegrees - 90f) % 360f
                                onApplyImageTransform(
                                    rotationDegrees, flipHorizontal, flipVertical,
                                    cropLeft, cropTop, cropRight, cropBottom, contrastBoost
                                )
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.RotateLeft, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Rotate -90°", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                rotationDegrees = (rotationDegrees + 90f) % 360f
                                onApplyImageTransform(
                                    rotationDegrees, flipHorizontal, flipVertical,
                                    cropLeft, cropTop, cropRight, cropBottom, contrastBoost
                                )
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Rotate +90°", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                flipHorizontal = !flipHorizontal
                                onApplyImageTransform(
                                    rotationDegrees, flipHorizontal, flipVertical,
                                    cropLeft, cropTop, cropRight, cropBottom, contrastBoost
                                )
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Flip, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Flip H", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                flipVertical = !flipVertical
                                onApplyImageTransform(
                                    rotationDegrees, flipHorizontal, flipVertical,
                                    cropLeft, cropTop, cropRight, cropBottom, contrastBoost
                                )
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.SwapVert, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Flip V", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { showCropControls = !showCropControls },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Crop, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (showCropControls) "Hide Crop/Border" else "Crop & Borders", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { zoomScale = (zoomScale + 0.25f).coerceAtMost(5f) },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.ZoomIn, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Zoom +", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                zoomScale = (zoomScale - 0.25f).coerceAtLeast(0.5f)
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.ZoomOut, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Zoom -", fontSize = 11.sp)
                        }

                        TextButton(
                            onClick = {
                                rotationDegrees = 0f
                                flipHorizontal = false
                                flipVertical = false
                                cropLeft = 0f
                                cropTop = 0f
                                cropRight = 1f
                                cropBottom = 1f
                                contrastBoost = 1.0f
                                zoomScale = 1f
                                panOffset = Offset.Zero
                                onResetImageTransform()
                            }
                        ) {
                            Text("Reset", fontSize = 11.sp)
                        }
                    }

                    // Crop & Border / Contrast Sliders
                    if (showCropControls) {
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Page Border / Margin Crop & Perspective Contrast:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Left/Right Margins", fontSize = 11.sp, modifier = Modifier.width(110.dp))
                                    Slider(
                                        value = cropLeft,
                                        onValueChange = {
                                            cropLeft = it.coerceIn(0f, cropRight - 0.2f)
                                        },
                                        valueRange = 0f..0.45f,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Slider(
                                        value = cropRight,
                                        onValueChange = {
                                            cropRight = it.coerceIn(cropLeft + 0.2f, 1f)
                                        },
                                        valueRange = 0.55f..1f,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Top/Bottom Margins", fontSize = 11.sp, modifier = Modifier.width(110.dp))
                                    Slider(
                                        value = cropTop,
                                        onValueChange = {
                                            cropTop = it.coerceIn(0f, cropBottom - 0.2f)
                                        },
                                        valueRange = 0f..0.45f,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Slider(
                                        value = cropBottom,
                                        onValueChange = {
                                            cropBottom = it.coerceIn(cropTop + 0.2f, 1f)
                                        },
                                        valueRange = 0.55f..1f,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Border Contrast", fontSize = 11.sp, modifier = Modifier.width(110.dp))
                                    Slider(
                                        value = contrastBoost,
                                        onValueChange = { contrastBoost = it },
                                        valueRange = 0.8f..1.8f,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Button(
                                    onClick = {
                                        onApplyImageTransform(
                                            rotationDegrees, flipHorizontal, flipVertical,
                                            cropLeft, cropTop, cropRight, cropBottom, contrastBoost
                                        )
                                    },
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Apply Crop & Border Adjustments", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // 5. Save Image & Rebuild PDF Actions
                    HorizontalDivider()
                    Text(
                        text = "4. Save Image & PDF Document Reconstruction (${savedPages.size} queued pages)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = onSaveEditedImage,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Image (JPG)", fontSize = 12.sp)
                        }

                        FilledTonalButton(
                            onClick = onAddPageToPdfQueue,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.NoteAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Queue Page (${savedPages.size})", fontSize = 12.sp)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = pdfFileName,
                            onValueChange = { pdfFileName = it },
                            label = { Text("Output PDF Filename", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                        )

                        Button(
                            onClick = { onGeneratePdfDocument(pdfFileName) }
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Build PDF", fontSize = 12.sp)
                        }

                        if (savedPages.isNotEmpty()) {
                            IconButton(onClick = onClearPdfQueue) {
                                Icon(Icons.Default.DeleteSweep, contentDescription = "Clear PDF Queue")
                            }
                        }
                    }

                    if (lastSavedImageFile != null) {
                        Text(
                            text = "Saved Image: ${lastSavedImageFile.absolutePath}",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF4CAF50)
                        )
                    }

                    if (lastGeneratedPdfFile != null) {
                        Text(
                            text = "Generated PDF: ${lastGeneratedPdfFile.absolutePath} (${lastGeneratedPdfFile.length() / 1024} KB)",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF4CAF50)
                        )
                    }
                }
            }
        }
    }
}
