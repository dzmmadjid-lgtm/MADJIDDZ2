package com.crimsonpdf.reconstructor.samples

import com.crimsonpdf.reconstructor.model.BorderProperties
import com.crimsonpdf.reconstructor.model.FontRole
import com.crimsonpdf.reconstructor.model.LayoutObjectType
import com.crimsonpdf.reconstructor.model.PageLayoutObject
import com.crimsonpdf.reconstructor.model.PreprocessingConfig
import com.crimsonpdf.reconstructor.model.SampleTestSpec
import com.crimsonpdf.reconstructor.model.TableCellModel
import com.crimsonpdf.reconstructor.model.TableStructureModel
import com.crimsonpdf.reconstructor.model.TextAlignment
import com.crimsonpdf.reconstructor.model.TextDirection

object AcceptanceTestSuite {

    val specs: List<SampleTestSpec> = listOf(
        SampleTestSpec(
            id = "arabic_paragraph",
            index = 1,
            titleAr = "١. مستند فقرات عربي رسمي",
            categoryAr = "خطاب إداري",
            descriptionAr = "مذكرة إدارية رسمية بترويسة وعناوين متفاوتة وفقرات عربية متصلة وتوقيع.",
            simulatedIssueAr = "ظل إضاءة جانبي خفيف",
            pageCount = 1
        ),
        SampleTestSpec(
            id = "arabic_school_form",
            index = 2,
            titleAr = "٢. استمارة مدرسية عربية",
            categoryAr = "نماذج وحقول",
            descriptionAr = "استمارة تسجيل طالب تحتوي على صناديق مؤطرة ومربعات اختيار وجدول ولي الأمر.",
            simulatedIssueAr = "تصوير بهاتف محمول مع اصفرار طفيف للورق",
            pageCount = 1
        ),
        SampleTestSpec(
            id = "arabic_table",
            index = 3,
            titleAr = "٣. جدول عربي من 5 أعمدة",
            categoryAr = "جداول مهيكلة",
            descriptionAr = "بيان توريدات ومستلزمات مكون من 5 أعمدة بعروض متفاوتة ومحاذاة يمين/وسط.",
            simulatedIssueAr = "ميلان 1.8 درجة مع ظل علوي",
            pageCount = 1
        ),
        SampleTestSpec(
            id = "mixed_arabic_english",
            index = 4,
            titleAr = "٤. مستند مزدوج عربي / إنجليزي",
            categoryAr = "ثنائي اللغة RTL/LTR",
            descriptionAr = "مواصفات تقنية تجمع بين الفقرات العربية (RTL) والمصطلحات الإنجليزية (LTR).",
            simulatedIssueAr = "تفاوت سطوع الخلفية",
            pageCount = 1
        ),
        SampleTestSpec(
            id = "numeric_financial",
            index = 5,
            titleAr = "٥. مستند مالي وأرقام قياسية",
            categoryAr = "أرقام وفواتير",
            descriptionAr = "كشف مالي يحتوي على أرقام عربية وغربية ونسب ضريبية ومجاميع.",
            simulatedIssueAr = "إضاءة جانبية غير متجانسة",
            pageCount = 1
        ),
        SampleTestSpec(
            id = "merged_cells_table",
            index = 6,
            titleAr = "٦. جدول بخلايا مدمجة (Merged Cells)",
            categoryAr = "دمج أفقي وعمودي",
            descriptionAr = "جدول توزيع الاختبارات يحتوي على خلايا مدمجة أفقياً (colSpan) وعمودياً (rowSpan).",
            simulatedIssueAr = "ظل قطري خفيف على الورقة",
            pageCount = 1
        ),
        SampleTestSpec(
            id = "angled_photo",
            index = 7,
            titleAr = "٧. صورة ملتقطة بزاوية مائلة",
            categoryAr = "تصحيح المنظور والميلان",
            descriptionAr = "ورقة مطبوعة ملتقطة بزاوية مائلة مع ظل كاميرا يحتاج إلى تصحيح هندسي.",
            simulatedIssueAr = "ميلان 4.5 درجة + ظل كاميرا",
            pageCount = 1
        ),
        SampleTestSpec(
            id = "low_quality_scan",
            index = 8,
            titleAr = "٨. مستند ممسوح بجودة منخفضة",
            categoryAr = "فحص عدم الهلوسة",
            descriptionAr = "نسخة أرشيفية قديمة بتشويش نقطي وكلمات باهتة يتم إبرازها للمراجعة البشرية.",
            simulatedIssueAr = "ضوضاء مسح ضوئي + بهتان حبر",
            pageCount = 1
        ),
        SampleTestSpec(
            id = "logo_stamp_doc",
            index = 9,
            titleAr = "٩. مستند يحتوي شعاراً وختماً رسمياً",
            categoryAr = "شعارات وأختام",
            descriptionAr = "شهادة رسمية تتضمن شعار المؤسسة، ختماً دائرياً أحمر، ومنطقة توقيع خطي.",
            simulatedIssueAr = "ورق كريمي مع أثر ختم وتوقيع حي",
            pageCount = 1
        ),
        SampleTestSpec(
            id = "multi_page_doc",
            index = 10,
            titleAr = "١٠. مستند متعدد الصفحات (صفحتان)",
            categoryAr = "متعدد الصفحات PDF",
            descriptionAr = "محضر اجتماع رسمي وجدول قرارات موزع على صفحتين مستقلتين للتصدير الموحد.",
            simulatedIssueAr = "صفحتان متتاليتان بتصوير مكتبي",
            pageCount = 2
        )
    )

    private fun cell(
        row: Int,
        col: Int,
        text: String,
        rowSpan: Int = 1,
        colSpan: Int = 1,
        align: TextAlignment = TextAlignment.RIGHT,
        dir: TextDirection = TextDirection.RTL,
        bold: Boolean = false,
        bg: Int = 0x00000000,
        conf: Float = 0.99f,
        hidden: Boolean = false
    ) = TableCellModel(
        id = "c_${row}_$col",
        row = row,
        col = col,
        rowSpan = rowSpan,
        colSpan = colSpan,
        content = text,
        confidence = conf,
        alignment = align,
        direction = dir,
        fontSizePt = 10.5f,
        isBold = bold,
        borders = BorderProperties.uniform(1.2f),
        backgroundColorArgb = bg,
        hiddenByMerge = hidden
    )

    data class SamplePageData(
        val objects: List<PageLayoutObject>,
        val preprocessing: PreprocessingConfig,
        val simulateAngleDeg: Float,
        val simulateNoiseLevel: Int,
        val simulateShadowStrength: Int
    )

    fun getPageData(testId: String, pageIndex: Int = 0): SamplePageData {
        val headerBg = 0xFFE2E8F0.toInt()
        val subBg = 0xFFF8FAFC.toInt()

        return when (testId) {
            "arabic_paragraph" -> SamplePageData(
                simulateAngleDeg = 0.8f,
                simulateNoiseLevel = 8,
                simulateShadowStrength = 28,
                preprocessing = PreprocessingConfig(),
                objects = listOf(
                    PageLayoutObject(
                        id = "hdr_r",
                        type = LayoutObjectType.TEXT,
                        x = 560f, y = 55f, width = 380f, height = 75f,
                        content = "الجمهورية الجزائرية الديمقراطية الشعبية\nمديرية التربية والتعليم — الأمانة العامة\nقسم التوثيق والأرشيف الرقمي",
                        alignment = TextAlignment.RIGHT,
                        fontSizePt = 11f,
                        isBold = true,
                        fontRole = FontRole.HEADING,
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "hdr_l",
                        type = LayoutObjectType.TEXT,
                        x = 60f, y = 60f, width = 280f, height = 55f,
                        content = "الرقم: ٢٠٢٦/أ.ع/٤١٨\nالتاريخ: ٣٠ سبتمبر ٢٠٢٦م",
                        alignment = TextAlignment.LEFT,
                        fontSizePt = 10f,
                        fontRole = FontRole.LABEL,
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "hdr_line",
                        type = LayoutObjectType.LINE,
                        x = 60f, y = 142f, width = 880f, height = 4f,
                        content = "",
                        borders = BorderProperties.uniform(2f),
                        zOrder = 2
                    ),
                    PageLayoutObject(
                        id = "title",
                        type = LayoutObjectType.TEXT,
                        x = 120f, y = 175f, width = 760f, height = 50f,
                        content = "مذكرة عمل بشأن توحيد معايير رقمنة الوثائق الرسمية",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 16.5f,
                        isBold = true,
                        fontRole = FontRole.TITLE,
                        zOrder = 3
                    ),
                    PageLayoutObject(
                        id = "para_1",
                        type = LayoutObjectType.PARAGRAPH,
                        x = 60f, y = 250f, width = 880f, height = 160f,
                        content = "السلام عليكم ورحمة الله وبركاته،\nفي إطار تحديث منظومة الأرشيف الإداري وضمان مطابقة النسخ الرقمية للأصول الورقية المعتمدة، يُطلب من كافة المصالح الالتزام بمعايير إعادة البناء الهيكلي للمستندات عند تحويل الاستمارات والجداول والمحاضر الرسمية إلى صيغة PDF قابلة للطباعة.",
                        alignment = TextAlignment.RIGHT,
                        fontSizePt = 12.5f,
                        zOrder = 4
                    ),
                    PageLayoutObject(
                        id = "para_2",
                        type = LayoutObjectType.PARAGRAPH,
                        x = 60f, y = 430f, width = 880f, height = 160f,
                        content = "أولاً: يجب الحفاظ على التخطيط البصري الأصلي للوثيقة بما في ذلك الهوامش، المسافات بين الفقرات، مواقع الترويسات، والأختام الرسمية دون أي تعديل أو تلخيص للمحتوى النصي.\nثانياً: تُحفظ الجداول بنفس عدد الأعمدة والصفوف والخلايا المدمجة وسماكة الخطوط الفاصلة كما وردت في الورقة المصدرية تماماً.",
                        alignment = TextAlignment.RIGHT,
                        fontSizePt = 12.5f,
                        zOrder = 5
                    ),
                    PageLayoutObject(
                        id = "box_note",
                        type = LayoutObjectType.RECTANGLE,
                        x = 80f, y = 620f, width = 840f, height = 100f,
                        content = "ملاحظة إلزامية: يُمنع منعاً باتاً إعادة صياغة النصوص أو تخمين الكلمات غير الواضحة تلقائياً؛ وفي حال وجود منطقة باهتة يتوجب إبرازها للمراجعة البشرية.",
                        alignment = TextAlignment.RIGHT,
                        fontSizePt = 11f,
                        isBold = true,
                        borders = BorderProperties.uniform(1.8f),
                        backgroundColorArgb = subBg,
                        zOrder = 6
                    ),
                    PageLayoutObject(
                        id = "sig_area",
                        type = LayoutObjectType.SIGNATURE_AREA,
                        x = 90f, y = 765f, width = 300f, height = 120f,
                        content = "إمضاء وختم الأمين العام\nد. عبد القادر المنصوري",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 11f,
                        isBold = true,
                        zOrder = 7
                    )
                )
            )

            "arabic_school_form" -> SamplePageData(
                simulateAngleDeg = -1.1f,
                simulateNoiseLevel = 10,
                simulateShadowStrength = 22,
                preprocessing = PreprocessingConfig(),
                objects = listOf(
                    PageLayoutObject(
                        id = "form_hdr",
                        type = LayoutObjectType.RECTANGLE,
                        x = 55f, y = 50f, width = 890f, height = 80f,
                        content = "مؤسسة النور التعليمية — استمارة تسجيل طالب للعام الدراسي ٢٠٢٦ / ٢٠٢٧",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 14f,
                        isBold = true,
                        borders = BorderProperties.uniform(2f),
                        backgroundColorArgb = headerBg,
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "photo_rect",
                        type = LayoutObjectType.RECTANGLE,
                        x = 60f, y = 155f, width = 165f, height = 180f,
                        content = "صورة شمسية\nللطالب\n(٣.٥×٤.٥)",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 10f,
                        borders = BorderProperties.uniform(1.5f, isDashed = true),
                        zOrder = 2
                    ),
                    PageLayoutObject(
                        id = "student_tbl",
                        type = LayoutObjectType.TABLE,
                        x = 245f, y = 155f, width = 700f, height = 180f,
                        content = "",
                        borders = BorderProperties.uniform(1.6f),
                        zOrder = 3,
                        tableStructure = TableStructureModel(
                            rows = 4, cols = 2,
                            rowHeights = listOf(0.25f, 0.25f, 0.25f, 0.25f),
                            colWidths = listOf(0.34f, 0.66f),
                            cells = listOf(
                                cell(0, 0, "الاسم الكامل للطالب:", bold = true, bg = subBg),
                                cell(0, 1, "يوسف بن محمد الأمين بن عيسى"),
                                cell(1, 0, "تاريخ ومكان الميلاد:", bold = true, bg = subBg),
                                cell(1, 1, "١٨ مارس ٢٠١٢ م — الجزائر العاصمة"),
                                cell(2, 0, "المرحلة الدراسية:", bold = true, bg = subBg),
                                cell(2, 1, "السنة الرابعة متوسط — القسم (ب)"),
                                cell(3, 0, "رقم القيد المدرسي:", bold = true, bg = subBg),
                                cell(3, 1, "STD-2026-08492", dir = TextDirection.LTR, align = TextAlignment.CENTER)
                            )
                        )
                    ),
                    PageLayoutObject(
                        id = "chk_1",
                        type = LayoutObjectType.CHECKBOX,
                        x = 640f, y = 370f, width = 300f, height = 38f,
                        content = "النقل المدرسي الصباحي والمسائي",
                        checked = true,
                        fontSizePt = 11f,
                        zOrder = 4
                    ),
                    PageLayoutObject(
                        id = "chk_2",
                        type = LayoutObjectType.CHECKBOX,
                        x = 330f, y = 370f, width = 290f, height = 38f,
                        content = "الإطعام المدرسي (وجبة الغداء)",
                        checked = true,
                        fontSizePt = 11f,
                        zOrder = 4
                    ),
                    PageLayoutObject(
                        id = "chk_3",
                        type = LayoutObjectType.CHECKBOX,
                        x = 55f, y = 370f, width = 260f, height = 38f,
                        content = "نادي الروبوتيك والبرمجة",
                        checked = false,
                        fontSizePt = 11f,
                        zOrder = 4
                    ),
                    PageLayoutObject(
                        id = "guardian_tbl",
                        type = LayoutObjectType.TABLE,
                        x = 55f, y = 435f, width = 890f, height = 230f,
                        content = "",
                        borders = BorderProperties.uniform(1.6f),
                        zOrder = 5,
                        tableStructure = TableStructureModel(
                            rows = 4, cols = 4,
                            rowHeights = listOf(0.25f, 0.25f, 0.25f, 0.25f),
                            colWidths = listOf(0.22f, 0.28f, 0.22f, 0.28f),
                            cells = listOf(
                                cell(0, 0, "اسم ولي الأمر:", bold = true, bg = subBg),
                                cell(0, 1, "محمد الأمين بن عيسى"),
                                cell(0, 2, "صلة القرابة:", bold = true, bg = subBg),
                                cell(0, 3, "الأب"),
                                cell(1, 0, "رقم الهاتف ١:", bold = true, bg = subBg),
                                cell(1, 1, "0550-48-91-23", dir = TextDirection.LTR, align = TextAlignment.CENTER),
                                cell(1, 2, "رقم الهاتف ٢:", bold = true, bg = subBg),
                                cell(1, 3, "021-64-19-80", dir = TextDirection.LTR, align = TextAlignment.CENTER),
                                cell(2, 0, "العنوان الكامل:", bold = true, bg = subBg),
                                cell(2, 1, "حي الياسمين، عمارة ١٤، شقة ٠٨ — باب الزوار", colSpan = 3),
                                cell(2, 2, "", hidden = true),
                                cell(2, 3, "", hidden = true),
                                cell(3, 0, "ملاحظات طبية:", bold = true, bg = subBg),
                                cell(3, 1, "لا توجد حساسية دوائية مسجلة", colSpan = 3),
                                cell(3, 2, "", hidden = true),
                                cell(3, 3, "", hidden = true)
                            )
                        )
                    ),
                    PageLayoutObject(
                        id = "sig_guardian",
                        type = LayoutObjectType.SIGNATURE_AREA,
                        x = 600f, y = 720f, width = 340f, height = 120f,
                        content = "توقيع ولي الأمر\nالتاريخ: ١٠ / ٠٩ / ٢٠٢٦",
                        alignment = TextAlignment.CENTER,
                        borders = BorderProperties.uniform(1.2f),
                        zOrder = 6
                    ),
                    PageLayoutObject(
                        id = "sig_admin",
                        type = LayoutObjectType.SIGNATURE_AREA,
                        x = 60f, y = 720f, width = 340f, height = 120f,
                        content = "ختم وتأشيرة إدارة التسجيل\nملف مكتمل ومقبول",
                        alignment = TextAlignment.CENTER,
                        borders = BorderProperties.uniform(1.2f),
                        zOrder = 6
                    )
                )
            )

            "arabic_table" -> SamplePageData(
                simulateAngleDeg = 1.8f,
                simulateNoiseLevel = 9,
                simulateShadowStrength = 26,
                preprocessing = PreprocessingConfig(deskewAngleDeg = -1.8f),
                objects = listOf(
                    PageLayoutObject(
                        id = "tbl_title",
                        type = LayoutObjectType.TEXT,
                        x = 100f, y = 65f, width = 800f, height = 48f,
                        content = "جدول جرد التجهيزات المخبرية والحاسوبية — الدفعة الثالثة ٢٠٢٦",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 15f,
                        isBold = true,
                        fontRole = FontRole.TITLE,
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "tbl_sub",
                        type = LayoutObjectType.TEXT,
                        x = 60f, y = 120f, width = 880f, height = 34f,
                        content = "المستودع المركزي — الجناح التقني (ب) · رقم المحضر: INV-2026-309",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 11f,
                        zOrder = 2
                    ),
                    PageLayoutObject(
                        id = "main_5col",
                        type = LayoutObjectType.TABLE,
                        x = 50f, y = 175f, width = 900f, height = 560f,
                        content = "",
                        borders = BorderProperties.uniform(2f),
                        zOrder = 3,
                        tableStructure = TableStructureModel(
                            rows = 7, cols = 5,
                            rowHeights = listOf(0.15f, 0.14f, 0.14f, 0.14f, 0.14f, 0.14f, 0.15f),
                            colWidths = listOf(0.10f, 0.34f, 0.14f, 0.20f, 0.22f),
                            cells = listOf(
                                cell(0, 0, "الرقم", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(0, 1, "بيان التجهيز والمواصفات", bold = true, bg = headerBg),
                                cell(0, 2, "الكمية", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(0, 3, "سعر الوحدة", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(0, 4, "الإجمالي (د.ج)", align = TextAlignment.CENTER, bold = true, bg = headerBg),

                                cell(1, 0, "٠١", align = TextAlignment.CENTER),
                                cell(1, 1, "حاسوب مكتبي معالج Core i7 — 16GB"),
                                cell(1, 2, "١٢", align = TextAlignment.CENTER),
                                cell(1, 3, "145,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR),
                                cell(1, 4, "1,740,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR, bold = true),

                                cell(2, 0, "٠٢", align = TextAlignment.CENTER),
                                cell(2, 1, "ماسح ضوئي احترافي للمستندات A4 مزدوج"),
                                cell(2, 2, "٠٤", align = TextAlignment.CENTER),
                                cell(2, 3, "68,500.00", align = TextAlignment.CENTER, dir = TextDirection.LTR),
                                cell(2, 4, "274,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR, bold = true),

                                cell(3, 0, "٠٣", align = TextAlignment.CENTER),
                                cell(3, 1, "طابعة ليزرية شبكية 45 صفحة/دقيقة"),
                                cell(3, 2, "٠٣", align = TextAlignment.CENTER),
                                cell(3, 3, "92,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR),
                                cell(3, 4, "276,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR, bold = true),

                                cell(4, 0, "٠٤", align = TextAlignment.CENTER),
                                cell(4, 1, "جهاز عرض تفاعلي ذكي بدقة 4K"),
                                cell(4, 2, "٠٢", align = TextAlignment.CENTER),
                                cell(4, 3, "185,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR),
                                cell(4, 4, "370,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR, bold = true),

                                cell(5, 0, "٠٥", align = TextAlignment.CENTER),
                                cell(5, 1, "مزود طاقة لا منقطع UPS 3000VA"),
                                cell(5, 2, "٠٥", align = TextAlignment.CENTER),
                                cell(5, 3, "44,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR),
                                cell(5, 4, "220,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR, bold = true),

                                cell(6, 0, "المجموع العام للتجهيزات المستلمة:", colSpan = 4, align = TextAlignment.LEFT, bold = true, bg = subBg),
                                cell(6, 1, "", hidden = true),
                                cell(6, 2, "", hidden = true),
                                cell(6, 3, "", hidden = true),
                                cell(6, 4, "2,880,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR, bold = true, bg = headerBg)
                            )
                        )
                    ),
                    PageLayoutObject(
                        id = "tbl_foot",
                        type = LayoutObjectType.TEXT,
                        x = 55f, y = 765f, width = 890f, height = 50f,
                        content = "تمت معاينة ومطابقة جميع الأصناف المذكورة أعلاه بحضور لجنة الاستلام التقنية.",
                        alignment = TextAlignment.RIGHT,
                        fontSizePt = 11.5f,
                        zOrder = 4
                    )
                )
            )

            "mixed_arabic_english" -> SamplePageData(
                simulateAngleDeg = 0.5f,
                simulateNoiseLevel = 7,
                simulateShadowStrength = 20,
                preprocessing = PreprocessingConfig(),
                objects = listOf(
                    PageLayoutObject(
                        id = "bi_hdr_ar",
                        type = LayoutObjectType.TEXT,
                        x = 520f, y = 55f, width = 420f, height = 55f,
                        content = "المركز الوطني للأنظمة الرقمية\nقسم هندسة معالجة الوثائق",
                        alignment = TextAlignment.RIGHT,
                        fontSizePt = 12f,
                        isBold = true,
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "bi_hdr_en",
                        type = LayoutObjectType.TEXT,
                        x = 60f, y = 55f, width = 420f, height = 55f,
                        content = "NATIONAL CENTER FOR DIGITAL SYSTEMS\nDocument Layout Spec v3.4",
                        alignment = TextAlignment.LEFT,
                        direction = TextDirection.LTR,
                        fontSizePt = 11f,
                        isBold = true,
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "bi_line",
                        type = LayoutObjectType.LINE,
                        x = 60f, y = 125f, width = 880f, height = 4f,
                        content = "",
                        borders = BorderProperties.uniform(2f),
                        zOrder = 2
                    ),
                    PageLayoutObject(
                        id = "bi_para_ar",
                        type = LayoutObjectType.PARAGRAPH,
                        x = 60f, y = 160f, width = 880f, height = 140f,
                        content = "تتطلب الوثائق الهندسية والطبية في المنطقة العربية دعماً مزدوجاً لاتجاه النص من اليمين إلى اليسار (RTL) مع الحفاظ على العبارات اللاتينية والرموز البرمجية مثل PDF/A-2b و UTF-8 و Homography في سياقها الصحيح.",
                        alignment = TextAlignment.RIGHT,
                        fontSizePt = 12f,
                        zOrder = 3
                    ),
                    PageLayoutObject(
                        id = "bi_para_en",
                        type = LayoutObjectType.PARAGRAPH,
                        x = 60f, y = 320f, width = 880f, height = 130f,
                        content = "Technical Requirement 4.2: Every reconstructed page object MUST retain explicit bounding coordinates (x, y, width, height) alongside bidirectional text shaping rules.",
                        alignment = TextAlignment.LEFT,
                        direction = TextDirection.LTR,
                        fontSizePt = 11.5f,
                        zOrder = 4
                    ),
                    PageLayoutObject(
                        id = "bi_tbl",
                        type = LayoutObjectType.TABLE,
                        x = 60f, y = 475f, width = 880f, height = 280f,
                        content = "",
                        borders = BorderProperties.uniform(1.6f),
                        zOrder = 5,
                        tableStructure = TableStructureModel(
                            rows = 4, cols = 3,
                            rowHeights = listOf(0.25f, 0.25f, 0.25f, 0.25f),
                            colWidths = listOf(0.28f, 0.42f, 0.30f),
                            cells = listOf(
                                cell(0, 0, "المعيار التقني", bold = true, bg = headerBg),
                                cell(0, 1, "الوصف العربي المعتمد", bold = true, bg = headerBg),
                                cell(0, 2, "Standard Parameter", align = TextAlignment.LEFT, dir = TextDirection.LTR, bold = true, bg = headerBg),
                                cell(1, 0, "دقة التصدير الطباعي"),
                                cell(1, 1, "٣٠٠ نقطة في البوصة بدون ضغط يفقد الحدة"),
                                cell(1, 2, "300 DPI Lossless Print PDF", align = TextAlignment.LEFT, dir = TextDirection.LTR),
                                cell(2, 0, "اتجاه النصوص والجداول"),
                                cell(2, 1, "دعم كامل للعربية RTL واللاتينية LTR"),
                                cell(2, 2, "BiDi Shaping & RTL", align = TextAlignment.LEFT, dir = TextDirection.LTR),
                                cell(3, 0, "قاعدة منع الهلوسة"),
                                cell(3, 1, "الحفاظ على النص الأصلي وإبراز غير الواضح"),
                                cell(3, 2, "Zero-Hallucination Rule", align = TextAlignment.LEFT, dir = TextDirection.LTR)
                            )
                        )
                    )
                )
            )

            "numeric_financial" -> SamplePageData(
                simulateAngleDeg = -0.7f,
                simulateNoiseLevel = 9,
                simulateShadowStrength = 24,
                preprocessing = PreprocessingConfig(),
                objects = listOf(
                    PageLayoutObject(
                        id = "fin_title",
                        type = LayoutObjectType.TEXT,
                        x = 120f, y = 60f, width = 760f, height = 48f,
                        content = "كشف الحساب الضريبي والفاتورة التفصيلية رقم #INV-2026/904",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 15f,
                        isBold = true,
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "fin_meta",
                        type = LayoutObjectType.RECTANGLE,
                        x = 60f, y = 125f, width = 880f, height = 75f,
                        content = "الرقم الجبائي: 001928374650912  |  السجل التجاري: ١٦/٠٠-٤٨٢٩١٠٣ ب  |  الاستحقاق: ٢٠٢٦/٠٩/٣٠",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 11f,
                        isBold = true,
                        borders = BorderProperties.uniform(1.5f),
                        backgroundColorArgb = subBg,
                        zOrder = 2
                    ),
                    PageLayoutObject(
                        id = "fin_tbl",
                        type = LayoutObjectType.TABLE,
                        x = 60f, y = 225f, width = 880f, height = 440f,
                        content = "",
                        borders = BorderProperties.uniform(1.6f),
                        zOrder = 3,
                        tableStructure = TableStructureModel(
                            rows = 5, cols = 5,
                            rowHeights = listOf(0.20f, 0.20f, 0.20f, 0.20f, 0.20f),
                            colWidths = listOf(0.12f, 0.34f, 0.14f, 0.18f, 0.22f),
                            cells = listOf(
                                cell(0, 0, "البند", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(0, 1, "البيان المالي والمرجع", bold = true, bg = headerBg),
                                cell(0, 2, "الضريبة", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(0, 3, "المبلغ الصافي", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(0, 4, "الإجمالي مع الرسم", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(1, 0, "١٠١", align = TextAlignment.CENTER),
                                cell(1, 1, "رخصة تشغيل خوادم الأرشفة (دفعة ١/٤)"),
                                cell(1, 2, "١٩٪", align = TextAlignment.CENTER),
                                cell(1, 3, "420,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR),
                                cell(1, 4, "499,800.00", align = TextAlignment.CENTER, dir = TextDirection.LTR, bold = true),
                                cell(2, 0, "١٠٢", align = TextAlignment.CENTER),
                                cell(2, 1, "وحدات تخزين احتياطية RAID-10 بسعة 64TB"),
                                cell(2, 2, "١٩٪", align = TextAlignment.CENTER),
                                cell(2, 3, "310,500.00", align = TextAlignment.CENTER, dir = TextDirection.LTR),
                                cell(2, 4, "369,495.00", align = TextAlignment.CENTER, dir = TextDirection.LTR, bold = true),
                                cell(3, 0, "١٠٣", align = TextAlignment.CENTER),
                                cell(3, 1, "عقود الصيانة الدورية والدعم الميداني"),
                                cell(3, 2, "٠٩٪", align = TextAlignment.CENTER),
                                cell(3, 3, "180,000.00", align = TextAlignment.CENTER, dir = TextDirection.LTR),
                                cell(3, 4, "196,200.00", align = TextAlignment.CENTER, dir = TextDirection.LTR, bold = true),
                                cell(4, 0, "الصافي الواجب الدفع (بالدينار):", colSpan = 4, align = TextAlignment.LEFT, bold = true, bg = headerBg),
                                cell(4, 1, "", hidden = true),
                                cell(4, 2, "", hidden = true),
                                cell(4, 3, "", hidden = true),
                                cell(4, 4, "1,065,495.00", align = TextAlignment.CENTER, dir = TextDirection.LTR, bold = true, bg = headerBg)
                            )
                        )
                    )
                )
            )

            "merged_cells_table" -> SamplePageData(
                simulateAngleDeg = 1.2f,
                simulateNoiseLevel = 8,
                simulateShadowStrength = 25,
                preprocessing = PreprocessingConfig(),
                objects = listOf(
                    PageLayoutObject(
                        id = "mrg_title",
                        type = LayoutObjectType.TEXT,
                        x = 100f, y = 65f, width = 800f, height = 48f,
                        content = "جدول توزيع اللجان والاختبارات الفصلية (خلايا مدمجة أفقياً وعمودياً)",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 14.5f,
                        isBold = true,
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "mrg_tbl",
                        type = LayoutObjectType.TABLE,
                        x = 50f, y = 150f, width = 900f, height = 540f,
                        content = "",
                        borders = BorderProperties.uniform(2f),
                        zOrder = 2,
                        tableStructure = TableStructureModel(
                            rows = 5, cols = 5,
                            rowHeights = listOf(0.18f, 0.18f, 0.22f, 0.22f, 0.20f),
                            colWidths = listOf(0.18f, 0.21f, 0.21f, 0.20f, 0.20f),
                            cells = listOf(
                                cell(0, 0, "اليوم / الفترة", rowSpan = 2, align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(0, 1, "الفترة الصباحية (٠٨:٠٠ - ١٢:٠٠)", colSpan = 2, align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(0, 2, "", hidden = true),
                                cell(0, 3, "الفترة المسائية (١٣:٣٠ - ١٦:٣٠)", colSpan = 2, align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(0, 4, "", hidden = true),

                                cell(1, 0, "", hidden = true),
                                cell(1, 1, "الحصة الأولى", align = TextAlignment.CENTER, bold = true, bg = subBg),
                                cell(1, 2, "الحصة الثانية", align = TextAlignment.CENTER, bold = true, bg = subBg),
                                cell(1, 3, "الحصة الثالثة", align = TextAlignment.CENTER, bold = true, bg = subBg),
                                cell(1, 4, "المخبر التطبيقي", align = TextAlignment.CENTER, bold = true, bg = subBg),

                                cell(2, 0, "الأحد", align = TextAlignment.CENTER, bold = true, bg = subBg),
                                cell(2, 1, "الرياضيات والهندسة", align = TextAlignment.CENTER),
                                cell(2, 2, "اللغة العربية", align = TextAlignment.CENTER),
                                cell(2, 3, "ورشة الفيزياء التجريبية المدمجة (٣ ساعات)", colSpan = 2, align = TextAlignment.CENTER, bold = true),
                                cell(2, 4, "", hidden = true),

                                cell(3, 0, "الإثنين", align = TextAlignment.CENTER, bold = true, bg = subBg),
                                cell(3, 1, "العلوم الطبيعية (مشترك)", colSpan = 2, align = TextAlignment.CENTER),
                                cell(3, 2, "", hidden = true),
                                cell(3, 3, "التاريخ والجغرافيا", align = TextAlignment.CENTER),
                                cell(3, 4, "مشروع التخرج\n(لجنة موحدة)", rowSpan = 2, align = TextAlignment.CENTER, bold = true, bg = subBg),

                                cell(4, 0, "الثلاثاء", align = TextAlignment.CENTER, bold = true, bg = subBg),
                                cell(4, 1, "اللغة الإنجليزية", align = TextAlignment.CENTER),
                                cell(4, 2, "الإعلام الآلي", align = TextAlignment.CENTER),
                                cell(4, 3, "التربية الإسلامية", align = TextAlignment.CENTER),
                                cell(4, 4, "", hidden = true)
                            )
                        )
                    )
                )
            )

            "angled_photo" -> SamplePageData(
                simulateAngleDeg = 4.5f,
                simulateNoiseLevel = 14,
                simulateShadowStrength = 48,
                preprocessing = PreprocessingConfig(deskewAngleDeg = -4.5f, removeShadows = true, shadowStrength = 85f),
                objects = listOf(
                    PageLayoutObject(
                        id = "ang_hdr",
                        type = LayoutObjectType.TEXT,
                        x = 120f, y = 70f, width = 760f, height = 48f,
                        content = "محضر معاينة ميدانية — مصحح من صورة ملتقطة بزاوية مائلة",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 15.5f,
                        isBold = true,
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "ang_para",
                        type = LayoutObjectType.PARAGRAPH,
                        x = 65f, y = 145f, width = 870f, height = 140f,
                        content = "تم التقاط هذه الوثيقة بكاميرا الهاتف بزاوية ميلان (٤.٥ درجة) مع وجود ظل إضاءة مكتبي. يقوم محرك المعالجة المسبقة بإزالة الميلان (Deskew) وتوحيد سطوع الخلفية قبل استخراج التخطيط والجدول.",
                        alignment = TextAlignment.RIGHT,
                        fontSizePt = 12.5f,
                        zOrder = 2
                    ),
                    PageLayoutObject(
                        id = "ang_tbl",
                        type = LayoutObjectType.TABLE,
                        x = 65f, y = 310f, width = 870f, height = 300f,
                        content = "",
                        borders = BorderProperties.uniform(1.6f),
                        zOrder = 3,
                        tableStructure = TableStructureModel(
                            rows = 4, cols = 3,
                            rowHeights = listOf(0.25f, 0.25f, 0.25f, 0.25f),
                            colWidths = listOf(0.28f, 0.44f, 0.28f),
                            cells = listOf(
                                cell(0, 0, "مرحلة المعالجة", bold = true, bg = headerBg),
                                cell(0, 1, "الإجراء الهندسي المطبق", bold = true, bg = headerBg),
                                cell(0, 2, "النتيجة القياسية", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                cell(1, 0, "تصحيح المنظور"),
                                cell(1, 1, "إعادة الورقة إلى مستطيل A4 متعامد"),
                                cell(1, 2, "مطابق ١٠٠٪", align = TextAlignment.CENTER),
                                cell(2, 0, "إزالة الميلان Deskew"),
                                cell(2, 1, "معايرة زاوية الأسطر (-4.5°)"),
                                cell(2, 2, "٠.٠ درجة انحراف", align = TextAlignment.CENTER),
                                cell(3, 0, "إزالة الظل والتباين"),
                                cell(3, 1, "تبييض خلفية الورقة دون المساس بالحبر"),
                                cell(3, 2, "خلفية نقية للطباعة", align = TextAlignment.CENTER)
                            )
                        )
                    )
                )
            )

            "low_quality_scan" -> SamplePageData(
                simulateAngleDeg = 1.4f,
                simulateNoiseLevel = 40,
                simulateShadowStrength = 38,
                preprocessing = PreprocessingConfig(denoiseLevel = 75f, contrastBoost = 70f),
                objects = listOf(
                    PageLayoutObject(
                        id = "low_title",
                        type = LayoutObjectType.TEXT,
                        x = 120f, y = 65f, width = 760f, height = 48f,
                        content = "نسخة أرشيفية مصورة — عقد إيجار محل تجاري رقم ١٩٩٨/٤٠٢",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 15f,
                        isBold = true,
                        confidence = 0.92f,
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "low_para",
                        type = LayoutObjectType.PARAGRAPH,
                        x = 65f, y = 140f, width = 870f, height = 130f,
                        content = "تم تحرير هذا العقد بتاريخ ١٢ مايو ١٩٩٨ بين الطرف الأول المالك السيد: عبد الحميد بوضياف، والطرف الثاني المستأجر السيد: كمال بن عمارة، وذلك لاستغلال المحل الكائن في شارع الاستقلال رقم ٢٤.",
                        alignment = TextAlignment.RIGHT,
                        fontSizePt = 12.5f,
                        confidence = 0.94f,
                        zOrder = 2
                    ),
                    PageLayoutObject(
                        id = "low_uncertain",
                        type = LayoutObjectType.PARAGRAPH,
                        x = 65f, y = 295f, width = 870f, height = 140f,
                        content = "البند الرابع (منطقة حبر باهت في الأصل الممسوح): يلتزم المستأجر بدفع بدل الإيجار الفصلي البالغ [٤٥,٠٠٠ د.ج] قبل اليوم الخامس من كل فصل وفق الوصل رقم [٩٨/٧٧١].",
                        alignment = TextAlignment.RIGHT,
                        fontSizePt = 12f,
                        confidence = 0.58f,
                        uncertainTokens = listOf("[٤٥,٠٠٠ د.ج]", "[٩٨/٧٧١]"),
                        borders = BorderProperties.uniform(1.5f, isDashed = true, colorArgb = 0xFFD97706.toInt()),
                        backgroundColorArgb = 0xFFFFFBEB.toInt(),
                        zOrder = 3
                    )
                )
            )

            "logo_stamp_doc" -> SamplePageData(
                simulateAngleDeg = 0.4f,
                simulateNoiseLevel = 6,
                simulateShadowStrength = 18,
                preprocessing = PreprocessingConfig(),
                objects = listOf(
                    PageLayoutObject(
                        id = "logo_top",
                        type = LayoutObjectType.IMAGE,
                        x = 425f, y = 45f, width = 150f, height = 125f,
                        content = "شعار الأكاديمية\nالعربية الرقمية",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 9.5f,
                        isBold = true,
                        stampColorArgb = 0xFF0F172A.toInt(),
                        zOrder = 1
                    ),
                    PageLayoutObject(
                        id = "cert_title",
                        type = LayoutObjectType.TEXT,
                        x = 120f, y = 190f, width = 760f, height = 52f,
                        content = "شهادة اعتماد ومطابقة تقنية للوثائق الرقمية",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 17f,
                        isBold = true,
                        zOrder = 2
                    ),
                    PageLayoutObject(
                        id = "cert_body",
                        type = LayoutObjectType.PARAGRAPH,
                        x = 75f, y = 270f, width = 850f, height = 175f,
                        content = "تشهد اللجنة العلمية بالأكاديمية العربية للهندسة الرقمية بأن منظومة إعادة بناء المستندات قد اجتازت كافة اختبارات المطابقة البصرية والهندسية للوثائق العربية والجداول المهيكلة والأختام الرسمية، مع الحفاظ التام على أمانة المحتوى.",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 13f,
                        zOrder = 3
                    ),
                    PageLayoutObject(
                        id = "cert_box",
                        type = LayoutObjectType.RECTANGLE,
                        x = 100f, y = 475f, width = 800f, height = 110f,
                        content = "رقم الاعتماد الدولي: CERT-AR-2026-8841\nتاريخ الإصدار: ٣٠ سبتمبر ٢٠٢٦ — الحالة: معتمد للطباعة والأرشفة",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 11.5f,
                        isBold = true,
                        borders = BorderProperties.uniform(2f, isDouble = true),
                        backgroundColorArgb = subBg,
                        zOrder = 4
                    ),
                    PageLayoutObject(
                        id = "red_stamp",
                        type = LayoutObjectType.IMAGE,
                        x = 415f, y = 635f, width = 170f, height = 160f,
                        content = "الختم الرسمي المعتمد\nمؤسسة التوثيق\n٢٠٢٦",
                        alignment = TextAlignment.CENTER,
                        fontSizePt = 9.5f,
                        isBold = true,
                        stampColorArgb = 0xFFDC2626.toInt(),
                        zOrder = 5
                    ),
                    PageLayoutObject(
                        id = "cert_sig",
                        type = LayoutObjectType.SIGNATURE_AREA,
                        x = 80f, y = 650f, width = 280f, height = 130f,
                        content = "توقيع رئيس اللجنة العلمية\nأ.د. سليم بن خلدون",
                        alignment = TextAlignment.CENTER,
                        borders = BorderProperties.uniform(1.2f),
                        zOrder = 6
                    )
                )
            )

            "multi_page_doc" -> if (pageIndex == 0) {
                SamplePageData(
                    simulateAngleDeg = 0.6f,
                    simulateNoiseLevel = 7,
                    simulateShadowStrength = 20,
                    preprocessing = PreprocessingConfig(),
                    objects = listOf(
                        PageLayoutObject(
                            id = "mp1_hdr",
                            type = LayoutObjectType.TEXT,
                            x = 60f, y = 55f, width = 880f, height = 48f,
                            content = "محضر الاجتماع السنوي للجنة رقمنة الأرشيف — (الصفحة ١ من ٢)",
                            alignment = TextAlignment.CENTER,
                            fontSizePt = 15f,
                            isBold = true,
                            zOrder = 1
                        ),
                        PageLayoutObject(
                            id = "mp1_para",
                            type = LayoutObjectType.PARAGRAPH,
                            x = 65f, y = 130f, width = 870f, height = 140f,
                            content = "انعقد يوم الأربعاء الموافق لـ ٣٠ سبتمبر ٢٠٢٦ بمقر المديرية العامة الاجتماع الدوري لمراجعة مخرجات مشروع إعادة بناء الوثائق الورقية الممسوحة ضوئياً، وتم استعراض نتائج الفحص على عشرة أنماط مختلفة من الوثائق العربية والجداول.",
                            alignment = TextAlignment.RIGHT,
                            fontSizePt = 12.5f,
                            zOrder = 2
                        ),
                        PageLayoutObject(
                            id = "mp1_tbl",
                            type = LayoutObjectType.TABLE,
                            x = 65f, y = 300f, width = 870f, height = 340f,
                            content = "",
                            borders = BorderProperties.uniform(1.6f),
                            zOrder = 3,
                            tableStructure = TableStructureModel(
                                rows = 4, cols = 3,
                                rowHeights = listOf(0.25f, 0.25f, 0.25f, 0.25f),
                                colWidths = listOf(0.18f, 0.52f, 0.30f),
                                cells = listOf(
                                    cell(0, 0, "البند", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                    cell(0, 1, "محور النقاش في الصفحة الأولى", bold = true, bg = headerBg),
                                    cell(0, 2, "القرار المتخذ", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                    cell(1, 0, "أولاً", align = TextAlignment.CENTER),
                                    cell(1, 1, "اعتماد محرك إعادة البناء الهيكلي بدل استخراج النص الخام"),
                                    cell(1, 2, "موافقة بالإجماع", align = TextAlignment.CENTER),
                                    cell(2, 0, "ثانياً", align = TextAlignment.CENTER),
                                    cell(2, 1, "تطبيق قاعدة عدم اختلاق أو تعديل أي نص غير واضح"),
                                    cell(2, 2, "إلزامي", align = TextAlignment.CENTER),
                                    cell(3, 0, "ثالثاً", align = TextAlignment.CENTER),
                                    cell(3, 1, "دعم تصدير ملفات PDF متعددة الصفحات بدقة 300 DPI"),
                                    cell(3, 2, "انظر الصفحة (٢)", align = TextAlignment.CENTER)
                                )
                            )
                        ),
                        PageLayoutObject(
                            id = "mp1_break",
                            type = LayoutObjectType.PAGE_BREAK,
                            x = 65f, y = 840f, width = 870f, height = 35f,
                            content = "— نهاية الصفحة الأولى (١/٢) · يتبع في الصفحة الثانية —",
                            alignment = TextAlignment.CENTER,
                            fontSizePt = 10f,
                            isBold = true,
                            zOrder = 4
                        )
                    )
                )
            } else {
                SamplePageData(
                    simulateAngleDeg = -0.5f,
                    simulateNoiseLevel = 7,
                    simulateShadowStrength = 19,
                    preprocessing = PreprocessingConfig(),
                    objects = listOf(
                        PageLayoutObject(
                            id = "mp2_hdr",
                            type = LayoutObjectType.TEXT,
                            x = 60f, y = 55f, width = 880f, height = 48f,
                            content = "تابع محضر الاجتماع السنوي — جدول التوصيات والتوقيعات (الصفحة ٢ من ٢)",
                            alignment = TextAlignment.CENTER,
                            fontSizePt = 15f,
                            isBold = true,
                            zOrder = 1
                        ),
                        PageLayoutObject(
                            id = "mp2_tbl",
                            type = LayoutObjectType.TABLE,
                            x = 65f, y = 140f, width = 870f, height = 340f,
                            content = "",
                            borders = BorderProperties.uniform(1.6f),
                            zOrder = 2,
                            tableStructure = TableStructureModel(
                                rows = 4, cols = 4,
                                rowHeights = listOf(0.25f, 0.25f, 0.25f, 0.25f),
                                colWidths = listOf(0.25f, 0.30f, 0.25f, 0.20f),
                                cells = listOf(
                                    cell(0, 0, "اسم العضو", bold = true, bg = headerBg),
                                    cell(0, 1, "الصفة الوظيفية", bold = true, bg = headerBg),
                                    cell(0, 2, "المهمة المكلف بها", bold = true, bg = headerBg),
                                    cell(0, 3, "التوقيع", align = TextAlignment.CENTER, bold = true, bg = headerBg),
                                    cell(1, 0, "م. نبيل بوجمعة"),
                                    cell(1, 1, "رئيس قسم معالجة الصور"),
                                    cell(1, 2, "معايرة خوارزميات المنظور"),
                                    cell(1, 3, "موقّع", align = TextAlignment.CENTER),
                                    cell(2, 0, "د. سارة بن دحمان"),
                                    cell(2, 1, "مهندسة التعرف الضوئي"),
                                    cell(2, 2, "ضبط الجداول العربية"),
                                    cell(2, 3, "موقّع", align = TextAlignment.CENTER),
                                    cell(3, 0, "أ. كمال زروقي"),
                                    cell(3, 1, "مسؤول الجودة PDF"),
                                    cell(3, 2, "فحص مطابقة الصفحة ١٠٠٪"),
                                    cell(3, 3, "موقّع", align = TextAlignment.CENTER)
                                )
                            )
                        ),
                        PageLayoutObject(
                            id = "mp2_stamp",
                            type = LayoutObjectType.IMAGE,
                            x = 415f, y = 550f, width = 170f, height = 155f,
                            content = "ختم الأمانة العامة\nصفحة ٢ / ٢",
                            alignment = TextAlignment.CENTER,
                            fontSizePt = 9.5f,
                            isBold = true,
                            stampColorArgb = 0xFFDC2626.toInt(),
                            zOrder = 3
                        )
                    )
                )
            }

            else -> getPageData("arabic_table", 0)
        }
    }
}
