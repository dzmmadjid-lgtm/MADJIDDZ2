package com.example.ui.tools

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.theme.AppThemeMode
import com.example.theme.RedBrand
import com.example.theme.ThemePreferences
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    themePreferences: ThemePreferences,
    currentThemeMode: AppThemeMode,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val defaultPageSize by themePreferences.defaultPageSize.collectAsState(initial = "A4")
    val defaultImageFormat by themePreferences.defaultImageFormat.collectAsState(initial = "JPG")
    val defaultImageQuality by themePreferences.defaultImageQuality.collectAsState(initial = 90)

    var showClearHistoryDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات والتخصيص", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Theme Mode Selector
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("المظهر والألوان", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    Text(
                        text = "اختر المظهر المفضل للتطبيق. يدعم التطبيق وضع OLED الأسود النقي لتوفير استهلاك البطارية على شاشات AMOLED.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    val modes = listOf(
                        AppThemeMode.SYSTEM to "تلقائي (حسب النظام)",
                        AppThemeMode.LIGHT to "فاتح (الأصل)",
                        AppThemeMode.DARK to "داكن",
                        AppThemeMode.OLED to "أسود نقي OLED (#000000)"
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        modes.forEach { (mode, label) ->
                            val isSelected = currentThemeMode == mode
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else Color.Transparent)
                                    .clickable {
                                        coroutineScope.launch {
                                            themePreferences.setThemeMode(mode)
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = label,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                                RadioButton(
                                    selected = isSelected,
                                    onClick = {
                                        coroutineScope.launch {
                                            themePreferences.setThemeMode(mode)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Document Export Defaults
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Description, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إعدادات تصدير المستندات", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    // Default Page Size
                    Text("الحجم الافتراضي لصفحات PDF:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("A4", "LETTER").forEach { pSize ->
                            FilterChip(
                                selected = defaultPageSize == pSize,
                                onClick = {
                                    coroutineScope.launch { themePreferences.setDefaultPageSize(pSize) }
                                },
                                label = { Text(pSize) }
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Default Image Format
                    Text("صيغة الصور الافتراضية:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("JPG", "PNG").forEach { fmt ->
                            FilterChip(
                                selected = defaultImageFormat == fmt,
                                onClick = {
                                    coroutineScope.launch { themePreferences.setDefaultImageFormat(fmt) }
                                },
                                label = { Text(fmt) }
                            )
                        }
                    }
                }
            }

            // Cache & History
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.CleaningServices, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إدارة الذاكرة المؤقتة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    Text(
                        text = "يتم حفظ الملفات المؤقتة محلياً فقط. يمكنك مسح الذاكرة المؤقتة لتحرير مساحة التخزين.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedButton(
                        onClick = { showClearHistoryDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("مسح الملفات المؤقتة وسجل المستندات")
                    }
                }
            }

            // About Application Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(RedBrand),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("PDF", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }

                    Text("Click School", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("منصة أدوات PDF الاحترافية • الإصدار 1.0", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "معالجة محلية آمنة 100% دون أي اتصال بخوادم خارجية أو جمع بيانات.",
                        fontSize = 11.sp,
                        color = Color(0xFF16A34A),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }

    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = { Text("تأكيد مسح الملفات المؤقتة") },
            text = { Text("سيتم حذف جميع ملفات المعاينة المؤقتة من ذاكرة التخزين المؤقت.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        coroutineScope.launch {
                            try {
                                context.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                                Toast.makeText(context, "تم تنظيف الملفات المؤقتة بنجاح!", Toast.LENGTH_SHORT).show()
                            } catch (_: Exception) {}
                            showClearHistoryDialog = false
                        }
                    }
                ) {
                    Text("مسح", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
