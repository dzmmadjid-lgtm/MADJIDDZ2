package com.example.streamhub.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkRemove
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.streamhub.data.SampleCatalog
import com.example.streamhub.model.MediaItem
import com.example.streamhub.theme.StreamTheme

@Composable
fun LibraryScreen(
    watchlistIds: Set<String>,
    downloads: Map<String, Float>,
    onPlayMedia: (MediaItem) -> Unit,
    onOpenMediaDetails: (MediaItem) -> Unit,
    onRemoveFromWatchlist: (String) -> Unit,
    onDeleteDownload: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = StreamTheme.colors

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("قائمتي (${watchlistIds.size})", "التنزيلات (${downloads.size})", "سجل المشاهدة")

    val watchlistItems = SampleCatalog.allMedia.filter { watchlistIds.contains(it.id) }
    val downloadedItems = SampleCatalog.allMedia.filter { downloads.containsKey(it.id) }
    val historyItems = SampleCatalog.allMedia.take(4)

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("library_screen")
    ) {
        // شريط التبويبات
        TabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = colors.background,
            contentColor = colors.primaryAccent,
            indicator = { tabPositions ->
                SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = colors.primaryAccent,
                    height = 3.dp
                )
            }
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == index) colors.primaryAccent else colors.textSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        when (selectedTabIndex) {
            0 -> {
                // قائمة المشاهدة (Watchlist)
                if (watchlistItems.isEmpty()) {
                    EmptyLibraryView(
                        title = "قائمتك فارغة حالياً",
                        message = "استكشف الأفلام والمسلسلات وأضفها إلى قائمتك لمشاهدتها لاحقاً"
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(watchlistItems) { item ->
                            LibraryItemCard(
                                media = item,
                                actionIcon = Icons.Default.BookmarkRemove,
                                actionContentDesc = "إزالة من القائمة",
                                onAction = { onRemoveFromWatchlist(item.id) },
                                onCardClick = { onOpenMediaDetails(item) },
                                onPlayClick = { onPlayMedia(item) }
                            )
                        }
                    }
                }
            }
            1 -> {
                // التنزيلات (Downloads for Offline)
                if (downloadedItems.isEmpty()) {
                    EmptyLibraryView(
                        title = "لا توجد تنزيلات",
                        message = "قم بتنزيل أفلامك ومسلسلاتك المفضلة للمشاهدة في أي وقت بدون إنترنت"
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(downloadedItems) { item ->
                            val progress = downloads[item.id] ?: 1.0f
                            val isComplete = progress >= 1.0f

                            Surface(
                                color = colors.cardBackground,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, colors.cardBorder, RoundedCornerShape(14.dp))
                                    .clickable { onOpenMediaDetails(item) }
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(44.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isComplete) colors.secondaryAccent.copy(alpha = 0.2f) else colors.surfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (isComplete) Icons.Default.CheckCircle else Icons.Default.Download,
                                                contentDescription = null,
                                                tint = if (isComplete) colors.secondaryAccent else colors.primaryAccent,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = item.title,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = colors.textPrimary
                                            )
                                            Text(
                                                text = if (isComplete) "${item.downloadSizeMb} MB • جاهز للمشاهدة بدون نت" else "جاري التنزيل... ${(progress * 100).toInt()}%",
                                                fontSize = 11.sp,
                                                color = colors.textSecondary
                                            )
                                        }

                                        Row {
                                            IconButton(onClick = { onPlayMedia(item) }) {
                                                Icon(
                                                    imageVector = Icons.Default.PlayArrow,
                                                    contentDescription = "تشغيل",
                                                    tint = colors.primaryAccent
                                                )
                                            }
                                            IconButton(onClick = { onDeleteDownload(item.id) }) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "حذف التنزيل",
                                                    tint = colors.textMuted
                                                )
                                            }
                                        }
                                    }

                                    if (!isComplete) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        LinearProgressIndicator(
                                            progress = { progress },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(4.dp)
                                                .clip(RoundedCornerShape(2.dp)),
                                            color = colors.secondaryAccent,
                                            trackColor = colors.surfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                // سجل المشاهدة (History)
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(historyItems) { item ->
                        LibraryItemCard(
                            media = item,
                            actionIcon = Icons.Default.PlayArrow,
                            actionContentDesc = "إعادة المشاهدة",
                            onAction = { onPlayMedia(item) },
                            onCardClick = { onOpenMediaDetails(item) },
                            onPlayClick = { onPlayMedia(item) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryItemCard(
    media: MediaItem,
    actionIcon: androidx.compose.ui.graphics.vector.ImageVector,
    actionContentDesc: String,
    onAction: () -> Unit,
    onCardClick: () -> Unit,
    onPlayClick: () -> Unit
) {
    val colors = StreamTheme.colors

    Surface(
        color = colors.cardBackground,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, colors.cardBorder, RoundedCornerShape(14.dp))
            .clickable(onClick = onCardClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(media.posterPlaceholderColor)),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onPlayClick) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "تشغيل",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = media.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Text(
                    text = "${media.year} • ${media.videoQuality} • ${media.genres.firstOrNull() ?: ""}",
                    fontSize = 11.sp,
                    color = colors.textSecondary
                )
            }

            IconButton(onClick = onAction) {
                Icon(
                    imageVector = actionIcon,
                    contentDescription = actionContentDesc,
                    tint = colors.textMuted
                )
            }
        }
    }
}

@Composable
private fun EmptyLibraryView(title: String, message: String) {
    val colors = StreamTheme.colors

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(colors.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.VideoLibrary,
                    contentDescription = null,
                    tint = colors.textMuted,
                    modifier = Modifier.size(32.dp)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            Text(
                text = message,
                fontSize = 12.sp,
                color = colors.textSecondary,
                modifier = Modifier.padding(top = 4.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
