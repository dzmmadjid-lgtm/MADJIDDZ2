import {
  BorderSide,
  PageLayoutObject,
  TableCellModel,
  TextAlignment,
  TextDirection,
} from '../models/DocumentModel';

export interface RenderOptions {
  widthPx: number;
  heightPx: number;
  highlightSelectedId?: string | null;
  highlightLowConfidence?: boolean;
  showBoundingBoxes?: boolean;
  simulateScannedPhoto?: {
    angleDeg: number;
    noiseLevel: number; // 0 to 100
    shadowStrength: number; // 0 to 100
  };
}

function drawBorderSide(
  ctx: CanvasRenderingContext2D,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  side: BorderSide,
  scale: number
) {
  if (!side || side.width <= 0 || side.style === 'none') return;
  ctx.save();
  ctx.strokeStyle = side.color || '#0F172A';
  ctx.lineWidth = Math.max(1, side.width * scale);
  if (side.style === 'dashed') {
    ctx.setLineDash([6 * scale, 4 * scale]);
  } else {
    ctx.setLineDash([]);
  }
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  if (side.style === 'double') {
    const offset = 3 * scale;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const len = Math.hypot(dx, dy) || 1;
    const nx = (-dy / len) * offset;
    const ny = (dx / len) * offset;
    ctx.beginPath();
    ctx.moveTo(x1 + nx, y1 + ny);
    ctx.lineTo(x2 + nx, y2 + ny);
    ctx.stroke();
  }
  ctx.restore();
}

function drawBoxBorders(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  borders: PageLayoutObject['borderProperties'],
  scale: number
) {
  if (!borders) return;
  drawBorderSide(ctx, x, y, x + w, y, borders.top, scale);
  drawBorderSide(ctx, x + w, y, x + w, y + h, borders.right, scale);
  drawBorderSide(ctx, x, y + h, x + w, y + h, borders.bottom, scale);
  drawBorderSide(ctx, x, y, x, y + h, borders.left, scale);
}

function wrapTextLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  if (!text) return [];
  const paragraphs = text.split('\n');
  const lines: string[] = [];

  for (const para of paragraphs) {
    const words = para.trim().split(/\s+/);
    if (words.length === 0 || (words.length === 1 && words[0] === '')) {
      lines.push('');
      continue;
    }
    let currentLine = words[0];
    for (let i = 1; i < words.length; i++) {
      const candidate = `${currentLine} ${words[i]}`;
      if (ctx.measureText(candidate).width <= Math.max(40, maxWidth)) {
        currentLine = candidate;
      } else {
        lines.push(currentLine);
        currentLine = words[i];
      }
    }
    lines.push(currentLine);
  }
  return lines;
}

function drawAlignedMultilineText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  w: number,
  h: number,
  options: {
    fontFamily: string;
    fontSizePx: number;
    fontWeight: 'normal' | 'bold';
    color: string;
    alignment: TextAlignment;
    direction: TextDirection;
    lineHeightMultiplier: number;
    verticalAlign?: 'top' | 'middle' | 'bottom';
    paddingPx?: number;
  }
) {
  if (!text) return;
  const pad = options.paddingPx ?? 6;
  const innerX = x + pad;
  const innerY = y + pad;
  const innerW = Math.max(10, w - pad * 2);
  const innerH = Math.max(10, h - pad * 2);

  ctx.save();
  ctx.font = `${options.fontWeight === 'bold' ? '700' : '400'} ${Math.round(
    options.fontSizePx
  )}px "${options.fontFamily}", "Cairo", "Amiri", sans-serif`;
  ctx.fillStyle = options.color || '#0F172A';
  ctx.direction = options.direction;
  ctx.textBaseline = 'top';

  const lines = wrapTextLines(ctx, text, innerW);
  const lineH = options.fontSizePx * (options.lineHeightMultiplier || 1.45);
  const totalTextH = lines.length * lineH;

  let startY = innerY;
  if (options.verticalAlign === 'middle') {
    startY = innerY + Math.max(0, (innerH - totalTextH) / 2);
  } else if (options.verticalAlign === 'bottom') {
    startY = innerY + Math.max(0, innerH - totalTextH);
  }

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const ly = startY + i * lineH;
    if (ly + options.fontSizePx * 0.4 > y + h + 8) break;

    if (options.alignment === 'center') {
      ctx.textAlign = 'center';
      ctx.fillText(line, innerX + innerW / 2, ly);
    } else if (options.alignment === 'left') {
      ctx.textAlign = 'left';
      ctx.fillText(line, innerX, ly);
    } else {
      ctx.textAlign = 'right';
      ctx.fillText(line, innerX + innerW, ly);
    }
  }
  ctx.restore();
}

function drawTableObject(
  ctx: CanvasRenderingContext2D,
  obj: PageLayoutObject,
  x: number,
  y: number,
  w: number,
  h: number,
  scale: number
) {
  const table = obj.tableStructure;
  if (!table) return;

  const { rows, cols, rowHeights, colWidths, direction, cells } = table;

  // Normalize rowHeights and colWidths
  const rSum = rowHeights.reduce((a, b) => a + b, 0) || 1;
  const cSum = colWidths.reduce((a, b) => a + b, 0) || 1;
  const normRowH = rowHeights.map((rh) => (rh / rSum) * h);
  const normColW = colWidths.map((cw) => (cw / cSum) * w);

  const rowY: number[] = [y];
  for (let r = 0; r < rows; r++) {
    rowY.push(rowY[r] + (normRowH[r] ?? h / rows));
  }

  // For RTL tables, column 0 is on the RIGHT side of the table
  const getCellRect = (cell: TableCellModel) => {
    const rStart = Math.min(rows - 1, Math.max(0, cell.row));
    const rEnd = Math.min(rows, rStart + Math.max(1, cell.rowSpan || 1));
    const cStart = Math.min(cols - 1, Math.max(0, cell.col));
    const cEnd = Math.min(cols, cStart + Math.max(1, cell.colSpan || 1));

    const cy = rowY[rStart];
    const ch = rowY[rEnd] - cy;

    let cx = x;
    let cw = 0;
    for (let c = cStart; c < cEnd; c++) {
      cw += normColW[c] ?? w / cols;
    }

    if (direction === 'rtl') {
      let offsetFromRight = 0;
      for (let c = 0; c < cEnd; c++) {
        offsetFromRight += normColW[c] ?? w / cols;
      }
      cx = x + w - offsetFromRight;
    } else {
      let offsetFromLeft = 0;
      for (let c = 0; c < cStart; c++) {
        offsetFromLeft += normColW[c] ?? w / cols;
      }
      cx = x + offsetFromLeft;
    }

    return { cx, cy, cw, ch };
  };

  for (const cell of cells) {
    if (cell.hiddenByMerge) continue;
    const { cx, cy, cw, ch } = getCellRect(cell);

    if (cell.backgroundColor && cell.backgroundColor !== 'transparent') {
      ctx.save();
      ctx.fillStyle = cell.backgroundColor;
      ctx.fillRect(cx, cy, cw, ch);
      ctx.restore();
    }

    drawBoxBorders(ctx, cx, cy, cw, ch, cell.borders, scale);

    drawAlignedMultilineText(ctx, cell.content, cx, cy, cw, ch, {
      fontFamily: obj.fontProperties.family,
      fontSizePx: (cell.fontSizePt || obj.fontProperties.sizePt || 11) * 1.33 * scale,
      fontWeight: cell.fontWeight || 'normal',
      color: obj.fontProperties.color || '#0F172A',
      alignment: cell.alignment || 'right',
      direction: cell.direction || direction || 'rtl',
      lineHeightMultiplier: 1.35,
      verticalAlign: cell.verticalAlignment || 'middle',
      paddingPx: (cell.padding || 6) * scale,
    });
  }

  // Outer table border
  drawBoxBorders(ctx, x, y, w, h, obj.borderProperties, scale);
}

function drawStampOrEmblem(
  ctx: CanvasRenderingContext2D,
  obj: PageLayoutObject,
  x: number,
  y: number,
  w: number,
  h: number,
  scale: number
) {
  const cx = x + w / 2;
  const cy = y + h / 2;
  const radius = Math.min(w, h) * 0.45;
  const color = obj.stampColor || '#DC2626';

  ctx.save();
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = 2.2 * scale;

  // Outer circle
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.stroke();

  // Inner circle
  ctx.lineWidth = 1.1 * scale;
  ctx.beginPath();
  ctx.arc(cx, cy, radius * 0.84, 0, Math.PI * 2);
  ctx.stroke();

  // Decorative stars left & right
  ctx.font = `bold ${Math.round(11 * scale)}px "Cairo", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('★', cx - radius * 0.65, cy);
  ctx.fillText('★', cx + radius * 0.65, cy);

  drawAlignedMultilineText(ctx, obj.content, x + w * 0.12, y + h * 0.18, w * 0.76, h * 0.64, {
    fontFamily: obj.fontProperties.family,
    fontSizePx: (obj.fontProperties.sizePt || 9.5) * 1.25 * scale,
    fontWeight: 'bold',
    color,
    alignment: 'center',
    direction: 'rtl',
    lineHeightMultiplier: 1.3,
    verticalAlign: 'middle',
    paddingPx: 2 * scale,
  });

  ctx.restore();
}

function drawSignatureArea(
  ctx: CanvasRenderingContext2D,
  obj: PageLayoutObject,
  x: number,
  y: number,
  w: number,
  h: number,
  scale: number
) {
  drawBoxBorders(ctx, x, y, w, h, obj.borderProperties, scale);

  // Label at top
  drawAlignedMultilineText(ctx, obj.content, x, y, w, h * 0.55, {
    fontFamily: obj.fontProperties.family,
    fontSizePx: (obj.fontProperties.sizePt || 11) * 1.33 * scale,
    fontWeight: obj.fontProperties.weight,
    color: obj.fontProperties.color || '#0F172A',
    alignment: obj.alignment || 'center',
    direction: obj.direction || 'rtl',
    lineHeightMultiplier: 1.4,
    verticalAlign: 'top',
    paddingPx: 6 * scale,
  });

  // Realistic handwritten fountain-pen signature flourish at bottom half
  ctx.save();
  ctx.strokeStyle = '#1E3A8A';
  ctx.lineWidth = 1.8 * scale;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  const sx = x + w * 0.22;
  const sy = y + h * 0.72;
  ctx.beginPath();
  ctx.moveTo(sx, sy);
  ctx.bezierCurveTo(
    sx + w * 0.18,
    sy - h * 0.22,
    sx + w * 0.35,
    sy + h * 0.16,
    sx + w * 0.54,
    sy - h * 0.08
  );
  ctx.bezierCurveTo(
    sx + w * 0.42,
    sy + h * 0.18,
    sx + w * 0.12,
    sy + h * 0.12,
    sx + w * 0.58,
    sy + h * 0.05
  );
  ctx.stroke();
  ctx.restore();
}

export function renderPageToCanvas(
  canvas: HTMLCanvasElement,
  objects: PageLayoutObject[],
  options: RenderOptions
) {
  const { widthPx, heightPx } = options;
  canvas.width = widthPx;
  canvas.height = heightPx;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const scale = widthPx / 1000;

  ctx.save();

  // Base paper fill
  if (options.simulateScannedPhoto) {
    // Desk/scanner dark border if tilted
    ctx.fillStyle = '#CBD5E1';
    ctx.fillRect(0, 0, widthPx, heightPx);

    const rad = (options.simulateScannedPhoto.angleDeg * Math.PI) / 180;
    ctx.translate(widthPx / 2, heightPx / 2);
    ctx.rotate(rad);
    ctx.translate(-widthPx / 2, -heightPx / 2);

    // Warm slightly aged paper gradient
    const paperGrad = ctx.createLinearGradient(0, 0, widthPx, heightPx);
    paperGrad.addColorStop(0, '#FDFBF7');
    paperGrad.addColorStop(0.6, '#F8F5EE');
    paperGrad.addColorStop(1, '#EFECE4');
    ctx.fillStyle = paperGrad;
    ctx.fillRect(14 * scale, 14 * scale, widthPx - 28 * scale, heightPx - 28 * scale);
  } else {
    // Clean reconstructed pure white print page
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, widthPx, heightPx);
  }

  // Sort objects by zOrder
  const sorted = [...objects].sort((a, b) => (a.zOrder || 0) - (b.zOrder || 0));

  for (const obj of sorted) {
    const x = obj.x * scale;
    const y = obj.y * scale;
    const w = obj.width * scale;
    const h = obj.height * scale;

    // Background fill
    if (
      obj.backgroundProperties?.fill &&
      obj.backgroundProperties.fill !== 'transparent' &&
      obj.type !== 'TABLE'
    ) {
      ctx.save();
      ctx.globalAlpha = obj.backgroundProperties.opacity ?? 1;
      ctx.fillStyle = obj.backgroundProperties.fill;
      ctx.fillRect(x, y, w, h);
      ctx.restore();
    }

    if (obj.type === 'LINE') {
      drawBorderSide(ctx, x, y + h / 2, x + w, y + h / 2, obj.borderProperties.top, scale);
    } else if (obj.type === 'TABLE') {
      drawTableObject(ctx, obj, x, y, w, h, scale);
    } else if (obj.type === 'CHECKBOX') {
      const boxSize = Math.min(22 * scale, h * 0.75);
      const boxX = obj.direction === 'rtl' ? x + w - boxSize - 4 * scale : x + 4 * scale;
      const boxY = y + (h - boxSize) / 2;

      ctx.save();
      ctx.strokeStyle = obj.fontProperties.color || '#0F172A';
      ctx.lineWidth = 1.6 * scale;
      ctx.strokeRect(boxX, boxY, boxSize, boxSize);

      if (obj.checked) {
        ctx.beginPath();
        ctx.lineWidth = 2.2 * scale;
        ctx.moveTo(boxX + boxSize * 0.2, boxY + boxSize * 0.52);
        ctx.lineTo(boxX + boxSize * 0.44, boxY + boxSize * 0.76);
        ctx.lineTo(boxX + boxSize * 0.82, boxY + boxSize * 0.24);
        ctx.stroke();
      }
      ctx.restore();

      const textW = w - boxSize - 14 * scale;
      const textX = obj.direction === 'rtl' ? x : x + boxSize + 10 * scale;
      drawAlignedMultilineText(ctx, obj.content, textX, y, textW, h, {
        fontFamily: obj.fontProperties.family,
        fontSizePx: obj.fontProperties.sizePt * 1.33 * scale,
        fontWeight: obj.fontProperties.weight,
        color: obj.fontProperties.color,
        alignment: obj.direction === 'rtl' ? 'right' : 'left',
        direction: obj.direction,
        lineHeightMultiplier: 1.3,
        verticalAlign: 'middle',
        paddingPx: 2 * scale,
      });
    } else if (obj.type === 'IMAGE') {
      drawStampOrEmblem(ctx, obj, x, y, w, h, scale);
    } else if (obj.type === 'SIGNATURE_AREA') {
      drawSignatureArea(ctx, obj, x, y, w, h, scale);
    } else if (obj.type === 'PAGE_BREAK') {
      ctx.save();
      ctx.strokeStyle = '#94A3B8';
      ctx.setLineDash([6 * scale, 4 * scale]);
      ctx.beginPath();
      ctx.moveTo(x, y + h / 2);
      ctx.lineTo(x + w, y + h / 2);
      ctx.stroke();
      ctx.restore();
      drawAlignedMultilineText(ctx, obj.content, x, y, w, h, {
        fontFamily: obj.fontProperties.family,
        fontSizePx: obj.fontProperties.sizePt * 1.25 * scale,
        fontWeight: obj.fontProperties.weight,
        color: obj.fontProperties.color,
        alignment: 'center',
        direction: obj.direction,
        lineHeightMultiplier: 1.2,
        verticalAlign: 'middle',
      });
    } else {
      // TEXT, PARAGRAPH, RECTANGLE
      drawBoxBorders(ctx, x, y, w, h, obj.borderProperties, scale);
      drawAlignedMultilineText(ctx, obj.content, x, y, w, h, {
        fontFamily: obj.fontProperties.family,
        fontSizePx: obj.fontProperties.sizePt * 1.33 * scale,
        fontWeight: obj.fontProperties.weight,
        color: obj.fontProperties.color,
        alignment: obj.alignment,
        direction: obj.direction,
        lineHeightMultiplier: obj.fontProperties.lineHeight || 1.55,
        verticalAlign: obj.type === 'RECTANGLE' ? 'middle' : 'top',
        paddingPx: obj.type === 'RECTANGLE' ? 10 * scale : 4 * scale,
      });
    }

    // Highlight low-confidence regions if enabled (Section 18 — Error Handling / Uncertain Region)
    if (options.highlightLowConfidence && obj.confidence < 0.78 && !obj.userCorrected) {
      ctx.save();
      ctx.strokeStyle = '#D97706';
      ctx.lineWidth = 2 * scale;
      ctx.setLineDash([5 * scale, 3 * scale]);
      ctx.strokeRect(x - 2 * scale, y - 2 * scale, w + 4 * scale, h + 4 * scale);
      ctx.fillStyle = 'rgba(245, 158, 11, 0.10)';
      ctx.fillRect(x, y, w, h);
      ctx.restore();
    }

    // Bounding box inspector overlay
    if (options.showBoundingBoxes || options.highlightSelectedId === obj.id) {
      const isSelected = options.highlightSelectedId === obj.id;
      ctx.save();
      ctx.strokeStyle = isSelected ? '#DC2626' : 'rgba(37, 99, 235, 0.42)';
      ctx.lineWidth = isSelected ? 2.5 * scale : 1 * scale;
      ctx.setLineDash(isSelected ? [] : [4 * scale, 3 * scale]);
      ctx.strokeRect(x, y, w, h);

      if (isSelected) {
        // Resize handles
        const hs = 7 * scale;
        ctx.fillStyle = '#DC2626';
        ctx.fillRect(x - hs / 2, y - hs / 2, hs, hs);
        ctx.fillRect(x + w - hs / 2, y - hs / 2, hs, hs);
        ctx.fillRect(x - hs / 2, y + h - hs / 2, hs, hs);
        ctx.fillRect(x + w - hs / 2, y + h - hs / 2, hs, hs);
      }
      ctx.restore();
    }
  }

  // Apply realistic camera lighting shadow and scanner grain if simulating source photograph
  if (options.simulateScannedPhoto) {
    const { shadowStrength, noiseLevel } = options.simulateScannedPhoto;
    if (shadowStrength > 0) {
      const shadowGrad = ctx.createRadialGradient(
        widthPx * 0.72,
        heightPx * 0.32,
        widthPx * 0.15,
        widthPx * 0.25,
        heightPx * 0.75,
        widthPx * 0.95
      );
      shadowGrad.addColorStop(0, 'rgba(0,0,0,0)');
      shadowGrad.addColorStop(1, `rgba(15, 23, 42, ${(shadowStrength / 100) * 0.34})`);
      ctx.fillStyle = shadowGrad;
      ctx.fillRect(0, 0, widthPx, heightPx);
    }

    if (noiseLevel > 0) {
      const imgData = ctx.getImageData(0, 0, widthPx, heightPx);
      const data = imgData.data;
      const amp = (noiseLevel / 100) * 42;
      for (let i = 0; i < data.length; i += 16) {
        const delta = ((i * 1103515245 + 12345) & 0xff) / 255 - 0.5;
        const n = delta * amp;
        data[i] = Math.min(255, Math.max(0, data[i] + n));
        data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n));
        data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n));
      }
      ctx.putImageData(imgData, 0, 0);
    }
  }

  ctx.restore();
}

export function renderObjectsToDataUrl(
  objects: PageLayoutObject[],
  options: RenderOptions,
  mimeType: 'image/png' | 'image/jpeg' = 'image/png',
  quality = 0.95
): string {
  const canvas = document.createElement('canvas');
  renderPageToCanvas(canvas, objects, options);
  return canvas.toDataURL(mimeType, quality);
}
