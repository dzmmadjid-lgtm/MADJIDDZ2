package com.example.ui.tools

import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.theme.AccentSlate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class DocType {
    NONE,
    PDF,
    TEXT,
    IMAGE,
    OFFICE_DOC
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentViewerScreen(
    onNavigateBack: () -> Unit,
    onNavigateToPdfReader: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("مستند") }
    var detectedDocType by remember { mutableStateOf(DocType.NONE) }
    var textContent by remember { mutableStateOf("") }
    var textFontSize by remember { mutableFloatStateOf(16f) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            coroutineScope.launch {
                var name = "مستند"
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && idx != -1) {
                        name = cursor.getString(idx)
                    }
                }
                fileName = name

                val lower = name.lowercase()
                detectedDocType = when {
                    lower.endsWith(".pdf") -> DocType.PDF
                    lower.endsWith(".txt") || lower.endsWith(".log") || lower.endsWith(".json") || lower.endsWith(".xml") -> DocType.TEXT
                    lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") -> DocType.IMAGE
                    lower.endsWith(".doc") || lower.endsWith(".docx") || lower.endsWith(".xls") || lower.endsWith(".xlsx") || lower.endsWith(".ppt") || lower.endsWith(".pptx") -> DocType.OFFICE_DOC
                    else -> DocType.TEXT
                }

                if (detectedDocType == DocType.TEXT) {
                    withContext(Dispatchers.IO) {
                        try {
                            context.contentResolver.openInputStream(uri)?.use { stream ->
                                textContent = stream.bufferedReader().readText()
                            }
                        } catch (e: Exception) {
                            textContent = "خطأ في قراءة الملف: ${e.localizedMessage}"
                        }
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مستعرض المستندات الشامل", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Picker
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (selectedUri != null) fileName else "اختر ملفاً لعرضه (PDF, TXT, DOCX, صور)",
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            text = when (detectedDocType) {
                                DocType.PDF -> "نوع الملف: PDF"
                                DocType.TEXT -> "نوع الملف: مستند نصي TXT"
                                DocType.IMAGE -> "نوع الملف: صورة"
                                DocType.OFFICE_DOC -> "نوع الملف: مستند مكتبي Office"
                                DocType.NONE -> "يدعم PDF، النصوص، الصور، وملفات Office"
                            },
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = { filePicker.launch(arrayOf("*/*")) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentSlate),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("open_document_viewer_picker_button")
                    ) {
                        Text("فتح مستند")
                    }
                }
            }

            // Body display depending on format
            when (detectedDocType) {
                DocType.NONE -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("اضغط على \"فتح مستند\" لعرض أي ملف.", color = Color.Gray, fontSize = 13.sp)
                        }
                    }
                }

                DocType.PDF -> {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(60.dp))
                            Spacer(modifier = Modifier.height(14.dp))
                            Text("ملف PDF: $fileName", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("افتح المستند في قارئ PDF الاحترافي للتقريب والطباعة وتصفح الصفحات.", fontSize = 12.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(18.dp))
                            Button(onClick = { selectedUri?.let { onNavigateToPdfReader(it) } }) {
                                Icon(Icons.Default.Visibility, null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("فتح في قارئ PDF")
                            }
                        }
                    }
                }

                DocType.TEXT -> {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("مستعرض النصوص الداخلي", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { textFontSize = (textFontSize - 2f).coerceAtLeast(10f) }) {
                                        Icon(Icons.Default.Remove, "تصغير الخط")
                                    }
                                    Text("${textFontSize.toInt()}sp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    IconButton(onClick = { textFontSize = (textFontSize + 2f).coerceAtMost(32f) }) {
                                        Icon(Icons.Default.Add, "تكبير الخط")
                                    }
                                }
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Text(
                                    text = textContent,
                                    fontSize = textFontSize.sp,
                                    lineHeight = (textFontSize * 1.5f).sp
                                )
                            }
                        }
                    }
                }

                DocType.IMAGE -> {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.Black)
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Image(
                                painter = rememberAsyncImagePainter(selectedUri),
                                contentDescription = fileName,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Fit
                            )
                        }
                    }
                }

                DocType.OFFICE_DOC -> {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.Description, contentDescription = null, tint = AccentSlate, modifier = Modifier.size(60.dp))
                            Spacer(modifier = Modifier.height(14.dp))
                            Text("مستند مكتبي: $fileName", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("فتح هذا المستند عبر التطبيقات المتوافقة المثبتة في الهاتف (مثل Google Docs أو Microsoft Word).", fontSize = 12.sp, color = Color.Gray, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            Spacer(modifier = Modifier.height(18.dp))
                            Button(onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(selectedUri, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "لم يتم العثور على تطبيق مناسب لفتح مستندات Word على هذا الجهاز.", Toast.LENGTH_LONG).show()
                                }
                            }) {
                                Icon(Icons.Default.OpenInNew, null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("فتح في تطبيق خارجي")
                            }
                        }
                    }
                }
            }
        }
    }
}
