package com.example.vocalseparator.audio

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Standard RIFF WAVE file writer and exporter for Android.
 * Generates uncompressed 16-bit PCM WAV files and exports them to MediaStore or shares them via FileProvider.
 */
class WavAudioWriter(private val context: Context) {

    /**
     * Initializes a new WAV file with a blank 44-byte header ready for streaming PCM chunks.
     */
    fun openWavStream(outputFile: File, sampleRate: Int, channels: Int = 2): WavStreamWriter {
        return WavStreamWriter(outputFile, sampleRate, channels)
    }

    class WavStreamWriter(
        val file: File,
        private val sampleRate: Int,
        private val channels: Int
    ) {
        private val outputStream = FileOutputStream(file)
        private var totalBytesWritten = 0L

        init {
            // Write placeholder 44-byte header
            outputStream.write(ByteArray(44))
        }

        /**
         * Writes a buffer of interleaved 16-bit PCM shorts (e.g. L, R, L, R...).
         */
        fun writePcmShorts(shorts: ShortArray, offset: Int = 0, length: Int = shorts.size) {
            val byteCount = length * 2
            val bytes = ByteArray(byteCount)
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            for (i in offset until offset + length) {
                bb.putShort(shorts[i])
            }
            outputStream.write(bytes)
            totalBytesWritten += byteCount
        }

        /**
         * Writes a byte array of raw PCM data.
         */
        fun writePcmBytes(bytes: ByteArray, offset: Int = 0, length: Int = bytes.size) {
            outputStream.write(bytes, offset, length)
            totalBytesWritten += length
        }

        /**
         * Finalizes the WAV file by writing the correct RIFF and data chunk headers.
         */
        fun close() {
            outputStream.flush()
            outputStream.close()

            // Update header lengths using RandomAccessFile
            RandomAccessFile(file, "rw").use { raf ->
                raf.seek(0)
                writeWavHeader(raf, totalBytesWritten, sampleRate, channels)
            }
        }

        private fun writeWavHeader(raf: RandomAccessFile, pcmDataLength: Long, sampleRate: Int, channels: Int) {
            val totalDataLen = pcmDataLength + 36
            val byteRate = (sampleRate * channels * 16) / 8
            val blockAlign = (channels * 16) / 8

            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            // "RIFF"
            header.put('R'.code.toByte()).put('I'.code.toByte()).put('F'.code.toByte()).put('F'.code.toByte())
            header.putInt(totalDataLen.toInt())
            // "WAVE"
            header.put('W'.code.toByte()).put('A'.code.toByte()).put('V'.code.toByte()).put('E'.code.toByte())
            // "fmt "
            header.put('f'.code.toByte()).put('m'.code.toByte()).put('t'.code.toByte()).put(' '.code.toByte())
            header.putInt(16) // Subchunk1Size for PCM
            header.putShort(1.toShort()) // AudioFormat 1 = PCM
            header.putShort(channels.toShort())
            header.putInt(sampleRate)
            header.putInt(byteRate)
            header.putShort(blockAlign.toShort())
            header.putShort(16.toShort()) // BitsPerSample
            // "data"
            header.put('d'.code.toByte()).put('a'.code.toByte()).put('t'.code.toByte()).put('a'.code.toByte())
            header.putInt(pcmDataLength.toInt())

            raf.write(header.array())
        }
    }

    /**
     * Exports a processed WAV file to the device's public Music folder using MediaStore.
     * This makes it directly visible and playable in any media player on the phone.
     *
     * @return Uri of the exported file in MediaStore
     */
    suspend fun exportToMediaStore(
        sourceFile: File,
        displayName: String,
        subFolder: String = "VocalRemoverAI"
    ): Uri? = withContext(Dispatchers.IO) {
        val fileName = if (displayName.endsWith(".wav", ignoreCase = true)) displayName else "$displayName.wav"

        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
            put(MediaStore.Audio.Media.TITLE, displayName.substringBeforeLast('.'))
            put(MediaStore.Audio.Media.IS_MUSIC, 1)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/$subFolder")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
        }

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        var resultUri: Uri? = null
        try {
            val resolver = context.contentResolver
            resultUri = resolver.insert(collection, values)
            if (resultUri != null) {
                resolver.openOutputStream(resultUri)?.use { out ->
                    FileInputStream(sourceFile).use { input ->
                        input.copyTo(out)
                    }
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                    resolver.update(resultUri, values, null, null)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error exporting WAV to MediaStore", e)
            resultUri = null
        }

        resultUri
    }

    /**
     * Gets a sharable Uri for a private WAV file via FileProvider.
     */
    fun getSharableUri(file: File): Uri {
        val authority = "${context.packageName}.fileprovider"
        return FileProvider.getUriForFile(context, authority, file)
    }

    companion object {
        private const val TAG = "WavAudioWriter"
    }
}
