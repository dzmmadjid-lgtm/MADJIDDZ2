package com.example.data

import kotlinx.coroutines.flow.Flow

class PdfRepository(private val pdfDao: PdfDao) {
    val allPdfs: Flow<List<PdfDocumentEntity>> = pdfDao.getAllPdfs()

    suspend fun getAllPdfsDirect(): List<PdfDocumentEntity> = pdfDao.getAllPdfsDirect()

    fun getPdfsByCategory(category: String): Flow<List<PdfDocumentEntity>> = pdfDao.getPdfsByCategory(category)

    suspend fun insertPdf(pdf: PdfDocumentEntity): Long = pdfDao.insertPdf(pdf)

    suspend fun updatePdf(pdf: PdfDocumentEntity) = pdfDao.updatePdf(pdf)

    suspend fun deletePdfById(id: Long) = pdfDao.deletePdfById(id)

    suspend fun getPdfById(id: Long): PdfDocumentEntity? = pdfDao.getPdfById(id)
    suspend fun deleteAllPdfs() = pdfDao.deleteAllPdfs()
}
