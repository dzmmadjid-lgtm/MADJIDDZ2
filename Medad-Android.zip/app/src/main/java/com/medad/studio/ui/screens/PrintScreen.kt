package com.medad.studio.ui.screens

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.medad.studio.print.WifiPrint
import com.medad.studio.print.WifiPrinter
import com.medad.studio.ui.components.GhostButton
import com.medad.studio.ui.components.GoldButton
import com.medad.studio.ui.components.GoldChip
import com.medad.studio.ui.components.IconOrb
import com.medad.studio.ui.components.MedadCard
import com.medad.studio.ui.theme.LocalPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

@Composable
fun PrintScreen(onBack: () -> Unit) {
    val p = LocalPalette.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var uri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("اختر مستنداً ثم اطبع") }
    var sending by remember { mutableStateOf(false) }
    var scanToken by remember { mutableIntStateOf(0) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.NEARBY_WIFI_DEVICES,
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!granted) permissionLauncher.launch(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
    }

    val printers by remember(scanToken) {
        WifiPrint.discover(context)
    }.collectAsState(initial = emptyList())

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        uri = picked
        if (picked != null) status = "المستند جاهز للطباعة"
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(p.canvas)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, "رجوع", tint = p.ink)
            }
            Column(Modifier.weight(1f)) {
                Text("الطباعة", color = p.ink, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Text(status, color = p.muted, fontSize = 12.sp)
            }
            IconButton(onClick = { scanToken += 1 }) {
                Icon(Icons.Outlined.Refresh, "تحديث", tint = p.gold)
            }
        }

        Spacer(Modifier.height(8.dp))
        GoldChip("PRINT · SYSTEM & WIFI")
        Spacer(Modifier.height(16.dp))

        MedadCard {
            Text("طباعة عادية", color = p.ink, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "تفتح ورقة أندرويد الرسمية: الطابعات المحفوظة، حفظ كـ PDF، ومعاينة الصفحات.",
                color = p.muted,
                fontSize = 13.sp,
                lineHeight = 20.sp,
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GoldButton("اختيار PDF", Icons.Outlined.FolderOpen) {
                    picker.launch(arrayOf("application/pdf"))
                }
                GhostButton("طباعة", Icons.Outlined.Print) {
                    val current = uri
                    if (current == null) {
                        status = "اختر ملفاً أولاً"
                    } else {
                        WifiPrint.systemPrint(context, "مداد", current)
                        status = "أُرسل إلى نظام الطباعة"
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        MedadCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconOrb(Icons.Outlined.Wifi, gold = true)
                Column(Modifier.padding(start = 14.dp)) {
                    Text("طباعة واي فاي مباشرة", color = p.ink, fontWeight = FontWeight.SemiBold)
                    Text("اكتشاف IPP / AirPrint على الشبكة المحلية", color = p.muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            if (printers.isEmpty()) {
                Text(
                    "لا طابعات ظاهرة الآن. تأكد أن الهاتف والطابعة على نفس الشبكة، وأن الاكتشاف مفعّل.",
                    color = p.muted,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                )
            } else {
                printers.forEach { printer ->
                    PrinterRow(
                        printer = printer,
                        enabled = uri != null && !sending,
                        onPrint = {
                            val current = uri ?: return@PrinterRow
                            sending = true
                            status = "إرسال إلى ${printer.name}…"
                            scope.launch {
                                val ok = sendIpp(context, printer, current)
                                status = if (ok) "أُرسلت المهمة إلى ${printer.name}" else "تعذر الإرسال المباشر، جرّب الطباعة العادية"
                                sending = false
                            }
                        },
                    )
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun PrinterRow(
    printer: WifiPrinter,
    enabled: Boolean,
    onPrint: () -> Unit,
) {
    val p = LocalPalette.current
    MedadCard(onClick = if (enabled) onPrint else null) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(printer.name, color = p.ink, fontWeight = FontWeight.Medium)
                Text("${printer.host}:${printer.port}", color = p.muted, fontSize = 12.sp)
            }
            Text(if (enabled) "إرسال" else "اختر ملفاً", color = p.gold, fontSize = 12.sp, letterSpacing = 1.sp)
        }
    }
}

private suspend fun sendIpp(context: android.content.Context, printer: WifiPrinter, uri: Uri): Boolean =
    withContext(Dispatchers.IO) {
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@withContext false
            val paths = listOf("/ipp/print", "/ipp/printer", "/")
            for (path in paths) {
                val url = URL("http://${printer.host}:${printer.port}$path")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 20000
                    setRequestProperty("Content-Type", "application/ipp")
                }
                val code = try {
                    conn.outputStream.use { it.write(buildIppPrintJob(bytes)) }
                    conn.responseCode
                } catch (_: Exception) {
                    conn.disconnect()
                    continue
                }
                conn.disconnect()
                if (code in 200..299) return@withContext true
            }
            false
        } catch (_: Exception) {
            false
        }
    }

private fun buildIppPrintJob(pdf: ByteArray): ByteArray {
    val header = byteArrayOf(
        0x01, 0x01,
        0x00, 0x02,
        0x00, 0x00, 0x00, 0x01,
        0x01,
        0x47, 0x00, 0x12,
    )
    val attr = "attributes-charset".toByteArray()
    val utf = "utf-8".toByteArray()
    val op = "attributes-natural-language".toByteArray()
    val ar = "ar".toByteArray()
    val mimeName = "document-format".toByteArray()
    val mime = "application/pdf".toByteArray()
    fun u16(n: Int) = byteArrayOf(((n shr 8) and 0xFF).toByte(), (n and 0xFF).toByte())
    val body = header +
        u16(attr.size) + attr + u16(utf.size) + utf +
        byteArrayOf(0x48) + u16(op.size) + op + u16(ar.size) + ar +
        byteArrayOf(0x49) + u16(mimeName.size) + mimeName + u16(mime.size) + mime +
        byteArrayOf(0x03) + pdf
    return body
}
