package com.example.ui.tools

import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.theme.AccentIndigo
import com.example.utils.PdfEngine
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SplitPdfScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var documentName by remember { mutableStateOf("مستند PDF") }
    var totalPages by remember { mutableIntStateOf(0) }

    var fromPage by remember { mutableIntStateOf(1) }
    var toPage by remember { mutableIntStateOf(1) }
    var isSplitting by remember { mutableStateOf(false) }
    var splitResultFile by remember { mutableStateOf<File?>(null) }

    val pdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            pdfUri = uri
            coroutineScope.launch {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && idx != -1) {
                        documentName = cursor.getString(idx)
                    }
                }
                totalPages = PdfEngine.getPageCount(context, uri)
                fromPage = 1
                toPage = totalPages.coerceAtLeast(1)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تقسيم واستخراج PDF", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Document Selection
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (pdfUri != null) documentName else "اختر مستند PDF للتقسيم",
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        if (totalPages > 0) {
                            Text("إجمالي عدد الصفحات: $totalPages", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Button(
                        onClick = { pdfPicker.launch(arrayOf("application/pdf")) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentIndigo),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("select_pdf_for_split_button")
                    ) {
                        Text("اختيار ملف")
                    }
                }
            }

            if (pdfUri != null && totalPages > 0) {
                // Range Selector Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("حدد نطاق الصفحات للاستخراج", fontWeight = FontWeight.Bold)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = fromPage.toString(),
                                onValueChange = { fromPage = it.toIntOrNull()?.coerceIn(1, totalPages) ?: 1 },
                                label = { Text("من صفحة") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )

                            OutlinedTextField(
                                value = toPage.toString(),
                                onValueChange = { toPage = it.toIntOrNull()?.coerceIn(fromPage, totalPages) ?: fromPage },
                                label = { Text("إلى صفحة") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Range summary
                        val extractedCount = (toPage - fromPage + 1).coerceAtLeast(0)
                        Text(
                            text = "سيتم استخراج $extractedCount صفحة (من $fromPage حتى $toPage)",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Split Action Button
                Button(
                    onClick = {
                        isSplitting = true
                        coroutineScope.launch {
                            val outFile = File(context.cacheDir, "مستخرج_صفحات_${fromPage}_إلى_${toPage}.pdf")
                            val success = PdfEngine.extractPageRange(
                                context = context,
                                inputUri = pdfUri!!,
                                fromPage = fromPage,
                                toPage = toPage,
                                outputFile = outFile
                            )
                            isSplitting = false
                            if (success && outFile.exists() && outFile.length() > 0) {
                                splitResultFile = outFile
                                Toast.makeText(context, "تم استخراج الصفحات بنجاح!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "فشل استخراج الصفحات.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    enabled = !isSplitting && fromPage <= toPage,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentIndigo),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("split_pdf_button")
                ) {
                    if (isSplitting) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جاري استخراج النطاق...")
                    } else {
                        Icon(Icons.Default.CallSplit, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("استخراج النطاق المحدد", fontWeight = FontWeight.Bold)
                    }
                }

                // Result card
                if (splitResultFile != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("تم إنشاء الملف الجديد بنجاح:", fontWeight = FontWeight.Bold)
                            Text(splitResultFile!!.name, style = MaterialTheme.typography.bodySmall)

                            Button(
                                onClick = {
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        splitResultFile!!
                                    )
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة الملف المستخرج"))
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("مشاركة الملف المستخرج")
                            }
                        }
                    }
                }
            }
        }
    }
}
