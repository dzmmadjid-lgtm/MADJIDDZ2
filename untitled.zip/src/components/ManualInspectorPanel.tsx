import React, { useState } from 'react';
import {
  ArabicFontFamily,
  LayoutObjectType,
  PageLayoutObject,
  TableCellModel,
  TextAlignment,
  TextDirection,
  ThemeMode,
  createDefaultBorder,
} from '../models/DocumentModel';
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  CheckCircle2,
  Columns,
  Plus,
  Rows,
  SplitSquareVertical,
  Trash2,
} from 'lucide-react';

interface ManualInspectorPanelProps {
  theme: ThemeMode;
  objects: PageLayoutObject[];
  selectedObjectId: string | null;
  onSelectObject: (id: string | null) => void;
  onUpdateObject: (updated: PageLayoutObject) => void;
  onAddObject: (newObj: PageLayoutObject) => void;
  onDeleteObject: (id: string) => void;
}

export const ManualInspectorPanel: React.FC<ManualInspectorPanelProps> = ({
  theme,
  objects,
  selectedObjectId,
  onSelectObject,
  onUpdateObject,
  onAddObject,
  onDeleteObject,
}) => {
  const [selectedCellIdx, setSelectedCellIdx] = useState<number>(0);

  const selectedObj = objects.find((o) => o.id === selectedObjectId) || null;

  const surfaceClass =
    theme === 'oled'
      ? 'bg-[#080808] border-[#1F1F1F] text-white'
      : theme === 'night'
      ? 'bg-slate-900 border-slate-800 text-slate-100'
      : 'bg-white border-slate-200 text-slate-900';

  const inputClass =
    theme === 'oled'
      ? 'bg-black border-[#262626] text-white focus:border-red-600'
      : theme === 'night'
      ? 'bg-slate-950 border-slate-700 text-slate-100 focus:border-red-500'
      : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-red-600';

  const mutedText =
    theme === 'oled' ? 'text-neutral-400' : theme === 'night' ? 'text-slate-400' : 'text-slate-500';

  const handleCreateObject = (type: LayoutObjectType) => {
    const id = `manual_${Date.now().toString(36)}`;
    const baseObj: PageLayoutObject = {
      id,
      type,
      x: 100,
      y: 150,
      width: type === 'CHECKBOX' ? 280 : 600,
      height: type === 'LINE' ? 6 : type === 'TABLE' ? 220 : 75,
      content:
        type === 'TABLE'
          ? ''
          : type === 'CHECKBOX'
          ? 'خيار جديد قابل للتحديد'
          : 'نص جديد — عدّل المحتوى والموقع حسب الورقة الأصلية',
      confidence: 1.0,
      uncertainTokens: [],
      userCorrected: true,
      alignment: 'right',
      direction: 'rtl',
      fontProperties: {
        family: 'Cairo',
        sizePt: 12,
        weight: 'normal',
        role: 'normal',
        color: '#0F172A',
        lineHeight: 1.5,
      },
      borderProperties:
        type === 'RECTANGLE' || type === 'TABLE' || type === 'LINE'
          ? createDefaultBorder(1.5, 'solid', '#0F172A')
          : createDefaultBorder(0),
      backgroundProperties: { fill: 'transparent', opacity: 1 },
      zOrder: objects.length + 1,
      checked: type === 'CHECKBOX' ? true : undefined,
      tableStructure:
        type === 'TABLE'
          ? {
              rows: 2,
              cols: 3,
              rowHeights: [0.5, 0.5],
              colWidths: [0.34, 0.33, 0.33],
              direction: 'rtl',
              cells: [0, 1].flatMap((r) =>
                [0, 1, 2].map((c) => ({
                  id: `cell_${r}_${c}`,
                  row: r,
                  col: c,
                  rowSpan: 1,
                  colSpan: 1,
                  content: r === 0 ? `عنوان ${c + 1}` : `بيان ${r}-${c + 1}`,
                  confidence: 1,
                  alignment: 'center' as TextAlignment,
                  verticalAlignment: 'middle' as const,
                  direction: 'rtl' as TextDirection,
                  padding: 6,
                  fontSizePt: 11,
                  fontWeight: r === 0 ? ('bold' as const) : ('normal' as const),
                  borders: createDefaultBorder(1, 'solid', '#0F172A'),
                  backgroundColor: r === 0 ? '#F1F5F9' : 'transparent',
                }))
              ),
            }
          : undefined,
    };
    onAddObject(baseObj);
    onSelectObject(id);
  };

  const handleMergeCellRight = (cell: TableCellModel) => {
    if (!selectedObj?.tableStructure) return;
    const tbl = selectedObj.tableStructure;
    const nextCol = cell.col + cell.colSpan;
    if (nextCol >= tbl.cols) return;

    const updatedCells = tbl.cells.map((c) => {
      if (c.row === cell.row && c.col === cell.col) {
        return { ...c, colSpan: c.colSpan + 1 };
      }
      if (
        c.row >= cell.row &&
        c.row < cell.row + cell.rowSpan &&
        c.col === nextCol
      ) {
        return { ...c, hiddenByMerge: true };
      }
      return c;
    });

    onUpdateObject({
      ...selectedObj,
      tableStructure: { ...tbl, cells: updatedCells },
    });
  };

  const handleMergeCellDown = (cell: TableCellModel) => {
    if (!selectedObj?.tableStructure) return;
    const tbl = selectedObj.tableStructure;
    const nextRow = cell.row + cell.rowSpan;
    if (nextRow >= tbl.rows) return;

    const updatedCells = tbl.cells.map((c) => {
      if (c.row === cell.row && c.col === cell.col) {
        return { ...c, rowSpan: c.rowSpan + 1 };
      }
      if (
        c.col >= cell.col &&
        c.col < cell.col + cell.colSpan &&
        c.row === nextRow
      ) {
        return { ...c, hiddenByMerge: true };
      }
      return c;
    });

    onUpdateObject({
      ...selectedObj,
      tableStructure: { ...tbl, cells: updatedCells },
    });
  };

  const handleSplitMergedCell = (cell: TableCellModel) => {
    if (!selectedObj?.tableStructure) return;
    const tbl = selectedObj.tableStructure;
    const updatedCells = tbl.cells.map((c) => {
      if (
        c.row >= cell.row &&
        c.row < cell.row + cell.rowSpan &&
        c.col >= cell.col &&
        c.col < cell.col + cell.colSpan
      ) {
        return { ...c, rowSpan: 1, colSpan: 1, hiddenByMerge: false };
      }
      return c;
    });

    onUpdateObject({
      ...selectedObj,
      tableStructure: { ...tbl, cells: updatedCells },
    });
  };

  return (
    <div className={`border rounded-lg p-4 space-y-4 ${surfaceClass}`}>
      <div className="flex items-center justify-between border-b pb-3 border-current/10">
        <div>
          <h3 className="text-sm font-semibold">أدوات الضبط اليدوي الدقيق (Coordinate Inspector)</h3>
          <p className={`text-xs ${mutedText}`}>
            تعديل أي عنصر دون التأثير الصامت على بقية عناصر الصفحة
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => handleCreateObject('PARAGRAPH')}
            className="px-2.5 py-1.5 text-xs font-medium rounded bg-red-600 text-white hover:bg-red-700 transition-colors flex items-center gap-1 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>فقرة</span>
          </button>
          <button
            type="button"
            onClick={() => handleCreateObject('TABLE')}
            className="px-2.5 py-1.5 text-xs font-medium rounded border border-current/20 hover:bg-current/5 transition-colors flex items-center gap-1 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>جدول</span>
          </button>
        </div>
      </div>

      {/* Object Selector List */}
      <div className="space-y-1.5">
        <label className={`block text-xs font-medium ${mutedText}`}>
          عناصر الصفحة المكتشفة ({objects.length})
        </label>
        <div className="max-h-36 overflow-y-auto space-y-1 pr-1">
          {objects.map((obj) => {
            const isSelected = obj.id === selectedObjectId;
            const isLowConf = obj.confidence < 0.78 && !obj.userCorrected;
            return (
              <button
                key={obj.id}
                type="button"
                onClick={() => {
                  onSelectObject(obj.id);
                  setSelectedCellIdx(0);
                }}
                className={`w-full text-right px-3 py-2 rounded text-xs flex items-center justify-between transition-colors border ${
                  isSelected
                    ? 'border-red-600 bg-red-600/10 font-semibold'
                    : isLowConf
                    ? 'border-amber-500/60 bg-amber-500/10'
                    : 'border-transparent hover:bg-current/5'
                }`}
              >
                <span className="truncate max-w-[180px]">
                  {obj.type} ·{' '}
                  {obj.content
                    ? obj.content.slice(0, 32)
                    : obj.type === 'TABLE'
                    ? `جدول (${obj.tableStructure?.rows}×${obj.tableStructure?.cols})`
                    : obj.id}
                </span>
                <span className="font-mono tabular-nums text-[11px] opacity-80 shrink-0">
                  {isLowConf ? '⚠️ مراجعة' : `${Math.round(obj.confidence * 100)}%`}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {!selectedObj ? (
        <div className={`py-6 text-center text-xs ${mutedText}`}>
          انقر على أي عنصر فوق الورقة المعاد بناؤها أو من القائمة أعلاه لتعديل إحداثياته أو نصه أو خلايا الجدول.
        </div>
      ) : (
        <div className="space-y-4 pt-2 border-t border-current/10">
          {/* Low-confidence warning banner if needed */}
          {selectedObj.confidence < 0.78 && !selectedObj.userCorrected && (
            <div className="p-3 rounded border border-amber-500/50 bg-amber-500/10 text-xs space-y-2">
              <div className="font-semibold text-amber-500">
                منطقة منخفضة الثقة ({Math.round(selectedObj.confidence * 100)}%) — لم يتم تخمين النص
              </div>
              <p className={mutedText}>
                تحقق من النص مقارنةً بالصورة المصدرية ثم اضغط تأكيد لاعتماده.
              </p>
              <button
                type="button"
                onClick={() =>
                  onUpdateObject({
                    ...selectedObj,
                    userCorrected: true,
                    confidence: 1.0,
                  })
                }
                className="px-3 py-1.5 rounded bg-amber-600 text-white text-xs font-medium flex items-center gap-1.5 hover:bg-amber-700"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>تأكيد صحة النص بعد المراجعة</span>
              </button>
            </div>
          )}

          {/* Coordinates X, Y, Width, Height (0..1000) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className={`text-xs font-medium ${mutedText}`}>
                الإحداثيات الهندسية (0..1000)
              </span>
              <button
                type="button"
                onClick={() => onDeleteObject(selectedObj.id)}
                className="text-xs text-red-500 hover:text-red-400 flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>حذف العنصر</span>
              </button>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {(['x', 'y', 'width', 'height'] as const).map((coord) => (
                <div key={coord}>
                  <label className={`block text-[10px] font-mono uppercase ${mutedText}`}>
                    {coord}
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={1000}
                    value={Math.round(selectedObj[coord])}
                    onChange={(e) =>
                      onUpdateObject({
                        ...selectedObj,
                        [coord]: Math.max(4, Math.min(1000, Number(e.target.value) || 0)),
                      })
                    }
                    className={`w-full px-2 py-1 text-xs font-mono tabular-nums rounded border ${inputClass}`}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Text content editor for non-table objects */}
          {selectedObj.type !== 'TABLE' && selectedObj.type !== 'LINE' && (
            <div className="space-y-1.5">
              <label className={`block text-xs font-medium ${mutedText}`}>
                النص المستخرج (تحرير مباشر دون المساس ببقية العناصر)
              </label>
              <textarea
                rows={3}
                dir={selectedObj.direction}
                value={selectedObj.content}
                onChange={(e) =>
                  onUpdateObject({
                    ...selectedObj,
                    content: e.target.value,
                    userCorrected: true,
                  })
                }
                className={`w-full p-2 text-xs rounded border ${inputClass}`}
              />
            </div>
          )}

          {/* Font, Size, Alignment & Direction controls */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className={`block text-[11px] mb-1 ${mutedText}`}>الخط العربي</label>
              <select
                value={selectedObj.fontProperties.family}
                onChange={(e) =>
                  onUpdateObject({
                    ...selectedObj,
                    fontProperties: {
                      ...selectedObj.fontProperties,
                      family: e.target.value as ArabicFontFamily,
                    },
                  })
                }
                className={`w-full px-2 py-1.5 text-xs rounded border ${inputClass}`}
              >
                <option value="Amiri">Amiri (أميري مطبعي رسمي)</option>
                <option value="Cairo">Cairo (القاهرة هندسي)</option>
                <option value="Tajawal">Tajawal (تجول واضح)</option>
                <option value="IBM Plex Sans Arabic">IBM Plex Sans Arabic</option>
              </select>
            </div>
            <div>
              <label className={`block text-[11px] mb-1 ${mutedText}`}>حجم الخط (pt)</label>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min={7}
                  max={36}
                  step={0.5}
                  value={selectedObj.fontProperties.sizePt}
                  onChange={(e) =>
                    onUpdateObject({
                      ...selectedObj,
                      fontProperties: {
                        ...selectedObj.fontProperties,
                        sizePt: Number(e.target.value) || 12,
                      },
                    })
                  }
                  className={`w-full px-2 py-1.5 text-xs font-mono tabular-nums rounded border ${inputClass}`}
                />
                <button
                  type="button"
                  onClick={() =>
                    onUpdateObject({
                      ...selectedObj,
                      fontProperties: {
                        ...selectedObj.fontProperties,
                        weight: selectedObj.fontProperties.weight === 'bold' ? 'normal' : 'bold',
                      },
                    })
                  }
                  className={`px-2.5 py-1.5 text-xs font-bold rounded border ${
                    selectedObj.fontProperties.weight === 'bold'
                      ? 'bg-red-600 text-white border-red-600'
                      : 'border-current/20'
                  }`}
                >
                  B
                </button>
              </div>
            </div>
          </div>

          {/* Alignment & Direction */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1">
              {(
                [
                  { align: 'right', icon: AlignRight, label: 'يمين' },
                  { align: 'center', icon: AlignCenter, label: 'وسط' },
                  { align: 'left', icon: AlignLeft, label: 'يسار' },
                ] as const
              ).map(({ align, icon: Icon, label }) => (
                <button
                  key={align}
                  type="button"
                  onClick={() => onUpdateObject({ ...selectedObj, alignment: align })}
                  className={`px-2.5 py-1.5 text-xs rounded border flex items-center gap-1 ${
                    selectedObj.alignment === align
                      ? 'bg-red-600 text-white border-red-600'
                      : 'border-current/20 hover:bg-current/5'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{label}</span>
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1">
              {(['rtl', 'ltr'] as const).map((dir) => (
                <button
                  key={dir}
                  type="button"
                  onClick={() => onUpdateObject({ ...selectedObj, direction: dir })}
                  className={`px-2.5 py-1.5 text-xs font-mono uppercase rounded border ${
                    selectedObj.direction === dir
                      ? 'bg-red-600 text-white border-red-600'
                      : 'border-current/20 hover:bg-current/5'
                  }`}
                >
                  {dir}
                </button>
              ))}
            </div>
          </div>

          {/* Structured Table Editor (Section 6 & 14) */}
          {selectedObj.type === 'TABLE' && selectedObj.tableStructure && (
            <div className="space-y-3 pt-3 border-t border-current/10">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold">
                  محرر الجدول المهيكل ({selectedObj.tableStructure.rows} صفوف ×{' '}
                  {selectedObj.tableStructure.cols} أعمدة)
                </h4>
              </div>

              {/* Interactive visual cell selector grid */}
              <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${selectedObj.tableStructure.cols}, minmax(0, 1fr))` }}>
                {selectedObj.tableStructure.cells.map((cell, idx) => {
                  if (cell.hiddenByMerge) return null;
                  const isCellActive = idx === selectedCellIdx;
                  return (
                    <button
                      key={cell.id || idx}
                      type="button"
                      onClick={() => setSelectedCellIdx(idx)}
                      style={{
                        gridColumn: `span ${cell.colSpan || 1}`,
                        gridRow: `span ${cell.rowSpan || 1}`,
                      }}
                      className={`p-1.5 text-[11px] rounded border truncate text-right transition-colors ${
                        isCellActive
                          ? 'border-red-600 bg-red-600/15 font-semibold'
                          : 'border-current/20 hover:bg-current/5'
                      }`}
                    >
                      {cell.content || `(${cell.row + 1},${cell.col + 1})`}
                    </button>
                  );
                })}
              </div>

              {/* Active Cell Properties */}
              {selectedObj.tableStructure.cells[selectedCellIdx] && (() => {
                const activeCell = selectedObj.tableStructure.cells[selectedCellIdx];
                return (
                  <div className="space-y-2.5 p-2.5 rounded border border-current/15 bg-current/[0.02]">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold">
                        خلية ({activeCell.row + 1}، {activeCell.col + 1}) · دمج:{' '}
                        {activeCell.rowSpan}×{activeCell.colSpan}
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleMergeCellRight(activeCell)}
                          title="دمج مع الخلية المجاورة أفقياً"
                          className="px-2 py-1 text-[11px] rounded border border-current/20 hover:bg-current/10 flex items-center gap-1"
                        >
                          <Columns className="w-3 h-3" />
                          <span>دمج أفقي</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleMergeCellDown(activeCell)}
                          title="دمج مع الخلية السفلية عمودياً"
                          className="px-2 py-1 text-[11px] rounded border border-current/20 hover:bg-current/10 flex items-center gap-1"
                        >
                          <Rows className="w-3 h-3" />
                          <span>دمج عمودي</span>
                        </button>
                        {(activeCell.colSpan > 1 || activeCell.rowSpan > 1) && (
                          <button
                            type="button"
                            onClick={() => handleSplitMergedCell(activeCell)}
                            className="px-2 py-1 text-[11px] rounded bg-red-600 text-white flex items-center gap-1"
                          >
                            <SplitSquareVertical className="w-3 h-3" />
                            <span>فك الدمج</span>
                          </button>
                        )}
                      </div>
                    </div>

                    <input
                      type="text"
                      value={activeCell.content}
                      onChange={(e) => {
                        const nextCells = selectedObj.tableStructure!.cells.map((c, i) =>
                          i === selectedCellIdx
                            ? { ...c, content: e.target.value, confidence: 1 }
                            : c
                        );
                        onUpdateObject({
                          ...selectedObj,
                          tableStructure: { ...selectedObj.tableStructure!, cells: nextCells },
                        });
                      }}
                      className={`w-full px-2.5 py-1.5 text-xs rounded border ${inputClass}`}
                      placeholder="نص الخلية..."
                    />

                    {/* Column Width & Row Height Sliders */}
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div>
                        <label className={`block text-[10px] ${mutedText}`}>
                          عرض العمود ({activeCell.col + 1})
                        </label>
                        <input
                          type="range"
                          min={0.08}
                          max={0.65}
                          step={0.02}
                          value={selectedObj.tableStructure.colWidths[activeCell.col] ?? 0.25}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            const nextColW = [...selectedObj.tableStructure!.colWidths];
                            nextColW[activeCell.col] = val;
                            onUpdateObject({
                              ...selectedObj,
                              tableStructure: {
                                ...selectedObj.tableStructure!,
                                colWidths: nextColW,
                              },
                            });
                          }}
                          className="w-full accent-red-600"
                        />
                      </div>
                      <div>
                        <label className={`block text-[10px] ${mutedText}`}>
                          ارتفاع الصف ({activeCell.row + 1})
                        </label>
                        <input
                          type="range"
                          min={0.08}
                          max={0.55}
                          step={0.02}
                          value={selectedObj.tableStructure.rowHeights[activeCell.row] ?? 0.2}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            const nextRowH = [...selectedObj.tableStructure!.rowHeights];
                            nextRowH[activeCell.row] = val;
                            onUpdateObject({
                              ...selectedObj,
                              tableStructure: {
                                ...selectedObj.tableStructure!,
                                rowHeights: nextRowH,
                              },
                            });
                          }}
                          className="w-full accent-red-600"
                        />
                      </div>
                    </div>

                    {/* Individual Cell Borders Toggle (Preserve or remove missing borders) */}
                    <div className="flex items-center justify-between pt-1">
                      <span className={`text-[11px] ${mutedText}`}>حدود الخلية:</span>
                      <div className="flex items-center gap-1">
                        {(
                          [
                            { side: 'top', label: 'أعلى' },
                            { side: 'right', label: 'يمين' },
                            { side: 'bottom', label: 'أسفل' },
                            { side: 'left', label: 'يسار' },
                          ] as const
                        ).map(({ side, label }) => {
                          const hasBorder = activeCell.borders[side].width > 0;
                          return (
                            <button
                              key={side}
                              type="button"
                              onClick={() => {
                                const nextBorders = {
                                  ...activeCell.borders,
                                  [side]: {
                                    width: hasBorder ? 0 : 1,
                                    style: hasBorder ? ('none' as const) : ('solid' as const),
                                    color: '#0F172A',
                                  },
                                };
                                const nextCells = selectedObj.tableStructure!.cells.map((c, i) =>
                                  i === selectedCellIdx ? { ...c, borders: nextBorders } : c
                                );
                                onUpdateObject({
                                  ...selectedObj,
                                  tableStructure: {
                                    ...selectedObj.tableStructure!,
                                    cells: nextCells,
                                  },
                                });
                              }}
                              className={`px-2 py-0.5 text-[10px] rounded border ${
                                hasBorder
                                  ? 'bg-red-600 text-white border-red-600'
                                  : 'border-current/20 opacity-60'
                              }`}
                            >
                              {label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
