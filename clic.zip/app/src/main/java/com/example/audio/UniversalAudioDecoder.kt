package com.example.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Universal offline audio decoder using Android's built-in MediaExtractor & MediaCodec.
 * Can decode any supported Android audio format (MP3, M4A, AAC, WAV, FLAC, OGG) to 44.1 kHz StereoAudio.
 */
object UniversalAudioDecoder {

    private const val TAG = "UniversalAudioDecoder"

    fun decodeUriToStereoAudio(context: Context, uri: Uri): StereoAudio {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            return decodeExtractor(extractor)
        } catch (e: Exception) {
            Log.e(TAG, "MediaExtractor failed on Uri, trying file fallback: ${e.message}")
            // Fallback: Copy to temporary cache file
            val tempFile = File(context.cacheDir, "decode_temp_${System.currentTimeMillis()}.bin")
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    tempFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
                return decodeFileToStereoAudio(tempFile)
            } finally {
                tempFile.delete()
            }
        } finally {
            try { extractor.release() } catch (ignored: Exception) {}
        }
    }

    fun decodeFileToStereoAudio(file: File): StereoAudio {
        // Fast path for 16-bit PCM WAV
        try {
            return WavAudioUtil.readWavFile(file)
        } catch (e: Exception) {
            Log.d(TAG, "Not a raw PCM WAV, falling back to MediaCodec decoder: ${e.message}")
        }

        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(file.absolutePath)
            return decodeExtractor(extractor)
        } finally {
            try { extractor.release() } catch (ignored: Exception) {}
        }
    }

    private fun decodeExtractor(extractor: MediaExtractor): StereoAudio {
        var audioTrackIndex = -1
        var audioFormat: MediaFormat? = null

        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                audioTrackIndex = i
                audioFormat = format
                break
            }
        }

        require(audioTrackIndex != -1 && audioFormat != null) {
            "لم يتم العثور على مسار صوتي صالح في الملف"
        }

        extractor.selectTrack(audioTrackIndex)

        val mime = audioFormat.getString(MediaFormat.KEY_MIME)!!
        val sampleRate = if (audioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
            audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        } else {
            44100
        }
        val channelCount = if (audioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
            audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        } else {
            2
        }

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(audioFormat, null, null, 0)
        codec.start()

        val pcmOutStream = ByteArrayOutputStream(1024 * 1024)
        val bufferInfo = MediaCodec.BufferInfo()
        var sawInputEOS = false
        var sawOutputEOS = false
        val timeoutUs = 5000L

        try {
            while (!sawOutputEOS) {
                if (!sawInputEOS) {
                    val inputBufferIndex = codec.dequeueInputBuffer(timeoutUs)
                    if (inputBufferIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputBufferIndex) ?: continue
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(
                                inputBufferIndex, 0, 0, 0L,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            sawInputEOS = true
                        } else {
                            val presentationTimeUs = extractor.sampleTime
                            codec.queueInputBuffer(
                                inputBufferIndex, 0, sampleSize, presentationTimeUs, 0
                            )
                            extractor.advance()
                        }
                    }
                }

                val outputBufferIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outputBufferIndex >= 0) {
                    val outputBuffer = codec.getOutputBuffer(outputBufferIndex)
                    if (outputBuffer != null && bufferInfo.size > 0) {
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        val chunk = ByteArray(bufferInfo.size)
                        outputBuffer.get(chunk)
                        pcmOutStream.write(chunk)
                    }
                    codec.releaseOutputBuffer(outputBufferIndex, false)

                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || pcmOutStream.size() >= 75_000_000) {
                        sawOutputEOS = true
                    }
                }
            }
        } finally {
            try {
                codec.stop()
                codec.release()
            } catch (ignored: Exception) {}
        }

        val rawPcm = pcmOutStream.toByteArray()
        require(rawPcm.isNotEmpty()) { "الملف الصوتي فارغ أو تعذر فك تشفيره" }

        // Standard MediaCodec audio output is 16-bit PCM (ENCODING_PCM_16BIT)
        return WavAudioUtil.decodePcm(rawPcm, channelCount, sampleRate, bitsPerSample = 16)
    }
}
