package com.example

import com.example.vocalseparator.audio.FastFourierTransform
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ExampleUnitTest {

    @Test
    fun testMidSideStereoDecomposition() {
        val left = 0.8f
        val right = 0.2f

        val mid = (left + right) * 0.5f
        val side = (left - right) * 0.5f

        // Check inverse identity
        val reconstructedL = mid + side
        val reconstructedR = mid - side

        assertEquals(left, reconstructedL, 1e-5f)
        assertEquals(right, reconstructedR, 1e-5f)
    }

    @Test
    fun testVocalAndInstrumentalEnergyConservation() {
        val vocalMask = 0.72f
        val instrumentalMask = 1.0f - vocalMask

        assertEquals(1.0f, vocalMask + instrumentalMask, 1e-6f)
    }

    @Test
    fun testFftMagnitudeCalculation() {
        val real = 3.0f
        val imag = 4.0f
        val mag = FastFourierTransform.magnitude(real, imag)
        assertEquals(5.0f, mag, 1e-5f)
    }
}
