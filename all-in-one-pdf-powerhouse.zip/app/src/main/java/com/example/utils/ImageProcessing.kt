package com.example.utils

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class DocumentFilterType {
    ORIGINAL,
    MAGIC_COLOR,
    GRAYSCALE,
    BLACK_AND_WHITE
}

object ImageProcessing {

    suspend fun applyFilter(bitmap: Bitmap, filterType: DocumentFilterType): Bitmap = withContext(Dispatchers.Default) {
        when (filterType) {
            DocumentFilterType.ORIGINAL -> bitmap
            DocumentFilterType.GRAYSCALE -> applyGrayscale(bitmap)
            DocumentFilterType.MAGIC_COLOR -> applyMagicColor(bitmap)
            DocumentFilterType.BLACK_AND_WHITE -> applyBlackAndWhite(bitmap)
        }
    }

    private fun applyGrayscale(src: Bitmap): Bitmap {
        val width = src.width
        val height = src.height
        val dest = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dest)
        val paint = Paint()
        val colorMatrix = ColorMatrix().apply { setSaturation(0f) }
        paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return dest
    }

    // Magic Color: Increases contrast, slightly brightens whites to remove page shadows
    private fun applyMagicColor(src: Bitmap): Bitmap {
        val width = src.width
        val height = src.height
        val dest = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dest)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Contrast and brightness matrix
        val contrast = 1.35f
        val brightness = 20f
        val cm = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, brightness,
                0f, contrast, 0f, 0f, brightness,
                0f, 0f, contrast, 0f, brightness,
                0f, 0f, 0f, 1f, 0f
            )
        )
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return dest
    }

    // High contrast black & white document thresholding
    private fun applyBlackAndWhite(src: Bitmap): Bitmap {
        val width = src.width
        val height = src.height
        val gray = applyGrayscale(src)
        val dest = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val pixels = IntArray(width * height)
        gray.getPixels(pixels, 0, width, 0, 0, width, height)

        // Simple adaptive threshold
        var sum = 0L
        for (p in pixels) {
            sum += Color.red(p)
        }
        val avg = (sum / pixels.size).toInt().coerceIn(80, 160)

        for (i in pixels.indices) {
            val r = Color.red(pixels[i])
            pixels[i] = if (r > avg) Color.WHITE else Color.BLACK
        }

        dest.setPixels(pixels, 0, width, 0, 0, width, height)
        gray.recycle()
        return dest
    }

    // Rotate bitmap by degrees
    fun rotateBitmap(src: Bitmap, degrees: Float): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }
}
