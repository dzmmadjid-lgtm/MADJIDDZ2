package com.example.core.diagnostics

import android.content.Context
import android.os.Build
import android.os.Process
import com.example.core.fs.GradleProvisioner
import com.example.core.fs.JdkProvisioner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.Properties

object EnvironmentDiagnostics {

    data class DiagnosticResult(
        val section: String,
        val details: List<String>,
        val isWarning: Boolean = false,
        val isError: Boolean = false
    )

    suspend fun runFullDiagnostic(
        context: Context,
        jdkProvisioner: JdkProvisioner,
        gradleProvisioner: GradleProvisioner,
        onLog: (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val report = StringBuilder()

        fun log(msg: String) {
            report.appendLine(msg)
            onLog(msg)
        }

        log("==================================================")
        log("🔍 DroidIDE / Android Environment Diagnostics")
        log("==================================================")
        log("Started at: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())}\n")

        // ----------------------------------------------------
        // 1. Device & Android OS Information
        // ----------------------------------------------------
        log("▶ [1/6] Device & Operating System:")
        log("  • Manufacturer: ${Build.MANUFACTURER}")
        log("  • Model: ${Build.MODEL} (${Build.DEVICE}, ${Build.PRODUCT})")
        log("  • Android Version: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
        log("  • Build ID: ${Build.ID}")
        log("  • Hardware / Board: ${Build.HARDWARE} / ${Build.BOARD}")
        log("  • Supported ABIs: ${Build.SUPPORTED_ABIS.joinToString(", ")}")
        log("  • Process Architecture: os.arch = ${System.getProperty("os.arch")}")
        log("  • Process 64-bit: ${Process.is64Bit()}")

        // Memory stats
        val maxHeap = Runtime.getRuntime().maxMemory() / (1024 * 1024)
        val totalHeap = Runtime.getRuntime().totalMemory() / (1024 * 1024)
        val freeHeap = Runtime.getRuntime().freeMemory() / (1024 * 1024)
        log("  • App Heap: Max ${maxHeap}MB | Allocated ${totalHeap}MB | Free ${freeHeap}MB")

        // Linux Kernel version
        try {
            val kernelVer = File("/proc/version").readText().trim()
            log("  • Kernel: $kernelVer")
        } catch (_: Exception) {
            log("  • Kernel: Could not read /proc/version")
        }

        // CPU Features / Pointer Tagging from /proc/cpuinfo
        try {
            val cpuInfo = File("/proc/cpuinfo").readLines()
            val featuresLine = cpuInfo.firstOrNull { it.startsWith("Features") || it.startsWith("flags") }
            if (featuresLine != null) {
                val features = featuresLine.substringAfter(":").trim()
                val hasMte = features.contains("mte", ignoreCase = true)
                val hasAsimd = features.contains("asimd", ignoreCase = true)
                log("  • CPU Features: asimd=$hasAsimd, mte (Memory Tagging)=$hasMte")
            }
        } catch (_: Exception) {}

        log("")

        // ----------------------------------------------------
        // 2. Storage & Dynamic Linkers
        // ----------------------------------------------------
        log("▶ [2/6] App Storage & Dynamic Linkers:")
        val filesDir = context.filesDir
        log("  • App filesDir: ${filesDir.absolutePath} (canRead=${filesDir.canRead()}, canWrite=${filesDir.canWrite()}, canExec=${filesDir.canExecute()})")
        val nativeLibDir = context.applicationInfo.nativeLibraryDir
        log("  • Native Libs Dir: $nativeLibDir")

        val linkerCandidates = listOf(
            File("/system/bin/linker64"),
            File("/apex/com.android.runtime/bin/linker64"),
            File("/system/bin/linker"),
            File("/apex/com.android.runtime/bin/linker")
        )
        for (l in linkerCandidates) {
            if (l.exists()) {
                log("  • Linker found: ${l.absolutePath} (size=${l.length()} bytes, canExec=${l.canExecute()})")
            }
        }
        val shFile = File("/system/bin/sh")
        log("  • Shell /system/bin/sh: exists=${shFile.exists()}, canExec=${shFile.canExecute()}")
        log("")

        // ----------------------------------------------------
        // 3. Custom JDK File Verification
        // ----------------------------------------------------
        log("▶ [3/6] Custom JDK Verification:")
        val jdkHome = jdkProvisioner.internalJdkDir
        val javaBin = jdkProvisioner.javaExecutable
        val javacBin = File(jdkHome, "bin/javac")
        val libJvm = File(jdkHome, "lib/server/libjvm.so")
        val libJli = File(jdkHome, "lib/jli/libjli.so")
        val releaseFile = File(jdkHome, "release")

        log("  • JDK Home: ${jdkHome.absolutePath} (exists=${jdkHome.exists()})")
        if (!jdkHome.exists()) {
            log("  ❌ JDK is not installed in app private directory!")
        } else {
            val totalJdkFiles = jdkHome.walkTopDown().count()
            log("  • Total JDK files count: $totalJdkFiles")
            log("  • bin/java: exists=${javaBin.exists()}, size=${if (javaBin.exists()) "${javaBin.length()} bytes" else "N/A"}, canExec=${javaBin.canExecute()}")
            log("  • bin/javac: exists=${javacBin.exists()}, canExec=${javacBin.canExecute()}")
            log("  • lib/server/libjvm.so: exists=${libJvm.exists()}, size=${if (libJvm.exists()) "${libJvm.length()} bytes" else "N/A"}")
            log("  • lib/jli/libjli.so: exists=${libJli.exists()}, size=${if (libJli.exists()) "${libJli.length()} bytes" else "N/A"}")

            if (releaseFile.exists()) {
                try {
                    val props = Properties()
                    releaseFile.inputStream().use { props.load(it) }
                    log("  • release info:")
                    log("      JAVA_VERSION = ${props.getProperty("JAVA_VERSION", "unknown")}")
                    log("      OS_NAME = ${props.getProperty("OS_NAME", "unknown")}")
                    log("      OS_ARCH = ${props.getProperty("OS_ARCH", "unknown")}")
                    log("      LIBC = ${props.getProperty("LIBC", "standard/bionic")}")
                } catch (e: Exception) {
                    log("  • Could not parse release file: ${e.message}")
                }
            }
        }
        log("")

        // ----------------------------------------------------
        // 4. Java Execution Tests
        // ----------------------------------------------------
        log("▶ [4/6] Java Execution Tests:")
        if (!javaBin.exists()) {
            log("  ⚠️ Skipping execution tests because bin/java was not found.")
        } else {
            // Test 4.1: Direct execution
            val t1Start = System.currentTimeMillis()
            val directTest = runCommand(listOf(javaBin.absolutePath, "-version"), jdkHome)
            val t1Duration = System.currentTimeMillis() - t1Start
            log("  [Test 4.1] Direct 'java -version' (${t1Duration}ms):")
            log("    • Exit Code: ${directTest.exitCode}")
            if (directTest.output.isNotBlank()) {
                directTest.output.lines().forEach { log("    | $it") }
            }

            // Test 4.2: Execution with Linker (if linker exists)
            val linker = jdkProvisioner.systemLinker
            if (linker != null) {
                val t2Start = System.currentTimeMillis()
                val linkerTest = runCommand(listOf(linker.absolutePath, javaBin.absolutePath, "-version"), jdkHome)
                val t2Duration = System.currentTimeMillis() - t2Start
                log("  [Test 4.2] Linker '${linker.name} java -version' (${t2Duration}ms):")
                log("    • Exit Code: ${linkerTest.exitCode}")
                if (linkerTest.output.isNotBlank()) {
                    linkerTest.output.lines().forEach { log("    | $it") }
                }
            }

            // Test 4.3: With CompressedOops disabled vs enabled
            log("  [Test 4.3] JVM Pointer flags comparison:")
            val safeFlagsResult = runCommand(
                listOf(
                    javaBin.absolutePath,
                    "-Xmx256m",
                    "-XX:+UseSerialGC",
                    "-XX:-UseCompressedOops",
                    "-XX:-UseCompressedClassPointers",
                    "-version"
                ),
                jdkHome
            )
            log("    • With -XX:-UseCompressedOops -XX:-UseCompressedClassPointers -> Exit: ${safeFlagsResult.exitCode}")
            if (safeFlagsResult.output.isNotBlank()) {
                safeFlagsResult.output.lines().take(3).forEach { log("      | $it") }
            }

            val defaultFlagsResult = runCommand(
                listOf(javaBin.absolutePath, "-Xmx256m", "-version"),
                jdkHome
            )
            log("    • Without pointer flags -> Exit: ${defaultFlagsResult.exitCode}")
            if (defaultFlagsResult.output.isNotBlank()) {
                defaultFlagsResult.output.lines().take(3).forEach { log("      | $it") }
            }

            // Test 4.4: Show JVM settings
            val settingsResult = runCommand(
                listOf(
                    javaBin.absolutePath,
                    "-Xmx256m",
                    "-XX:-UseCompressedOops",
                    "-XX:-UseCompressedClassPointers",
                    "-XshowSettings:properties",
                    "-version"
                ),
                jdkHome
            )
            val javaArch = settingsResult.output.lines().firstOrNull { it.contains("sun.arch.data.model") || it.contains("os.arch") }
            if (javaArch != null) {
                log("  [Test 4.4] JVM Properties: ${javaArch.trim()}")
            }
        }
        log("")

        // ----------------------------------------------------
        // 5. Gradle Distribution & Launcher Test
        // ----------------------------------------------------
        log("▶ [5/6] Gradle Distribution & Launcher Engine:")
        val gradleStatus = gradleProvisioner.checkGradleStatus()
        log("  • Gradle Status: isInstalled=${gradleStatus.isInstalled}")
        log("  • Distribution Path: ${gradleStatus.distributionPath}")
        log("  • Launcher JAR: ${gradleStatus.launcherJarPath}")

        val launcherJar = gradleStatus.launcherJarPath?.let { File(it) }
        if (javaBin.exists() && launcherJar != null && launcherJar.exists()) {
            val tGradleStart = System.currentTimeMillis()
            val gradleTest = runCommand(
                listOf(
                    javaBin.absolutePath,
                    "-Xmx512m",
                    "-XX:+UseSerialGC",
                    "-XX:-UseCompressedOops",
                    "-XX:-UseCompressedClassPointers",
                    "-Dfile.encoding=UTF-8",
                    "-classpath", launcherJar.absolutePath,
                    "org.gradle.launcher.GradleMain",
                    "--version",
                    "--no-daemon",
                    "--console=plain"
                ),
                jdkHome
            )
            val tGradleDuration = System.currentTimeMillis() - tGradleStart
            log("  [Test 5.1] 'org.gradle.launcher.GradleMain --version' (${tGradleDuration}ms):")
            log("    • Exit Code: ${gradleTest.exitCode}")
            if (gradleTest.output.isNotBlank()) {
                gradleTest.output.lines().forEach { log("    | $it") }
            }
        } else {
            log("  ⚠️ Cannot run Gradle test (java or gradle-launcher-*.jar is missing)")
        }
        log("")

        // ----------------------------------------------------
        // 6. Diagnostics Analysis & Recommendations
        // ----------------------------------------------------
        log("▶ [6/6] Diagnosis Summary & Recommendations:")
        val hasTruncatedPointer = report.contains("Pointer tag for", ignoreCase = true)
        val hasExit134 = report.contains("exit code: 134", ignoreCase = true) || report.contains("Exit Code: 134")
        val hasExit13 = report.contains("error=13", ignoreCase = true) || report.contains("Permission denied", ignoreCase = true)

        if (hasExit134 || hasTruncatedPointer) {
            log("  ⚠️ Detected Android Scudo / ARM Tagged Pointer Issue (Exit 134 / SIGABRT):")
            log("     Exit code 134 corresponds to SIGABRT (128 + 6).")
            log("     On Android 11+ (especially Android 12-16) on ARM64 processors,")
            log("     Android's bionic allocator (Scudo) enforces top-byte pointer tagging.")
            log("     Standard desktop Linux OpenJDK HotSpot binaries often assume all 64 bits")
            log("     in object pointers are available for address arithmetic or compressed OOPs,")
            log("     which triggers SIGABRT when Scudo validates pointer tags.")
            log("")
            log("  💡 Recommended Solutions:")
            log("     1. Install an Android-native OpenJDK build compiled against Bionic libc")
            log("        (such as OpenJDK 17/21 for Termux aarch64, which contains Android Bionic patches).")
            log("     2. Ensure '-XX:-UseCompressedOops -XX:-UseCompressedClassPointers' is present.")
            log("     3. You can download or import an Android Bionic JDK package directly via the JDK button.")
        } else if (hasExit13) {
            log("  ⚠️ Detected Android Executable Permission Restriction (error=13):")
            log("     Binaries must reside in internal storage (/data/user/0/.../files) with chmod 755.")
        } else {
            log("  ✅ No critical initialization errors detected.")
        }

        log("==================================================")
        log("Diagnostics completed.")
        log("==================================================")

        report.toString()
    }

    private data class CommandResult(val exitCode: Int, val output: String)

    private fun runCommand(command: List<String>, jdkHome: File): CommandResult {
        return try {
            val pb = ProcessBuilder(command)
            val env = pb.environment()
            env["JAVA_HOME"] = jdkHome.absolutePath
            val binPath = File(jdkHome, "bin").absolutePath
            val libPath = File(jdkHome, "lib").absolutePath
            val jliPath = File(jdkHome, "lib/jli").absolutePath
            val serverPath = File(jdkHome, "lib/server").absolutePath
            val existingPath = env["PATH"] ?: ""
            env["PATH"] = "$binPath:$existingPath"
            val existingLd = env["LD_LIBRARY_PATH"] ?: ""
            env["LD_LIBRARY_PATH"] = "$libPath:$jliPath:$serverPath:$existingLd"
            env["SCUDO_OPTIONS"] = "Tagging=0:ZeroContents=0:DeallocTypeMismatch=0:DeleteSizeMismatch=0"
            env["BIONIC_TAGGED_POINTERS"] = "0"
            env["ANDROID_TAGGED_POINTERS"] = "0"
            env["MALLOC_TAGGING_LEVEL"] = "0"
            env["MALLOC_CHECK_"] = "0"

            val process = pb.start()
            val out = StringBuilder()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errReader = BufferedReader(InputStreamReader(process.errorStream))

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                out.appendLine(line)
            }
            while (errReader.readLine().also { line = it } != null) {
                out.appendLine(line)
            }

            val exit = process.waitFor()
            CommandResult(exit, out.toString().trim())
        } catch (e: Exception) {
            CommandResult(-1, "Execution failed: ${e.message}")
        }
    }
}
