package com.example.utils

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

object PrintHelper {

    // Ordinary Printing (Yellow) — Uses Android Print Framework
    fun printOrdinary(
        activity: Activity,
        uri: Uri,
        documentName: String = "Click_School_Document"
    ) {
        val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("$documentName.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                var input: InputStream? = null
                var output: OutputStream? = null
                try {
                    input = activity.contentResolver.openInputStream(uri)
                    output = FileOutputStream(destination?.fileDescriptor)

                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    while (input?.read(buffer).also { bytesRead = it ?: -1 } != -1) {
                        if (cancellationSignal?.isCanceled == true) {
                            callback?.onWriteCancelled()
                            return
                        }
                        output.write(buffer, 0, bytesRead)
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    try { input?.close() } catch (_: Exception) {}
                    try { output?.close() } catch (_: Exception) {}
                }
            }
        }

        printManager.print(
            documentName,
            printAdapter,
            PrintAttributes.Builder().build()
        )
    }

    // Direct Printing (Red) — Sends RAW PDF data directly to network printer socket (default port 9100)
    suspend fun printDirect(
        context: Context,
        uri: Uri,
        printerIp: String,
        port: Int = 9100,
        onProgress: (Float) -> Unit = {}
    ): Result<String> = withContext(Dispatchers.IO) {
        var socket: Socket? = null
        var inputStream: InputStream? = null
        var outputStream: OutputStream? = null

        try {
            socket = Socket()
            // 5 second connect timeout
            socket.connect(InetSocketAddress(printerIp, port), 5000)
            socket.soTimeout = 10000

            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                ?: return@withContext Result.failure(Exception("Cannot open document for reading"))
            val totalBytes = pfd.statSize
            pfd.close()

            inputStream = context.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(Exception("Cannot open input stream"))
            outputStream = socket.getOutputStream()

            val buffer = ByteArray(8192)
            var bytesRead: Int
            var totalSent = 0L

            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                outputStream.write(buffer, 0, bytesRead)
                totalSent += bytesRead
                if (totalBytes > 0) {
                    onProgress((totalSent.toFloat() / totalBytes).coerceIn(0f, 1f))
                }
            }
            outputStream.flush()

            Result.success("تم إرسال المستند بنجاح إلى الطابعة $printerIp:$port ($totalSent بايت)")
        } catch (e: Exception) {
            Result.failure(Exception("فشل الاتصال المباشر بالطابعة ($printerIp:$port): ${e.localizedMessage ?: "مهلة الاتصال انتهت"}"))
        } finally {
            try { inputStream?.close() } catch (_: Exception) {}
            try { outputStream?.close() } catch (_: Exception) {}
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    // Test socket connection to printer IP
    suspend fun testConnection(ip: String, port: Int = 9100): Boolean = withContext(Dispatchers.IO) {
        try {
            val socket = Socket()
            socket.connect(InetSocketAddress(ip, port), 2500)
            socket.close()
            true
        } catch (e: Exception) {
            false
        }
    }
}
