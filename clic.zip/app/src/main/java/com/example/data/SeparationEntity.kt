package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "separations")
data class SeparationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Float,
    val inferenceTimeMs: Long,
    val modelName: String,
    val vocalsPath: String,
    val instrumentalPath: String,
    val originalPath: String = ""
)
